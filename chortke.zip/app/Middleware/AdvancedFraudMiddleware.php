<?php

namespace App\Middleware;

use App\Services\AntiFraud\BrowserFingerprintService;
use App\Services\AntiFraud\IPQualityService;
use App\Services\AntiFraud\SessionAnomalyService;
use App\Services\AntiFraud\AccountTakeoverService;
use Core\Request;
use Core\Response;

class AdvancedFraudMiddleware
{
    private BrowserFingerprintService $fingerprintService;
    private IPQualityService $ipQualityService;
    private SessionAnomalyService $sessionAnomalyService;
    private AccountTakeoverService $accountTakeoverService;
    
    public function __construct()
    {
        $this->fingerprintService = new BrowserFingerprintService();
        $this->ipQualityService = new IPQualityService();
        $this->sessionAnomalyService = new SessionAnomalyService();
        $this->accountTakeoverService = new AccountTakeoverService();
    }
    
    /**
     * بررسی پیشرفته تقلب
     */
    public function handle(Request $request, \Closure $next)
    {
        if (!auth()) {
            return $next($request);
        }
        
        $userId = user_id();
        $ip = get_client_ip();
        $userAgent = get_user_agent();
        
        // 1. بررسی IP Quality
        $ipCheck = $this->ipQualityService->check($ip);
        
        if ($ipCheck['score'] >= 80) {
            log_activity($userId, 'high_risk_ip', 'IP با ریسک بالا: ' . implode(', ', $ipCheck['reasons']));
            
            // اگر خیلی مشکوک بود
            session()->setFlash('warning', 'فعالیت شما از IP مشکوک شناسایی شد. در صورت تکرار، حساب شما بررسی خواهد شد.');
        }
        
        // 2. بررسی Session Anomaly
        $sessionId = session()->get('session_id');
        $sessionCheck = $this->sessionAnomalyService->analyze($userId, $sessionId);
        
        if ($sessionCheck['is_anomaly']) {
            log_activity($userId, 'session_anomaly', implode(', ', $sessionCheck['anomalies']));
            
            // افزایش Fraud Score
            $currentScore = db()->fetch("SELECT fraud_score FROM users WHERE id = ?", [$userId]);
            $newScore = ($currentScore->fraud_score ?? 0) + ($sessionCheck['score'] / 2);
            
            db()->query("UPDATE users SET fraud_score = ? WHERE id = ?", [$newScore, $userId]);
        }
        
        // 3. بررسی Account Takeover
        $takeoverCheck = $this->accountTakeoverService->detect($userId, $ip, $userAgent);
        
        if ($takeoverCheck['is_takeover']) {
            log_activity($userId, 'account_takeover_detected', implode(', ', $takeoverCheck['signals']));
            
            // اقدام بر اساس ریسک
            switch ($takeoverCheck['action']) {
                case 'block':
                    // مسدود کردن موقت
                    db()->query("UPDATE users SET active_status = 'suspended' WHERE id = ?", [$userId]);
                    
                    // نوتیفیکیشن
                    notify($userId, 'danger', 'به دلیل فعالیت مشکوک، حساب شما موقتاً مسدود شد. لطفاً با پشتیبانی تماس بگیرید.');
                    notify_admin("حساب کاربر #{$userId} به دلیل Account Takeover مسدود شد");
                    
                    // خروج
                    session()->destroy();
                    return redirect('/login');
                
                case 'challenge':
                    // نیاز به تأیید دو مرحله‌ای
                    if (!session()->get('2fa_verified')) {
                        session()->setFlash('warning', 'به دلیل فعالیت مشکوک، نیاز به تأیید هویت دارید.');
                        return redirect('/verify-2fa');
                    }
                    break;
                
                case 'notify':
                    // فقط اطلاع‌رسانی
                    notify($userId, 'warning', 'فعالیت مشکوکی از حساب شما شناسایی شد. اگر شما نیستید، فوراً رمز خود را تغییر دهید.');
                    break;
            }
        }
        
        return $next($request);
    }
}