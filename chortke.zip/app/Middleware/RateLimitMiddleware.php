<?php
namespace App\Middleware;

use Core\Request;
use Core\Response;
use Core\RateLimiter;

/**
 * Rate Limit Middleware
 * 
 * محدودسازی تعداد درخواست‌ها
 */
class RateLimitMiddleware
{
    private $rateLimiter;
    private $maxAttempts;
    private $decayMinutes;
    
    public function __construct($maxAttempts = 60, $decayMinutes = 1)
    {
        $this->rateLimiter = new RateLimiter();
        $this->maxAttempts = $maxAttempts;
        $this->decayMinutes = $decayMinutes;
    }
    
    public function handle(Request $request, Response $response)
    {
        $key = $this->resolveRequestSignature($request);
        
        if (!$this->rateLimiter->attempt($key, $this->maxAttempts, $this->decayMinutes)) {
            $retryAfter = $this->rateLimiter->availableIn($key);
            
            logger('security', 'Rate limit exceeded', [
                'ip' => get_client_ip(),
                'uri' => $request->uri(),
                'key' => $key
            ]);
            
            if (is_ajax()) {
                return $response->json([
                    'success' => false,
                    'message' => 'تعداد درخواست‌های شما بیش از حد مجاز است.',
                    'retry_after' => $retryAfter
                ], 429);
            }
            
            http_response_code(429);
            echo '<h1>429 Too Many Requests</h1>';
            echo '<p>لطفاً ' . ceil($retryAfter / 60) . ' دقیقه دیگر تلاش کنید.</p>';
            exit;
        }
        
        return true;
    }
    
    /**
     * ایجاد کلید منحصر به فرد برای درخواست
     */
    private function resolveRequestSignature(Request $request)
    {
        $userId = app()->session->get('user_id');
        
        if ($userId) {
            return 'rate_limit_user_' . $userId;
        }
        
        return 'rate_limit_ip_' . sha1(get_client_ip());
    }
}