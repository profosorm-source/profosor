<?php

namespace App\Middleware;

use App\Services\CaptchaService;
use Core\Request;
use Core\Response;

class CaptchaMiddleware
{
    private CaptchaService $captchaService;
    
    public function __construct()
    {
        $this->captchaService = new CaptchaService();
    }
    
    /**
     * بررسی CAPTCHA
     */
    public function handle(Request $request, \Closure $next)
    {
        if (!$this->captchaService->isEnabled()) {
            return $next($request);
        }
        
        // فقط برای POST
        if ($request->method() !== 'POST') {
            return $next($request);
        }
        
        // بررسی CAPTCHA
        if (!verify_captcha()) {
            $response = new Response();
            
            if ($request->isAjax()) {
                return $response->json([
                    'success' => false,
                    'message' => 'کد امنیتی اشتباه است. لطفاً دوباره تلاش کنید.'
                ]);
            }
            
            session()->setFlash('error', 'کد امنیتی اشتباه است.');
            session()->setFlash('old', $request->all());
            
            return redirect($_SERVER['HTTP_REFERER'] ?? '/');
        }
        
        return $next($request);
    }
}