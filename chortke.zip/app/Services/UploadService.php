<?php

namespace App\Services;

/**
 * UploadService - آپلود امن فایل
 *
 * لایه‌های امنیتی:
 *   1. بررسی خطای PHP
 *   2. بررسی حجم
 *   3. بررسی magic bytes (امضای باینری فایل)
 *   4. بررسی MIME از finfo
 *   5. جلوگیری از double-extension attack (file.php.jpg)
 *   6. نام‌گذاری تصادفی
 *   7. لاگ آپلود
 */
class UploadService
{
    private string $storageRoot;
    private string $publicRoot;

    /**
     * Magic bytes معروف برای هر نوع فایل
     * key: mime type, value: آرایه‌ای از signatures به صورت hex prefix
     */
    private const MAGIC_BYTES = [
        'image/jpeg' => ["\xFF\xD8\xFF"],
        'image/png'  => ["\x89PNG\r\n\x1A\n"],
        'image/gif'  => ["GIF87a", "GIF89a"],
        'image/webp' => ["RIFF"],   // RIFF????WEBP - بررسی اضافه می‌شود
        'application/pdf' => ["%PDF-"],
        'video/mp4'  => ["\x00\x00\x00\x18ftyp", "\x00\x00\x00\x20ftyp", "\x00\x00\x00\x14ftyp"],
    ];

    /**
     * پسوندهایی که هرگز مجاز نیستند (حتی اگر MIME درست باشد)
     */
    private const DANGEROUS_EXTENSIONS = [
        'php', 'php3', 'php4', 'php5', 'php7', 'phtml', 'phar',
        'asp', 'aspx', 'jsp', 'jspx',
        'exe', 'sh', 'bat', 'cmd', 'ps1',
        'py', 'rb', 'pl', 'cgi',
        'htaccess', 'htpasswd',
        'svg', // می‌تواند حاوی JS باشد
    ];

    /** نگاشت mime → پسوند مجاز */
    private const MIME_EXTENSIONS = [
        'image/jpeg'      => 'jpg',
        'image/png'       => 'png',
        'image/gif'       => 'gif',
        'image/webp'      => 'webp',
        'application/pdf' => 'pdf',
        'video/mp4'       => 'mp4',
    ];

    public function __construct()
    {
        $root              = realpath(__DIR__ . '/../../') ?: (__DIR__ . '/../../');
        $this->storageRoot = rtrim($root, '/\\') . '/storage/uploads/';
        $this->publicRoot  = rtrim($root, '/\\') . '/public/uploads/';
    }

    /**
     * آپلود امن فایل
     *
     * @param array  $file         $_FILES['field']
     * @param string $folder       پوشه مقصد
     * @param array  $allowedMimes لیست mime type های مجاز
     * @param int    $maxBytes     حداکثر حجم به بایت
     * @param bool   $isPublic     آیا فایل باید از public قابل دسترس باشد؟
     *
     * @return array ['success'=>bool, 'filename'=>'', 'path'=>'', 'url'=>null, 'message'=>'']
     */
    public function upload(
        array  $file,
        string $folder,
        array  $allowedMimes,
        int    $maxBytes,
        bool   $isPublic = false
    ): array {
        // ─── ۱. اعتبارسنجی اولیه ───────────────────────────────
        $folder = $this->sanitizeFolder($folder);
        if ($folder === null) {
            return $this->fail('نام پوشه نامعتبر است');
        }

        $uploadError = $file['error'] ?? UPLOAD_ERR_NO_FILE;
        if ($uploadError !== UPLOAD_ERR_OK) {
            return $this->fail($this->uploadErrorMessage($uploadError));
        }

        $tmp = $file['tmp_name'] ?? '';
        if (empty($tmp) || !is_uploaded_file($tmp)) {
            return $this->fail('فایل موقت نامعتبر است');
        }

        // ─── ۲. حجم ────────────────────────────────────────────
        $size = (int)($file['size'] ?? 0);
        if ($size <= 0) {
            return $this->fail('فایل خالی است');
        }
        if ($size > $maxBytes) {
            $maxMb = round($maxBytes / 1048576, 1);
            return $this->fail("حجم فایل بیشتر از حد مجاز ({$maxMb}MB) است");
        }

        // ─── ۳. بررسی پسوند اصلی (double-extension attack) ────
        $originalName = $file['name'] ?? 'file';
        if (!$this->isSafeFilename($originalName)) {
            return $this->fail('نام فایل حاوی پسوند خطرناک است');
        }

        // ─── ۴. MIME از finfo (واقعی) ──────────────────────────
        $finfo    = finfo_open(FILEINFO_MIME_TYPE);
        $realMime = finfo_file($finfo, $tmp);
        finfo_close($finfo);

        if (!in_array($realMime, $allowedMimes, true)) {
            return $this->fail("نوع فایل مجاز نیست (شناسایی‌شده: {$realMime})");
        }

        // ─── ۵. Magic bytes ──────────────────────────────────────
        if (!$this->validateMagicBytes($tmp, $realMime)) {
            return $this->fail('امضای فایل با نوع اعلام‌شده مطابقت ندارد');
        }

        // ─── ۶. WebP اضافی (RIFF????WEBP) ───────────────────────
        if ($realMime === 'image/webp' && !$this->isValidWebp($tmp)) {
            return $this->fail('فایل WebP نامعتبر است');
        }

        // ─── ۷. پسوند امن بر اساس mime واقعی ───────────────────
        $ext  = self::MIME_EXTENSIONS[$realMime] ?? 'bin';
        $dest = $this->buildDestination($folder, $ext, $isPublic);

        // ─── ۸. انتقال فایل ─────────────────────────────────────
        if (!is_dir($dest['dir'])) {
            mkdir($dest['dir'], 0755, true);
        }

        if (!move_uploaded_file($tmp, $dest['fullPath'])) {
            return $this->fail('خطا در ذخیره فایل روی سرور');
        }

        // ─── ۹. لاگ ─────────────────────────────────────────────
        $this->logUpload($folder, $dest['filename'], $size, $realMime);

        return [
            'success'  => true,
            'filename' => $dest['filename'],
            'path'     => $dest['relativePath'],
            'url'      => $dest['url'],
            'size'     => $size,
            'mime'     => $realMime,
            'message'  => '',
        ];
    }

    /**
     * حذف فایل
     */
    public function delete(string $relativePath): bool
    {
        $paths = [
            $this->storageRoot . $relativePath,
            $this->publicRoot  . $relativePath,
        ];
        $deleted = false;
        foreach ($paths as $p) {
            if (file_exists($p)) {
                unlink($p);
                $deleted = true;
                // حذف نسخه blur اگر وجود داشت
                $blur = preg_replace('/(\.\w+)$/', '_blur$1', $p);
                if ($blur && file_exists($blur)) {
                    unlink($blur);
                }
            }
        }
        return $deleted;
    }

    /**
     * دریافت مسیر کامل فایل
     */
    public function getPath(string $relativePath): string
    {
        $relativePath = ltrim(str_replace('\\', '/', $relativePath), '/');
        $folder       = explode('/', $relativePath, 2)[0] ?? '';

        $publicFolders = ['avatars', 'banners', 'public', 'ad-tasks'];
        if (in_array($folder, $publicFolders, true)) {
            return $this->publicRoot . $relativePath;
        }
        return $this->storageRoot . $relativePath;
    }

    /**
     * بررسی وجود فایل
     */
    public function exists(string $relativePath): bool
    {
        return file_exists($this->getPath($relativePath));
    }

    // ─────────────────────────────────────────────────────────
    //  private helpers
    // ─────────────────────────────────────────────────────────

    private function sanitizeFolder(string $folder): ?string
    {
        $folder = trim($folder, "/\\ \t\n\r\0\x0B");
        // فقط حروف، اعداد، خط تیره و underscore
        if (!preg_match('/^[a-zA-Z0-9_\-]+$/', $folder)) {
            return null;
        }
        return $folder;
    }

    /** بررسی double-extension attack: file.php.jpg */
    private function isSafeFilename(string $name): bool
    {
        // تمام قسمت‌های نام را بررسی کن
        $parts = explode('.', strtolower($name));
        array_shift($parts); // اولین قسمت (نام بدون پسوند)
        foreach ($parts as $part) {
            if (in_array($part, self::DANGEROUS_EXTENSIONS, true)) {
                return false;
            }
        }
        return true;
    }

    /** بررسی magic bytes */
    private function validateMagicBytes(string $tmpPath, string $mime): bool
    {
        $signatures = self::MAGIC_BYTES[$mime] ?? null;
        if ($signatures === null) {
            return true; // اگر signature تعریف نشده، skip
        }

        $fp      = fopen($tmpPath, 'rb');
        $header  = fread($fp, 16);
        fclose($fp);

        foreach ($signatures as $sig) {
            if (str_starts_with($header, $sig)) {
                return true;
            }
        }
        return false;
    }

    /** بررسی اضافه برای WebP */
    private function isValidWebp(string $tmpPath): bool
    {
        $fp     = fopen($tmpPath, 'rb');
        $header = fread($fp, 12);
        fclose($fp);
        // RIFF????WEBP
        return strlen($header) >= 12
            && str_starts_with($header, 'RIFF')
            && substr($header, 8, 4) === 'WEBP';
    }

    /** ساخت مسیر مقصد */
    private function buildDestination(string $folder, string $ext, bool $isPublic): array
    {
        $publicFolders = ['avatars', 'banners', 'public', 'ad-tasks'];
        $usePublic     = $isPublic || in_array($folder, $publicFolders, true);

        $baseDir      = $usePublic ? $this->publicRoot : $this->storageRoot;
        $dir          = $baseDir . $folder . '/';
        $filename     = bin2hex(random_bytes(12)) . '.' . $ext;
        $fullPath     = $dir . $filename;
        $relativePath = $folder . '/' . $filename;
        $url          = $usePublic ? ('uploads/' . $relativePath) : null;

        return compact('dir', 'filename', 'fullPath', 'relativePath', 'url');
    }

    private function uploadErrorMessage(int $code): string
    {
        return match($code) {
            UPLOAD_ERR_INI_SIZE, UPLOAD_ERR_FORM_SIZE => 'حجم فایل بیش از حد مجاز است',
            UPLOAD_ERR_PARTIAL    => 'فایل ناقص آپلود شد',
            UPLOAD_ERR_NO_FILE    => 'فایلی انتخاب نشده',
            UPLOAD_ERR_NO_TMP_DIR => 'پوشه موقت سرور یافت نشد',
            UPLOAD_ERR_CANT_WRITE => 'خطا در نوشتن روی دیسک',
            UPLOAD_ERR_EXTENSION  => 'آپلود توسط PHP Extension مسدود شد',
            default               => 'خطای ناشناخته در آپلود',
        };
    }

    private function fail(string $message): array
    {
        return ['success' => false, 'filename' => '', 'path' => '', 'url' => null, 'message' => $message];
    }

    private function logUpload(string $folder, string $filename, int $size, string $mime): void
    {
        try {
            $userId = function_exists('user_id') ? user_id() : null;
            \Core\Database::getInstance()->query(
                "INSERT IGNORE INTO file_logs (folder, filename, user_id, mime_type, size_bytes, ip_address, created_at)
                 VALUES (?, ?, ?, ?, ?, ?, NOW())",
                [$folder, $filename, $userId, $mime, $size, $_SERVER['REMOTE_ADDR'] ?? '']
            );
        } catch (\Throwable $e) {
            // log table ممکنه نباشه - silent fail
        }
    }
}
