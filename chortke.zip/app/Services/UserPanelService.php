<?php

namespace App\Services;

use Core\Database;

class UserPanelService
{
    public function build(int $userId): array
    {
        $db = Database::getInstance();

        // 1) User
        $user = $db->fetch("SELECT * FROM users WHERE id = :id AND deleted_at IS NULL", ['id' => $userId]);
        $user = $user ? (is_array($user) ? (object)$user : $user) : null;

        // 2) Wallet
        $wallet = $db->fetch("SELECT * FROM wallets WHERE user_id = :uid", ['uid' => $userId]);
        $wallet = $wallet ? (is_array($wallet) ? (object)$wallet : $wallet) : (object)['balance_irt'=>0,'balance_usdt'=>0];

        // 3) KYC
        $kyc = $db->fetch("SELECT status FROM kyc_verifications WHERE user_id = :uid ORDER BY id DESC LIMIT 1", ['uid' => $userId]);
        $kyc = $kyc ? (is_array($kyc) ? (object)$kyc : $kyc) : (object)['status' => 'pending'];

        // 4) badges
        $notifUnread = (int)$db->fetchColumn("SELECT COUNT(*) FROM notifications WHERE user_id = :uid AND is_read = 0", ['uid' => $userId]);
        $ticketsOpen = (int)$db->fetchColumn("SELECT COUNT(*) FROM tickets WHERE user_id = :uid AND status IN ('open','in_progress') AND deleted_at IS NULL", ['uid' => $userId]);

        // 5) آمار پرداختی (نمونه‌های ضروری)
        $today = date('Y-m-d');
        $todayDeposit = (float)$db->fetchColumn(
            "SELECT COALESCE(SUM(amount),0) FROM transactions 
             WHERE user_id = :uid AND type = 'deposit' AND status = 'completed' AND DATE(created_at) = :d",
            ['uid'=>$userId,'d'=>$today]
        );
        $todayWithdraw = (float)$db->fetchColumn(
            "SELECT COALESCE(SUM(amount),0) FROM transactions 
             WHERE user_id = :uid AND type = 'withdraw' AND status = 'completed' AND DATE(created_at) = :d",
            ['uid'=>$userId,'d'=>$today]
        );
        $pendingTx = (int)$db->fetchColumn(
            "SELECT COUNT(*) FROM transactions WHERE user_id = :uid AND status IN ('pending','processing')",
            ['uid'=>$userId]
        );

        return [
            'user' => $user,
            'tier' => $user->tier_level ?? 'silver',
            'wallet' => [
                'balance_irt' => (float)($wallet->balance_irt ?? 0),
                'balance_usdt' => (float)($wallet->balance_usdt ?? 0),
            ],
            'kyc' => ['status' => $kyc->status ?? 'pending'],
            'badges' => [
                'notif_unread' => $notifUnread,
                'tickets_open' => $ticketsOpen,
            ],
            'payment_stats' => [
                'today_deposit' => $todayDeposit,
                'today_withdraw' => $todayWithdraw,
                'pending_transactions' => $pendingTx,
            ],
        ];
    }
}