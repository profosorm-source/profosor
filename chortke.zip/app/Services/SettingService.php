<?php

namespace App\Services;

use App\Models\Setting;

class SettingService
{
    private Setting $model;
    private string $cacheFile;

    public function __construct()
    {
        $this->model = new Setting();
        $this->cacheFile = __DIR__ . '/../../storage/cache/system_settings.php';
    }

    public function load(): array
    {
        // cache file
        if (\file_exists($this->cacheFile)) {
            $data = include $this->cacheFile;
            if (\is_array($data)) return $data;
        }

        $settings = $this->model->all();

        if (!\is_dir(\dirname($this->cacheFile))) {
            \mkdir(\dirname($this->cacheFile), 0755, true);
        }

        $export = "<?php\nreturn " . \var_export($settings, true) . ";\n";
        \file_put_contents($this->cacheFile, $export);

        return $settings;
    }

    public function clearCache(): void
    {
        if (\file_exists($this->cacheFile)) {
            \unlink($this->cacheFile);
        }
    }

    public function get(string $key, mixed $default = null): mixed
    {
        $all = $this->load();
        return $all[$key] ?? $default;
    }
	
	public function updateById(int $id, string $key, string $value): bool
{
    $row = db()->query(
        "SELECT `key` FROM system_settings WHERE id = ? LIMIT 1",
        [$id]
    )->fetch(\PDO::FETCH_ASSOC);

    if (!$row || (string)$row['key'] !== $key) {
        return false;
    }

    db()->query(
        "UPDATE system_settings SET `value` = ?, updated_at = NOW() WHERE id = ?",
        [$value, $id]
    );

    return true;
}
public function loadAll(): array
{
    // همه تنظیمات (بدون فیلتر is_public)
    $rows = db()->query("SELECT `key`, `value`, `type` FROM system_settings")
        ->fetchAll(\PDO::FETCH_ASSOC);

    $out = [];
    foreach ($rows as $r) {
        $k = (string)($r['key'] ?? '');
        if ($k === '') continue;
        $out[$k] = $r['value']; // اگر cast دارید همان cast خودتان را اعمال کنید
    }
    return $out;
}
}