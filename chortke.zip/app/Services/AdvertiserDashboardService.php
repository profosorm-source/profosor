<?php

namespace App\Services;

use Core\Database;
use Core\Cache;

/**
 * AdvertiserDashboardService - آنالیتیک کامل آگهی‌دهنده
 *
 * داده‌هایی که ارائه می‌دهد:
 *  - خلاصه کلی (بودجه، تعداد، نرخ تأیید)
 *  - عملکرد هر کمپین
 *  - نمودار روزانه اجراها
 *  - پلتفرم‌های پربازده
 *  - وضعیت بررسی‌های معلق
 */
class AdvertiserDashboardService
{
    private Database $db;
    private Cache $cache;

    public function __construct()
    {
        $this->db    = Database::getInstance();
        $this->cache = Cache::getInstance();
    }

    // ─────────────────────────────────────────────────────────
    //  خلاصه کلی
    // ─────────────────────────────────────────────────────────

    /**
     * آمار کلی کمپین‌های یک advertiser
     */
    public function getSummary(int $advertiserId): array
    {
        $cacheKey = "adv_summary_{$advertiserId}";
        return $this->cache->remember($cacheKey, 5, function () use ($advertiserId) {

            $ads = $this->db->fetch(
                "SELECT
                    COUNT(*)                                                    AS total_campaigns,
                    SUM(status = 'active')                                      AS active_campaigns,
                    SUM(status = 'paused')                                      AS paused_campaigns,
                    SUM(status = 'completed')                                   AS completed_campaigns,
                    SUM(status = 'pending')                                     AS pending_campaigns,
                    COALESCE(SUM(total_budget), 0)                              AS total_budget,
                    COALESCE(SUM(total_budget - remaining_budget), 0)           AS spent_budget,
                    COALESCE(SUM(remaining_budget), 0)                          AS remaining_budget,
                    COALESCE(SUM(total_count - remaining_count), 0)             AS total_executions_ordered
                 FROM advertisements
                 WHERE user_id = ? AND deleted_at IS NULL",
                [$advertiserId]
            );

            $execs = $this->db->fetch(
                "SELECT
                    COUNT(*)                               AS total_executions,
                    SUM(te.status = 'approved')            AS approved,
                    SUM(te.status = 'rejected')            AS rejected,
                    SUM(te.status = 'submitted')           AS pending_review,
                    SUM(te.status = 'expired')             AS expired,
                    COALESCE(SUM(te.reward_amount), 0)     AS total_paid_out
                 FROM task_executions te
                 JOIN advertisements a ON a.id = te.advertisement_id
                 WHERE a.user_id = ?",
                [$advertiserId]
            );

            $ads   = (array)$ads;
            $execs = (array)$execs;
            $total = (int)($execs['total_executions'] ?? 0);

            return [
                // کمپین‌ها
                'total_campaigns'     => (int)($ads['total_campaigns']    ?? 0),
                'active_campaigns'    => (int)($ads['active_campaigns']   ?? 0),
                'paused_campaigns'    => (int)($ads['paused_campaigns']   ?? 0),
                'completed_campaigns' => (int)($ads['completed_campaigns']?? 0),
                'pending_campaigns'   => (int)($ads['pending_campaigns']  ?? 0),
                // بودجه
                'total_budget'        => (float)($ads['total_budget']     ?? 0),
                'spent_budget'        => (float)($ads['spent_budget']     ?? 0),
                'remaining_budget'    => (float)($ads['remaining_budget'] ?? 0),
                // اجراها
                'total_executions'    => $total,
                'approved'            => (int)($execs['approved']         ?? 0),
                'rejected'            => (int)($execs['rejected']         ?? 0),
                'pending_review'      => (int)($execs['pending_review']   ?? 0),
                'expired'             => (int)($execs['expired']          ?? 0),
                'total_paid_out'      => (float)($execs['total_paid_out'] ?? 0),
                // نرخ‌ها
                'approval_rate'       => $total > 0 ? round(($execs['approved'] / $total) * 100, 1) : 0,
                'rejection_rate'      => $total > 0 ? round(($execs['rejected'] / $total) * 100, 1) : 0,
                'budget_utilization'  => ($ads['total_budget'] ?? 0) > 0
                    ? round(($ads['spent_budget'] / $ads['total_budget']) * 100, 1)
                    : 0,
            ];
        });
    }

    // ─────────────────────────────────────────────────────────
    //  نمودار روزانه
    // ─────────────────────────────────────────────────────────

    /**
     * اجراهای روزانه ۳۰ روز اخیر (برای نمودار)
     */
    public function getDailyChart(int $advertiserId, int $days = 30): array
    {
        $cacheKey = "adv_chart_{$advertiserId}_{$days}";
        return $this->cache->remember($cacheKey, 10, function () use ($advertiserId, $days) {

            $rows = $this->db->fetchAll(
                "SELECT
                    DATE(te.created_at)             AS day,
                    COUNT(*)                         AS total,
                    SUM(te.status = 'approved')      AS approved,
                    SUM(te.status = 'rejected')      AS rejected,
                    COALESCE(SUM(te.reward_amount),0) AS cost
                 FROM task_executions te
                 JOIN advertisements a ON a.id = te.advertisement_id
                 WHERE a.user_id = ?
                   AND te.created_at >= DATE_SUB(NOW(), INTERVAL ? DAY)
                 GROUP BY DATE(te.created_at)
                 ORDER BY day ASC",
                [$advertiserId, $days]
            );

            // پر کردن روزهای خالی
            $byDay    = [];
            foreach ($rows as $r) {
                $r = (array)$r;
                $byDay[$r['day']] = $r;
            }

            $result = [];
            for ($i = $days - 1; $i >= 0; $i--) {
                $date = date('Y-m-d', strtotime("-{$i} days"));
                $result[] = [
                    'date'     => $date,
                    'label'    => date('m/d', strtotime($date)),
                    'total'    => (int)($byDay[$date]['total']    ?? 0),
                    'approved' => (int)($byDay[$date]['approved'] ?? 0),
                    'rejected' => (int)($byDay[$date]['rejected'] ?? 0),
                    'cost'     => (float)($byDay[$date]['cost']   ?? 0),
                ];
            }

            return $result;
        });
    }

    // ─────────────────────────────────────────────────────────
    //  بهترین / بدترین کمپین‌ها
    // ─────────────────────────────────────────────────────────

    /**
     * عملکرد هر کمپین
     */
    public function getCampaignPerformance(int $advertiserId, int $limit = 10): array
    {
        return $this->db->fetchAll(
            "SELECT
                a.id,
                a.title,
                a.platform,
                a.task_type,
                a.status,
                a.total_budget,
                a.remaining_budget,
                a.total_count,
                a.remaining_count,
                a.price_per_task,
                a.created_at,
                COUNT(te.id)                             AS total_executions,
                SUM(te.status = 'approved')              AS approved,
                SUM(te.status = 'rejected')              AS rejected,
                SUM(te.status = 'submitted')             AS pending,
                COALESCE(SUM(te.reward_amount), 0)       AS paid_out,
                CASE WHEN COUNT(te.id) > 0
                    THEN ROUND(SUM(te.status='approved') / COUNT(te.id) * 100, 1)
                    ELSE 0
                END                                      AS approval_rate,
                CASE WHEN a.total_count > 0
                    THEN ROUND((a.total_count - a.remaining_count) / a.total_count * 100, 1)
                    ELSE 0
                END                                      AS completion_pct
             FROM advertisements a
             LEFT JOIN task_executions te ON te.advertisement_id = a.id
             WHERE a.user_id = ? AND a.deleted_at IS NULL
             GROUP BY a.id
             ORDER BY total_executions DESC
             LIMIT ?",
            [$advertiserId, $limit]
        );
    }

    // ─────────────────────────────────────────────────────────
    //  آنالیز پلتفرم
    // ─────────────────────────────────────────────────────────

    /**
     * مقایسه پلتفرم‌ها
     */
    public function getPlatformBreakdown(int $advertiserId): array
    {
        $rows = $this->db->fetchAll(
            "SELECT
                a.platform,
                COUNT(DISTINCT a.id)                 AS campaigns,
                COUNT(te.id)                         AS executions,
                SUM(te.status = 'approved')          AS approved,
                COALESCE(SUM(te.reward_amount), 0)   AS cost,
                CASE WHEN COUNT(te.id) > 0
                    THEN ROUND(SUM(te.status='approved')/COUNT(te.id)*100,1)
                    ELSE 0
                END                                  AS approval_rate
             FROM advertisements a
             LEFT JOIN task_executions te ON te.advertisement_id = a.id
             WHERE a.user_id = ? AND a.deleted_at IS NULL
             GROUP BY a.platform
             ORDER BY executions DESC",
            [$advertiserId]
        );
        return array_map(fn($r) => (array)$r, $rows);
    }

    /**
     * مقایسه نوع تسک
     */
    public function getTaskTypeBreakdown(int $advertiserId): array
    {
        $rows = $this->db->fetchAll(
            "SELECT
                a.task_type,
                COUNT(DISTINCT a.id)                 AS campaigns,
                COUNT(te.id)                         AS executions,
                SUM(te.status = 'approved')          AS approved,
                CASE WHEN COUNT(te.id) > 0
                    THEN ROUND(SUM(te.status='approved')/COUNT(te.id)*100,1)
                    ELSE 0
                END                                  AS approval_rate,
                COALESCE(AVG(a.price_per_task), 0)   AS avg_price
             FROM advertisements a
             LEFT JOIN task_executions te ON te.advertisement_id = a.id
             WHERE a.user_id = ? AND a.deleted_at IS NULL
             GROUP BY a.task_type
             ORDER BY executions DESC",
            [$advertiserId]
        );
        return array_map(fn($r) => (array)$r, $rows);
    }

    // ─────────────────────────────────────────────────────────
    //  بررسی‌های معلق
    // ─────────────────────────────────────────────────────────

    /**
     * اجراهایی که advertiser باید بررسی کند
     */
    public function getPendingReviews(int $advertiserId, int $limit = 20, int $offset = 0): array
    {
        return $this->db->fetchAll(
            "SELECT
                te.*,
                a.title        AS ad_title,
                a.platform,
                a.task_type,
                u.full_name    AS executor_name,
                u.email        AS executor_email,
                sa.username    AS social_username
             FROM task_executions te
             JOIN advertisements a  ON a.id  = te.advertisement_id
             JOIN users u           ON u.id  = te.executor_id
             LEFT JOIN social_accounts sa ON sa.id = te.executor_social_account_id
             WHERE a.user_id = ? AND te.status = 'submitted'
             ORDER BY te.submitted_at ASC
             LIMIT ? OFFSET ?",
            [$advertiserId, $limit, $offset]
        );
    }

    public function countPendingReviews(int $advertiserId): int
    {
        return (int)$this->db->fetchColumn(
            "SELECT COUNT(*) FROM task_executions te
             JOIN advertisements a ON a.id = te.advertisement_id
             WHERE a.user_id = ? AND te.status = 'submitted'",
            [$advertiserId]
        );
    }

    // ─────────────────────────────────────────────────────────
    //  اجراهای اخیر
    // ─────────────────────────────────────────────────────────

    public function getRecentExecutions(int $advertiserId, int $limit = 10): array
    {
        return $this->db->fetchAll(
            "SELECT
                te.id, te.status, te.reward_amount, te.created_at, te.reviewed_at,
                a.title  AS ad_title,
                u.full_name AS executor_name
             FROM task_executions te
             JOIN advertisements a ON a.id = te.advertisement_id
             JOIN users u ON u.id = te.executor_id
             WHERE a.user_id = ?
             ORDER BY te.created_at DESC
             LIMIT ?",
            [$advertiserId, $limit]
        );
    }

    /**
     * پاک‌سازی cache آگهی‌دهنده
     */
    public function clearCache(int $advertiserId): void
    {
        $this->cache->forget("adv_summary_{$advertiserId}");
        $this->cache->forget("adv_chart_{$advertiserId}_30");
        $this->cache->forget("adv_chart_{$advertiserId}_7");
    }
}
