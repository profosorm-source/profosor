<?php

namespace App\Services;

use Core\Database;
use App\Models\Withdrawal;
use App\Models\WithdrawalLimit;
use App\Models\User;
use App\Models\BankCard;
use App\Models\Setting;
use App\Services\WithdrawalLimitService;
use App\Services\AuditTrail;

class WithdrawalService
{
    private Database $db;
    private Withdrawal $model;
    private Setting $settings;
    private WalletService $wallet;
    private NotificationService $notifier;
    private WithdrawalLimitService $limitService;

    public function __construct(
        WalletService $walletService,
        NotificationService $notificationService
    ) {
        $this->db = Database::getInstance();
        $this->model = new Withdrawal();
        $this->settings = new Setting();
        $this->wallet = $walletService;
        $this->notifier = $notificationService;
        $this->limitService = new WithdrawalLimitService();
    }

    public function create(int $userId, array $data): array
    {
        $user = (new User())->find($userId);
        if (!$user || $user->kyc_status !== 'verified') {
            return ['success'=>false,'message'=>'برای برداشت باید احراز هویت تأیید شده باشد'];
        }

        $currency = (string)($data['currency'] ?? 'IRT');
        if (!in_array($currency, ['IRT','USDT'], true)) return ['success'=>false,'message'=>'ارز نامعتبر'];

        // بررسی محدودیت هوشمند (بر اساس KYC و tier)
        $limitCheck = $this->limitService->check($userId, $amount ?? 0, $currency ?? 'IRT');
        if (!$limitCheck['allowed']) {
            return ['success' => false, 'message' => $limitCheck['reason']];
        }

        $pending = $this->model->where('user_id', $userId)->whereIn('status', ['pending','processing'])->first();
        if ($pending) return ['success'=>false,'message'=>'شما یک برداشت در حال بررسی دارید'];

        $amount = (float)($data['amount'] ?? 0);
        if ($amount <= 0) return ['success'=>false,'message'=>'مبلغ نامعتبر'];

        $min = (float)$this->settings->get($currency === 'IRT' ? 'min_withdrawal_irt' : 'min_withdrawal_usdt', $currency === 'IRT' ? 50000 : 10);
        $max = (float)$this->settings->get($currency === 'IRT' ? 'max_withdrawal_irt' : 'max_withdrawal_usdt', $currency === 'IRT' ? 50000000 : 100000);

        if ($amount < $min) return ['success'=>false,'message'=>'کمتر از حداقل برداشت است'];
        if ($amount > $max) return ['success'=>false,'message'=>'بیشتر از حداکثر برداشت است'];

        $feePercent = (float)$this->settings->get($currency === 'IRT' ? 'withdrawal_fee_irt' : 'withdrawal_fee_usdt', 0);
        $fee = ($amount * $feePercent) / 100;
        $final = $amount - $fee;

        $available = $this->wallet->getAvailableBalance($userId, $currency);
        if ($available < $amount) return ['success'=>false,'message'=>'موجودی کافی نیست'];

        $withdrawalData = [
            'bank_card_id' => null,
            'crypto_wallet' => null,
            'crypto_network' => null
        ];

        if ($currency === 'IRT') {
            $bankCardId = (int)($data['bank_card_id'] ?? 0);
            $card = (new BankCard())
                ->where('id', $bankCardId)
                ->where('user_id', $userId)
                ->where('status', 'verified')
                ->where('deleted_at', null)
                ->first();

            if (!$card) return ['success'=>false,'message'=>'کارت بانکی مقصد نامعتبر یا تأیید نشده است'];

            $withdrawalData['bank_card_id'] = $bankCardId;
        } else {
            $net = (string)($data['crypto_network'] ?? '');
            $addr = trim((string)($data['crypto_wallet'] ?? ''));

            if (!in_array($net, ['BNB20','TRC20','ERC20','TON','SOL'], true)) {
                return ['success'=>false,'message'=>'شبکه نامعتبر'];
            }
            if ($addr === '' || strlen($addr) < 10) return ['success'=>false,'message'=>'آدرس ولت نامعتبر'];

            $withdrawalData['crypto_network'] = $net;
            $withdrawalData['crypto_wallet'] = $addr;
        }

        $idempotencyKey = $this->uuid();

        // کسر موجودی + ثبت ledger pending
        $w = $this->wallet->withdraw($userId, $currency, $amount, $idempotencyKey, 'withdraw', [
            'description' => 'درخواست برداشت'
        ], 'pending');

        if (!$w['success']) return ['success'=>false,'message'=>$w['message'] ?? 'خطا در ثبت برداشت'];

        $id = $this->model->create(array_merge([
            'user_id' => $userId,
            'currency' => $currency,
            'amount' => $amount,
            'fee' => $fee,
            'final_amount' => $final,
            'user_description' => $data['user_description'] ?? null,
            'status' => 'pending',
            'idempotency_key' => $idempotencyKey,
            'ip_address' => get_client_ip(),
            'user_agent' => get_user_agent(),
        ], $withdrawalData));

        $this->increaseDailyLimit($userId);

        return ['success'=>true,'withdrawal_id'=>(int)$id,'message'=>'درخواست برداشت ثبت شد'];
    }

    public function adminApprove(int $adminId, int $withdrawalId, array $paymentData): array
    {
        try {
            $this->db->beginTransaction();

            $w = $this->model->find($withdrawalId);
            if (!$w) { $this->db->rollBack(); return ['success'=>false,'message'=>'برداشت یافت نشد']; }
            if (!in_array($w->status, ['pending','processing'], true)) {
                $this->db->rollBack();
                return ['success'=>false,'message'=>'قبلاً بررسی شده'];
            }

            $update = [
                'status' => 'completed',
                'processed_by' => $adminId,
                'processed_at' => date('Y-m-d H:i:s'),
                'admin_note' => $paymentData['admin_note'] ?? null,
            ];

            if ($w->currency === 'IRT') {
                $update['bank_tracking_code'] = $paymentData['bank_tracking_code'] ?? null;
            } else {
                $update['transaction_hash'] = $paymentData['transaction_hash'] ?? null;
            }

            $this->model->update($withdrawalId, $update);

            // ledger completed
            $this->wallet->updateLedgerStatusByIdempotency((string)$w->idempotency_key, 'completed');

            $this->db->commit();

            $this->notifier->withdrawalApproved((int)$w->user_id, (float)$w->amount, (string)$w->currency);

            return ['success'=>true,'message'=>'برداشت تکمیل شد'];
        } catch (\Exception $e) {
            $this->db->rollBack();
            logger()->error('withdrawal.adminApprove.failed', ['id'=>$withdrawalId,'err'=>$e->getMessage()]);
            return ['success'=>false,'message'=>'خطا در تکمیل برداشت'];
        }
    }

    public function adminReject(int $adminId, int $withdrawalId, string $reason): array
    {
        try {
            $this->db->beginTransaction();

            $w = $this->model->find($withdrawalId);
            if (!$w) { $this->db->rollBack(); return ['success'=>false,'message'=>'برداشت یافت نشد']; }
            if (!in_array($w->status, ['pending','processing'], true)) {
                $this->db->rollBack();
                return ['success'=>false,'message'=>'قبلاً بررسی شده'];
            }

            // refund wallet (completed credit)
            $ok = $this->wallet->deposit((int)$w->user_id, (string)$w->currency, (float)$w->amount, 'refund', [
                'withdrawal_id' => $withdrawalId,
                'reason' => $reason,
                'description' => 'بازگشت وجه برداشت'
            ], 'completed');

            if (!$ok) { $this->db->rollBack(); return ['success'=>false,'message'=>'خطا در بازگشت وجه']; }

            $this->model->update($withdrawalId, [
                'status' => 'rejected',
                'admin_note' => $reason,
                'processed_by' => $adminId,
                'processed_at' => date('Y-m-d H:i:s'),
            ]);

            $this->wallet->updateLedgerStatusByIdempotency((string)$w->idempotency_key, 'refunded');

            $this->db->commit();

            $this->notifier->withdrawalRejected((int)$w->user_id, (float)$w->amount, $reason);

            return ['success'=>true,'message'=>'برداشت رد شد و وجه برگشت داده شد'];
        } catch (\Exception $e) {
            $this->db->rollBack();
            logger()->error('withdrawal.adminReject.failed', ['id'=>$withdrawalId,'err'=>$e->getMessage()]);
            return ['success'=>false,'message'=>'خطا در رد برداشت'];
        }
    }

    private function checkDailyLimit(int $userId, int $limit): bool
    {
        $today = date('Y-m-d');
        $row = $this->db->table('withdrawal_limits')->where('user_id', $userId)->where('limit_date', $today)->first();
        if (!$row) return true;
        return ((int)$row->withdrawal_count) < $limit;
    }

    private function increaseDailyLimit(int $userId): void
    {
        $today = date('Y-m-d');
        $row = $this->db->table('withdrawal_limits')->where('user_id', $userId)->where('limit_date', $today)->first();

        if ($row) {
            $this->db->table('withdrawal_limits')->where('id', $row->id)->update([
                'withdrawal_count' => (int)$row->withdrawal_count + 1,
                'last_withdrawal_at' => date('Y-m-d H:i:s'),
                'updated_at' => date('Y-m-d H:i:s'),
            ]);
        } else {
            $this->db->table('withdrawal_limits')->insert([
                'user_id' => $userId,
                'limit_date' => $today,
                'withdrawal_count' => 1,
                'last_withdrawal_at' => date('Y-m-d H:i:s'),
                'created_at' => date('Y-m-d H:i:s'),
                'updated_at' => date('Y-m-d H:i:s'),
            ]);
        }
    }

    private function uuid(): string
    {
        return \sprintf(
            '%04x%04x-%04x-%04x-%04x-%04x%04x%04x',
            \mt_rand(0, 0xffff), \mt_rand(0, 0xffff),
            \mt_rand(0, 0xffff),
            \mt_rand(0, 0x0fff) | 0x4000,
            \mt_rand(0, 0x3fff) | 0x8000,
            \mt_rand(0, 0xffff), \mt_rand(0, 0xffff), \mt_rand(0, 0xffff)
        );
    }
}