<?php
namespace App\Services;

use App\Models\User;
use Core\Database;

/**
 * Two Factor Authentication Service (بهبود یافته)
 */
class TwoFactorService
{
    private $userModel;
    private $db;

    public function __construct()
    {
        $this->userModel = new User();
        $this->db = Database::getInstance();
    }

    /**
     * تولید Secret Key
     */
    public function generateSecret()
    {
        $secret = '';
        $chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';
        
        for ($i = 0; $i < 32; $i++) {
            $secret .= $chars[random_int(0, strlen($chars) - 1)];
        }
        
        return $secret;
    }

    /**
     * تولید QR Code URL
     */
    public function getQRCodeUrl($username, $secret)
    {
        $appName = urlencode(config('app.name'));
        $username = urlencode($username);
        
        $otpauthUrl = "otpauth://totp/{$appName}:{$username}?secret={$secret}&issuer={$appName}";
        
        return "https://chart.googleapis.com/chart?chs=200x200&chld=M|0&cht=qr&chl=" . urlencode($otpauthUrl);
    }

    /**
     * تایید کد 2FA
     */
    public function verifyCode($secret, $code)
    {
        $timeSlice = floor(time() / 30);
        
        for ($i = -1; $i <= 1; $i++) {
            $calculatedCode = $this->generateTOTP($secret, $timeSlice + $i);
            
            if ($this->timingSafeEquals($calculatedCode, $code)) {
                return true;
            }
        }
        
        // بررسی کدهای بازیابی
        return $this->verifyRecoveryCode($code);
    }

    /**
     * تولید کد TOTP
     */
    private function generateTOTP($secret, $timeSlice)
    {
        $secret = $this->base32Decode($secret);
        
        $time = pack('N*', 0) . pack('N*', $timeSlice);
        $hash = hash_hmac('sha1', $time, $secret, true);
        
        $offset = ord($hash[19]) & 0xf;
        
        $code = (
            ((ord($hash[$offset + 0]) & 0x7f) << 24) |
            ((ord($hash[$offset + 1]) & 0xff) << 16) |
            ((ord($hash[$offset + 2]) & 0xff) << 8) |
            (ord($hash[$offset + 3]) & 0xff)
        ) % 1000000;
        
        return str_pad($code, 6, '0', STR_PAD_LEFT);
    }

    /**
     * Base32 Decode
     */
    private function base32Decode($secret)
    {
        $base32chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';
        $base32charsFlipped = array_flip(str_split($base32chars));
        
        $paddedSecret = str_pad($secret, strlen($secret) + (8 - strlen($secret) % 8) % 8, '=');
        
        $bits = '';
        for ($i = 0; $i < strlen($paddedSecret); $i++) {
            if ($paddedSecret[$i] == '=') {
                continue;
            }
            $bits .= sprintf('%05b', $base32charsFlipped[$paddedSecret[$i]]);
        }
        
        $bytes = '';
        for ($i = 0; $i < strlen($bits); $i += 8) {
            $bytes .= chr(bindec(substr($bits, $i, 8)));
        }
        
        return $bytes;
    }

    /**
     * مقایسه امن زمانی
     */
    private function timingSafeEquals($safe, $user)
    {
        $safe = (string) $safe;
        $user = (string) $user;
        
        if (function_exists('hash_equals')) {
            return hash_equals($safe, $user);
        }
        
        $safeLen = strlen($safe);
        $userLen = strlen($user);
        
        if ($userLen !== $safeLen) {
            return false;
        }
        
        $result = 0;
        for ($i = 0; $i < $safeLen; $i++) {
            $result |= (ord($safe[$i]) ^ ord($user[$i]));
        }
        
        return $result === 0;
    }

    /**
     * تولید کدهای بازیابی
     */
    public function generateRecoveryCodes($count = 8)
    {
        $codes = [];
        
        for ($i = 0; $i < $count; $i++) {
            $codes[] = strtoupper(bin2hex(random_bytes(4)));
        }
        
        return $codes;
    }

    /**
     * ذخیره کدهای بازیابی در دیتابیس (بهبود یافته)
     */
    private function saveRecoveryCodes($userId, $codes)
    {
        // حذف کدهای قبلی
        $this->db->query(
            "DELETE FROM two_factor_codes WHERE user_id = ?",
            [$userId]
        );
        
        // ذخیره کدهای جدید
        foreach ($codes as $code) {
            $this->db->query(
                "INSERT INTO two_factor_codes (user_id, code, used, expires_at, created_at) 
                 VALUES (?, ?, 0, ?, ?)",
                [
                    $userId,
                    hash('sha256', $code), // Hash برای امنیت
                    date('Y-m-d H:i:s', strtotime('+1 year')),
                    now()
                ]
            );
        }
    }

    /**
     * بررسی کد بازیابی
     */
    private function verifyRecoveryCode($code)
    {
        $userId = app()->session->get('user_id') ?? app()->session->get('2fa_user_id');
        
        if (!$userId) {
            return false;
        }
        
        $hashedCode = hash('sha256', strtoupper($code));
        
        $record = $this->db->selectOne(
            "SELECT id FROM two_factor_codes 
             WHERE user_id = ? 
             AND code = ? 
             AND used = 0 
             AND expires_at > NOW()",
            [$userId, $hashedCode]
        );
        
        if ($record) {
            // علامت‌گذاری به عنوان استفاده شده
            $this->db->query(
                "UPDATE two_factor_codes SET used = 1 WHERE id = ?",
                [$record['id']]
            );
            
            logger('info', '2FA recovery code used', [
                'user_id' => $userId,
                'code_id' => $record['id']
            ]);
            
            return true;
        }
        
        return false;
    }

    /**
     * فعالسازی 2FA (بهبود یافته)
     */
    public function enable($userId, $code)
    {
        $user = $this->userModel->find($userId);
        
        if (!$user || !$user['two_factor_secret']) {
            return [
                'success' => false,
                'message' => 'Secret key یافت نشد.'
            ];
        }
        
        if (!$this->verifyCode($user['two_factor_secret'], $code)) {
            return [
                'success' => false,
                'message' => 'کد وارد شده نامعتبر است.'
            ];
        }
        
        // تولید کدهای بازیابی
        $recoveryCodes = $this->generateRecoveryCodes();
        
        // ذخیره در دیتابیس
        $this->saveRecoveryCodes($userId, $recoveryCodes);
        
        // فعالسازی 2FA
        $this->userModel->update($userId, [
            'two_factor_enabled' => 1
        ]);
        
        return [
            'success' => true,
            'message' => 'احراز هویت دو مرحله‌ای فعال شد.',
            'recovery_codes' => $recoveryCodes
        ];
    }

    /**
     * غیرفعالسازی 2FA
     */
    public function disable($userId, $password)
    {
        if (!$this->userModel->verifyPassword($userId, $password)) {
            return [
                'success' => false,
                'message' => 'رمز عبور اشتباه است.'
            ];
        }
        
        $this->userModel->disable2FA($userId);
        
        // حذف کدهای بازیابی
        $this->db->query(
            "DELETE FROM two_factor_codes WHERE user_id = ?",
            [$userId]
        );
        
        return [
            'success' => true,
            'message' => 'احراز هویت دو مرحله‌ای غیرفعال شد.'
        ];
    }
}