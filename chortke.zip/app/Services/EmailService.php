<?php

namespace App\Services;

use App\Models\EmailQueue;
use App\Models\NotificationPreference;
use App\Models\User;
use App\Models\Setting;

class EmailService
{
    private EmailQueue $emailQueue;
    private NotificationPreference $prefModel;
    
    // تنظیمات SMTP
    private string $smtpHost;
    private int $smtpPort;
    private string $smtpUsername;
    private string $smtpPassword;
    private string $smtpEncryption;
    private string $fromEmail;
    private string $fromName;
    
    public function __construct()
    {
        $this->emailQueue = new EmailQueue();
        $this->prefModel = new NotificationPreference();
        
        // بارگذاری تنظیمات SMTP
        $this->loadSmtpSettings();
    }
    
    /**
     * بارگذاری تنظیمات SMTP
     */
    private function loadSmtpSettings(): void
    {
        $settings = new Setting();
        
        $this->smtpHost = $settings->get('smtp_host', 'smtp.gmail.com');
        $this->smtpPort = (int)$settings->get('smtp_port', 587);
        $this->smtpUsername = $settings->get('smtp_username', '');
        $this->smtpPassword = $settings->get('smtp_password', '');
        $this->smtpEncryption = $settings->get('smtp_encryption', 'tls');
        $this->fromEmail = $settings->get('smtp_from_email', 'noreply@chortke.com');
        $this->fromName = $settings->get('smtp_from_name', 'چرتکه');
    }
    
    /**
     * افزودن ایمیل به صف
     */
    public function queue(
        int $userId,
        string $subject,
        string $bodyHtml,
        ?string $bodyText = null,
        string $priority = 'normal',
        ?string $scheduledAt = null
    ): ?int {
        try {
            $user = (new User())->find($userId);
            
            if (!$user || !$user->email) {
                logger()->warning('Email queue skipped - no email', ['user_id' => $userId]);
                return null;
            }
            
            // بررسی تنظیمات کاربر
            if (!$this->prefModel->isEmailEnabled($userId, 'system')) {
                logger()->info('Email queue skipped - user preference', ['user_id' => $userId]);
                return null;
            }
            
            $emailId = $this->emailQueue->create([
                'user_id' => $userId,
                'to_email' => $user->email,
                'to_name' => $user->full_name,
                'subject' => $subject,
                'body_html' => $bodyHtml,
                'body_text' => $bodyText ?? strip_tags($bodyHtml),
                'priority' => $priority,
                'scheduled_at' => $scheduledAt
            ]);
            
            logger()->info('Email queued', [
                'email_id' => $emailId,
                'user_id' => $userId,
                'subject' => $subject
            ]);
            
            return $emailId;
            
        } catch (\Exception $e) {
            logger()->error('Failed to queue email', [
                'user_id' => $userId,
                'error' => $e->getMessage()
            ]);
            
            return null;
        }
    }
    
    /**
     * ارسال ایمیل مستقیم (بدون صف)
     */
    public function sendNow(
        string $toEmail,
        string $toName,
        string $subject,
        string $bodyHtml
    ): bool {
        try {
            return $this->sendViaSMTP($toEmail, $toName, $subject, $bodyHtml);
        } catch (\Exception $e) {
            logger()->error('Direct email send failed', [
                'to' => $toEmail,
                'error' => $e->getMessage()
            ]);
            
            return false;
        }
    }
    
    /**
     * پردازش صف ایمیل
     */
    public function processQueue(int $batchSize = 10): array
    {
        $pendingEmails = $this->emailQueue->getPendingEmails($batchSize);
        
        $stats = [
            'total' => count($pendingEmails),
            'sent' => 0,
            'failed' => 0
        ];
        
        foreach ($pendingEmails as $email) {
            // علامت‌گذاری به عنوان در حال ارسال
            $this->emailQueue->markAsSending($email->id);
            
            // تلاش برای ارسال
            $sent = $this->sendViaSMTP(
                $email->to_email,
                $email->to_name,
                $email->subject,
                $email->body_html
            );
            
            if ($sent) {
                $this->emailQueue->markAsSent($email->id);
                $stats['sent']++;
            } else {
                $this->emailQueue->markAsFailed($email->id, 'SMTP connection failed');
                $stats['failed']++;
            }
            
            // تأخیر کوچک برای جلوگیری از spam
            usleep(500000); // 0.5 ثانیه
        }
        
        logger()->info('Email queue processed', $stats);
        
        return $stats;
    }
    
    /**
     * ارسال واقعی از طریق SMTP
     */
    private function sendViaSMTP(
        string $toEmail,
        string $toName,
        string $subject,
        string $bodyHtml
    ): bool {
        try {
            // استفاده از PHPMailer یا mail() ساده
            
            // روش 1: با mail() ساده (نیاز به تنظیم sendmail در php.ini)
            $headers = [
                'MIME-Version: 1.0',
                'Content-type: text/html; charset=utf-8',
                'From: ' . $this->fromName . ' <' . $this->fromEmail . '>',
                'Reply-To: ' . $this->fromEmail,
                'X-Mailer: PHP/' . phpversion()
            ];
            
            $success = mail(
                $toEmail,
                '=?UTF-8?B?' . base64_encode($subject) . '?=',
                $bodyHtml,
                implode("\r\n", $headers)
            );
            
            if ($success) {
                logger()->info('Email sent successfully', [
                    'to' => $toEmail,
                    'subject' => $subject
                ]);
            }
            
            return $success;
            
            // روش 2: با PHPMailer (پیشنهادی برای production)
            /*
            require_once __DIR__ . '/../../vendor/phpmailer/phpmailer/src/PHPMailer.php';
            require_once __DIR__ . '/../../vendor/phpmailer/phpmailer/src/SMTP.php';
            require_once __DIR__ . '/../../vendor/phpmailer/phpmailer/src/Exception.php';
            
            $mail = new \PHPMailer\PHPMailer\PHPMailer(true);
            
            $mail->isSMTP();
            $mail->Host = $this->smtpHost;
            $mail->SMTPAuth = true;
            $mail->Username = $this->smtpUsername;
            $mail->Password = $this->smtpPassword;
            $mail->SMTPSecure = $this->smtpEncryption;
            $mail->Port = $this->smtpPort;
            $mail->CharSet = 'UTF-8';
            
            $mail->setFrom($this->fromEmail, $this->fromName);
            $mail->addAddress($toEmail, $toName);
            
            $mail->isHTML(true);
            $mail->Subject = $subject;
            $mail->Body = $bodyHtml;
            $mail->AltBody = strip_tags($bodyHtml);
            
            return $mail->send();
            */
            
        } catch (\Exception $e) {
            logger()->error('SMTP send failed', [
                'to' => $toEmail,
                'error' => $e->getMessage()
            ]);
            
            return false;
        }
    }
    
    /**
     * قالب‌های ایمیل از پیش آماده
     */
    
    // خوش‌آمدگویی
    public function sendWelcomeEmail(int $userId): ?int
    {
        $user = (new User())->find($userId);
        
        if (!$user) {
            return null;
        }
        
        $subject = 'خوش آمدید به چرتکه';
        $body = $this->getEmailTemplate('welcome', [
            'name' => $user->full_name,
            'email' => $user->email,
            'dashboard_url' => url('/dashboard')
        ]);
        
        return $this->queue($userId, $subject, $body, null, 'high');
    }
    
    // بازیابی رمز عبور
    public function sendPasswordResetEmail(int $userId, string $token): ?int
    {
        $user = (new User())->find($userId);
        
        if (!$user) {
            return null;
        }
        
        $subject = 'بازیابی رمز عبور';
        $resetUrl = url('/reset-password?token=' . $token);
        
        $body = $this->getEmailTemplate('password-reset', [
            'name' => $user->full_name,
            'reset_url' => $resetUrl,
            'expires_in' => '1 ساعت'
        ]);
        
        return $this->queue($userId, $subject, $body, null, 'urgent');
    }
    
    // تأیید برداشت
    public function sendWithdrawalConfirmation(int $userId, float $amount, string $currency): ?int
    {
        $subject = 'تأیید برداشت';
        $body = $this->getEmailTemplate('withdrawal-approved', [
            'amount' => format_amount($amount),
            'currency' => $currency,
            'date' => to_jalali(date('Y-m-d H:i:s')),
            'wallet_url' => url('/wallet')
        ]);
        
        return $this->queue($userId, $subject, $body, null, 'high');
    }
    
    // اعلام برنده قرعه‌کشی
    public function sendLotteryWinnerEmail(int $userId, float $prize): ?int
    {
        $subject = '🎉 تبریک! شما برنده شدید!';
        $body = $this->getEmailTemplate('lottery-winner', [
            'prize' => format_amount($prize),
            'date' => to_jalali(date('Y-m-d H:i:s')),
            'wallet_url' => url('/wallet')
        ]);
        
        return $this->queue($userId, $subject, $body, null, 'urgent');
    }
    
    /**
     * دریافت قالب ایمیل
     */
    private function getEmailTemplate(string $template, array $vars = []): string
    {
        $templatePath = __DIR__ . '/../../views/emails/' . $template . '.php';
        
        if (!file_exists($templatePath)) {
            // قالب پیش‌فرض
            return $this->getDefaultTemplate($vars);
        }
        
        // استخراج متغیرها
        extract($vars);
        
        ob_start();
        include $templatePath;
        return ob_get_clean();
    }
    
    /**
     * قالب پیش‌فرض
     */
    private function getDefaultTemplate(array $vars): string
    {
        $siteName = env('APP_NAME', 'چرتکه');
        $siteUrl = env('APP_URL', 'http://localhost');
        
        return <<<HTML
<!DOCTYPE html>
<html dir="rtl" lang="fa">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f5f7fa;
            margin: 0;
            padding: 20px;
        }
        .email-container {
            max-width: 600px;
            margin: 0 auto;
            background: white;
            border-radius: 10px;
            overflow: hidden;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        .email-header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 30px;
            text-align: center;
        }
        .email-body {
            padding: 30px;
            line-height: 1.8;
        }
        .email-footer {
            background: #f8f9fa;
            padding: 20px;
            text-align: center;
            font-size: 12px;
            color: #666;
        }
        .btn {
            display: inline-block;
            padding: 12px 30px;
            background: #4fc3f7;
            color: white;
            text-decoration: none;
            border-radius: 5px;
            margin: 20px 0;
        }
    </style>
</head>
<body>
    <div class="email-container">
        <div class="email-header">
            <h1>{$siteName}</h1>
        </div>
        <div class="email-body">
            {$vars['content'] ?? 'محتوای ایمیل'}
        </div>
        <div class="email-footer">
            <p>© 2025 {$siteName}. تمامی حقوق محفوظ است.</p>
            <p>
                <a href="{$siteUrl}">وب‌سایت</a> | 
                <a href="{$siteUrl}/help">راهنما</a> | 
                <a href="{$siteUrl}/contact">تماس با ما</a>
            </p>
        </div>
    </div>
</body>
</html>
HTML;
    }
}