<?php

namespace App\Services;

use App\Models\Notification;
use App\Models\NotificationPreference;
use App\Models\User;
use Core\Database;

class NotificationService
{
    private Notification $notificationModel;

    public function __construct()
    {
        $this->notificationModel = new Notification();
    }
    
    /**
     * ارسال نوتیفیکیشن به کاربر
     */
    public function send(
        int $userId,
        string $type,
        string $title,
        string $message,
        ?array $data = null,
        ?string $actionUrl = null,
        ?string $actionText = null,
        string $priority = 'normal',
        ?string $expiresAt = null
    ): ?int {
        // بررسی تنظیمات کاربر
        if (!$this->prefModel->isInAppEnabled($userId, $type)) {
            logger()->info('Notification skipped - user preference', [
                'user_id' => $userId,
                'type' => $type
            ]);
            
            return null;
        }
        
        try {
            $notificationId = $this->notificationModel->create([
                'user_id' => $userId,
                'type' => $type,
                'title' => $title,
                'message' => $message,
                'data' => $data ? json_encode($data) : null,
                'action_url' => $actionUrl,
                'action_text' => $actionText,
                'priority' => $priority,
                'expires_at' => $expiresAt
            ]);
            
            logger()->info('Notification sent', [
                'notification_id' => $notificationId,
                'user_id' => $userId,
                'type' => $type
            ]);
            
            return $notificationId;
            
        } catch (\Exception $e) {
            logger()->error('Failed to send notification', [
                'user_id' => $userId,
                'type' => $type,
                'error' => $e->getMessage()
            ]);
            
            return null;
        }
    }
	
    public function getUnreadCount(?int $userId = null): int
    {
        if (!$userId) return 0;
        return $this->notificationModel->countUnread($userId);
    }

    
    // ✅ بدون User::where  (با db()->query)
    public function sendToAll(
        string $type,
        string $title,
        string $message,
        ?string $actionUrl = null,
        ?string $actionText = null,
        string $priority = 'normal',
        ?array $data = null
    ): int {
        $admins = db()->query("
            SELECT id
            FROM users
            WHERE role = 'admin'
              AND deleted_at IS NULL
              AND status = 'active'
        ")->fetchAll();

        $count = 0;
        foreach ($admins as $a) {
            $ok = $this->send(
    (int)$a->id,
    $type,
    $title,
    $message,
    $data,        // ✅ پارامتر پنجم
    $actionUrl,   // ✅ پارامتر ششم
    $actionText,  // ✅ پارامتر هفتم
    $priority     // ✅ پارامتر هشتم
);

            if ($ok) $count++;
        }

        return $count;
    }

    /**
     * ارسال نوتیفیکیشن گروهی
     */
    public function sendBulk(
        array $userIds,
        string $type,
        string $title,
        string $message,
        ?array $data = null,
        ?string $actionUrl = null,
        string $priority = 'normal'
    ): int {
        $sent = 0;
        
        foreach ($userIds as $userId) {
            if ($this->send($userId, $type, $title, $message, $data, $actionUrl, null, $priority)) {
                $sent++;
            }
        }
        
        logger()->info('Bulk notifications sent', [
            'total_users' => count($userIds),
            'sent' => $sent
        ]);
        
        return $sent;
    }

public function latest(int $userId, int $limit = 10): array
    {
        return $this->notificationModel->getLatestForUser($userId, $limit);
    }    
    /**
     * نوتیفیکیشن‌های از پیش تعریف شده
     */
    
    // واریز موفق
    public function depositSuccess(int $userId, float $amount, string $currency): ?int
    {
        return $this->send(
            $userId,
            Notification::TYPE_DEPOSIT,
            'واریز موفق',
            "مبلغ " . format_amount($amount) . " با موفقیت به کیف پول شما واریز شد.",
            ['amount' => $amount, 'currency' => $currency],
            url('/wallet'),
            'مشاهده کیف پول',
            'high'
        );
    }
    
    // برداشت تأیید شد
    public function withdrawalApproved(int $userId, float $amount, string $currency): ?int
    {
        return $this->send(
            $userId,
            Notification::TYPE_WITHDRAWAL,
            'برداشت تأیید شد',
            "درخواست برداشت شما به مبلغ " . format_amount($amount) . " تأیید و پردازش شد.",
            ['amount' => $amount, 'currency' => $currency],
            url('/wallet/withdrawal/history'),
            'مشاهده تاریخچه',
            'high'
        );
    }
    
    // برداشت رد شد
    public function withdrawalRejected(int $userId, float $amount, string $reason): ?int
    {
        return $this->send(
            $userId,
            Notification::TYPE_WITHDRAWAL,
            'برداشت رد شد',
            "درخواست برداشت شما به دلیل: {$reason} رد شد و مبلغ به کیف پول شما بازگشت داده شد.",
            ['amount' => $amount, 'reason' => $reason],
            url('/wallet/withdrawal/history'),
            'مشاهده جزئیات',
            'high'
        );
    }
    
    // تسک جدید
    public function newTaskAvailable(int $userId, string $taskTitle): ?int
    {
        return $this->send(
            $userId,
            Notification::TYPE_TASK,
            'تسک جدید',
            "تسک جدید '{$taskTitle}' برای شما در دسترس است.",
            ['task_title' => $taskTitle],
            url('/tasks'),
            'مشاهده تسک‌ها',
            'normal'
        );
    }
    
    // KYC تأیید شد
    public function kycVerified(int $userId): ?int
    {
        return $this->send(
            $userId,
            Notification::TYPE_KYC,
            'احراز هویت تأیید شد',
            "احراز هویت شما با موفقیت تأیید شد. اکنون می‌توانید از تمام امکانات سایت استفاده کنید.",
            null,
            url('/dashboard'),
            'ورود به داشبورد',
            'high'
        );
    }
    
    // KYC رد شد
    public function kycRejected(int $userId, string $reason): ?int
    {
        return $this->send(
            $userId,
            Notification::TYPE_KYC,
            'احراز هویت رد شد',
            "احراز هویت شما رد شد. دلیل: {$reason}. لطفاً مدارک را مجدداً ارسال کنید.",
            ['reason' => $reason],
            url('/kyc/upload'),
            'ارسال مجدد',
            'urgent'
        );
    }
    
    // برنده قرعه‌کشی
    public function lotteryWinner(int $userId, float $amount): ?int
    {
        return $this->send(
            $userId,
            Notification::TYPE_LOTTERY,
            '🎉 تبریک! برنده شدید!',
            "شما برنده قرعه‌کشی شدید! مبلغ " . format_amount($amount) . " به کیف پول شما واریز شد.",
            ['amount' => $amount],
            url('/wallet'),
            'مشاهده کیف پول',
            'urgent',
            date('Y-m-d H:i:s', strtotime('+7 days'))
        );
    }
    
    // کمیسیون معرفی
    public function referralEarning(int $userId, float $amount, string $referredUserName): ?int
    {
        return $this->send(
            $userId,
            Notification::TYPE_REFERRAL,
            'کمیسیون معرفی',
            "شما از فعالیت '{$referredUserName}' مبلغ " . format_amount($amount) . " کمیسیون دریافت کردید.",
            ['amount' => $amount, 'referred_user' => $referredUserName],
            url('/referral'),
            'مشاهده زیرمجموعه‌ها',
            'normal'
        );
    }
    
    // هشدار امنیتی
    public function securityAlert(int $userId, string $message, string $ip): ?int
    {
        return $this->send(
            $userId,
            Notification::TYPE_SECURITY,
            '⚠️ هشدار امنیتی',
            $message,
            ['ip' => $ip, 'time' => date('Y-m-d H:i:s')],
            url('/profile/security'),
            'بررسی حساب',
            'urgent'
        );
    }
}