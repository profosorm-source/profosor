<?php

namespace App\Services;

use App\Models\Wallet;
use App\Models\Transaction;
use Core\Database;

class WalletService
{
    private Wallet $walletModel;
    private Transaction $transactionModel;
    private Database $db;

    public function __construct()
    {
        $this->db = Database::getInstance();
        $this->walletModel = new Wallet();
        $this->transactionModel = new Transaction();
    }

    /**
     * دریافت یا ایجاد کیف پول کاربر
     */
    public function getOrCreateWallet(int $userId): ?object
    {
        $wallet = $this->walletModel->findByUserId($userId);
        
        if (!$wallet) {
            $wallet = $this->walletModel->createForUser($userId);
        }

        return $wallet;
    }

    /**
     * افزایش موجودی (واریز)
     */
    public function deposit(int $userId, float $amount, string $currency = 'irt', array $metadata = []): ?object
    {
        if ($amount <= 0) {
            throw new \InvalidArgumentException('مبلغ باید بیشتر از صفر باشد');
        }

        try {
            $this->db->beginTransaction();

            // دریافت موجودی قبل
            $balanceBefore = $this->walletModel->getBalance($userId, $currency);

            // بروزرسانی موجودی
            $updated = $this->walletModel->updateBalance($userId, $amount, $currency);
            
            if (!$updated) {
                throw new \RuntimeException('خطا در بروزرسانی موجودی');
            }

            // دریافت موجودی بعد
            $balanceAfter = $balanceBefore + $amount;

            // ثبت تراکنش
            $transaction = $this->transactionModel->create([
                'user_id' => $userId,
                'type' => 'deposit',
                'currency' => $currency,
                'amount' => $amount,
                'balance_before' => $balanceBefore,
                'balance_after' => $balanceAfter,
                'status' => 'completed',
                'description' => $metadata['description'] ?? 'واریز وجه',
                'gateway' => $metadata['gateway'] ?? null,
                'gateway_transaction_id' => $metadata['gateway_transaction_id'] ?? null,
                'metadata' => $metadata,
            ]);

            if (!$transaction) {
                throw new \RuntimeException('خطا در ثبت تراکنش');
            }

            $this->db->commit();

            // ثبت لاگ
            log_activity(
                $userId,
                'wallet_deposit',
                "واریز {$amount} " . ($currency === 'usdt' ? 'USDT' : 'تومان'),
                ['transaction_id' => $transaction->transaction_id]
            );

            return $transaction;

        } catch (\Exception $e) {
            $this->db->rollBack();
            logger()->error('Deposit failed', [
                'user_id' => $userId,
                'amount' => $amount,
                'currency' => $currency,
                'error' => $e->getMessage()
            ]);
            throw $e;
        }
    }

    /**
     * برداشت وجه (با قفل موجودی)
     */
    public function withdraw(int $userId, float $amount, string $currency = 'irt', array $metadata = []): ?object
    {
        if ($amount <= 0) {
            throw new \InvalidArgumentException('مبلغ باید بیشتر از صفر باشد');
        }

        try {
            $this->db->beginTransaction();

            // بررسی موجودی با قفل (SELECT FOR UPDATE)
            $wallet = $this->db->query(
                "SELECT * FROM wallets WHERE user_id = :user_id FOR UPDATE",
                ['user_id' => $userId]
            )->fetch(\PDO::FETCH_OBJ);

            if (!$wallet) {
                throw new \RuntimeException('کیف پول یافت نشد');
            }

            $balanceField = $currency === 'usdt' ? 'balance_usdt' : 'balance_irt';
            $currentBalance = (float)$wallet->$balanceField;

            if ($currentBalance < $amount) {
                throw new \RuntimeException('موجودی کافی نیست');
            }

            $balanceBefore = $currentBalance;

            // قفل کردن موجودی
            $locked = $this->walletModel->lockBalance($userId, $amount, $currency);
            
            if (!$locked) {
                throw new \RuntimeException('خطا در قفل کردن موجودی');
            }

            $balanceAfter = $balanceBefore - $amount;

            // ثبت تراکنش با وضعیت pending
            $transaction = $this->transactionModel->create([
                'user_id' => $userId,
                'type' => 'withdraw',
                'currency' => $currency,
                'amount' => $amount,
                'balance_before' => $balanceBefore,
                'balance_after' => $balanceAfter,
                'status' => 'pending',
                'description' => $metadata['description'] ?? 'برداشت وجه',
                'metadata' => $metadata,
            ]);

            if (!$transaction) {
                throw new \RuntimeException('خطا در ثبت تراکنش');
            }

            $this->db->commit();

            // ثبت لاگ
            log_activity(
                $userId,
                'wallet_withdraw_request',
                "درخواست برداشت {$amount} " . ($currency === 'usdt' ? 'USDT' : 'تومان'),
                ['transaction_id' => $transaction->transaction_id]
            );

            return $transaction;

        } catch (\Exception $e) {
            $this->db->rollBack();
            logger()->error('Withdraw failed', [
                'user_id' => $userId,
                'amount' => $amount,
                'currency' => $currency,
                'error' => $e->getMessage()
            ]);
            throw $e;
        }
    }

    /**
     * تکمیل برداشت (توسط ادمین)
     */
    public function completeWithdrawal(int $userId, float $amount, string $currency, string $transactionId): bool
    {
        try {
            $this->db->beginTransaction();

            // کسر از موجودی قفل‌شده
            $deducted = $this->walletModel->deductLocked($userId, $amount, $currency);
            
            if (!$deducted) {
                throw new \RuntimeException('خطا در کسر موجودی قفل‌شده');
            }

            // بروزرسانی وضعیت تراکنش
            $transaction = $this->transactionModel->findByTransactionId($transactionId);
            if ($transaction) {
                $this->transactionModel->updateStatus($transaction->id, 'completed');
            }

            // بروزرسانی زمان آخرین برداشت
            $this->walletModel->updateLastWithdrawal($userId);

            $this->db->commit();

            // ثبت لاگ
            log_activity(
                $userId,
                'wallet_withdraw_completed',
                "برداشت {$amount} " . ($currency === 'usdt' ? 'USDT' : 'تومان') . " تکمیل شد",
                ['transaction_id' => $transactionId]
            );

            return true;

        } catch (\Exception $e) {
            $this->db->rollBack();
            logger()->error('Complete withdrawal failed', [
                'user_id' => $userId,
                'transaction_id' => $transactionId,
                'error' => $e->getMessage()
            ]);
            return false;
        }
    }

    /**
     * لغو برداشت (آزاد کردن موجودی قفل‌شده)
     */
    public function cancelWithdrawal(int $userId, float $amount, string $currency, string $transactionId): bool
    {
        try {
            $this->db->beginTransaction();

            // آزاد کردن موجودی قفل‌شده
            $unlocked = $this->walletModel->unlockBalance($userId, $amount, $currency);
            
            if (!$unlocked) {
                throw new \RuntimeException('خطا در آزادسازی موجودی');
            }

            // بروزرسانی وضعیت تراکنش
            $transaction = $this->transactionModel->findByTransactionId($transactionId);
            if ($transaction) {
                $this->transactionModel->updateStatus($transaction->id, 'cancelled');
            }

            $this->db->commit();

            // ثبت لاگ
            log_activity(
                $userId,
                'wallet_withdraw_cancelled',
                "برداشت {$amount} " . ($currency === 'usdt' ? 'USDT' : 'تومان') . " لغو شد",
                ['transaction_id' => $transactionId]
            );

            return true;

        } catch (\Exception $e) {
            $this->db->rollBack();
            logger()->error('Cancel withdrawal failed', [
                'user_id' => $userId,
                'transaction_id' => $transactionId,
                'error' => $e->getMessage()
            ]);
            return false;
        }
    }

    /**
     * بررسی امکان برداشت
     */
    public function canWithdraw(int $userId, float $amount, string $currency = 'irt'): array
    {
        $result = [
            'can_withdraw' => false,
            'message' => ''
        ];

        // بررسی موجودی
        $balance = $this->walletModel->getBalance($userId, $currency);
        if ($balance < $amount) {
            $result['message'] = 'موجودی کافی نیست';
            return $result;
        }

        // بررسی محدودیت روزانه
        if (!$this->walletModel->canWithdrawToday($userId)) {
            $result['message'] = 'شما امروز یکبار برداشت کرده‌اید';
            return $result;
        }

        // بررسی حداقل برداشت
        $minWithdrawal = (float)config('min_withdrawal_' . $currency, $currency === 'usdt' ? 10 : 50000);
        if ($amount < $minWithdrawal) {
            $result['message'] = 'حداقل مبلغ برداشت ' . number_format($minWithdrawal) . ' ' . ($currency === 'usdt' ? 'USDT' : 'تومان') . ' است';
            return $result;
        }

        $result['can_withdraw'] = true;
        return $result;
    }

    /**
     * دریافت خلاصه کیف پول
     */
    public function getWalletSummary(int $userId): object
    {
        $wallet = $this->getOrCreateWallet($userId);
        $stats = $this->transactionModel->getUserStats($userId);

        return (object)[
            'balance_irt' => (float)$wallet->balance_irt,
            'balance_usdt' => (float)$wallet->balance_usdt,
            'locked_irt' => (float)$wallet->locked_irt,
            'locked_usdt' => (float)$wallet->locked_usdt,
            'total_irt' => (float)$wallet->balance_irt + (float)$wallet->locked_irt,
            'total_usdt' => (float)$wallet->balance_usdt + (float)$wallet->locked_usdt,
            'last_withdrawal_at' => $wallet->last_withdrawal_at,
            'can_withdraw_today' => $this->walletModel->canWithdrawToday($userId),
            'stats' => $stats,
        ];
    }

    /**
     * انتقال وجه بین کاربران
     */
    public function transfer(int $fromUserId, int $toUserId, float $amount, string $currency = 'irt', string $description = ''): ?object
    {
        if ($amount <= 0) {
            throw new \InvalidArgumentException('مبلغ باید بیشتر از صفر باشد');
        }

        if ($fromUserId === $toUserId) {
            throw new \InvalidArgumentException('نمی‌توانید به خودتان انتقال دهید');
        }

        try {
            $this->db->beginTransaction();

            // بررسی موجودی فرستنده با قفل
            $fromWallet = $this->db->query(
                "SELECT * FROM wallets WHERE user_id = :user_id FOR UPDATE",
                ['user_id' => $fromUserId]
            )->fetch(\PDO::FETCH_OBJ);

            if (!$fromWallet) {
                throw new \RuntimeException('کیف پول فرستنده یافت نشد');
            }

            $balanceField = $currency === 'usdt' ? 'balance_usdt' : 'balance_irt';
            $fromBalance = (float)$fromWallet->$balanceField;

            if ($fromBalance < $amount) {
                throw new \RuntimeException('موجودی کافی نیست');
            }

            // کسر از فرستنده
            $this->walletModel->updateBalance($fromUserId, -$amount, $currency);

            // افزایش به گیرنده
            $this->walletModel->updateBalance($toUserId, $amount, $currency);

            // ثبت تراکنش برای فرستنده
            $this->transactionModel->create([
                'user_id' => $fromUserId,
                'type' => 'transfer',
                'currency' => $currency,
                'amount' => -$amount,
                'balance_before' => $fromBalance,
                'balance_after' => $fromBalance - $amount,
                'status' => 'completed',
                'description' => $description ?: "انتقال به کاربر {$toUserId}",
                'metadata' => ['to_user_id' => $toUserId],
            ]);

            // ثبت تراکنش برای گیرنده
            $toBalance = $this->walletModel->getBalance($toUserId, $currency);
            $transaction = $this->transactionModel->create([
                'user_id' => $toUserId,
                'type' => 'transfer',
                'currency' => $currency,
                'amount' => $amount,
                'balance_before' => $toBalance - $amount,
                'balance_after' => $toBalance,
                'status' => 'completed',
                'description' => $description ?: "دریافت از کاربر {$fromUserId}",
                'metadata' => ['from_user_id' => $fromUserId],
            ]);

            $this->db->commit();

            // ثبت لاگ
            log_activity(
                $fromUserId,
                'wallet_transfer',
                "انتقال {$amount} " . ($currency === 'usdt' ? 'USDT' : 'تومان') . " به کاربر {$toUserId}",
                ['to_user_id' => $toUserId]
            );

            return $transaction;

        } catch (\Exception $e) {
            $this->db->rollBack();
            logger()->error('Transfer failed', [
                'from_user_id' => $fromUserId,
                'to_user_id' => $toUserId,
                'amount' => $amount,
                'currency' => $currency,
                'error' => $e->getMessage()
            ]);
            throw $e;
        }
    }
}