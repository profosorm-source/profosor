<?php

namespace App\Services\AntiFraud;

class IPQualityService
{
    /**
     * بررسی کیفیت IP
     */
    public function check(string $ip): array
    {
        $score = 0;
        $reasons = [];
        $details = [];
        
        // 1. بررسی Private IP
        if ($this->isPrivateIP($ip)) {
            $score += 50;
            $reasons[] = 'استفاده از IP خصوصی';
            $details['is_private'] = true;
        }
        
        // 2. بررسی محدوده‌های مشکوک
        if ($this->isSuspiciousRange($ip)) {
            $score += 30;
            $reasons[] = 'محدوده IP مشکوک (Datacenter/VPN)';
            $details['suspicious_range'] = true;
        }
        
        // 3. بررسی Tor Exit Node (لیست ساده)
        if ($this->isTorNode($ip)) {
            $score += 80;
            $reasons[] = 'استفاده از شبکه Tor';
            $details['is_tor'] = true;
        }
        
        // 4. بررسی تعداد کاربران با این IP
        $userCount = $this->getUserCountByIP($ip);
        if ($userCount > 5) {
            $score += 40;
            $reasons[] = "استفاده مشترک توسط {$userCount} کاربر";
            $details['user_count'] = $userCount;
        }
        
        // 5. بررسی سرعت تغییر IP (Velocity)
        $velocityCheck = $this->checkIPVelocity($ip);
        if ($velocityCheck['suspicious']) {
            $score += 25;
            $reasons[] = $velocityCheck['reason'];
            $details['velocity'] = $velocityCheck;
        }
        
        return [
            'score' => min($score, 100),
            'is_suspicious' => $score >= 60,
            'reasons' => $reasons,
            'details' => $details
        ];
    }
    
    /**
     * بررسی IP خصوصی
     */
    private function isPrivateIP(string $ip): bool
    {
        $privateRanges = [
            '10.0.0.0/8',
            '172.16.0.0/12',
            '192.168.0.0/16',
            '127.0.0.0/8'
        ];
        
        foreach ($privateRanges as $range) {
            if ($this->ipInRange($ip, $range)) {
                return true;
            }
        }
        
        return false;
    }
    
    /**
     * بررسی محدوده‌های مشکوک (VPN/Datacenter)
     */
    private function isSuspiciousRange(string $ip): bool
    {
        // لیست ساده محدوده‌های مشکوک
        $suspiciousRanges = [
            // مثال: محدوده‌های AWS
            '52.0.0.0/8',
            '54.0.0.0/8',
            // محدوده‌های Google Cloud
            '35.0.0.0/8',
            // محدوده‌های DigitalOcean
            '64.225.0.0/16'
        ];
        
        foreach ($suspiciousRanges as $range) {
            if ($this->ipInRange($ip, $range)) {
                return true;
            }
        }
        
        return false;
    }
    
    /**
     * بررسی Tor Node (لیست ساده)
     */
    private function isTorNode(string $ip): bool
    {
        // در پروداکشن باید از API یا لیست به‌روز استفاده شود
        // https://check.torproject.org/exit-addresses
        
        $torNodes = [
            // مثال
            '185.220.101.1',
            '185.220.101.2'
        ];
        
        return in_array($ip, $torNodes);
    }
    
    /**
     * شمارش کاربران با این IP
     */
    private function getUserCountByIP(string $ip): int
    {
        $sql = "SELECT COUNT(DISTINCT user_id) as count 
                FROM user_sessions 
                WHERE ip_address = ? 
                AND created_at > DATE_SUB(NOW(), INTERVAL 7 DAY)";
        
        $result = db()->fetch($sql, [$ip]);
        return $result ? (int) $result->count : 0;
    }
    
    /**
     * بررسی سرعت تغییر IP
     */
    private function checkIPVelocity(string $ip): array
    {
        // بررسی چند IP در مدت کوتاه
        $sql = "SELECT COUNT(DISTINCT ip_address) as ip_count 
                FROM user_sessions 
                WHERE created_at > DATE_SUB(NOW(), INTERVAL 1 HOUR)";
        
        $result = db()->fetch($sql);
        $ipCount = $result ? (int) $result->ip_count : 0;
        
        if ($ipCount > 10) {
            return [
                'suspicious' => true,
                'reason' => "تغییر {$ipCount} IP در 1 ساعت اخیر"
            ];
        }
        
        return ['suspicious' => false];
    }
    
    /**
     * بررسی IP در محدوده
     */
    private function ipInRange(string $ip, string $range): bool
    {
        list($subnet, $mask) = explode('/', $range);
        
        $ip_long = ip2long($ip);
        $subnet_long = ip2long($subnet);
        $mask_long = -1 << (32 - (int)$mask);
        
        return ($ip_long & $mask_long) === ($subnet_long & $mask_long);
    }
    
    /**
     * دریافت اطلاعات Geolocation (ساده)
     */
    public function getGeolocation(string $ip): ?array
    {
        // در پروداکشن باید از API استفاده شود (مثل MaxMind)
        // فعلاً mock
        
        if ($this->isPrivateIP($ip)) {
            return null;
        }
        
        return [
            'country' => 'IR',
            'city' => 'Tehran',
            'latitude' => 35.6892,
            'longitude' => 51.3890
        ];
    }
}