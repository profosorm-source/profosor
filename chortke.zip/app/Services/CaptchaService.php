<?php

namespace App\Services;

use Core\Session;
use Core\Database;
use App\Models\SystemSetting;

class CaptchaService
{
    private Database $db;
    private SystemSetting $settingModel;
    
    public function __construct()
    {
        $this->db = Database::getInstance();
        $this->settingModel = new SystemSetting();
    }
    
    /**
     * ایجاد CAPTCHA
     */
    public function generate(string $type = null): array
    {
        if (!$type) {
            $type = $this->settingModel->get('captcha_type', 'math');
        }
        
        switch ($type) {
            case 'math':
                return $this->generateMath();
            
            case 'image':
                return $this->generateImage();
            
            case 'recaptcha_v2':
                return $this->generateRecaptchaV2();
            
            case 'recaptcha_v3':
                return $this->generateRecaptchaV3();
            
            case 'behavioral':
                return $this->generateBehavioral();
            
            default:
                return $this->generateMath();
        }
    }
    
    /**
     * Math CAPTCHA
     */
    private function generateMath(): array
    {
        $operators = ['+', '-', '*'];
        $operator = $operators[array_rand($operators)];
        
        if ($operator === '*') {
            $num1 = rand(2, 9);
            $num2 = rand(2, 9);
        } else {
            $num1 = rand(10, 50);
            $num2 = rand(1, 20);
        }
        
        switch ($operator) {
            case '+':
                $answer = $num1 + $num2;
                break;
            case '-':
                $answer = $num1 - $num2;
                break;
            case '*':
                $answer = $num1 * $num2;
                break;
        }
        
        $question = "{$num1} {$operator} {$num2} = ?";
        $token = $this->storeChallenge('math', $question, (string) $answer);
        
        return [
            'type' => 'math',
            'question' => $question,
            'token' => $token
        ];
    }
    
    /**
     * Image CAPTCHA
     */
   private function generateImage(): array
{
    // ✅ پاکسازی فایل‌های قدیمی (مثلاً 1 ساعت)
    $this->cleanupCaptchaFiles(3600);

    $code = $this->generateRandomCode(6);
    $token = $this->storeChallenge('image', $code, $code);

    // ایجاد تصویر
    $imagePath = $this->createCaptchaImage($code); // مثل: storage/captcha/captcha_xxx.png

    // ✅ ذخیره نام فایل در session تا بعد از verify حذف شود
    $filename = basename($imagePath);
    $data = app()->session->get("captcha_{$token}");
    if (is_array($data)) {
        $data['image_file'] = $filename;
        app()->session->set("captcha_{$token}", $data);
    }

    return [
        'type'  => 'image',
        'image' => $imagePath,
        'token' => $token
    ];
}
private function cleanupCaptchaFiles(int $maxAgeSeconds = 3600): void
{
    $dir = realpath(__DIR__ . '/../../storage/captcha');
    if (!$dir || !is_dir($dir)) {
        return;
    }

    $files = glob($dir . '/captcha_*.png');
    if (!$files) {
        return;
    }

    $now = time();

    foreach ($files as $file) {
        $mtime = @filemtime($file);
        if ($mtime && ($now - $mtime) > $maxAgeSeconds) {
            @unlink($file);
        }
    }
}
    
    /**
     * reCAPTCHA v2
     */
private function generateRecaptchaV2(): array
{
    // 1) اول از DB (settings)
    $siteKey = '';
    if ($this->settingModel) {
        $siteKey = (string) $this->settingModel->get('recaptcha_site_key', '');
        $siteKey = trim($siteKey);
    }

    // 2) fallback از config/.env
    if ($siteKey === '') {
        $siteKey = (string) config('captcha.recaptcha_site_key', '');
        $siteKey = trim($siteKey);
    }

    if ($siteKey === '') {
        throw new \Exception('reCAPTCHA Site Key تنظیم نشده است');
    }

    return [
        'type' => 'recaptcha_v2',
        'site_key' => $siteKey
    ];
}
    /**
     * reCAPTCHA v3
     */
    private function generateRecaptchaV3(): array
    {
        $siteKey = $this->settingModel->get('recaptcha_site_key', '');
        
        if (!$siteKey) {
            throw new \Exception('reCAPTCHA Site Key تنظیم نشده است');
        }
        
        return [
            'type' => 'recaptcha_v3',
            'site_key' => $siteKey
        ];
    }
    
    /**
     * Behavioral CAPTCHA
     */
    private function generateBehavioral(): array
    {
        $token = bin2hex(random_bytes(16));
        
        app()->session->set("captcha_{$token}", [
  'type' => 'behavioral',
  'created_at' => time(),
  'attempts' => 0,
  'verified' => false,
]);
        
        return [
            'type' => 'behavioral',
            'token' => $token,
            'instruction' => 'لطفاً به صورت طبیعی با صفحه تعامل کنید'
        ];
    }
    
    /**
     * ذخیره Challenge
     */
   
    private function storeChallenge(string $type, string $challenge, string $answer): string
{
    $token = bin2hex(random_bytes(16));

    app()->session->set("captcha_{$token}", [
        'type' => $type,
        'challenge' => $challenge,
        'answer' => $answer,
        'created_at' => time(),
        'attempts' => 0
    ]);

    return $token;
}
    /**
     * بررسی پاسخ
     */
    public function verify(string $token, string $response, ?string $recaptchaResponse = null): bool
{
    // 1) بررسی reCAPTCHA (اگر ارسال شده)
    if ($recaptchaResponse) {
        return $this->verifyRecaptcha($recaptchaResponse);
    }

    // 2) دریافت داده از Session
    $captchaData = app()->session->get("captcha_{$token}");
    if (!$captchaData || !is_array($captchaData)) {
        return false;
    }

    // 3) بررسی انقضا
   $expireMinutes = (int) $this->settingModel->get('captcha_expire_minutes', 5);
$createdAt = (int) ($captchaData['created_at'] ?? 0);

if ($createdAt <= 0) {
    app()->session->delete("captcha_{$token}");
    return false;
}

$elapsedMinutes = (time() - $createdAt) / 60;

if ($elapsedMinutes > $expireMinutes) {
    $this->deleteCaptchaImageFile($captchaData); // اگر این متد را ساختی
    app()->session->delete("captcha_{$token}");
    return false;
}

    // 4) بررسی تعداد تلاش (برای behavioral هم می‌خواهیم کنترل کنیم)
    $maxAttempts = (int) $this->settingModel->get('captcha_max_attempts', 3);
    $attempts = (int) ($captchaData['attempts'] ?? 0);

    if ($attempts >= $maxAttempts) {
    $this->deleteCaptchaImageFile($captchaData);
    app()->session->delete("captcha_{$token}");
    return false;
}

    $type = (string) ($captchaData['type'] ?? '');

    // 5) مسیر جدا برای Behavioral CAPTCHA (بدون answer)
    if ($type === 'behavioral') {

    $minSeconds = (int) $this->settingModel->get('behavioral_min_seconds', 2);
    $minInteractions = (int) $this->settingModel->get('behavioral_min_interactions', 8);

    $interactions = (int)($captchaData['interactions'] ?? 0);
    $lastInteractionAt = (int)($captchaData['last_interaction_at'] ?? 0);

    // حداقل زمان
    if ((time() - $createdAt) < $minSeconds) {
        $captchaData['attempts'] = $attempts + 1;
        app()->session->set("captcha_{$token}", $captchaData);
        return false;
    }

    // حداقل تعامل
    if ($interactions < $minInteractions) {
        $captchaData['attempts'] = $attempts + 1;
        app()->session->set("captcha_{$token}", $captchaData);
        return false;
    }

    // تعامل باید نزدیک زمان ارسال باشد (مثلاً در 20 ثانیه اخیر)
    if ($lastInteractionAt === 0 || (time() - $lastInteractionAt) > 20) {
        $captchaData['attempts'] = $attempts + 1;
        app()->session->set("captcha_{$token}", $captchaData);
        return false;
    }

    app()->session->delete("captcha_{$token}");
    return true;


        // موفق
        $this->logAttempt(
            $token,
            $type,
            (string)($captchaData['challenge'] ?? ''),
            $response,
            true
        );

        app()->session->delete("captcha_{$token}");
        return true;
    }

    // 6) مسیر معمولی برای کپچاهای دارای answer (math/image/...)
    if (!array_key_exists('answer', $captchaData)) {
        // داده خراب است
        app()->session->delete("captcha_{$token}");
        return false;
    }

    $expected = (string) $captchaData['answer'];
    $isCorrect = strtolower(trim($response)) === strtolower(trim($expected));

    if ($isCorrect) {
    $this->logAttempt($token, $captchaData['type'], $captchaData['challenge'], $response, true);

    // ✅ فقط اگر image باشد، فایلش حذف می‌شود
    $this->deleteCaptchaImageFile($captchaData);

    app()->session->delete("captcha_{$token}");
    return true;
}

    // ناموفق: افزایش تلاش
    $captchaData['attempts'] = $attempts + 1;
    app()->session->set("captcha_{$token}", $captchaData);

    $this->logAttempt($token, $type, (string)($captchaData['challenge'] ?? ''), $response, false);
    return false;
}
    
    /**
     * بررسی reCAPTCHA
     */
    private function verifyRecaptcha(string $response): bool
    {
        $secretKey = $this->settingModel->get('recaptcha_secret_key', '');
        
        if (!$secretKey) {
            return false;
        }
        
        $url = 'https://www.google.com/recaptcha/api/siteverify';
        
        $data = [
            'secret' => $secretKey,
            'response' => $response,
            'remoteip' => get_client_ip()
        ];
        
        $options = [
            'http' => [
                'header' => "Content-type: application/x-www-form-urlencoded\r\n",
                'method' => 'POST',
                'content' => http_build_query($data)
            ]
        ];
        
        $context = stream_context_create($options);
        $result = @file_get_contents($url, false, $context);
        
        if ($result === false) {
            return false;
        }
        
        $resultJson = json_decode($result, true);
        
        // reCAPTCHA v3 - بررسی Score
        if (isset($resultJson['score'])) {
            $threshold = (float) $this->settingModel->get('recaptcha_v3_threshold', 0.5);
            
            $this->logAttempt(null, 'recaptcha_v3', 'auto', $response, $resultJson['success'], $resultJson['score']);
            
            return $resultJson['success'] && $resultJson['score'] >= $threshold;
        }
        
        // reCAPTCHA v2
        $this->logAttempt(null, 'recaptcha_v2', 'checkbox', $response, $resultJson['success']);
        
        return $resultJson['success'] ?? false;
    }
    
	private function deleteCaptchaImageFile(array $captchaData): void
{
    if (($captchaData['type'] ?? '') !== 'image') {
        return;
    }

    $file = (string)($captchaData['image_file'] ?? '');
    $file = trim($file);

    if ($file === '') {
        return;
    }

    // امنیت: فقط نام فایل
    $fileName = basename($file);

    // مسیر ثابت storage/captcha
    $fullPath = __DIR__ . '/../../storage/captcha/' . $fileName;

    if (is_file($fullPath)) {
        @unlink($fullPath);
    }
}
    /**
     * ثبت لاگ
     */
    private function logAttempt(?string $token, string $type, string $challenge, string $response, bool $success, ?float $score = null): void
    {
        $userId = auth() ? user_id() : null;
        $sessionId = app()->session->get('session_id');
        
        $sql = "INSERT INTO captcha_logs 
                (user_id, session_id, type, challenge, response, ip_address, user_agent, is_success, score, solved_at) 
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        
        $this->db->query($sql, [
            $userId,
            $sessionId,
            $type,
            $challenge,
            $response,
            get_client_ip(),
            get_user_agent(),
            $success ? 1 : 0,
            $score,
            $success ? date('Y-m-d H:i:s') : null
        ]);
    }
    
    /**
     * ایجاد تصویر CAPTCHA
     */
    private function createCaptchaImage(string $code): string
    {
        $width = 200;
        $height = 60;
        
        $image = \imagecreate($width, $height);
        
        // رنگ‌ها
        $bgColor = \imagecolorallocate($image, 255, 255, 255);
        $textColor = \imagecolorallocate($image, 0, 0, 0);
        $lineColor = \imagecolorallocate($image, 200, 200, 200);
        
        // خطوط تصادفی (نویز)
        for ($i = 0; $i < 5; $i++) {
            \imageline($image, rand(0, $width), rand(0, $height), rand(0, $width), rand(0, $height), $lineColor);
        }
        
        // نقاط تصادفی
        for ($i = 0; $i < 100; $i++) {
            \imagesetpixel($image, rand(0, $width), rand(0, $height), $lineColor);
        }
        
        // نوشتن کد
        $fontPath = __DIR__ . '/../../public/assets/fonts/captcha-font.ttf';
        
        if (file_exists($fontPath)) {
            \imagettftext($image, 24, rand(-10, 10), 20, 40, $textColor, $fontPath, $code);
        } else {
            // fallback به فونت داخلی
            \imagestring($image, 5, 60, 20, $code, $textColor);
        }
        
        // ذخیره تصویر
        $filename = 'captcha_' . bin2hex(random_bytes(8)) . '.png';
        $path = __DIR__ . '/../../storage/captcha/' . $filename;
        
        // ایجاد پوشه اگر وجود ندارد
        if (!is_dir(dirname($path))) {
            mkdir(dirname($path), 0755, true);
        }
        
        \imagepng($image, $path);
        \imagedestroy($image);
        
        return '/storage/captcha/' . $filename;
    }
    
    /**
     * تولید کد تصادفی
     */
    private function generateRandomCode(int $length = 6): string
    {
        $characters = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'; // بدون حروف مشابه
        $code = '';
        
        for ($i = 0; $i < $length; $i++) {
            $code .= $characters[rand(0, strlen($characters) - 1)];
        }
        
        return $code;
    }
    
    /**
     * بررسی فعال بودن CAPTCHA
     */
    public function isEnabled(): bool
    {
        return (bool) $this->settingModel->get('captcha_enabled', true);
    }
    
    /**
     * دریافت سطح امنیت بر اساس Risk Score
     */
    public function getCaptchaTypeByRisk(int $riskScore): string
    {
        if ($riskScore >= 80) {
            return 'recaptcha_v2'; // سخت‌ترین
        } elseif ($riskScore >= 60) {
            return 'image';
        } elseif ($riskScore >= 40) {
            return 'behavioral';
        } else {
            return 'math'; // ساده‌ترین
        }
    }
}