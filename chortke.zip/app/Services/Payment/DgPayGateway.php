<?php

namespace App\Services\Payment;

use App\Models\PaymentGateway;

class DgPayGateway implements PaymentGatewayInterface
{
    private ?object $config;

    public function __construct()
    {
        $model = new PaymentGateway();
        $this->config = $model->getActiveGateway('dgpay');
    }

    public function request(int $amount, string $description, string $callback): array
    {
        if (!$this->config) {
            return [
                'success' => false,
                'message' => 'درگاه دی‌جی‌پی غیرفعال است'
            ];
        }

        // توجه: این یک نمونه است - API واقعی DgPay ممکن است متفاوت باشد
        $data = [
            'merchant' => $this->config->merchant_id,
            'amount' => $amount / 10,
            'description' => $description,
            'callback' => $callback,
        ];

        $url = 'https://dgpay.ir/api/v1/payment/request';

        try {
            $ch = \curl_init($url);
            \curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            \curl_setopt($ch, CURLOPT_POST, true);
            \curl_setopt($ch, CURLOPT_POSTFIELDS, \json_encode($data));
            \curl_setopt($ch, CURLOPT_HTTPHEADER, [
                'Content-Type: application/json',
            ]);

            $response = \curl_exec($ch);
            $httpCode = \curl_getinfo($ch, CURLINFO_HTTP_CODE);
            \curl_close($ch);

            if ($httpCode !== 200) {
                throw new \Exception('خطا در اتصال به درگاه');
            }

            $result = \json_decode($response, true);

            if (isset($result['status']) && $result['status'] === 'success') {
                return [
                    'success' => true,
                    'authority' => $result['token'],
                    'url' => "https://dgpay.ir/payment/{$result['token']}",
                    'message' => 'موفق'
                ];
            }

            return [
                'success' => false,
                'message' => $result['message'] ?? 'خطای نامشخص'
            ];

        } catch (\Exception $e) {
            logger()->error('DgPay request failed', ['error' => $e->getMessage()]);
            return [
                'success' => false,
                'message' => 'خطا در برقراری ارتباط با درگاه'
            ];
        }
    }

    public function verify(string $authority, int $amount): array
    {
        if (!$this->config) {
            return [
                'success' => false,
                'message' => 'درگاه دی‌جی‌پی غیرفعال است'
            ];
        }

        $data = [
            'merchant' => $this->config->merchant_id,
            'token' => $authority,
        ];

        $url = 'https://dgpay.ir/api/v1/payment/verify';

        try {
            $ch = \curl_init($url);
            \curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            \curl_setopt($ch, CURLOPT_POST, true);
            \curl_setopt($ch, CURLOPT_POSTFIELDS, \json_encode($data));
            \curl_setopt($ch, CURLOPT_HTTPHEADER, [
                'Content-Type: application/json',
            ]);

            $response = \curl_exec($ch);
            $httpCode = \curl_getinfo($ch, CURLINFO_HTTP_CODE);
            \curl_close($ch);

            if ($httpCode !== 200) {
                throw new \Exception('خطا در اتصال به درگاه');
            }

            $result = \json_decode($response, true);

            if (isset($result['status']) && $result['status'] === 'success') {
                return [
                    'success' => true,
                    'ref_id' => $result['ref_id'] ?? $authority,
                    'message' => 'پرداخت با موفقیت انجام شد'
                ];
            }

            return [
                'success' => false,
                'message' => $result['message'] ?? 'تراکنش ناموفق'
            ];

        } catch (\Exception $e) {
            logger()->error('DgPay verify failed', ['error' => $e->getMessage()]);
            return [
                'success' => false,
                'message' => 'خطا در تأیید پرداخت'
            ];
        }
    }

    public function getName(): string
    {
        return 'dgpay';
    }
}