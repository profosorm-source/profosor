<?php

namespace App\Models;

use Core\Model;
use Core\Database;

class Notification extends Model {
    // اگر در پروژه جایی از این ثابت‌ها استفاده شده باشد، وجودشان مفید است
    public const TYPE_SYSTEM  = 'system';
    public const TYPE_DEPOSIT = 'deposit';
    public const TYPE_SECURITY = 'security';
/**
     * ایجاد نوتیفیکیشن
     * خروجی: id یا false
     */
    public function create(array $data): int|false
    {
        $now = \date('Y-m-d H:i:s');

        $sql = "INSERT INTO notifications
            (user_id, type, title, message, data, action_url, action_text, priority, is_read, is_archived, expires_at, created_at, updated_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

        $payload = [
            $data['user_id'] ?? null,
            $data['type'] ?? self::TYPE_SYSTEM,
            $data['title'] ?? '',
            $data['message'] ?? '',
            isset($data['data']) ? \json_encode($data['data'], JSON_UNESCAPED_UNICODE) : null,
            $data['action_url'] ?? null,
            $data['action_text'] ?? null,
            $data['priority'] ?? 'normal',
            (int)($data['is_read'] ?? 0),
            (int)($data['is_archived'] ?? 0),
            $data['expires_at'] ?? null,
            $now,
            $now,
        ];

        $stmt = $this->db->query($sql, $payload);

        if (!$stmt) {
            return false;
        }

        // نیازمند Database::lastInsertId()
        $id = (int)$this->db->lastInsertId();
        return $id > 0 ? $id : false;
    }

    public function getLatestForUser(int $userId, int $limit = 10): array
    {
        $limit = \max(1, (int)$limit);

        $sql = "SELECT *
                FROM notifications
                WHERE user_id = ?
                  AND is_archived = 0
                  AND (expires_at IS NULL OR expires_at > NOW())
                ORDER BY id DESC
                LIMIT {$limit}";

        return $this->db->query($sql, [$userId])->fetchAll(\PDO::FETCH_OBJ);
    }

    /**
     * دریافت نوتیفیکیشن‌های کاربر
     * (قبلاً با where-chain نوشته شده بود که این کلاس ندارد)
     */
    public function getUserNotifications(int $userId, bool $onlyUnread = false, int $limit = 20): array
    {
        $limit = \max(1, (int)$limit);

        $sql = "SELECT *
                FROM notifications
                WHERE user_id = ?
                  AND is_archived = 0
                  AND (expires_at IS NULL OR expires_at > NOW())";

        $params = [$userId];

        if ($onlyUnread) {
            $sql .= " AND is_read = 0";
        }

        // اولویت بالاتر و جدیدترها
        $sql .= " ORDER BY
                    CASE priority
                      WHEN 'urgent' THEN 4
                      WHEN 'high' THEN 3
                      WHEN 'normal' THEN 2
                      WHEN 'low' THEN 1
                      ELSE 0
                    END DESC,
                    created_at DESC
                  LIMIT {$limit}";

        return $this->db->query($sql, $params)->fetchAll(\PDO::FETCH_OBJ);
    }

    /**
     * تعداد خوانده‌نشده‌ها (نسخه SQL-based)
     */
    public function countUnread(int $userId): int
    {
        $sql = "SELECT COUNT(*) AS total
                FROM notifications
                WHERE user_id = ?
                  AND is_read = 0
                  AND is_archived = 0
                  AND (expires_at IS NULL OR expires_at > NOW())";

        $row = $this->db->query($sql, [$userId])->fetch(\PDO::FETCH_OBJ);
        return (int)($row->total ?? 0);
    }

    // سازگاری با متد قدیمی
    public function getUnreadCount(int $userId): int
    {
        return $this->countUnread($userId);
    }

    /**
     * علامت‌گذاری به عنوان خوانده شده
     */
    public function markAsRead(int $id, int $userId): bool
    {
        $now = \date('Y-m-d H:i:s');

        $sql = "UPDATE notifications
                SET is_read = 1, read_at = ?, updated_at = ?
                WHERE id = ? AND user_id = ?";

        $stmt = $this->db->query($sql, [$now, $now, $id, $userId]);

        if ($stmt instanceof \PDOStatement) {
            return $stmt->rowCount() > 0;
        }

        return (bool)$stmt;
    }

    /**
     * علامت‌گذاری همه به عنوان خوانده شده
     */
    public function markAllAsRead(int $userId): bool
    {
        $now = \date('Y-m-d H:i:s');

        $sql = "UPDATE notifications
                SET is_read = 1, read_at = ?, updated_at = ?
                WHERE user_id = ? AND is_read = 0";

        $stmt = $this->db->query($sql, [$now, $now, $userId]);

        if ($stmt instanceof \PDOStatement) {
            return $stmt->rowCount() >= 0;
        }

        return (bool)$stmt;
    }

    /**
     * آرشیو کردن (Soft)
     */
    public function archive(int $notificationId, int $userId): bool
    {
        $now = \date('Y-m-d H:i:s');

        $sql = "UPDATE notifications
                SET is_archived = 1, archived_at = ?, updated_at = ?
                WHERE id = ? AND user_id = ?";

        $stmt = $this->db->query($sql, [$now, $now, $notificationId, $userId]);

        if ($stmt instanceof \PDOStatement) {
            return $stmt->rowCount() > 0;
        }

        return (bool)$stmt;
    }

    /**
     * قبلاً delete واقعی داشت (ممنوع)
     * اینجا به جای delete، expired ها را آرشیو می‌کنیم.
     */
    public function deleteExpired(): int
    {
        $now = \date('Y-m-d H:i:s');

        $sql = "UPDATE notifications
                SET is_archived = 1, archived_at = ?, updated_at = ?
                WHERE is_archived = 0
                  AND expires_at IS NOT NULL
                  AND expires_at < ?";

        $stmt = $this->db->query($sql, [$now, $now, $now]);

        if ($stmt instanceof \PDOStatement) {
            return $stmt->rowCount();
        }

        return 0;
    }

    /**
     * دریافت نوتیفیکیشن‌های اخیر بر اساس نوع
     */
    public function getByType(int $userId, string $type, int $limit = 10): array
    {
        $limit = \max(1, (int)$limit);

        $sql = "SELECT *
                FROM notifications
                WHERE user_id = ?
                  AND type = ?
                  AND is_archived = 0
                  AND (expires_at IS NULL OR expires_at > NOW())
                ORDER BY created_at DESC
                LIMIT {$limit}";

        return $this->db->query($sql, [$userId, $type])->fetchAll(\PDO::FETCH_OBJ);
    }
}