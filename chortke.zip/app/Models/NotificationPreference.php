<?php

namespace App\Models;

use Core\Model;

class NotificationPreference extends Model
{
    protected static string $table = 'notification_preferences';

    /**
     * دریافت یا ایجاد تنظیمات کاربر
     */
    public function getOrCreate(int $userId): object
    {
        $prefs = $this->db->fetch(
            "SELECT * FROM " . static::$table . " WHERE user_id = ? LIMIT 1",
            [$userId]
        );

        if (!$prefs) {
            $id = $this->db->table(static::$table)->insert([
                'user_id'    => $userId,
                'created_at' => date('Y-m-d H:i:s'),
                'updated_at' => date('Y-m-d H:i:s'),
            ]);
            $prefs = $this->db->fetch(
                "SELECT * FROM " . static::$table . " WHERE id = ?",
                [$id]
            );
        }

        return $prefs;
    }

    /**
     * بررسی فعال بودن نوتیف In-App
     */
    public function isInAppEnabled(int $userId, string $type): bool
    {
        $prefs = $this->getOrCreate($userId);
        if (!($prefs->in_app_enabled ?? true)) {
            return false;
        }
        $field = 'in_app_' . $type;
        return (bool)($prefs->$field ?? true);
    }

    /**
     * بررسی فعال بودن نوتیف Email
     */
    public function isEmailEnabled(int $userId, string $type): bool
    {
        $prefs = $this->getOrCreate($userId);
        if (!($prefs->email_enabled ?? true)) {
            return false;
        }
        $field = 'email_' . $type;
        return (bool)($prefs->$field ?? true);
    }

    /**
     * آپدیت تنظیمات
     */
    public function updateForUser(int $userId, array $data): bool
    {
        $this->getOrCreate($userId); // ensure exists
        return $this->db->query(
            "UPDATE " . static::$table . " SET updated_at = NOW() " .
            implode('', array_map(fn($k) => ", `$k` = ?", array_keys($data))) .
            " WHERE user_id = ?",
            [...array_values($data), $userId]
        ) !== false;
    }
}
