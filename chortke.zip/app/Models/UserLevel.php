<?php

namespace App\Models;

use Core\Model;
use Core\Database;

class UserLevel extends Model {
/**
     * یافتن با ID
     */
    public function find(int $id): ?object
    {
        $stmt = $this->db->prepare("SELECT * FROM user_levels WHERE id = ?");
        $stmt->execute([$id]);
        $result = $stmt->fetch(\PDO::FETCH_OBJ);
        return $result ?: null;
    }

    /**
     * یافتن با slug
     */
    public function findBySlug(string $slug): ?object
    {
        $stmt = $this->db->prepare("SELECT * FROM user_levels WHERE slug = ?");
        $stmt->execute([$slug]);
        $result = $stmt->fetch(\PDO::FETCH_OBJ);
        return $result ?: null;
    }

    /**
     * تمام سطوح (مرتب‌شده)
     */
    public function all(bool $onlyActive = true): array
    {
        $sql = "SELECT * FROM user_levels";
        if ($onlyActive) {
            $sql .= " WHERE is_active = 1";
        }
        $sql .= " ORDER BY sort_order ASC";

        $stmt = $this->db->prepare($sql);
        $stmt->execute();
        return $stmt->fetchAll(\PDO::FETCH_OBJ);
    }

    /**
     * بروزرسانی سطح
     */
    public function update(int $id, array $data): bool
    {
        $fields = [];
        $values = [];

        $allowed = [
            'name', 'icon', 'color', 'sort_order',
            'min_active_days', 'min_completed_tasks', 'min_total_earning', 'min_total_earning_usdt',
            'purchase_price_irt', 'purchase_price_usdt', 'purchase_duration_days',
            'earning_bonus_percent', 'referral_bonus_percent', 'daily_task_limit_bonus',
            'withdrawal_limit_bonus', 'priority_support', 'special_badge', 'is_active',
        ];

        foreach ($allowed as $field) {
            if (\array_key_exists($field, $data)) {
                $fields[] = "{$field} = ?";
                $values[] = $data[$field];
            }
        }

        if (empty($fields)) return false;
        $values[] = $id;

        $stmt = $this->db->prepare("UPDATE user_levels SET " . \implode(', ', $fields) . " WHERE id = ?");
        return $stmt->execute($values);
    }

    /**
     * سطح بالاتر بعدی
     */
    public function getNextLevel(string $currentSlug): ?object
    {
        $current = $this->findBySlug($currentSlug);
        if (!$current) return null;

        $stmt = $this->db->prepare("
            SELECT * FROM user_levels 
            WHERE sort_order > ? AND is_active = 1
            ORDER BY sort_order ASC 
            LIMIT 1
        ");
        $stmt->execute([$current->sort_order]);
        $result = $stmt->fetch(\PDO::FETCH_OBJ);
        return $result ?: null;
    }

    /**
     * سطح پایین‌تر بعدی
     */
    public function getPreviousLevel(string $currentSlug): ?object
    {
        $current = $this->findBySlug($currentSlug);
        if (!$current) return null;

        $stmt = $this->db->prepare("
            SELECT * FROM user_levels 
            WHERE sort_order < ? AND is_active = 1
            ORDER BY sort_order DESC 
            LIMIT 1
        ");
        $stmt->execute([$current->sort_order]);
        $result = $stmt->fetch(\PDO::FETCH_OBJ);
        return $result ?: null;
    }

    /**
     * بالاترین سطح قابل دسترسی با فعالیت
     */
    public function getEligibleLevel(int $activeDays, int $completedTasks, float $totalEarning, float $totalEarningUsdt): ?object
    {
        $stmt = $this->db->prepare("
            SELECT * FROM user_levels 
            WHERE is_active = 1
            AND min_active_days <= ?
            AND min_completed_tasks <= ?
            AND min_total_earning <= ?
            AND min_total_earning_usdt <= ?
            ORDER BY sort_order DESC
            LIMIT 1
        ");
        $stmt->execute([$activeDays, $completedTasks, $totalEarning, $totalEarningUsdt]);
        $result = $stmt->fetch(\PDO::FETCH_OBJ);
        return $result ?: null;
    }

    /**
     * آمار کاربران هر سطح
     */
    public function getUserCountPerLevel(): array
    {
        $stmt = $this->db->prepare("
            SELECT level_slug, COUNT(*) as user_count 
            FROM users 
            WHERE deleted_at IS NULL
            GROUP BY level_slug
        ");
        $stmt->execute();
        $rows = $stmt->fetchAll(\PDO::FETCH_OBJ);

        $result = [];
        foreach ($rows as $row) {
            $result[$row->level_slug] = (int) $row->user_count;
        }
        return $result;
    }
}