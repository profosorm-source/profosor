<?php

namespace App\Models;

use Core\Model;

class Wallet extends Model
{
    protected static string $table = 'wallets';

    private function currencyField(string $currency): string
    {
        $currency = \strtolower(\trim($currency));
        return $currency === 'usdt' ? 'balance_usdt' : 'balance_irt';
    }

    private function lockedField(string $currency): string
    {
        $currency = \strtolower(\trim($currency));
        return $currency === 'usdt' ? 'locked_usdt' : 'locked_irt';
    }

    /**
     * ایجاد کیف پول برای کاربر جدید
     */
    public function createForUser(int $userId): ?object
    {
        $sql = "
            INSERT INTO " . static::$table . " (user_id, created_at, updated_at)
            VALUES (:user_id, NOW(), NOW())
        ";

        $stmt = $this->db->prepare($sql);
        $stmt->execute(['user_id' => $userId]);

        return $this->findByUserId($userId);
    }

    /**
     * دریافت کیف پول بر اساس user_id
     */
    public function findByUserId(int $userId): ?object
    {
        $sql = "SELECT * FROM " . static::$table . " WHERE user_id = :user_id LIMIT 1";
        $stmt = $this->db->prepare($sql);
        $stmt->execute(['user_id' => $userId]);

        $result = $stmt->fetch(\PDO::FETCH_OBJ);
        return $result ?: null;
    }

    /**
     * دریافت موجودی (بر اساس ارز)
     */
    public function getBalance(int $userId, string $currency = 'irt'): float
    {
        $wallet = $this->findByUserId($userId);
        if (!$wallet) return 0.0;

        $field = $this->currencyField($currency);
        return (float)($wallet->{$field} ?? 0);
    }

    /**
     * دریافت موجودی قفل‌شده
     */
    public function getLockedBalance(int $userId, string $currency = 'irt'): float
    {
        $wallet = $this->findByUserId($userId);
        if (!$wallet) return 0.0;

        $field = $this->lockedField($currency);
        return (float)($wallet->{$field} ?? 0);
    }

    /**
     * بروزرسانی موجودی
     */
    public function updateBalance(int $userId, float $amount, string $currency = 'irt'): bool
    {
        $field = $this->currencyField($currency);

        $sql = "
            UPDATE " . static::$table . "
            SET {$field} = {$field} + :amount, updated_at = NOW()
            WHERE user_id = :user_id
        ";

        $stmt = $this->db->prepare($sql);
        return $stmt->execute([
            'amount' => $amount,
            'user_id' => $userId,
        ]);
    }

    /**
     * قفل کردن موجودی (برای برداشت)
     */
    public function lockBalance(int $userId, float $amount, string $currency = 'irt'): bool
    {
        $balanceField = $this->currencyField($currency);
        $lockedField  = $this->lockedField($currency);

        $sql = "
            UPDATE " . static::$table . "
            SET
              {$balanceField} = {$balanceField} - :amount,
              {$lockedField}  = {$lockedField} + :amount,
              updated_at = NOW()
            WHERE user_id = :user_id
              AND {$balanceField} >= :amount
        ";

        $stmt = $this->db->prepare($sql);
        return $stmt->execute([
            'amount' => $amount,
            'user_id' => $userId,
        ]);
    }

    /**
     * آزاد کردن موجودی قفل‌شده
     */
    public function unlockBalance(int $userId, float $amount, string $currency = 'irt'): bool
    {
        $balanceField = $this->currencyField($currency);
        $lockedField  = $this->lockedField($currency);

        $sql = "
            UPDATE " . static::$table . "
            SET
              {$balanceField} = {$balanceField} + :amount,
              {$lockedField}  = {$lockedField} - :amount,
              updated_at = NOW()
            WHERE user_id = :user_id
              AND {$lockedField} >= :amount
        ";

        $stmt = $this->db->prepare($sql);
        return $stmt->execute([
            'amount' => $amount,
            'user_id' => $userId,
        ]);
    }

    /**
     * کسر از موجودی قفل‌شده (برای تکمیل برداشت)
     */
    public function deductLocked(int $userId, float $amount, string $currency = 'irt'): bool
    {
        $lockedField = $this->lockedField($currency);

        $sql = "
            UPDATE " . static::$table . "
            SET {$lockedField} = {$lockedField} - :amount, updated_at = NOW()
            WHERE user_id = :user_id
              AND {$lockedField} >= :amount
        ";

        $stmt = $this->db->prepare($sql);
        return $stmt->execute([
            'amount' => $amount,
            'user_id' => $userId,
        ]);
    }

    /**
     * بروزرسانی زمان آخرین برداشت
     */
    public function updateLastWithdrawal(int $userId): bool
    {
        $sql = "
            UPDATE " . static::$table . "
            SET last_withdrawal_at = NOW(), updated_at = NOW()
            WHERE user_id = :user_id
        ";

        $stmt = $this->db->prepare($sql);
        return $stmt->execute(['user_id' => $userId]);
    }

    /**
     * بررسی امکان برداشت (روزی یکبار)
     */
    public function canWithdrawToday(int $userId): bool
    {
        $wallet = $this->findByUserId($userId);
        if (!$wallet || !$wallet->last_withdrawal_at) return true;

        $lastWithdrawal = \strtotime((string)$wallet->last_withdrawal_at);
        $today = \strtotime('today');

        return $lastWithdrawal < $today;
    }

    /**
     * موجودی کل (آزاد + قفل‌شده)
     */
    public function getTotalBalance(int $userId, string $currency = 'irt'): float
    {
        $wallet = $this->findByUserId($userId);
        if (!$wallet) return 0.0;

        if (\strtolower(\trim($currency)) === 'usdt') {
            return (float)$wallet->balance_usdt + (float)$wallet->locked_usdt;
        }

        return (float)$wallet->balance_irt + (float)$wallet->locked_irt;
    }
}