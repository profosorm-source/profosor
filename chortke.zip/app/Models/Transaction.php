<?php

namespace App\Models;

use Core\Model;

class Transaction extends Model
{
    protected static string $table = 'transactions';

    /**
     * ایجاد تراکنش جدید
     */
    public function create(array $data): ?object
    {
        if (!isset($data['transaction_id']) || $data['transaction_id'] === '') {
            $data['transaction_id'] = $this->generateUUID();
        }

        $type = (string)($data['type'] ?? '');
        if (!isset($data['idempotency_key']) && \in_array($type, ['deposit', 'withdraw'], true)) {
            $data['idempotency_key'] = $this->generateIdempotencyKey($data);
        }

        $data['ip_address'] = $data['ip_address'] ?? (function_exists('get_client_ip') ? get_client_ip() : null);
        $data['device_fingerprint'] = $data['device_fingerprint'] ?? (
            \function_exists('generate_device_fingerprint') ? generate_device_fingerprint() : null
        );

        if (isset($data['metadata']) && \is_array($data['metadata'])) {
            $data['metadata'] = \json_encode($data['metadata'], JSON_UNESCAPED_UNICODE);
        }

        $now = \date('Y-m-d H:i:s');
        $data['created_at'] = $data['created_at'] ?? $now;
        $data['updated_at'] = $data['updated_at'] ?? $now;

        $idOrBool = parent::create($data);

        if (\is_int($idOrBool)) {
            return $this->find($idOrBool);
        }

        return null;
    }

    /**
     * بروزرسانی وضعیت تراکنش
     */
    public function updateStatus(int $id, string $status, ?array $metadata = null): bool
    {
        $sql = "UPDATE " . static::$table . " SET status = :status, updated_at = NOW()";
        $params = ['id' => $id, 'status' => $status];

        if ($status === 'completed') {
            $sql .= ", completed_at = NOW()";
        }

        if ($metadata) {
            $sql .= ", metadata = :metadata";
            $params['metadata'] = \json_encode($metadata, JSON_UNESCAPED_UNICODE);
        }

        $sql .= " WHERE id = :id";

        $stmt = $this->db->prepare($sql);
        return $stmt->execute($params);
    }

    /**
     * دریافت تراکنش بر اساس transaction_id
     */
    public function findByTransactionId(string $transactionId): ?object
    {
        $sql = "SELECT * FROM " . static::$table . " WHERE transaction_id = :transaction_id LIMIT 1";
        $stmt = $this->db->prepare($sql);
        $stmt->execute(['transaction_id' => $transactionId]);
        $result = $stmt->fetch(\PDO::FETCH_OBJ);
        return $result ?: null;
    }

    /**
     * دریافت تراکنش بر اساس Idempotency Key
     */
    public function findByIdempotencyKey(string $key): ?object
    {
        $sql = "SELECT * FROM " . static::$table . " WHERE idempotency_key = :k LIMIT 1";
        $stmt = $this->db->prepare($sql);
        $stmt->execute(['k' => $key]);
        $result = $stmt->fetch(\PDO::FETCH_OBJ);
        return $result ?: null;
    }

    /**
     * دریافت تراکنش‌های کاربر
     */
    public function getUserTransactions(
        int $userId,
        ?string $type = null,
        ?string $currency = null,
        int $limit = 50,
        int $offset = 0
    ): array {
        $limit  = \max(1, (int)$limit);
        $offset = \max(0, (int)$offset);

        $sql = "SELECT * FROM " . static::$table . " WHERE user_id = :user_id";
        $params = ['user_id' => $userId];

        if ($type) {
            $sql .= " AND type = :type";
            $params['type'] = $type;
        }

        if ($currency) {
            $sql .= " AND currency = :currency";
            $params['currency'] = $currency;
        }

        $sql .= " ORDER BY created_at DESC LIMIT {$limit} OFFSET {$offset}";

        $stmt = $this->db->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetchAll(\PDO::FETCH_OBJ);
    }

    /**
     * شمارش تراکنش‌های کاربر
     */
    public function countUserTransactions(int $userId, ?string $type = null, ?string $currency = null): int
    {
        $sql = "SELECT COUNT(*) as count FROM " . static::$table . " WHERE user_id = :user_id";
        $params = ['user_id' => $userId];

        if ($type) {
            $sql .= " AND type = :type";
            $params['type'] = $type;
        }

        if ($currency) {
            $sql .= " AND currency = :currency";
            $params['currency'] = $currency;
        }

        $stmt = $this->db->prepare($sql);
        $stmt->execute($params);
        $result = $stmt->fetch(\PDO::FETCH_OBJ);
        return (int)($result->count ?? 0);
    }

    /**
     * آمار تراکنش‌های کاربر
     */
    public function getUserStats(int $userId): object
    {
        $sql = "
            SELECT
                currency,
                SUM(CASE WHEN type = 'deposit' AND status = 'completed' THEN amount ELSE 0 END) as total_deposits,
                SUM(CASE WHEN type = 'withdraw' AND status = 'completed' THEN amount ELSE 0 END) as total_withdrawals,
                COUNT(CASE WHEN type = 'deposit' THEN 1 END) as deposit_count,
                COUNT(CASE WHEN type = 'withdraw' THEN 1 END) as withdrawal_count
            FROM " . static::$table . "
            WHERE user_id = :user_id
            GROUP BY currency
        ";

        $stmt = $this->db->prepare($sql);
        $stmt->execute(['user_id' => $userId]);
        $results = $stmt->fetchAll(\PDO::FETCH_OBJ);

        $stats = (object)[
            'irt'  => (object)['total_deposits' => 0, 'total_withdrawals' => 0, 'deposit_count' => 0, 'withdrawal_count' => 0],
            'usdt' => (object)['total_deposits' => 0, 'total_withdrawals' => 0, 'deposit_count' => 0, 'withdrawal_count' => 0],
        ];

        foreach ($results as $result) {
            $cur = (string)($result->currency ?? '');
            if ($cur !== '') {
                $stats->{$cur} = $result;
            }
        }

        return $stats;
    }

    /**
     * دریافت تمام تراکنش‌ها (ادمین)
     */
    public function getAll(?string $status = null, ?string $type = null, ?string $currency = null, int $limit = 50, int $offset = 0): array
    {
        $limit  = \max(1, (int)$limit);
        $offset = \max(0, (int)$offset);

        $sql = "SELECT t.*, u.full_name, u.email
                FROM " . static::$table . " t
                LEFT JOIN users u ON t.user_id = u.id
                WHERE 1=1";
        $params = [];

        if ($status) {
            $sql .= " AND t.status = :status";
            $params['status'] = $status;
        }
        if ($type) {
            $sql .= " AND t.type = :type";
            $params['type'] = $type;
        }
        if ($currency) {
            $sql .= " AND t.currency = :currency";
            $params['currency'] = $currency;
        }

        $sql .= " ORDER BY t.created_at DESC LIMIT {$limit} OFFSET {$offset}";

        $stmt = $this->db->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetchAll(\PDO::FETCH_OBJ);
    }

    /**
     * شمارش کل تراکنش‌ها (ادمین)
     */
    public function countAll(?string $status = null, ?string $type = null, ?string $currency = null): int
    {
        $sql = "SELECT COUNT(*) as count FROM " . static::$table . " WHERE 1=1";
        $params = [];

        if ($status) {
            $sql .= " AND status = :status";
            $params['status'] = $status;
        }
        if ($type) {
            $sql .= " AND type = :type";
            $params['type'] = $type;
        }
        if ($currency) {
            $sql .= " AND currency = :currency";
            $params['currency'] = $currency;
        }

        $stmt = $this->db->prepare($sql);
        $stmt->execute($params);
        $result = $stmt->fetch(\PDO::FETCH_OBJ);
        return (int)($result->count ?? 0);
    }

    private function generateUUID(): string
    {
        return \sprintf(
            '%04x%04x-%04x-%04x-%04x-%04x%04x%04x',
            \mt_rand(0, 0xffff), \mt_rand(0, 0xffff),
            \mt_rand(0, 0xffff),
            \mt_rand(0, 0x0fff) | 0x4000,
            \mt_rand(0, 0x3fff) | 0x8000,
            \mt_rand(0, 0xffff), \mt_rand(0, 0xffff), \mt_rand(0, 0xffff)
        );
    }

    private function generateIdempotencyKey(array $data): string
    {
        $seed = \implode('|', [
            (string)($data['user_id'] ?? ''),
            (string)($data['type'] ?? ''),
            (string)($data['amount'] ?? ''),
            (string)($data['currency'] ?? ''),
            \bin2hex(\random_bytes(8)),
        ]);
        return \hash('sha256', $seed);
    }
}
