<?php

namespace App\Models;

use Core\Model;

class WithdrawalLimit extends Model
{
    protected static string $table = 'withdrawal_limits';

    protected array $fillable = [
        'user_id','limit_date','withdrawal_count','last_withdrawal_at'
    ];
}