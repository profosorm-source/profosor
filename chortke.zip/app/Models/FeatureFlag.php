<?php

namespace App\Models;
use Core\Model;

use Core\Database;

class FeatureFlag extends Model {
/**
     * دریافت همه فیچرها
     */
    public function getAll(): array
    {
        $sql = "SELECT * FROM feature_flags ORDER BY name ASC";
        return $this->db->fetchAll($sql);
    }
    
    /**
     * دریافت فیچر با نام
     */
    public function findByName(string $name): ?object
    {
        $sql = "SELECT * FROM feature_flags WHERE name = ?";
        return $this->db->fetch($sql, [$name]);
    }
    
    /**
     * بررسی فعال بودن
     */
    public function isEnabled(string $name, ?int $userId = null, ?string $role = null): bool
    {
        $feature = $this->findByName($name);
        
        if (!$feature) {
            // اگر فیچر وجود نداشت، پیش‌فرض فعال
            return true;
        }
        
        if (!$feature->enabled) {
            return false;
        }
        
        // بررسی محدودیت نقش
        if ($feature->enabled_for_roles) {
            $roles = json_decode($feature->enabled_for_roles, true);
            if (!empty($roles) && $role && !in_array($role, $roles)) {
                return false;
            }
        }
        
        // بررسی محدودیت کاربر
        if ($feature->enabled_for_users) {
            $users = json_decode($feature->enabled_for_users, true);
            if (!empty($users) && $userId && !in_array($userId, $users)) {
                return false;
            }
        }
        
        // بررسی درصد (A/B Testing)
        if ($feature->enabled_percentage < 100) {
            // استفاده از User ID برای تصمیم‌گیری ثابت
            if ($userId) {
                $hash = crc32($userId . $name);
                $percentage = ($hash % 100) + 1;
                
                if ($percentage > $feature->enabled_percentage) {
                    return false;
                }
            } else {
                // اگر کاربر لاگین نیست، تصادفی
                if (rand(1, 100) > $feature->enabled_percentage) {
                    return false;
                }
            }
        }
        
        return true;
    }
    
    /**
     * فعال/غیرفعال کردن
     */
    public function toggle(string $name): bool
    {
        $feature = $this->findByName($name);
        
        if (!$feature) {
            return false;
        }
        
        $newStatus = !$feature->enabled;
        
        $sql = "UPDATE feature_flags SET enabled = ? WHERE name = ?";
        return $this->db->query($sql, [$newStatus ? 1 : 0, $name]);
    }
    
    /**
     * بروزرسانی فیچر
     */
    public function update(string $name, array $data): bool
    {
        $fields = [];
        $params = [];
        
        foreach ($data as $key => $value) {
            if (in_array($key, ['enabled_for_roles', 'enabled_for_users', 'metadata'])) {
                $value = json_encode($value);
            }
            
            $fields[] = "$key = ?";
            $params[] = $value;
        }
        
        $params[] = $name;
        
        $sql = "UPDATE feature_flags SET " . implode(', ', $fields) . " WHERE name = ?";
        
        return $this->db->query($sql, $params);
    }
}