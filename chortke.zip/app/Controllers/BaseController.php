<?php

namespace App\Controllers;

use Core\Session;
use Core\Request;
use Core\Response;

/**
 * BaseController - پایه تمام کنترلرهای پروژه
 *
 * قرارداد استاندارد:
 *   - $this->session  → Core\Session  (instance از app())
 *   - $this->request  → Core\Request  (instance از app())
 *   - $this->response → Core\Response (instance از app())
 *   - $this->userId() → int|null      (user_id از session)
 *   - $this->requireAuth() → redirect به login اگر لاگین نیست
 *   - $this->requireAdmin() → redirect اگر admin نیست
 *   - $this->json()   → JSON response استاندارد
 *   - $this->back()   → redirect به صفحه قبلی
 *
 * سرویس‌ها: در constructor هر کنترلر با new Service() ساخته می‌شن
 * (نه Singleton، نه static) — DI ساده و صریح.
 */
abstract class BaseController
{
    protected Session  $session;
    protected Request  $request;
    protected Response $response;

    public function __construct()
    {
        $app = app();
        $this->session  = $app->session;
        $this->request  = $app->request;
        $this->response = $app->response;
    }

    /* ─────────────────────────────────────────
     | Auth Helpers
     * ─────────────────────────────────────── */

    /**
     * user_id کاربر لاگین‌شده یا null
     */
    protected function userId(): ?int
    {
        $id = $this->session->get('user_id');
        return $id ? (int)$id : null;
    }

    /**
     * اگر لاگین نباشد → redirect به login
     */
    protected function requireAuth(): void
    {
        if (!$this->userId()) {
            if (is_ajax()) {
                $this->response->error('احراز هویت لازم است', [], 401);
                exit;
            }
            $this->session->setFlash('error', 'ابتدا وارد حساب کاربری خود شوید.');
            $this->response->redirect(url('login'));
            exit;
        }
    }

    /**
     * اگر admin نباشد → 403
     */
    protected function requireAdmin(): void
    {
        $role = $this->session->get('user_role');
        if (!in_array($role, ['admin', 'super_admin'], true)) {
            if (is_ajax()) {
                $this->response->error('دسترسی غیرمجاز', [], 403);
                exit;
            }
            $this->response->redirect(url('dashboard'));
            exit;
        }
    }

    /**
     * بررسی permission خاص
     */
    protected function requirePermission(string $permission): void
    {
        // اگر super_admin بود، همه چیز مجاز
        if ($this->session->get('user_role') === 'super_admin') return;

        $permissions = $this->session->get('user_permissions', []);
        if (!in_array($permission, (array)$permissions, true)) {
            if (is_ajax()) {
                $this->response->error('مجوز کافی ندارید', [], 403);
                exit;
            }
            $this->session->setFlash('error', 'مجوز کافی ندارید.');
            $this->back();
            exit;
        }
    }

    /* ─────────────────────────────────────────
     | Response Helpers
     * ─────────────────────────────────────── */

    /**
     * JSON response یکدست
     */
    protected function json(bool $success, string $message = '', array $data = [], int $code = 200): void
    {
        http_response_code($code);
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode([
            'success' => $success,
            'message' => $message,
            'data'    => $data,
        ], JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
        exit;
    }

    protected function jsonSuccess(string $message = '', array $data = []): void
    {
        $this->json(true, $message, $data, 200);
    }

    protected function jsonError(string $message, array $data = [], int $code = 422): void
    {
        $this->json(false, $message, $data, $code);
    }

    /**
     * redirect به صفحه قبلی (یا fallback)
     */
    protected function back(string $fallback = '/'): void
    {
        $ref = $_SERVER['HTTP_REFERER'] ?? '';
        $this->response->redirect($ref ?: url($fallback));
        exit;
    }

    /**
     * flash + redirect ترکیبی
     */
    protected function redirectWithError(string $message, string $to = ''): void
    {
        $this->session->setFlash('error', $message);
        if ($to) {
            $this->response->redirect(url($to));
        } else {
            $this->back();
        }
        exit;
    }

    protected function redirectWithSuccess(string $message, string $to = ''): void
    {
        $this->session->setFlash('success', $message);
        if ($to) {
            $this->response->redirect(url($to));
        } else {
            $this->back();
        }
        exit;
    }

    /**
     * render view با داده
     */
    protected function view(string $template, array $data = []): void
    {
        view($template, $data);
    }
}
