<?php

namespace App\Controllers;

use App\Services\UploadService;
use App\Controllers\BaseController;

class FileController extends BaseController
{
    public function __construct()
    {
        parent::__construct();
    }

    public function view(string $folder, string $filename): void
{
    $session = $this->session; // ✅ اجباری
    
    if (!$this->checkAccess($folder, $filename)) {
        \http_response_code(403);
        echo 'دسترسی غیرمجاز';
        exit;
    }

        $uploadService = new UploadService();
        $relative = $folder . '/' . $filename;
        $path = $uploadService->getPath($relative);

        if (!\file_exists($path)) {
            \http_response_code(404);
            echo 'فایل یافت نشد';
            exit;
        }

        // جلوگیری از خراب شدن تصویر اگر output قبلی بوده
        while (\ob_get_level() > 0) {
            \ob_end_clean();
        }

        $mimeType = \mime_content_type($path) ?: 'application/octet-stream';
        \header('Content-Type: ' . $mimeType);
        \header('Content-Length: ' . (string)\filesize($path));
        if ($folder === 'captcha') {
    \header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
    \header('Pragma: no-cache');
    \header('Expires: 0');
} else {
    \header('Cache-Control: private, max-age=3600');
}

        // لاگ دیدن فایل‌های حساس
        if (\in_array($folder, ['kyc'], true)) {
            $this->logFileView($folder, $filename);
        }

        \readfile($path);
        exit;
    }

    
   private function checkAccess(string $folder, string $filename): bool
{
    
    $isAdmin = $this->session->get('is_admin') ?? false;
    $userId  = $this->userId() ?? null;

 
    if ($isAdmin === true) {
        return true;
    }

    if (\in_array($folder, ['public', 'banners', 'captcha'], true)) {
    return true;
}

    if (!$userId) {
        return false;
    }

    if ($folder === 'kyc') {
        $kyc = db()->query(
            "SELECT user_id FROM kyc_verifications
             WHERE verification_image = ? OR verification_image = ?
             ORDER BY id DESC LIMIT 1",
            [$filename, 'kyc/' . $filename]
        )->fetch();

        if (!$kyc) return false;
        return (int)$kyc->user_id === (int)$userId;
    }

    return false;
}

    private function logFileView(string $folder, string $filename): void
    {
        if (!auth()) return;

        db()->query(
            "INSERT INTO file_logs (folder, filename, viewer_id, action, ip_address, created_at)
             VALUES (?, ?, ?, 'view', ?, ?)",
            [
                $folder,
                $filename,
                user_id(),
                get_client_ip(),
                \date('Y-m-d H:i:s')
            ]
        );
    }
}