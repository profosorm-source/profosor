<?php
// app/Controllers/Admin/TaskRecheckController.php

namespace App\Controllers\Admin;

use App\Models\TaskRecheck;
use App\Services\TaskRecheckService;
use App\Controllers\Admin\BaseAdminController;

class TaskRecheckController extends BaseAdminController
{
    private TaskRecheckService $service;

    public function __construct()
    {
        parent::__construct();
        $this->service = new TaskRecheckService();
    }

    /**
     * لیست بررسی‌های مجدد
     */
    public function index()
    {
        $page = (int) ($_GET['page'] ?? 1);
        $limit = 30;
        $offset = ($page - 1) * $limit;

        $filters = [];
        if (!empty($_GET['status'])) $filters['status'] = $_GET['status'];

        $rechecks = (new \App\Models\TaskRecheck())->getAll($filters, $limit, $offset);

        return view('admin.task-rechecks.index', [
            'rechecks' => $rechecks,
            'filters'  => $filters,
            'page'     => $page,
        ]);
    }

    /**
     * تایید (هنوز فالو دارد) — Ajax
     */
    public function pass(): void
    {
        $id = (int) $this->request->param('id');

        $result = $this->service->pass($id);

        log_activity('recheck_pass', 'تایید بررسی مجدد #' . $id, $id, 'task_recheck');

        $this->response->json($result);
    }

    /**
     * شکست (آنفالو کرده) — Ajax
     */
    public function fail(): void
    {
        $id = (int) $this->request->param('id');

        $result = $this->service->fail($id);

        log_activity('recheck_fail', 'شکست بررسی مجدد #' . $id, $id, 'task_recheck');

        $this->response->json($result);
    }
}