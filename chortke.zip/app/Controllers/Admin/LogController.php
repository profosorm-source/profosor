<?php

namespace App\Controllers\Admin;

use App\Models\ActivityLog;
use App\Controllers\Admin\BaseAdminController;

class LogController extends BaseAdminController
{
    private ActivityLog $activityLog;
    private \App\Models\User $userModel;
    
    public function __construct()
    {
        parent::__construct();
        $this->activityLog = new ActivityLog();
        $this->userModel = new \App\Models\User();
    }
    
    /**
     * نمایش لیست لاگ‌ها
     */
    public function index(): void
    {
        $page = (int)($_GET['page'] ?? 1);
        $perPage = 50;
        
        // فیلترها
        $userId = $_GET['user_id'] ?? null;
        $action = $_GET['action'] ?? null;
        $search = $_GET['search'] ?? null;
        
        // دریافت لاگ‌ها
        $result = $this->activityLog->getPaginated(
            $page,
            $perPage,
            $userId ? (int)$userId : null,
            $action,
            $search
        );
        
        // دریافت کاربر فعلی برای Layout
        $currentUserId = $this->userId();
        $user = $this->userModel->find((int)$currentUserId);
    $logs = db()->query(
    "SELECT l.*, u.full_name, u.email AS user_email
     FROM activity_logs l
     LEFT JOIN users u ON u.id = l.user_id
     ORDER BY l.id DESC
     LIMIT 300"
)->fetchAll();

view('admin.logs.index', ['logs' => $logs]);
        
    }
    
    /**
     * حذف لاگ‌های قدیمی
     */
    public function cleanup(): void
    {
        $days = (int)($_POST['days'] ?? 90);
        
        if ($days < 30) {
            $this->session->setFlash('error', 'حداقل 30 روز باید باقی بماند.');
            redirect('/admin/logs');
            return;
        }
        
        $deleted = $this->activityLog->deleteOlderThan($days);
        
        log_activity('cleanup_logs', "حذف {$deleted} لاگ قدیمی‌تر از {$days} روز");
        
        $this->session->setFlash('success', "{$deleted} رکورد حذف شد.");
        redirect('/admin/logs');
    }
}