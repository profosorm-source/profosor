<?php

namespace App\Controllers\Admin;

use App\Models\Withdrawal;
use App\Services\WalletService;
use Core\Validator;
use App\Controllers\Admin\BaseAdminController;

class WithdrawalController extends BaseAdminController
{
    private Withdrawal $withdrawalModel;
    private WalletService $walletService;

    public function __construct()
    {
        parent::__construct();
        $this->withdrawalModel = new Withdrawal();
        $this->walletService = new WalletService();
    }

    /**
     * لیست درخواست‌های برداشت
     */
    public function index(): void
    {
                
        $page = (int)$this->request->get('page', 1);
        $status = $this->request->get('status');
        $currency = $this->request->get('currency');
        $limit = 20;
        $offset = ($page - 1) * $limit;

        try {
            if ($status || $currency) {
                $withdrawals = $this->withdrawalModel->getAll($status, $currency, $limit, $offset);
                $total = $this->withdrawalModel->countAll($status, $currency);
            } else {
                $withdrawals = $this->withdrawalModel->getPendingWithdrawals($limit, $offset);
                $total = $this->withdrawalModel->countPendingWithdrawals();
            }

            $totalPages = (int)\ceil($total / $limit);

            view('admin.withdrawals.index', [
                'withdrawals' => $withdrawals,
                'currentPage' => $page,
                'totalPages' => $totalPages,
                'total' => $total,
                'status' => $status,
                'currency' => $currency,
                'pageTitle' => 'درخواست‌های برداشت'
            ]);

        } catch (\Exception $e) {
            logger()->error('Admin withdrawals index failed', [
                'error' => $e->getMessage()
            ]);

            $this->session->setFlash('error', 'خطا در دریافت لیست');
            redirect('/admin/dashboard');
        }
    }

    /**
     * صفحه بررسی درخواست برداشت
     */
    public function review(): void
    {
                $withdrawalId = (int)$this->request->get('id');

        try {
            $withdrawal = $this->withdrawalModel->find($withdrawalId);

            if (!$withdrawal) {
                $this->session->setFlash('error', 'درخواست یافت نشد');
                redirect('/admin/withdrawals');
                return;
            }

            // دریافت اطلاعات کاربر
            $userModel = new \App\Models\User();
            $user = $userModel->find($withdrawal->user_id);

            // دریافت اطلاعات کارت (برای IRT)
            $card = null;
            if ($withdrawal->card_id) {
                $cardModel = new \App\Models\UserBankCard();
                $card = $cardModel->find($withdrawal->card_id);
            }

            view('admin.withdrawals.review', [
                'withdrawal' => $withdrawal,
                'user' => $user,
                'card' => $card,
                'pageTitle' => 'بررسی درخواست برداشت'
            ]);

        } catch (\Exception $e) {
            logger()->error('Admin withdrawal review failed', [
                'withdrawal_id' => $withdrawalId,
                'error' => $e->getMessage()
            ]);

            $this->session->setFlash('error', 'خطا در دریافت اطلاعات');
            redirect('/admin/withdrawals');
        }
    }

    /**
     * پردازش (تأیید) درخواست برداشت
     */
    public function process(): void
    {
                        $adminId = $this->userId();

        $withdrawalId = (int)$this->request->input('withdrawal_id');

        try {
            $withdrawal = $this->withdrawalModel->find($withdrawalId);

            if (!$withdrawal) {
                $this->response->json([
                    'success' => false,
                    'message' => 'درخواست یافت نشد'
                ]);
                return;
            }

            if ($withdrawal->status !== 'pending') {
                $this->response->json([
                    'success' => false,
                    'message' => 'این درخواست قبلاً پردازش شده است'
                ]);
                return;
            }

            // تکمیل برداشت (کسر از موجودی قفل‌شده)
            $completed = $this->walletService->completeWithdrawal(
                $withdrawal->user_id,
                (float)$withdrawal->amount,
                $withdrawal->currency,
                $withdrawal->transaction_id
            );

            if (!$completed) {
                throw new \RuntimeException('خطا در تکمیل برداشت');
            }

            // بروزرسانی وضعیت
            $updated = $this->withdrawalModel->updateStatus(
                $withdrawalId,
                'completed',
                null,
                $adminId,
                $withdrawal->transaction_id
            );

            if ($updated) {
                // ثبت لاگ
                log_activity(
                    $adminId,
                    'withdrawal_processed',
                    "پردازش برداشت {$withdrawal->amount} " . ($withdrawal->currency === 'usdt' ? 'USDT' : 'تومان') . " برای کاربر {$withdrawal->user_id}",
                    ['withdrawal_id' => $withdrawalId]
                );

                $this->response->json([
                    'success' => true,
                    'message' => 'برداشت با موفقیت پردازش شد'
                ]);
            } else {
                throw new \RuntimeException('خطا در بروزرسانی وضعیت');
            }

        } catch (\Exception $e) {
            logger()->error('Admin process withdrawal failed', [
                'admin_id' => $adminId,
                'withdrawal_id' => $withdrawalId,
                'error' => $e->getMessage()
            ]);

            $this->response->json([
                'success' => false,
                'message' => 'خطا در پردازش برداشت: ' . $e->getMessage()
            ]);
        }
    }

    /**
     * رد درخواست برداشت
     */
    public function reject(): void
    {
                        $adminId = $this->userId();

        $data = [
            'withdrawal_id' => $this->request->input('withdrawal_id'),
            'rejection_reason' => $this->request->input('rejection_reason'),
        ];

        // اعتبارسنجی
        $validator = new Validator($data, [
            'withdrawal_id' => 'required|numeric',
            'rejection_reason' => 'required|min:10|max:500',
        ], [
            'rejection_reason.required' => 'دلیل رد الزامی است',
            'rejection_reason.min' => 'دلیل رد باید حداقل 10 کاراکتر باشد',
        ]);

        if ($validator->fails()) {
            $this->response->json([
                'success' => false,
                'message' => $validator->errors()[0]
            ]);
            return;
        }

        try {
            $withdrawalId = (int)$data['withdrawal_id'];
            $withdrawal = $this->withdrawalModel->find($withdrawalId);

            if (!$withdrawal) {
                $this->response->json([
                    'success' => false,
                    'message' => 'درخواست یافت نشد'
                ]);
                return;
            }

            if ($withdrawal->status !== 'pending') {
                $this->response->json([
                    'success' => false,
                    'message' => 'این درخواست قبلاً پردازش شده است'
                ]);
                return;
            }

            // لغو برداشت (آزادسازی موجودی قفل‌شده)
            $cancelled = $this->walletService->cancelWithdrawal(
                $withdrawal->user_id,
                (float)$withdrawal->amount,
                $withdrawal->currency,
                $withdrawal->transaction_id
            );

            if (!$cancelled) {
                throw new \RuntimeException('خطا در آزادسازی موجودی');
            }

            // بروزرسانی وضعیت
            $updated = $this->withdrawalModel->updateStatus(
                $withdrawalId,
                'rejected',
                $data['rejection_reason'],
                $adminId
            );

            if ($updated) {
                // ثبت لاگ
                log_activity(
                    $adminId,
                    'withdrawal_rejected',
                    "رد برداشت کاربر {$withdrawal->user_id}",
                    ['withdrawal_id' => $withdrawalId, 'reason' => $data['rejection_reason']]
                );

                $this->response->json([
                    'success' => true,
                    'message' => 'برداشت رد شد و موجودی به کاربر بازگردانده شد'
                ]);
            } else {
                throw new \RuntimeException('خطا در رد برداشت');
            }

        } catch (\Exception $e) {
            logger()->error('Admin reject withdrawal failed', [
                'admin_id' => $adminId,
                'error' => $e->getMessage()
            ]);

            $this->response->json([
                'success' => false,
                'message' => 'خطا در رد برداشت'
            ]);
        }
    }
}