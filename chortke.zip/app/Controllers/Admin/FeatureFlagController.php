<?php

namespace App\Controllers\Admin;

use App\Models\FeatureFlag;
use App\Controllers\Admin\BaseAdminController;

class FeatureFlagController extends BaseAdminController
{
    private FeatureFlag $featureModel;
    
    public function __construct()
    {
        parent::__construct();
        $this->featureModel = new FeatureFlag();
    }
    
    /**
     * لیست فیچرها
     */
    public function index()
    {
        $features = $this->featureModel->getAll();
        
        return view('admin/features/index', [
            'features' => $features
        ]);
    }
    
    /**
     * تغییر وضعیت فیچر
     */
    public function toggle()
    {
                        
        $data = $this->request->json();
        $name = $data['name'] ?? '';
        
        if (!$name) {
            return $this->response->json(['success' => false, 'message' => 'نام فیچر الزامی است.']);
        }
        
        if ($this->featureModel->toggle($name)) {
            log_activity(user_id(), 'feature_toggled', "فیچر {$name} تغییر وضعیت داد");
            
            return $this->response->json([
                'success' => true,
                'message' => 'وضعیت فیچر تغییر کرد.'
            ]);
        }
        
        return $this->response->json(['success' => false, 'message' => 'خطا در تغییر وضعیت.']);
    }
}