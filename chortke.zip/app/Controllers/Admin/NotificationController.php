<?php

namespace App\Controllers\Admin;

use App\Models\Notification;
use App\Services\NotificationService;
use App\Controllers\Admin\BaseAdminController;

class NotificationController extends BaseAdminController
{
    private NotificationService $service;
    private Notification $model;

    public function __construct()
    {
        parent::__construct();
        $this->service = new NotificationService();
        $this->model = new Notification();
    }

    public function index(): void
    {
        
        // فقط ادمین
        if (!is_admin()) {
            $this->response->redirect(url('/user/dashboard'));
            return;
        }

        $notifications = $this->service->latest(user_id(), 50);

        view('admin.notifications.index', [
            'notifications' => $notifications,
        ]);
    }

    // Ajax dropdown fetch
    public function fetch(): void
    {
        
        $items = $this->service->latest(user_id(), 10);
        $unread = $this->service->getUnreadCount(user_id());

        $this->response->json([
            'success' => true,
            'notifications' => $items,
            'unread_count' => $unread,
        ]);
    }

    public function markAsRead(int $id): void
    {
        
        $ok = $this->model->markAsRead($id, user_id());

        $this->response->json([
            'success' => $ok,
            'message' => $ok ? 'خوانده شد' : 'عملیات ناموفق بود'
        ], $ok ? 200 : 400);
    }

    public function markAllAsRead(): void
    {
        
        $ok = $this->model->markAllAsRead(user_id());

        $this->response->json([
            'success' => $ok,
            'message' => $ok ? 'همه خوانده شدند' : 'عملیات ناموفق بود'
        ], $ok ? 200 : 400);
    }
}