<?php

namespace App\Controllers\Admin;

use App\Models\ManualDeposit;
use App\Services\WalletService;
use Core\Validator;
use App\Controllers\Admin\BaseAdminController;

class ManualDepositController extends BaseAdminController
{
    private ManualDeposit $depositModel;
    private WalletService $walletService;

    public function __construct()
    {
        parent::__construct();
        $this->depositModel = new ManualDeposit();
        $this->walletService = new WalletService();
    }

    /**
     * لیست واریزهای دستی در انتظار
     */
    public function index(): void
    {
                
        $page = (int)$this->request->get('page', 1);
        $status = $this->request->get('status');
        $limit = 20;
        $offset = ($page - 1) * $limit;

        try {
            if ($status) {
                $deposits = $this->depositModel->getAll($status, $limit, $offset);
                $total = $this->depositModel->countAll($status);
            } else {
                $deposits = $this->depositModel->getPendingDeposits($limit, $offset);
                $total = $this->depositModel->countPendingDeposits();
            }

            $totalPages = (int)\ceil($total / $limit);

            view('admin.manual-deposits.index', [
                'deposits' => $deposits,
                'currentPage' => $page,
                'totalPages' => $totalPages,
                'total' => $total,
                'status' => $status,
                'pageTitle' => 'واریزهای دستی'
            ]);

        } catch (\Exception $e) {
            logger()->error('Admin manual deposits index failed', [
                'error' => $e->getMessage()
            ]);

            $this->session->setFlash('error', 'خطا در دریافت لیست');
            redirect('/admin/dashboard');
        }
    }

    /**
     * صفحه بررسی واریز دستی
     */
    public function review(): void
    {
                $depositId = (int)$this->request->get('id');

        try {
            $deposit = $this->depositModel->find($depositId);

            if (!$deposit) {
                $this->session->setFlash('error', 'واریز یافت نشد');
                redirect('/admin/manual-deposits');
                return;
            }

            // دریافت اطلاعات کاربر
            $userModel = new \App\Models\User();
            $user = $userModel->find($deposit->user_id);

            // دریافت اطلاعات کارت
            $cardModel = new \App\Models\UserBankCard();
            $card = $cardModel->find($deposit->card_id);

            view('admin.manual-deposits.review', [
                'deposit' => $deposit,
                'user' => $user,
                'card' => $card,
                'pageTitle' => 'بررسی واریز دستی'
            ]);

        } catch (\Exception $e) {
            logger()->error('Admin manual deposit review failed', [
                'deposit_id' => $depositId,
                'error' => $e->getMessage()
            ]);

            $this->session->setFlash('error', 'خطا در دریافت اطلاعات');
            redirect('/admin/manual-deposits');
        }
    }

    /**
     * تأیید واریز دستی
     */
    public function verify(): void
    {
                        $adminId = $this->userId();

        $depositId = (int)$this->request->input('deposit_id');

        try {
            $deposit = $this->depositModel->find($depositId);

            if (!$deposit) {
                $this->response->json([
                    'success' => false,
                    'message' => 'واریز یافت نشد'
                ]);
                return;
            }

            if ($deposit->status !== 'pending' && $deposit->status !== 'under_review') {
                $this->response->json([
                    'success' => false,
                    'message' => 'این واریز قبلاً بررسی شده است'
                ]);
                return;
            }

            // افزایش موجودی کاربر
            $transaction = $this->walletService->deposit(
                $deposit->user_id,
                (float)$deposit->amount,
                'irt',
                [
                    'gateway' => 'manual',
                    'description' => 'واریز دستی - شماره پیگیری: ' . $deposit->tracking_code,
                    'tracking_code' => $deposit->tracking_code,
                ]
            );

            if (!$transaction) {
                throw new \RuntimeException('خطا در افزایش موجودی');
            }

            // بروزرسانی وضعیت واریز
            $updated = $this->depositModel->updateStatus(
                $depositId,
                'verified',
                null,
                $adminId,
                $transaction->transaction_id
            );

            if ($updated) {
                // ثبت لاگ
                log_activity(
                    $adminId,
                    'manual_deposit_verified',
                    "تأیید واریز دستی {$deposit->amount} تومان برای کاربر {$deposit->user_id}",
                    ['deposit_id' => $depositId, 'transaction_id' => $transaction->transaction_id]
                );

                $this->response->json([
                    'success' => true,
                    'message' => 'واریز با موفقیت تأیید شد و موجودی کاربر افزایش یافت'
                ]);
            } else {
                throw new \RuntimeException('خطا در بروزرسانی وضعیت');
            }

        } catch (\Exception $e) {
            logger()->error('Admin verify manual deposit failed', [
                'admin_id' => $adminId,
                'deposit_id' => $depositId,
                'error' => $e->getMessage()
            ]);

            $this->response->json([
                'success' => false,
                'message' => 'خطا در تأیید واریز: ' . $e->getMessage()
            ]);
        }
    }

    /**
     * رد واریز دستی
     */
    public function reject(): void
    {
                        $adminId = $this->userId();

        $data = [
            'deposit_id' => $this->request->input('deposit_id'),
            'rejection_reason' => $this->request->input('rejection_reason'),
        ];

        // اعتبارسنجی
        $validator = new Validator($data, [
            'deposit_id' => 'required|numeric',
            'rejection_reason' => 'required|min:10|max:500',
        ], [
            'rejection_reason.required' => 'دلیل رد الزامی است',
            'rejection_reason.min' => 'دلیل رد باید حداقل 10 کاراکتر باشد',
        ]);

        if ($validator->fails()) {
            $this->response->json([
                'success' => false,
                'message' => $validator->errors()[0]
            ]);
            return;
        }

        try {
            $depositId = (int)$data['deposit_id'];
            $deposit = $this->depositModel->find($depositId);

            if (!$deposit) {
                $this->response->json([
                    'success' => false,
                    'message' => 'واریز یافت نشد'
                ]);
                return;
            }

            if ($deposit->status !== 'pending' && $deposit->status !== 'under_review') {
                $this->response->json([
                    'success' => false,
                    'message' => 'این واریز قبلاً بررسی شده است'
                ]);
                return;
            }

            $updated = $this->depositModel->updateStatus(
                $depositId,
                'rejected',
                $data['rejection_reason'],
                $adminId
            );

            if ($updated) {
                // ثبت لاگ
                log_activity(
                    $adminId,
                    'manual_deposit_rejected',
                    "رد واریز دستی کاربر {$deposit->user_id}",
                    ['deposit_id' => $depositId, 'reason' => $data['rejection_reason']]
                );

                $this->response->json([
                    'success' => true,
                    'message' => 'واریز رد شد'
                ]);
            } else {
                throw new \RuntimeException('خطا در رد واریز');
            }

        } catch (\Exception $e) {
            logger()->error('Admin reject manual deposit failed', [
                'admin_id' => $adminId,
                'error' => $e->getMessage()
            ]);

            $this->response->json([
                'success' => false,
                'message' => 'خطا در رد واریز'
            ]);
        }
    }
}