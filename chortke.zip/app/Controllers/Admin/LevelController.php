<?php

namespace App\Controllers\Admin;

use App\Models\UserLevel;
use App\Models\UserLevelHistory;
use App\Services\UserLevelService;
use App\Middleware\PermissionMiddleware;
use Core\Validator;
use App\Controllers\Admin\BaseAdminController;

class LevelController extends BaseAdminController
{
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * لیست سطوح + آمار
     */
    public function index()
    {
        PermissionMiddleware::require('settings.view');

        $levelModel = new UserLevel();
        $levels = $levelModel->all(false);
        $userCounts = $levelModel->getUserCountPerLevel();

        log_activity('levels.view', 'مشاهده لیست سطوح');

        return view('admin.levels.index', [
            'levels' => $levels,
            'userCounts' => $userCounts,
        ]);
    }

    /**
     * فرم ویرایش سطح
     */
    public function edit()
    {
        PermissionMiddleware::require('settings.edit');

                $id = (int) $this->request->param('id');

        $levelModel = new UserLevel();
        $level = $levelModel->find($id);

        if (!$level) {
            \http_response_code(404);
            include __DIR__ . '/../../../views/errors/404.php';
            exit;
        }

        return view('admin.levels.edit', ['level' => $level]);
    }

    /**
     * ذخیره ویرایش
     */
    public function update()
    {
        PermissionMiddleware::require('settings.edit');

                        
        $id = (int) $this->request->param('id');

        if (!verify_csrf_token($this->request->post('csrf_token'))) {
            $this->session->setFlash('error', 'توکن امنیتی نامعتبر.');
            return redirect(url('/admin/levels/' . $id . '/edit'));
        }

        $validator = new Validator($this->request->all(), [
            'name' => 'required|min:2|max:50',
            'min_active_days' => 'required|numeric',
            'min_completed_tasks' => 'required|numeric',
            'min_total_earning' => 'required|numeric',
            'purchase_price_irt' => 'required|numeric',
            'earning_bonus_percent' => 'required|numeric',
        ]);

        if ($validator->fails()) {
            $this->session->setFlash('error', $validator->errors()[0] ?? 'خطا');
            $this->session->setFlash('old', $this->request->all());
            return redirect(url('/admin/levels/' . $id . '/edit'));
        }

        $data = $validator->data();
        $levelModel = new UserLevel();

        $levelModel->update($id, [
            'name' => $data->name,
            'icon' => $this->request->post('icon') ?? 'workspace_premium',
            'color' => $this->request->post('color') ?? '#c0c0c0',
            'min_active_days' => (int) $data->min_active_days,
            'min_completed_tasks' => (int) $data->min_completed_tasks,
            'min_total_earning' => (float) $data->min_total_earning,
            'min_total_earning_usdt' => (float) ($this->request->post('min_total_earning_usdt') ?? 0),
            'purchase_price_irt' => (float) $data->purchase_price_irt,
            'purchase_price_usdt' => (float) ($this->request->post('purchase_price_usdt') ?? 0),
            'purchase_duration_days' => (int) ($this->request->post('purchase_duration_days') ?? 30),
            'earning_bonus_percent' => (float) $data->earning_bonus_percent,
            'referral_bonus_percent' => (float) ($this->request->post('referral_bonus_percent') ?? 0),
            'daily_task_limit_bonus' => (int) ($this->request->post('daily_task_limit_bonus') ?? 0),
            'withdrawal_limit_bonus' => (float) ($this->request->post('withdrawal_limit_bonus') ?? 0),
            'priority_support' => $this->request->post('priority_support') ? 1 : 0,
            'special_badge' => $this->request->post('special_badge') ? 1 : 0,
            'is_active' => $this->request->post('is_active') ? 1 : 0,
        ]);

        log_activity('levels.update', 'ویرایش سطح', ['level_id' => $id, 'name' => $data->name]);

        $this->session->setFlash('success', 'سطح «' . e($data->name) . '» بروزرسانی شد.');
        return redirect(url('/admin/levels'));
    }

    /**
     * تغییر سطح کاربر توسط ادمین (Ajax)
     */
    public function changeUserLevel()
    {
        PermissionMiddleware::require('users.edit');

                
        $body = \json_decode(\file_get_contents('php://input'), true) ?? [];
        $userId = (int) ($body['user_id'] ?? 0);
        $newLevel = $body['level'] ?? '';
        $reason = $body['reason'] ?? 'تغییر توسط مدیر';

        if (!$userId || !$newLevel) {
            $this->response->json(['success' => false, 'message' => 'اطلاعات ناقص'], 422);
            return;
        }

        $levelService = new \App\Services\UserLevelService(
            new \App\Services\WalletService(),
            new \App\Services\ReferralCommissionService(new \App\Services\WalletService())
        );
        $changed = $levelService->adminChangeLevel($userId, $newLevel, $reason);

        if (!$changed) {
            $this->response->json(['success' => false, 'message' => 'خطا در تغییر سطح'], 500);
            return;
        }

        log_activity('levels.admin_change', 'تغییر سطح کاربر', [
            'user_id' => $userId,
            'new_level' => $newLevel,
            'reason' => $reason,
        ]);

        $this->response->json([
            'success' => true,
            'message' => 'سطح کاربر با موفقیت تغییر یافت.',
        ]);
    }

    /**
     * لیست تاریخچه تغییرات سطح
     */
    public function history()
    {
        PermissionMiddleware::require('settings.view');

                $historyModel = new UserLevelHistory();
        $levelModel = new UserLevel();

        $filters = [
            'change_type' => $this->request->get('change_type'),
            'to_level' => $this->request->get('to_level'),
            'user_id' => $this->request->get('user_id'),
        ];

        $page = \max(1, (int) $this->request->get('page', 1));
        $limit = 30;
        $offset = ($page - 1) * $limit;

        $items = $historyModel->adminList($filters, $limit, $offset);
        $total = $historyModel->adminCount($filters);
        $levels = $levelModel->all(false);

        return view('admin.levels.user-levels', [
            'items' => $items,
            'total' => $total,
            'page' => $page,
            'pages' => \ceil($total / $limit),
            'filters' => $filters,
            'levels' => $levels,
        ]);
    }
}