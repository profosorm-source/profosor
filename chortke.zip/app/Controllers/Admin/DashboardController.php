<?php

namespace App\Controllers\Admin;

use Core\Database;
use App\Controllers\Admin\BaseAdminController;

class DashboardController extends BaseAdminController
{
    private Database $db;

   public function __construct()
    {
        parent::__construct();
    }

    public function index(): void
    {
        $userId = $this->userId();
        if (!$userId) {
            $this->session->setFlash('error', 'لطفاً وارد شوید.');
            redirect('/admin/login');
            return;
        }

        // بازیابی اطلاعات یا آمار ادمین
        $stats = [
            'users' => 0,
            'tasks' => 0,
        ];

        // نمایش ویو داشبورد
        view('admin/dashboard', [
            'title' => 'داشبورد مدیریت',
            'stats' => $stats
        ]);
    }

    /**
     * نمایش فرم ورود ادمین
     */
    public function loginForm(): void
    {
        // اگر کاربر قبلاً لاگین کرده، مستقیم به داشبورد بره
        if ($this->userId() && $this->session->get('role') === 'admin') {
            echo json_encode([
                'status' => 'success',
                'redirect' => '/admin/dashboard'
            ]);
            return;
        }

        // ارسال ویو به صورت HTML
        view('admin/login', [
            'title' => 'ورود ادمین'
        ]);
    }

    /**
     * پردازش ورود ادمین با پاسخ JSON
     */
    public function login(): void
    {
        header('Content-Type: application/json');

        $email = $_POST['email'] ?? '';
        $password = $_POST['password'] ?? '';

        if (!$email || !$password) {
            echo json_encode([
                'status' => 'error',
                'message' => 'تمام فیلدها باید پر شوند.'
            ]);
            return;
        }

        // جستجوی کاربر با ایمیل و نقش ادمین
        $user = $this->db->query(
            "SELECT * FROM users WHERE email = ? AND role = 'admin' LIMIT 1",
            [$email]
        )->fetch();
		
$user = (array) $user; // حالا $user آرایه شده

       if (!$user || !password_verify($password, $user->password)) {
            echo json_encode([
                'status' => 'error',
                'message' => 'ایمیل یا رمز عبور اشتباه است.'
            ]);
            return;
        }

        // ذخیره اطلاعات در سشن
        $this->session->set('user_id', $user->id);
        $this->session->set('role', $user->role);

        echo json_encode([
            'status' => 'success',
            'message' => 'ورود موفقیت‌آمیز بود.',
            'redirect' => '/admin/dashboard'
        ]);
    }

    /**
     * خروج ادمین با پاسخ JSON
     */
    public function logout(): void
    {
        header('Content-Type: application/json');

        $this->session->destroy();

        echo json_encode([
            'status' => 'success',
            'message' => 'شما از سیستم خارج شدید.',
            'redirect' => '/admin/login'
        ]);
    }
}
