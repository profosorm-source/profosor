<?php

namespace App\Controllers\Admin;

use Core\Database;
use Core\Request;
use Core\Response;
use Core\Scheduler;
use App\Services\EmailService;
use App\Models\EmailQueue;

// ─────────────────────────────────────────
// CronController
// ─────────────────────────────────────────
class CronController
{
    public function index(): void
    {
        view('admin.cron.index', ['title' => 'مدیریت Cron Jobs']);
    }

    /** اجرای دستی از پنل ادمین */
    public function run(): void
    {
        $response = new Response();

        // اجرای cron.php به صورت CLI
        ob_start();
        $_SERVER['argv'] = ['cron.php'];
        require BASE_PATH . '/cron.php';
        ob_get_clean();

        // ریدایرکت به نتایج parse شده
        // چون cron.php exit نمی‌کند، نتایج رو از Scheduler جدید می‌گیریم
        $scheduler = new Scheduler();
        $results   = $scheduler->run();

        $response->json(['results' => $results]);
    }
}

// ─────────────────────────────────────────
// EmailQueueController (Admin)
// ─────────────────────────────────────────
class EmailQueueController
{
    private EmailQueue $model;
    private Database $db;

    public function __construct()
    {
        $this->model = new EmailQueue();
        $this->db    = Database::getInstance();
    }

    public function index(): void
    {
        $request = new Request();
        $page    = max(1, (int)($request->get('page') ?? 1));
        $perPage = 30;
        $offset  = ($page - 1) * $perPage;

        $filters = [];
        $where   = 'WHERE 1=1';
        $params  = [];

        if ($status = $request->get('status')) {
            $where    .= ' AND status = ?';
            $params[]  = $status;
        }
        if ($search = $request->get('search')) {
            $where    .= ' AND (to_email LIKE ? OR subject LIKE ?)';
            $params[]  = "%$search%";
            $params[]  = "%$search%";
        }

        $emails = $this->db->fetchAll(
            "SELECT * FROM email_queue $where ORDER BY created_at DESC LIMIT ? OFFSET ?",
            [...$params, $perPage, $offset]
        );
        $total = (int)$this->db->fetchColumn(
            "SELECT COUNT(*) FROM email_queue $where", $params
        );
        $stats = $this->model->getStats();

        view('admin.email-queue.index', [
            'title'      => 'صف ایمیل',
            'emails'     => $emails,
            'stats'      => $stats,
            'total'      => $total,
            'page'       => $page,
            'totalPages' => (int)ceil($total / $perPage),
        ]);
    }

    public function process(): void
    {
        $response = new Response();
        $service  = new EmailService();
        $result   = $service->processQueue(20);
        $response->json($result);
    }

    public function retryFailed(): void
    {
        $response = new Response();
        $count = $this->db->query(
            "UPDATE email_queue SET status = 'pending', attempts = 0, error_message = NULL
             WHERE status = 'failed'",
        );
        (new Response())->json(['success' => true, 'count' => $count]);
    }

    public function retry(): void
    {
        $request  = new Request();
        $response = new Response();
        $id       = (int)$request->param('id');

        $ok = $this->db->query(
            "UPDATE email_queue SET status = 'pending', attempts = 0
             WHERE id = ? AND status IN ('failed','pending')",
            [$id]
        );
        $response->json(['success' => (bool)$ok, 'message' => $ok ? 'آماده تلاش مجدد' : 'یافت نشد']);
    }
}

// ─────────────────────────────────────────
// ApiTokenAdminController
// ─────────────────────────────────────────
class ApiTokenAdminController
{
    private Database $db;

    public function __construct()
    {
        $this->db = Database::getInstance();
    }

    public function index(): void
    {
        $request = new Request();
        $page    = max(1, (int)($request->get('page') ?? 1));
        $perPage = 30;
        $offset  = ($page - 1) * $perPage;

        $where  = 'WHERE 1=1';
        $params = [];

        if ($search = $request->get('search')) {
            $where    .= ' AND (at.name LIKE ? OR u.email LIKE ?)';
            $params[]  = "%$search%";
            $params[]  = "%$search%";
        }

        $statusFilter = $request->get('status');
        if ($statusFilter === 'active') {
            $where .= ' AND at.revoked = 0 AND (at.expires_at IS NULL OR at.expires_at > NOW())';
        } elseif ($statusFilter === 'revoked') {
            $where .= ' AND at.revoked = 1';
        } elseif ($statusFilter === 'expired') {
            $where .= ' AND at.revoked = 0 AND at.expires_at < NOW()';
        }

        $tokens = $this->db->fetchAll(
            "SELECT at.*, u.full_name, u.email
             FROM api_tokens at
             LEFT JOIN users u ON u.id = at.user_id
             $where
             ORDER BY at.created_at DESC
             LIMIT ? OFFSET ?",
            [...$params, $perPage, $offset]
        );

        $total = (int)$this->db->fetchColumn(
            "SELECT COUNT(*) FROM api_tokens at LEFT JOIN users u ON u.id = at.user_id $where",
            $params
        );

        $stats = [
            'active'     => (int)$this->db->fetchColumn("SELECT COUNT(*) FROM api_tokens WHERE revoked = 0 AND (expires_at IS NULL OR expires_at > NOW())"),
            'revoked'    => (int)$this->db->fetchColumn("SELECT COUNT(*) FROM api_tokens WHERE revoked = 1"),
            'expired'    => (int)$this->db->fetchColumn("SELECT COUNT(*) FROM api_tokens WHERE revoked = 0 AND expires_at < NOW()"),
            'used_today' => (int)$this->db->fetchColumn("SELECT COUNT(*) FROM api_tokens WHERE DATE(last_used_at) = CURDATE()"),
        ];

        view('admin.api-tokens.index', [
            'title'  => 'توکن‌های API',
            'tokens' => $tokens,
            'total'  => $total,
            'stats'  => $stats,
        ]);
    }

    public function revoke(): void
    {
        $request  = new Request();
        $response = new Response();
        $id       = (int)$request->param('id');

        $ok = $this->db->query(
            "UPDATE api_tokens SET revoked = 1, revoked_at = NOW() WHERE id = ?",
            [$id]
        );
        $response->json(['success' => (bool)$ok, 'message' => $ok ? 'باطل شد' : 'یافت نشد']);
    }

    public function revokeExpired(): void
    {
        $count = $this->db->query(
            "UPDATE api_tokens SET revoked = 1, revoked_at = NOW()
             WHERE revoked = 0 AND expires_at < NOW()"
        );
        (new Response())->json(['success' => true, 'count' => $count]);
    }
}

// ─────────────────────────────────────────
// CacheAdminController
// ─────────────────────────────────────────
class CacheAdminController
{
    public function index(): void
    {
        $cacheDir = BASE_PATH . '/storage/cache/app/';
        $files    = glob($cacheDir . '*.cache') ?: [];

        $totalFiles   = count($files);
        $validFiles   = 0;
        $expiredFiles = 0;
        $totalBytes   = 0;
        $keys         = [];

        foreach ($files as $file) {
            $raw  = @file_get_contents($file);
            $data = $raw ? @unserialize($raw) : null;
            if (!$data) continue;

            $totalBytes += filesize($file);
            $isExpired   = $data['expire_at'] < time();

            if ($isExpired) $expiredFiles++;
            else            $validFiles++;

            // Try to get key from filename (we store md5 only, so show hash)
            $keys[] = (object)[
                'key'        => basename($file, '.cache'),
                'expire_at'  => $data['expire_at'],
                'size_bytes' => filesize($file),
            ];
        }

        // Add known named keys from Cache class
        $cache = \Core\Cache::getInstance();
        $namedKeys = ['settings_all', 'kpi_dashboard_summary', 'kpi_weekly_report'];
        $knownKeys = [];
        foreach ($namedKeys as $k) {
            if ($cache->has($k)) {
                $knownKeys[] = (object)[
                    'key'        => $k,
                    'expire_at'  => time() + 600, // approximate
                    'size_bytes' => 0,
                ];
            }
        }

        view('admin.cache.index', [
            'title' => 'مدیریت Cache',
            'stats' => [
                'total_files'   => $totalFiles,
                'valid_files'   => $validFiles,
                'expired_files' => $expiredFiles,
                'total_size_kb' => round($totalBytes / 1024, 1),
                'keys'          => array_merge($knownKeys, array_slice($keys, 0, 50)),
            ],
        ]);
    }

    public function clear(): void
    {
        $request  = new Request();
        $response = new Response();
        $body     = $request->body();
        $type     = $body['type'] ?? 'all';
        $cache    = \Core\Cache::getInstance();

        $cleared = 0;
        if ($type === 'settings') {
            $cache->forget('settings_all');
            (new \App\Models\Setting())->clearCache();
            $cleared = 1;
        } elseif ($type === 'kpi') {
            $cache->forget('kpi_dashboard_summary');
            $cache->forget('kpi_weekly_report');
            $cleared = 2;
        } else {
            $cache->flush();
            $cleared = 'همه';
        }

        $response->json(['success' => true, 'message' => "Cache پاک شد ({$cleared} آیتم)"]);
    }

    public function forget(): void
    {
        $request = new Request();
        $body    = $request->body();
        $key     = $body['key'] ?? '';

        if ($key) {
            \Core\Cache::getInstance()->forget($key);
        }

        (new Response())->json(['success' => true]);
    }
}
