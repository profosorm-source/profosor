<?php

namespace App\Controllers\Admin;

use Core\Database;
use Core\Validator;
use App\Controllers\BaseController;

class AuthController extends BaseController
{
    private Database $db;

    public function __construct()
    {
        parent::__construct();
        $this->db = Database::getInstance();
    }

    /**
     * نمایش صفحه ورود ادمین
     */
    public function showLogin(): void
    {
        view('admin/login', ['title' => 'ورود به پنل مدیریت']);
    }

    /**
     * ورود ادمین
     */
    public function login(): void
    {
		
        $data = $this->request->all();

        // اعتبارسنجی
        $validator = new Validator($data, [
            'email' => 'required|email',
            'password' => 'required|min:6',
        ]);

        if ($validator->fails()) {
			  log_activity(
        'auth.login.invalid_input',
        'ورود ناموفق (ورودی نامعتبر)',
        null,
        ['email' => $data['email'] ?? null]
    );
            $this->session->setFlash('errors', $validator->errors());
            $this->session->setFlash('old', $data);
            redirect('/admin/login');
            return;
        }

        // بررسی کاربر
        $user = $this->db->query(
            "SELECT * FROM users WHERE email = ? LIMIT 1",
            [$data['email']]
        )->fetch();

       if (!$user) {
    $this->session->setFlash('error', 'ایمیل یا رمز عبور اشتباه است');
    $this->session->setFlash('old', $data);

    log_activity(
        'auth.login.invalid_input',
        'ورود ناموفق (ورودی نامعتبر)',
        null,
        ['email' => $data['email'] ?? null]
    );

    redirect('/admin/login');
    return;
}

        // بررسی نقش
        if ($user->role !== 'admin' && $user->role !== 'support') {
            $this->session->setFlash('error', 'شما دسترسی به پنل مدیریت ندارید');
			$attemptEmail = $data['email'] ?? null;
			log_activity(
    'auth.login.failed',
    'ورود ناموفق به پنل مدیریت',
    null,
    ['email' => ($data['email'] ?? null)]
);
            redirect('/admin/login');
            return;
        }

        // بررسی رمز عبور
        if (!verify_password($data['password'], $user->password)) {
            $this->session->setFlash('error', 'ایمیل یا رمز عبور اشتباه است');
            $this->session->setFlash('old', $data);
            redirect('/admin/login');
            return;
        }

        // بررسی وضعیت
        if ($user->status !== 'active') {
            $this->session->setFlash('error', 'حساب کاربری شما غیرفعال است');
            redirect('/admin/login');
            return;
        }

        // ذخیره در Session
        $this->session->set('user_id', $user->id);
        $this->session->set('user_email', $user->email);
        $this->session->set('user_role', $user->role);
		$this->session->set('is_admin', $user->role === 'admin');

        // بروزرسانی آخرین ورود
        $this->db->query(
            "UPDATE users SET last_login = NOW() WHERE id = ?",
            [$user->id]
        );

        // لاگ فعالیت
        if (function_exists('log_activity')) {
            log_activity('admin_login', 'ورود به پنل مدیریت');
        }

        // هدایت
        $this->session->setFlash('success', 'خوش آمدید به پنل مدیریت');
// ورود موفق ادمین
if (($user->role ?? '') === 'admin') {
	    log_activity(
    'auth.login.success',
    'ورود موفق به پنل مدیریت',
    (int)$user->id,
    ['email' => $user->email]
);
}
        redirect('/admin/dashboard');
    }

    /**
     * خروج از پنل
     */
    public function logout(): void
    {
        $this->session->destroy();
        $this->session->setFlash('success', 'با موفقیت خارج شدید');
        redirect('/admin/login');
    }
}
