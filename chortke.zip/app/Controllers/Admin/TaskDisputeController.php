<?php
// app/Controllers/Admin/TaskDisputeController.php

namespace App\Controllers\Admin;

use App\Models\TaskDispute;
use App\Models\TaskExecution;
use App\Models\Advertisement;
use App\Services\TaskDisputeService;
use App\Controllers\Admin\BaseAdminController;

class TaskDisputeController extends BaseAdminController
{
    private TaskDisputeService $service;

    public function __construct()
    {
        parent::__construct();
        $this->service = new TaskDisputeService();
    }

    /**
     * لیست اختلافات
     */
    public function index()
    {
        $page = (int) ($_GET['page'] ?? 1);
        $limit = 30;
        $offset = ($page - 1) * $limit;

        $filters = [];
        if (!empty($_GET['status'])) $filters['status'] = $_GET['status'];

        $disputes = (new \App\Models\TaskDispute())->getAll($filters, $limit, $offset);
        $total = (new \App\Models\TaskDispute())->countAll($filters);
        $totalPages = \ceil($total / $limit);

        return view('admin.task-disputes.index', [
            'disputes'   => $disputes,
            'filters'    => $filters,
            'page'       => $page,
            'totalPages' => $totalPages,
            'total'      => $total,
        ]);
    }

    /**
     * جزئیات اختلاف
     */
    public function show()
    {
                $id = (int) $this->request->param('id');

        $dispute = (new \App\Models\TaskDispute())->find($id);
        if (!$dispute) {
            $this->session->setFlash('error', 'اختلاف یافت نشد.');
            return redirect(url('/admin/task-disputes'));
        }

        $execution = (new \App\Models\TaskExecution())->find($dispute->execution_id);
        $task = (new \App\Models\Advertisement())->find($dispute->advertisement_id);

        return view('admin.task-disputes.show', [
            'dispute'   => $dispute,
            'execution' => $execution,
            'task'      => $task,
        ]);
    }

    /**
     * داوری به نفع انجام‌دهنده — Ajax
     */
    public function resolveForExecutor(): void
    {
        $id = (int) $this->request->param('id');

        $body          = $this->request->body();
        $decision      = $body['decision'] ?? '';
        $penaltyAmount = (float) ($body['penalty_amount'] ?? 0);

        if (empty($decision)) {
            $this->response->json(['success' => false, 'message' => 'توضیح تصمیم الزامی است.']);
            return;
        }

        $result = $this->service->resolveForExecutor($id, user_id(), $decision, $penaltyAmount);

        log_activity('dispute_resolve', 'داوری اختلاف #' . $id . ' به نفع انجام‌دهنده', $id, 'task_dispute');

        $this->response->json($result);
    }

    /**
     * داوری به نفع تبلیغ‌دهنده — Ajax
     */
    public function resolveForAdvertiser(): void
    {
        $id = (int) $this->request->param('id');

        $body          = $this->request->body();
        $decision      = $body['decision'] ?? '';
        $penaltyAmount = (float) ($body['penalty_amount'] ?? 0);

        if (empty($decision)) {
            $this->response->json(['success' => false, 'message' => 'توضیح تصمیم الزامی است.']);
            return;
        }

        $result = $this->service->resolveForAdvertiser($id, user_id(), $decision, $penaltyAmount);

        log_activity('dispute_resolve', 'داوری اختلاف #' . $id . ' به نفع تبلیغ‌دهنده', $id, 'task_dispute');

        $this->response->json($result);
    }
}