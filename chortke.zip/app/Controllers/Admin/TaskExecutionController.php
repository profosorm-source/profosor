<?php
// app/Controllers/Admin/TaskExecutionController.php

namespace App\Controllers\Admin;

use App\Models\TaskExecution;
use App\Models\Advertisement;
use App\Services\TaskExecutionService;
use App\Controllers\Admin\BaseAdminController;

class TaskExecutionController extends BaseAdminController
{
    private TaskExecutionService $service;

    public function __construct()
    {
        parent::__construct();
        $this->service = new TaskExecutionService(new \App\Services\WalletService());
    }

    /**
     * لیست تمام اجراها
     */
    public function index()
    {
        $page = (int) ($_GET['page'] ?? 1);
        $limit = 30;
        $offset = ($page - 1) * $limit;

        $filters = [];
        if (!empty($_GET['status'])) $filters['status'] = $_GET['status'];
        if (!empty($_GET['search'])) $filters['search'] = $_GET['search'];
        if (!empty($_GET['ad_id'])) $filters['advertisement_id'] = (int) $_GET['ad_id'];

        $executions = (new \App\Models\TaskExecution())->getAll($filters, $limit, $offset);
        $total = (new \App\Models\TaskExecution())->countAll($filters);
        $totalPages = \ceil($total / $limit);

        return view('admin.task-executions.index', [
            'executions' => $executions,
            'filters'    => $filters,
            'page'       => $page,
            'totalPages' => $totalPages,
            'total'      => $total,
        ]);
    }

    /**
     * جزئیات اجرا
     */
    public function show()
    {
                $id = (int) $this->request->param('id');

        $execution = (new \App\Models\TaskExecution())->find($id);
        if (!$execution) {
            $this->session->setFlash('error', 'رکورد یافت نشد.');
            return redirect(url('/admin/task-executions'));
        }

        $task = (new \App\Models\Advertisement())->find($execution->advertisement_id);

        // اختلاف مرتبط
        $dispute = (new \App\Models\TaskDispute())->findByExecution($id);

        return view('admin.task-executions.show', [
            'execution' => $execution,
            'task'      => $task,
            'dispute'   => $dispute,
        ]);
    }

    /**
     * تایید توسط ادمین — Ajax
     */
    public function approve(): void
    {
        $id = (int) $this->request->param('id');

        $result = $this->service->approveByAdmin($id, user_id());

        log_activity('task_exec_approve', 'تایید اجرای تسک #' . $id, $id, 'task_execution');

        $this->response->json($result);
    }

    /**
     * رد توسط ادمین — Ajax
     */
    public function reject(): void
    {
        $id = (int) $this->request->param('id');

        $body   = $this->request->body();
        $reason = $body['reason'] ?? '';

        if (empty($reason)) {
            $this->response->json(['success' => false, 'message' => 'دلیل رد الزامی است.']);
            return;
        }

        $result = $this->service->rejectByAdmin($id, user_id(), $reason);

        log_activity('task_exec_reject', 'رد اجرای تسک #' . $id . ': ' . $reason, $id, 'task_execution');

        $this->response->json($result);
    }
}