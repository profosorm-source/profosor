<?php
// app/Controllers/Admin/SEOKeywordController.php

namespace App\Controllers\Admin;

use App\Models\SEOKeyword;
use App\Models\SEOExecution;
use Core\Validator;
use App\Controllers\Admin\BaseAdminController;

class SEOKeywordController extends BaseAdminController
{

    public function __construct()
    {
        parent::__construct();
    }

    public function index()
    {
        $page = (int) ($_GET['page'] ?? 1);
        $limit = 30;
        $offset = ($page - 1) * $limit;
        $filters = [];
        if (isset($_GET['is_active']) && $_GET['is_active'] !== '') $filters['is_active'] = $_GET['is_active'];
        if (!empty($_GET['search'])) $filters['search'] = $_GET['search'];

        $keywords = (new \App\Models\SEOKeyword())->getAll($filters, $limit, $offset);
        $total = (new \App\Models\SEOKeyword())->countAll($filters);
        $totalPages = \ceil($total / $limit);
        $stats = (new \App\Models\SEOKeyword())->getStats();

        return view('admin.seo-keywords.index', [
            'keywords'   => $keywords, 'filters' => $filters, 'stats' => $stats,
            'page' => $page, 'totalPages' => $totalPages, 'total' => $total,
        ]);
    }

    public function showCreate()
    {
        $currency = setting('currency_mode') ?? 'irt';
        return view('admin.seo-keywords.create', ['currency' => $currency]);
    }

    public function store()
    {
                $data = $this->request->body();

        $validator = new Validator($data, [
            'keyword'    => 'required|string|min:2|max:255',
            'target_url' => 'required|string|max:500',
        ]);

        if ($validator->fails()) {
            $this->session->setFlash('error', $validator->errors()[0] ?? 'خطا');
            return redirect(url('/admin/seo-keywords/create'));
        }

        $data['created_by'] = user_id();
        $data['currency'] = setting('currency_mode') ?? 'irt';

        $keyword = (new \App\Models\SEOKeyword())->create($data);
        if ($keyword) {
            log_activity('seo_keyword_create', 'ایجاد کلمه: ' . $data['keyword'], $keyword->id, 'seo_keyword');
            $this->session->setFlash('success', 'کلمه کلیدی با موفقیت ایجاد شد.');
            return redirect(url('/admin/seo-keywords'));
        }

        $this->session->setFlash('error', 'خطا در ایجاد.');
        return redirect(url('/admin/seo-keywords/create'));
    }

    public function showEdit()
    {
                $id = (int) $this->request->param('id');
        $keyword = (new \App\Models\SEOKeyword())->find($id);
        if (!$keyword) {
            $this->session->setFlash('error', 'یافت نشد.');
            return redirect(url('/admin/seo-keywords'));
        }
        return view('admin.seo-keywords.edit', ['keyword' => $keyword]);
    }

    public function update()
    {
                $id = (int) $this->request->param('id');
        $data = $this->request->body();

        $validator = new Validator($data, [
            'keyword'    => 'required|string|min:2|max:255',
            'target_url' => 'required|string|max:500',
        ]);

        if ($validator->fails()) {
            $this->session->setFlash('error', $validator->errors()[0] ?? 'خطا');
            return redirect(url('/admin/seo-keywords/' . $id . '/edit'));
        }

        (new \App\Models\SEOKeyword())->update($id, $data);
        log_activity('seo_keyword_update', 'ویرایش کلمه #' . $id, $id, 'seo_keyword');
        $this->session->setFlash('success', 'بروزرسانی شد.');
        return redirect(url('/admin/seo-keywords'));
    }

    public function toggleActive()
    {
                        $id = (int) $this->request->param('id');
        $keyword = (new \App\Models\SEOKeyword())->find($id);
        if (!$keyword) return $this->response->json(['success' => false, 'message' => 'یافت نشد.']);

        (new \App\Models\SEOKeyword())->update($id, ['is_active' => $keyword->is_active ? 0 : 1]);
        log_activity('seo_keyword_toggle', ($keyword->is_active ? 'غیرفعال' : 'فعال') . ' کلمه #' . $id, $id, 'seo_keyword');
        return $this->response->json(['success' => true, 'message' => 'وضعیت تغییر کرد.']);
    }

    public function delete()
    {
                        $id = (int) $this->request->param('id');
        (new \App\Models\SEOKeyword())->softDelete($id);
        log_activity('seo_keyword_delete', 'حذف کلمه #' . $id, $id, 'seo_keyword');
        return $this->response->json(['success' => true, 'message' => 'حذف شد.']);
    }
}