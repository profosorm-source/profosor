<?php

namespace App\Controllers\Admin;

use App\Services\AuditTrail;
use App\Services\ExportService;
use App\Controllers\Admin\BaseAdminController;

class AuditTrailController extends BaseAdminController
{
    public function __construct()
    {
        parent::__construct();
    }

    public function index(): void
    {
                $page    = max(1, (int)($this->request->get('page') ?? 1));

        $result     = AuditTrail::getAll(
            page:    $page,
            perPage: 50,
            event:   $this->request->get('event')   ?: null,
            userId:  $this->request->get('user_id') ? (int)$this->request->get('user_id') : null,
            search:  $this->request->get('search')  ?: null,
        );
        $eventTypes = AuditTrail::getEventTypes();

        view('admin.audit-trail.index', [
            'title'      => 'Audit Trail',
            'result'     => $result,
            'eventTypes' => $eventTypes,
        ]);
    }

    public function export(): void
    {
                $filters = array_filter([
            'event'  => $this->request->get('event'),
            'from'   => $this->request->get('from'),
            'to'     => $this->request->get('to'),
            'user_id'=> $this->request->get('user_id'),
        ]);
        (new ExportService())->exportAuditTrail($filters);
    }
}
