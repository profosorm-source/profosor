<?php

namespace App\Controllers\Admin;

use App\Models\SystemSetting;
use Core\Validator;
use App\Controllers\Admin\BaseAdminController;

class SystemSettingController extends BaseAdminController
{
    private SystemSetting $settingModel;
    
    public function __construct()
    {
        parent::__construct();
        $this->settingModel = new SystemSetting();
    }
    
    /**
     * نمایش تنظیمات
     */
    public function index()
    {
        $category = $_GET['category'] ?? 'general';
        
        $settings = $this->settingModel->getByCategory($category);
        
        $categories = [
            'general' => 'عمومی',
            'task' => 'تسک‌ها',
            'wallet' => 'کیف پول',
            'security' => 'امنیت',
            'contact' => 'تماس'
        ];
        
        return view('admin/settings/index', [
            'settings' => $settings,
            'categories' => $categories,
            'currentCategory' => $category
        ]);
    }
    
    /**
     * بروزرسانی تنظیم
     */
   public function update(): void
{
    
    $raw  = \file_get_contents('php://input');
    $data = \json_decode($raw, true);

    if (!\is_array($data)) {
        $this->response->json(['success' => false, 'message' => 'بدنه JSON نامعتبر است.'], 422);
        return;
    }

    $id    = (int)($data['id'] ?? 0);
    $key   = \trim((string)($data['key'] ?? ''));
    $value = (string)($data['value'] ?? '');

    if ($id <= 0 || $key === '') {
        $this->response->json(['success' => false, 'message' => 'درخواست نامعتبر است.'], 422);
        return;
    }

    $service = new \App\Services\SettingService();

    $ok = $service->updateById($id, $key, $value);

    if (!$ok) {
        $this->response->json([
            'success' => false,
            'message' => 'تنظیمات یافت نشد یا کلید معتبر نیست.'
        ], 400);
        return;
    }

    // ✅ اینجا بهترین جای clearCache است
    $service->clearCache();

    // اگر helper settings() کش داخل-request دارد
    if (\function_exists('settings')) {
        settings(true);
    }

    $this->response->json([
        'success' => true,
        'message' => 'تنظیمات ذخیره شد.'
    ]);
}

}