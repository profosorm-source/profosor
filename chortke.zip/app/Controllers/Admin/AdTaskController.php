<?php
// app/Controllers/Admin/AdTaskController.php

namespace App\Controllers\Admin;

use App\Models\Advertisement;
use App\Services\AdTaskService;
use App\Controllers\Admin\BaseAdminController;

class AdTaskController extends BaseAdminController
{
    private AdTaskService $service;

    public function __construct()
    {
        parent::__construct();
        $this->service = new AdTaskService();
    }

    /**
     * لیست تمام تسک‌ها
     */
    public function index()
    {
        $page = (int) ($_GET['page'] ?? 1);
        $limit = 30;
        $offset = ($page - 1) * $limit;

        $filters = [];
        if (!empty($_GET['status'])) $filters['status'] = $_GET['status'];
        if (!empty($_GET['platform'])) $filters['platform'] = $_GET['platform'];
        if (!empty($_GET['task_type'])) $filters['task_type'] = $_GET['task_type'];
        if (!empty($_GET['search'])) $filters['search'] = $_GET['search'];

        $tasks = (new \App\Models\Advertisement())->getAll($filters, $limit, $offset);
        $total = (new \App\Models\Advertisement())->countAll($filters);
        $totalPages = \ceil($total / $limit);

        $stats = (new \App\Models\Advertisement())->getStats();

        return view('admin.ad-tasks.index', [
            'tasks'      => $tasks,
            'filters'    => $filters,
            'stats'      => $stats,
            'page'       => $page,
            'totalPages' => $totalPages,
            'total'      => $total,
        ]);
    }

    /**
     * جزئیات تسک
     */
    public function show()
    {
                $id = (int) $this->request->param('id');

        $task = (new \App\Models\Advertisement())->find($id);
        if (!$task) {
            $this->session->setFlash('error', 'تسک یافت نشد.');
            return redirect(url('/admin/ad-tasks'));
        }

        // انجام‌شده‌ها
        $executions = (new \App\Models\TaskExecution())->getAll(
            ['advertisement_id' => $id], 50, 0
        );

        return view('admin.ad-tasks.show', [
            'task'       => $task,
            'executions' => $executions,
        ]);
    }

    /**
     * تایید تسک — Ajax
     */
    public function approve(): void
    {
        $id = (int) $this->request->param('id');

        $result = $this->service->approve($id, user_id());

        log_activity('ad_task_approve', 'تایید تسک #' . $id, $id, 'ad_task');

        $this->response->json($result);
    }

    /**
     * رد تسک — Ajax
     */
    public function reject(): void
    {
        $id = (int) $this->request->param('id');

        $body   = $this->request->body();
        $reason = $body['reason'] ?? '';

        if (empty($reason)) {
            $this->response->json(['success' => false, 'message' => 'دلیل رد الزامی است.']);
            return;
        }

        $result = $this->service->reject($id, user_id(), $reason);

        log_activity('ad_task_reject', 'رد تسک #' . $id . ': ' . $reason, $id, 'ad_task');

        $this->response->json($result);
    }
}