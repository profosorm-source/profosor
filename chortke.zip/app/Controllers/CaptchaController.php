<?php

namespace App\Controllers;

use App\Controllers\BaseController;

class CaptchaController extends BaseController
{
    public function __construct()
    {
        parent::__construct();
    }

    public function behavioralPing(): void
{
    // فقط AJAX
    $isAjax = isset($_SERVER['HTTP_X_REQUESTED_WITH']) &&
        strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest';

    if (!$isAjax) {
        $this->json(['success' => false, 'message' => 'Bad request'], 400);
    }

    // token از POST (چون Request::input اینجا خالی می‌داد)
    $token = (string) ($_POST['captcha_token'] ?? '');
    $token = trim($token);

    if ($token === '') {
        $this->json(['success' => false, 'message' => 'Token missing'], 422);
    }

    $key = "captcha_{$token}";
    $data = $this->session->get($key);

    if (!$data || !is_array($data)) {
        $this->json(['success' => false, 'message' => 'Captcha not found'], 404);
    }

    if (($data['type'] ?? '') !== 'behavioral') {
        $this->json(['success' => false, 'message' => 'Invalid captcha type'], 400);
    }

    // throttle ساده
    $now = time();
    $last = (int) ($data['last_ping_at'] ?? 0);
    if ($last > 0 && ($now - $last) < 1) {
        $this->json([
            'success' => true,
            'interactions' => (int) ($data['interactions'] ?? 0)
        ]);
    }

    $data['interactions'] = (int) ($data['interactions'] ?? 0) + 1;
    $data['last_interaction_at'] = $now;
    $data['last_ping_at'] = $now;

    $this->session->set($key, $data);

    $this->json([
        'success' => true,
        'interactions' => $data['interactions']
    ]);
}
	
	private function json(array $data, int $status = 200): void
{
    http_response_code($status);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}
}