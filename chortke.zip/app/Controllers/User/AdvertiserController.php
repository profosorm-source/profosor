<?php

namespace App\Controllers\User;

use App\Services\AdvertiserDashboardService;
use App\Services\TaskExecutionService;
use App\Models\Advertisement;
use App\Controllers\User\BaseUserController;

/**
 * AdvertiserController - داشبورد کامل آگهی‌دهنده
 *
 * Routes:
 *   GET  /advertiser                → داشبورد اصلی
 *   GET  /advertiser/campaigns      → لیست کمپین‌ها
 *   GET  /advertiser/analytics      → آنالیتیک پیشرفته
 *   GET  /advertiser/reviews        → بررسی اجراها
 *   POST /advertiser/reviews/{id}/approve
 *   POST /advertiser/reviews/{id}/reject
 *   GET  /advertiser/chart-data     → داده JSON برای نمودار
 */
class AdvertiserController extends BaseUserController
{
    private AdvertiserDashboardService $dashService;
    private TaskExecutionService $execService;

    public function __construct()
    {
        parent::__construct();
        $this->dashService = new AdvertiserDashboardService();
        $this->execService = new TaskExecutionService();
    }

    // ─────────────────────────────────────────────────────────
    //  داشبورد اصلی
    // ─────────────────────────────────────────────────────────

    public function index(): void
    {
        $userId = (int)user_id();

        $summary        = $this->dashService->getSummary($userId);
        $pendingReviews = $this->dashService->getPendingReviews($userId, 5);
        $recentExecs    = $this->dashService->getRecentExecutions($userId, 8);
        $platformData   = $this->dashService->getPlatformBreakdown($userId);
        $pendingCount   = $this->dashService->countPendingReviews($userId);

        view('user.advertiser.dashboard', [
            'title'          => 'داشبورد تبلیغ‌دهنده',
            'summary'        => $summary,
            'pendingReviews' => $pendingReviews,
            'recentExecs'    => $recentExecs,
            'platformData'   => $platformData,
            'pendingCount'   => $pendingCount,
        ]);
    }

    // ─────────────────────────────────────────────────────────
    //  لیست کمپین‌ها با فیلتر
    // ─────────────────────────────────────────────────────────

    public function campaigns(): void
    {
        $userId  = (int)user_id();
        
        $page    = max(1, (int)($this->request->get('page') ?? 1));
        $perPage = 20;
        $offset  = ($page - 1) * $perPage;
        $status  = $this->request->get('status') ?? '';

        $adModel   = new Advertisement();
        $campaigns = $adModel->getByAdvertiser($userId, $perPage, $offset);

        // آمار هر کمپین از طریق join
        $performance = $this->dashService->getCampaignPerformance($userId, 100);
        $perfById    = [];
        foreach ($performance as $p) {
            $p = (array)$p;
            $perfById[$p['id']] = $p;
        }

        view('user.advertiser.campaigns', [
            'title'      => 'کمپین‌های من',
            'campaigns'  => $campaigns,
            'perfById'   => $perfById,
            'page'       => $page,
            'perPage'    => $perPage,
            'total'      => $adModel->countByAdvertiser($userId),
        ]);
    }

    // ─────────────────────────────────────────────────────────
    //  آنالیتیک پیشرفته
    // ─────────────────────────────────────────────────────────

    public function analytics(): void
    {
        $userId  = (int)user_id();
                $days    = in_array((int)($this->request->get('days') ?? 30), [7, 14, 30, 90], true)
                   ? (int)$this->request->get('days')
                   : 30;

        $summary      = $this->dashService->getSummary($userId);
        $dailyChart   = $this->dashService->getDailyChart($userId, $days);
        $platforms    = $this->dashService->getPlatformBreakdown($userId);
        $taskTypes    = $this->dashService->getTaskTypeBreakdown($userId);
        $topCampaigns = $this->dashService->getCampaignPerformance($userId, 5);

        view('user.advertiser.analytics', [
            'title'        => 'آنالیتیک تبلیغات',
            'summary'      => $summary,
            'dailyChart'   => $dailyChart,
            'platforms'    => $platforms,
            'taskTypes'    => $taskTypes,
            'topCampaigns' => $topCampaigns,
            'days'         => $days,
        ]);
    }

    // ─────────────────────────────────────────────────────────
    //  بررسی اجراها
    // ─────────────────────────────────────────────────────────

    public function reviews(): void
    {
        $userId  = (int)user_id();
                $page    = max(1, (int)($this->request->get('page') ?? 1));
        $perPage = 20;
        $offset  = ($page - 1) * $perPage;

        $reviews = $this->dashService->getPendingReviews($userId, $perPage, $offset);
        $total   = $this->dashService->countPendingReviews($userId);

        view('user.advertiser.reviews', [
            'title'      => 'بررسی اجراها',
            'reviews'    => $reviews,
            'total'      => $total,
            'page'       => $page,
            'totalPages' => (int)ceil($total / $perPage),
        ]);
    }

    public function approve(): void
    {
        $userId  = (int)user_id();
                $execId  = (int)$this->request->param('id');
        $result  = $this->execService->approveByAdvertiser($execId, $userId);

        $this->dashService->clearCache($userId);

        if (is_ajax()) {
            $this->response->json($result);
            return;
        }
        $this->session->setFlash($result['success'] ? 'success' : 'error', $result['message']);
        redirect(url('/advertiser/reviews'));
    }

    public function reject(): void
    {
        $userId  = (int)user_id();
                $execId  = (int)$this->request->param('id');
        $reason  = trim($this->request->post('reason') ?? '');

        if (empty($reason)) {
            $this->response->json(['success' => false, 'message' => 'دلیل رد الزامی است']);
            return;
        }

        $result = $this->execService->rejectByAdvertiser($execId, $userId, $reason);
        $this->dashService->clearCache($userId);

        if (is_ajax()) {
            $this->response->json($result);
            return;
        }
        $this->session->setFlash($result['success'] ? 'success' : 'error', $result['message']);
        redirect(url('/advertiser/reviews'));
    }

    // ─────────────────────────────────────────────────────────
    //  Chart data API (JSON برای نمودار)
    // ─────────────────────────────────────────────────────────

    public function chartData(): void
    {
        $userId  = (int)user_id();
                $days    = in_array((int)($this->request->get('days') ?? 30), [7, 14, 30, 90], true)
                   ? (int)$this->request->get('days')
                   : 30;

        $data = $this->dashService->getDailyChart($userId, $days);
        $this->response->json(['success' => true, 'data' => $data]);
    }
}
