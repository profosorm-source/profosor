<?php
// app/Controllers/User/ContentController.php

namespace App\Controllers\User;

use App\Models\ContentSubmission;
use App\Models\ContentRevenue;
use App\Services\ContentService;
use Core\Validator;
use App\Controllers\User\BaseUserController;

class ContentController extends BaseUserController
{
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * صفحه لیست محتواهای کاربر
     */
    public function index()
    {
        $userId = user_id();
        $model = new ContentSubmission();

        $status = $_GET['status'] ?? null;
        $page = \max(1, (int)($_GET['page'] ?? 1));
        $perPage = 10;
        $offset = ($page - 1) * $perPage;

        $submissions = $model->getByUser($userId, $status, $perPage, $offset);
        $total = $model->countByUser($userId, $status);
        $totalPages = \ceil($total / $perPage);

        // آمار کلی
        $stats = [
            'total' => $model->countByUser($userId),
            'pending' => $model->countByUser($userId, ContentSubmission::STATUS_PENDING),
            'approved' => $model->countByUser($userId, ContentSubmission::STATUS_APPROVED),
            'published' => $model->countByUser($userId, ContentSubmission::STATUS_PUBLISHED),
            'rejected' => $model->countByUser($userId, ContentSubmission::STATUS_REJECTED),
        ];

        // مجموع درآمد
        $revenueModel = new ContentRevenue();
        $totalRevenue = $revenueModel->getTotalUserRevenue($userId, ContentRevenue::STATUS_PAID);
        $pendingRevenue = $revenueModel->getTotalUserRevenue($userId, ContentRevenue::STATUS_PENDING);

        $user = auth()->user();

        return view('user.content.index', [
            'user' => $user,
            'submissions' => $submissions,
            'stats' => $stats,
            'totalRevenue' => $totalRevenue,
            'pendingRevenue' => $pendingRevenue,
            'total' => $total,
            'totalPages' => $totalPages,
            'currentPage' => $page,
            'currentStatus' => $status,
        ]);
    }

    /**
     * صفحه ارسال محتوای جدید
     */
    public function create()
    {
        $service = new ContentService();
        $user = auth()->user();

        return view('user.content.create', [
            'user' => $user,
            'agreementText' => $service->getAgreementText(),
            'settings' => $service->getSettings(),
        ]);
    }

    /**
     * ثبت محتوای جدید (POST)
     */
    public function store()
    {
                
        // خواندن داده‌ها
        $input = \json_decode(\file_get_contents('php://input'), true);
        if (!$input) {
            $input = $_POST;
        }

        // اعتبارسنجی
        $validator = new Validator($input, [
            'platform' => 'required|in:aparat,youtube',
            'video_url' => 'required|url|max:500',
            'title' => 'required|min:5|max:255',
            'description' => 'max:2000',
            'category' => 'max:100',
            'agreement_accepted' => 'required',
        ]);

        if ($validator->fails()) {
            return $this->response->json([
                'success' => false,
                'message' => 'اطلاعات ورودی نامعتبر است.',
                'errors' => $validator->errors()
            ], 422);
        }

        $data = $validator->data();
        $service = new ContentService();
        $result = $service->submitContent(user_id(), $data);

        $statusCode = $result['success'] ? 200 : 422;
        return $this->response->json($result, $statusCode);
    }

    /**
     * مشاهده جزئیات یک محتوا
     */
    public function show()
    {
                $id = (int)$this->request->param('id');
        $userId = user_id();

        $model = new ContentSubmission();
        $submission = $model->find($id);

        if (!$submission || $submission->user_id !== $userId) {
            return view('errors.404');
        }

        // درآمدهای این محتوا
        $revenueModel = new ContentRevenue();
        $revenues = $revenueModel->getBySubmission($id);

        $user = auth()->user();

        return view('user.content.show', [
            'user' => $user,
            'submission' => $submission,
            'revenues' => $revenues,
        ]);
    }

    /**
     * لیست درآمدها
     */
    public function revenues()
    {
        $userId = user_id();
        $revenueModel = new ContentRevenue();

        $page = \max(1, (int)($_GET['page'] ?? 1));
        $perPage = 15;
        $offset = ($page - 1) * $perPage;

        $revenues = $revenueModel->getByUser($userId, $perPage, $offset);
        $total = $revenueModel->countByUser($userId);
        $totalPages = \ceil($total / $perPage);

        $totalPaid = $revenueModel->getTotalUserRevenue($userId, ContentRevenue::STATUS_PAID);
        $totalPending = $revenueModel->getTotalUserRevenue($userId, ContentRevenue::STATUS_PENDING);

        $user = auth()->user();

        return view('user.content.revenues', [
            'user' => $user,
            'revenues' => $revenues,
            'totalPaid' => $totalPaid,
            'totalPending' => $totalPending,
            'total' => $total,
            'totalPages' => $totalPages,
            'currentPage' => $page,
        ]);
    }
}