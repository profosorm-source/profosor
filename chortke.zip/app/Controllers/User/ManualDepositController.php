<?php

namespace App\Controllers\User;

use App\Models\ManualDeposit;
use App\Models\UserBankCard;
use App\Services\UploadService;
use Core\Validator;
use App\Services\ApiRateLimiter;
use App\Controllers\User\BaseUserController;

class ManualDepositController extends BaseUserController
{
    private ManualDeposit $depositModel;
    private UserBankCard $cardModel;
    private UploadService $uploadService;

    public function __construct()
    {
        parent::__construct();
        $this->depositModel = new ManualDeposit();
        $this->cardModel = new UserBankCard();
        $this->uploadService = new UploadService();
    }

    /**
     * فرم واریز دستی
     */
    public function create(): void
    {
        $userId = $this->userId();

        try {
            // بررسی درخواست در انتظار
            if ($this->depositModel->hasPendingDeposit($userId)) {
                $this->session->setFlash('error', 'شما یک درخواست واریز در انتظار بررسی دارید');
                redirect('/user/wallet');
                return;
            }

            // دریافت کارت‌های تأییدشده
            $cards = $this->cardModel->getUserCards($userId, 'verified');

            if (empty($cards)) {
                $this->session->setFlash('error', 'ابتدا باید کارت بانکی خود را ثبت و تأیید کنید');
                redirect('/user/bank-cards/create');
                return;
            }

            // دریافت اطلاعات کارت سایت
            $siteCardNumber = config('site_irt_card_number');
            $siteAccountNumber = config('site_irt_account_number');
            $siteSheba = config('site_irt_sheba');
            $siteBankName = config('site_irt_bank_name');

            if (!$siteCardNumber) {
                $this->session->setFlash('error', 'اطلاعات بانکی سایت تنظیم نشده است. لطفاً با پشتیبانی تماس بگیرید');
                redirect('/user/wallet');
                return;
            }

            view('user.manual-deposit.create', [
                'cards' => $cards,
                'siteCardNumber' => $siteCardNumber,
                'siteAccountNumber' => $siteAccountNumber,
                'siteSheba' => $siteSheba,
                'siteBankName' => $siteBankName,
                'pageTitle' => 'واریز دستی'
            ]);

        } catch (\Exception $e) {
            logger()->error('Manual deposit create failed', [
                'user_id' => $userId,
                'error' => $e->getMessage()
            ]);

            $this->session->setFlash('error', 'خطا در بارگذاری صفحه');
            redirect('/user/wallet');
        }
    }

    /**
     * ثبت درخواست واریز دستی
     */
    public function store(): void
    {
                $userId = $this->userId();
        ApiRateLimiter::enforce('manual_deposit', (int)user_id(), is_ajax());

        // بررسی درخواست در انتظار
        if ($this->depositModel->hasPendingDeposit($userId)) {
            $this->session->setFlash('error', 'شما یک درخواست واریز در انتظار بررسی دارید');
            redirect('/user/wallet');
            return;
        }

        // دریافت داده‌ها
        $data = [
            'card_id' => $this->request->input('card_id'),
            'amount' => $this->request->input('amount'),
            'tracking_code' => $this->request->input('tracking_code'),
            'deposit_date' => $this->request->input('deposit_date'),
            'deposit_time' => $this->request->input('deposit_time'),
        ];

        // اعتبارسنجی
        $validator = new Validator($data, [
            'card_id' => 'required|numeric',
            'amount' => 'required|numeric|min:10000',
            'tracking_code' => 'required|min:5|max:50',
            'deposit_date' => 'required',
            'deposit_time' => 'required',
        ], [
            'card_id.required' => 'انتخاب کارت الزامی است',
            'amount.required' => 'مبلغ الزامی است',
            'amount.numeric' => 'مبلغ باید عددی باشد',
            'amount.min' => 'حداقل مبلغ واریز 10,000 تومان است',
            'tracking_code.required' => 'شماره پیگیری الزامی است',
            'deposit_date.required' => 'تاریخ واریز الزامی است',
            'deposit_time.required' => 'ساعت واریز الزامی است',
        ]);

        if ($validator->fails()) {
            $this->session->setFlash('error', $validator->errors()[0]);
            $this->session->setFlash('old', $data);
            redirect('/user/wallet/deposit/manual');
            return;
        }

        try {
            // بررسی کارت
            $card = $this->cardModel->find((int)$data['card_id']);

            if (!$card || $card->user_id !== $userId || $card->status !== 'verified') {
                throw new \RuntimeException('کارت نامعتبر است');
            }

            // آپلود فیش (اختیاری)
            $receiptPath = null;
            $receiptFile = $this->request->file('receipt_image');

            if ($receiptFile && $receiptFile['error'] === UPLOAD_ERR_OK) {
                $uploadResult = $this->uploadService->upload(
                    $receiptFile,
                    'receipts',
                    ['image/jpeg', 'image/png'],
                    2 * 1024 * 1024 // 2MB
                );

                if ($uploadResult['success']) {
                    $receiptPath = $uploadResult['path'];
                } else {
                    throw new \RuntimeException($uploadResult['message']);
                }
            }

            $data['user_id'] = $userId;
            $data['receipt_image'] = $receiptPath;
            $data['status'] = 'pending';

            $deposit = $this->depositModel->create($data);

            if (!$deposit) {
                throw new \RuntimeException('خطا در ثبت درخواست');
            }

            // ثبت لاگ
            log_activity(
                $userId,
                'manual_deposit_requested',
                "درخواست واریز دستی {$data['amount']} تومان",
                ['deposit_id' => $deposit->id]
            );

            $this->session->setFlash('success', 'درخواست واریز شما با موفقیت ثبت شد و در انتظار بررسی است');
            redirect('/user/wallet');

        } catch (\Exception $e) {
            logger()->error('Manual deposit store failed', [
                'user_id' => $userId,
                'error' => $e->getMessage()
            ]);

            $this->session->setFlash('error', $e->getMessage());
            $this->session->setFlash('old', $data);
            redirect('/user/wallet/deposit/manual');
        }
    }

    /**
     * لیست درخواست‌های واریز دستی کاربر
     */
    public function index(): void
    {
        $userId = $this->userId();

        try {
            $deposits = $this->depositModel->getUserDeposits($userId);

            view('user.manual-deposit.index', [
                'deposits' => $deposits,
                'pageTitle' => 'درخواست‌های واریز دستی'
            ]);

        } catch (\Exception $e) {
            logger()->error('Manual deposit index failed', [
                'user_id' => $userId,
                'error' => $e->getMessage()
            ]);

            $this->session->setFlash('error', 'خطا در دریافت لیست');
            redirect('/user/wallet');
        }
    }
}