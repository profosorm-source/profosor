<?php
// app/Controllers/User/TaskController.php

namespace App\Controllers\User;

use App\Models\Advertisement;
use App\Models\TaskExecution;
use App\Models\SocialAccount;
use App\Services\TaskExecutionService;
use App\Services\TaskDisputeService;
use App\Services\UploadService;
use App\Controllers\User\BaseUserController;

class TaskController extends BaseUserController
{
    private TaskExecutionService $execService;
    private UploadService $uploadService;

    public function __construct()
    {
        parent::__construct();
        $this->execService   = new TaskExecutionService(new \App\Services\WalletService());
        $this->uploadService = new UploadService();
    }

    /**
     * لیست تسک‌های فعال (برای انجام دادن)
     */
    public function index()
    {
        $userId = user_id();

        $socialAccounts = (new \App\Models\SocialAccount())->getVerifiedByUser($userId);
        $tasks          = (new \App\Models\Advertisement())->getActiveForExecutor($userId, 30);
        $stats          = (new \App\Models\TaskExecution())->getUserStats($userId);

        return view('user.tasks.index', [
            'tasks'          => $tasks,
            'socialAccounts' => $socialAccounts,
            'stats'          => $stats,
        ]);
    }

    /**
     * شروع تسک — Ajax
     */
    public function start(): void
    {
        $body = $this->request->body();
        $adId = (int) ($body['ad_id'] ?? 0);

        if ($adId <= 0) {
            $this->response->json(['success' => false, 'message' => 'تسک نامعتبر.']);
            return;
        }

        $result = $this->execService->start($adId, user_id());
        $this->response->json($result);
    }

    /**
     * صفحه انجام تسک (بعد از شروع)
     */
    public function showExecute()
    {
        $executionId = (int) $this->request->param('id');

        $execution = (new \App\Models\TaskExecution())->find($executionId);
        if (!$execution || $execution->executor_id !== user_id()) {
            $this->session->setFlash('error', 'تسک یافت نشد.');
            $this->response->redirect(url('/user/tasks'));
            exit;
        }

        if ($execution->status !== 'started') {
            $this->session->setFlash('error', 'این تسک دیگر قابل انجام نیست.');
            $this->response->redirect(url('/user/tasks'));
            exit;
        }

        if ($execution->deadline_at && \strtotime($execution->deadline_at) < \time()) {
            (new \App\Models\TaskExecution())->update($executionId, ['status' => 'expired']);
            $this->session->setFlash('error', 'زمان انجام تسک به پایان رسیده.');
            $this->response->redirect(url('/user/tasks'));
            exit;
        }

        $task = (new \App\Models\Advertisement())->find($execution->advertisement_id);

        if ($task && $task->task_type === 'view' && $task->platform === 'youtube') {
            return view('user.tasks.execute-video', [
                'execution' => $execution,
                'task'      => $task,
            ]);
        }

        return view('user.tasks.execute', [
            'execution' => $execution,
            'task'      => $task,
        ]);
    }

    /**
     * ارسال مدرک — Ajax
     */
    public function submit(): void
    {
        $executionId = (int) $this->request->param('id');

        $proofPath = null;
        if (!empty($_FILES['proof_image']['name'])) {
            $uploadResult = $this->uploadService->upload(
                $_FILES['proof_image'],
                'task-proofs',
                ['jpg', 'jpeg', 'png', 'webp'],
                3
            );

            if (!$uploadResult['success']) {
                $this->response->json(['success' => false, 'message' => 'خطا در آپلود تصویر: ' . ($uploadResult['message'] ?? '')]);
                return;
            }

            $proofPath = $uploadResult['path'];
        }

        if (!$proofPath) {
            $this->response->json(['success' => false, 'message' => 'لطفاً اسکرین‌شات ارسال کنید.']);
            return;
        }

        $imagePath     = \rtrim(env('UPLOAD_PATH', 'storage/uploads'), '/') . '/' . $proofPath;
        $proofMetadata = [];
        if (\file_exists($imagePath)) {
            $proofMetadata['image_hash'] = \md5_file($imagePath);
            $proofMetadata['file_size']  = \filesize($imagePath);
        }

        $body         = $this->request->body();
        $behaviorData = [];
        if (!empty($body['mouse_data'])) {
            $behaviorData['mouse_data'] = $body['mouse_data'];
        }
        if (!empty($body['time_on_page'])) {
            $behaviorData['time_on_page'] = (int) $body['time_on_page'];
        }

        $result = $this->execService->submit($executionId, user_id(), [
            'proof_image'    => $proofPath,
            'proof_metadata' => $proofMetadata,
            'behavior_data'  => $behaviorData,
        ]);

        $this->response->json($result);
    }

    /**
     * تاریخچه تسک‌های انجام‌شده
     */
    public function history()
    {
        $userId = user_id();
        $page   = (int) ($_GET['page'] ?? 1);
        $limit  = 20;
        $offset = ($page - 1) * $limit;

        $status  = $_GET['status'] ?? '';
        $filters = [];
        if ($status) {
            $filters['status'] = $status;
        }

        $executions = (new \App\Models\TaskExecution())->getByExecutor($userId, $filters, $limit, $offset);
        $total      = (new \App\Models\TaskExecution())->countByExecutor($userId, $filters);
        $totalPages = \ceil($total / $limit);
        $stats      = (new \App\Models\TaskExecution())->getUserStats($userId);

        return view('user.tasks.history', [
            'executions' => $executions,
            'stats'      => $stats,
            'page'       => $page,
            'totalPages' => $totalPages,
            'total'      => $total,
            'status'     => $status,
        ]);
    }

    /**
     * ثبت اعتراض (Dispute) — Ajax
     */
    public function dispute(): void
    {
        $executionId = (int) $this->request->param('id');

        $body   = $this->request->body();
        $reason = $body['reason'] ?? '';

        if (empty($reason)) {
            $this->response->json(['success' => false, 'message' => 'لطفاً دلیل اعتراض را وارد کنید.']);
            return;
        }

        $evidencePath = null;
        if (!empty($_FILES['evidence_image']['name'])) {
            $uploadResult = $this->uploadService->upload($_FILES['evidence_image'], 'dispute-evidence', ['jpg', 'jpeg', 'png'], 3);
            if ($uploadResult['success']) {
                $evidencePath = $uploadResult['path'];
            }
        }

        $disputeService = new TaskDisputeService(
            new \App\Services\WalletService(),
            new \App\Services\TaskExecutionService(new \App\Services\WalletService())
        );
        $result = $disputeService->open($executionId, user_id(), 'executor', $reason, $evidencePath);

        $this->response->json($result);
    }
}
