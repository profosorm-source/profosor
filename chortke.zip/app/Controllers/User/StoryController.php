<?php

namespace App\Controllers\User;

use App\Models\InfluencerProfile;
use App\Models\StoryOrder;
use App\Services\StoryPromotionService;
use App\Services\UploadService;
use Core\Validator;
use App\Controllers\User\BaseUserController;

class StoryController extends BaseUserController
{
    public function __construct()
    {
        parent::__construct();
    }

    /** لیست اینفلوئنسرها */
    public function influencers()
    {
                $profileModel = new InfluencerProfile();
        $filters = [
            'category' => $this->request->get('category'),
            'min_followers' => $this->request->get('min_followers'),
            'max_price' => $this->request->get('max_price'),
            'search' => $this->request->get('search'),
        ];
        $sort = $this->request->get('sort', 'priority');
        $page = \max(1, (int) $this->request->get('page', 1));
        $limit = 12; $offset = ($page - 1) * $limit;

        $profiles = $profileModel->getVerified($filters, $sort, $limit, $offset);
        $total = $profileModel->countVerified($filters);
        $categories = (new \App\Models\InfluencerProfile())->categories();

        return view('user.stories.influencers', [
            'profiles' => $profiles, 'total' => $total,
            'page' => $page, 'pages' => \ceil($total / $limit),
            'filters' => $filters, 'sort' => $sort, 'categories' => $categories,
        ]);
    }

    /** فرم ثبت پیج */
    public function register()
    {
                $userId = $this->userId();
        $profileModel = new InfluencerProfile();
        $existing = $profileModel->findByUserId($userId);
        $categories = (new \App\Models\InfluencerProfile())->categories();
        return view('user.stories.register', ['existing' => $existing, 'categories' => $categories]);
    }

    /** ذخیره پیج */
    public function storeProfile()
    {
                        $userId = $this->userId();

        if (!verify_csrf_token($this->request->post('csrf_token'))) {
            $this->session->setFlash('error', 'توکن نامعتبر.');
            return redirect(url('/user/stories/register'));
        }

        $validator = new Validator($this->request->all(), [
            'username' => 'required|min:3|max:100',
            'page_url' => 'required|min:10',
            'follower_count' => 'required|numeric',
            'story_price_24h' => 'required|numeric',
        ]);
        if ($validator->fails()) {
            $this->session->setFlash('error', $validator->errors()[0] ?? 'خطا');
            $this->session->setFlash('old', $this->request->all());
            return redirect(url('/user/stories/register'));
        }
        $data = $validator->data();

        // آپلود تصویر پروفایل
        $profileImage = null;
        if (!empty($_FILES['profile_image']['name'])) {
            $upload = $this->uploadService;
            $r = $upload->upload($_FILES['profile_image'], 'influencer-profiles', ['jpg','jpeg','png','webp'], 2 * 1024 * 1024);
            if ($r['success']) $profileImage = $r['path'];
        }

        $service = new StoryPromotionService();
        $result = $service->registerInfluencer($userId, [
            'username' => $data->username,
            'page_url' => $data->page_url,
            'profile_image' => $profileImage,
            'follower_count' => (int) $data->follower_count,
            'engagement_rate' => (float) ($this->request->post('engagement_rate') ?? 0),
            'category' => $this->request->post('category'),
            'bio' => $this->request->post('bio'),
            'story_price_24h' => (float) $data->story_price_24h,
            'post_price_24h' => (float) ($this->request->post('post_price_24h') ?? 0),
            'post_price_48h' => (float) ($this->request->post('post_price_48h') ?? 0),
            'post_price_72h' => (float) ($this->request->post('post_price_72h') ?? 0),
        ]);

        $this->session->setFlash($result['success'] ? 'success' : 'error', $result['message']);
        return redirect(url('/user/stories/register'));
    }

    /** فرم ثبت سفارش */
    public function createOrder()
    {
                $influencerId = (int) $this->request->get('influencer');
        $profileModel = new InfluencerProfile();
        $profile = $profileModel->find($influencerId);
        if (!$profile || $profile->status !== 'verified') {
            \http_response_code(404); include __DIR__ . '/../../../views/errors/404.php'; exit;
        }
        return view('user.stories.create-order', ['profile' => $profile]);
    }

    /** ذخیره سفارش */
    public function storeOrder()
{
            $userId = $this->userId();

    if (!verify_csrf_token($this->request->post('csrf_token'))) {
        $this->session->setFlash('error', 'توکن امنیتی نامعتبر است.');
        return redirect(url('/user/stories/influencers'));
    }

    $validator = new Validator($this->request->all(), [
        'influencer_id' => 'required|numeric',
        'order_type'    => 'required',
        'duration_hours'=> 'required|numeric',
    ]);

    if ($validator->fails()) {
        $this->session->setFlash('error', $validator->errors()[0] ?? 'خطا در اعتبارسنجی');
        return redirect(url('/user/stories/influencers'));
    }

    $data = $validator->data();
    $influencerId = (int) $data->influencer_id;

    // آپلود مدیا (اختیاری)
    $mediaPath = null;
    if (!empty($_FILES['media']['name'])) {
        $upload = $this->uploadService;
        $maxSize = (int) setting('story_max_file_size_mb', 10) * 1024 * 1024;

        $r = $upload->upload(
            $_FILES['media'],
            'story-media',
            ['jpg','jpeg','png','webp','mp4','gif'],
            $maxSize
        );

        if ($r['success']) {
            $mediaPath = $r['path'];
        } else {
            $this->session->setFlash('error', 'خطا در آپلود فایل تبلیغ.');
            return redirect(url('/user/stories/create-order?influencer=' . $influencerId));
        }
    }

    $service = new StoryPromotionService();
    $result = $service->createOrder($userId, $influencerId, [
        'order_type'            => $this->request->post('order_type') ?? 'story',
        'duration_hours'        => (int) ($this->request->post('duration_hours') ?? 24),
        'media_path'            => $mediaPath,
        'caption'               => $this->request->post('caption'),
        'link'                  => $this->request->post('link'),
        'preferred_publish_time'=> $this->request->post('preferred_publish_time') ?: null,
    ]);

    $this->session->setFlash($result['success'] ? 'success' : 'error', $result['message']);

    if ($result['success']) {
        return redirect(url('/user/stories/my-orders'));
    }

    return redirect(url('/user/stories/create-order?influencer=' . $influencerId));
}

    /** سفارش‌های من (تبلیغ‌دهنده) */
    public function myOrders()
    {
                $userId = $this->userId();
        $orderModel = new StoryOrder();
        $orders = $orderModel->getByCustomer($userId, null, 30, 0);
        return view('user.stories.my-orders', ['orders' => $orders]);
    }

    /** سفارش‌های پیج من (اینفلوئنسر) */
    public function myPageOrders()
    {
                $userId = $this->userId();
        $orderModel = new StoryOrder();
        $orders = $orderModel->getByInfluencer($userId, null, 30, 0);
        return view('user.stories.my-page-orders', ['orders' => $orders]);
    }

    /** پذیرش/رد سفارش (اینفلوئنسر - Ajax) */
    public function respondOrder()
    {
                                $userId = $this->userId();

        $body = \json_decode(\file_get_contents('php://input'), true) ?? [];
        $orderId = (int) ($body['order_id'] ?? 0);
        $decision = $body['decision'] ?? '';
        $reason = $body['reason'] ?? null;

        $service = new StoryPromotionService();
        $result = $service->respondToOrder($orderId, $userId, $decision, $reason);
        $this->response->json($result, $result['success'] ? 200 : 422);
    }

    /** ارسال مدرک (اینفلوئنسر - Ajax) */
    public function submitProof()
    {
                                $userId = $this->userId();
        $orderId = (int) $this->request->param('id');

        $proofData = [];

        if (!empty($_FILES['proof_screenshot']['name'])) {
            $upload = $this->uploadService;
            $r = $upload->upload($_FILES['proof_screenshot'], 'story-proofs', ['jpg','jpeg','png','webp'], 5 * 1024 * 1024);
            if ($r['success']) $proofData['proof_screenshot'] = $r['path'];
        }

        $proofData['actual_publish_time'] = $this->request->post('actual_publish_time') ?? \date('Y-m-d H:i:s');

        $service = new StoryPromotionService();
        $result = $service->submitProof($orderId, $userId, $proofData);
        $this->response->json($result, $result['success'] ? 200 : 422);
    }
}