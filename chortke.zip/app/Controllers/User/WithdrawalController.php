<?php

namespace App\Controllers\User;

use App\Models\Withdrawal;
use App\Models\UserBankCard;
use App\Models\User;
use App\Services\WalletService;
use Core\Validator;
use App\Services\ApiRateLimiter;
use App\Controllers\User\BaseUserController;

class WithdrawalController extends BaseUserController
{
    private Withdrawal $withdrawalModel;
    private UserBankCard $cardModel;
    private WalletService $walletService;
    private User $userModel;

    public function __construct()
    {
        parent::__construct();
        $this->withdrawalModel = new Withdrawal();
        $this->cardModel = new UserBankCard();
        $this->walletService = new WalletService();
        $this->userModel = new User();
    }

    /**
     * فرم برداشت وجه
     */
    public function create(): void
    {
        $userId = $this->userId();

        try {
            // بررسی KYC
            $user = $this->userModel->find($userId);

            if (!$user || $user->kyc_status !== 'verified') {
                $this->session->setFlash('error', 'برای برداشت وجه ابتدا باید احراز هویت کنید');
                redirect('/user/kyc');
                return;
            }

            // بررسی درخواست در انتظار
            if ($this->withdrawalModel->hasPendingWithdrawal($userId)) {
                $this->session->setFlash('error', 'شما یک درخواست برداشت در انتظار دارید');
                redirect('/user/wallet');
                return;
            }

            // بررسی محدودیت روزانه
            $summary = $this->walletService->getWalletSummary($userId);
            if (!$summary->can_withdraw_today) {
                $this->session->setFlash('error', 'شما امروز یکبار برداشت کرده‌اید');
                redirect('/user/wallet');
                return;
            }

            $siteCurrency = config('site_currency', 'irt');
            
            // دریافت کارت‌ها برای IRT
            $cards = [];
            if ($siteCurrency === 'irt') {
                $cards = $this->cardModel->getUserCards($userId, 'verified');
                if (empty($cards)) {
                    $this->session->setFlash('error', 'ابتدا باید کارت بانکی خود را ثبت و تأیید کنید');
                    redirect('/user/bank-cards/create');
                    return;
                }
            }

            $minWithdrawal = $siteCurrency === 'usdt'
                ? (float)config('min_withdrawal_usdt', 10)
                : (float)config('min_withdrawal_irt', 50000);

            view('user.withdrawal.create', [
                'summary' => $summary,
                'cards' => $cards,
                'siteCurrency' => $siteCurrency,
                'minWithdrawal' => $minWithdrawal,
                'pageTitle' => 'برداشت وجه'
            ]);

        } catch (\Exception $e) {
            logger()->error('Withdrawal create failed', [
                'user_id' => $userId,
                'error' => $e->getMessage()
            ]);

            $this->session->setFlash('error', 'خطا در بارگذاری صفحه');
            redirect('/user/wallet');
        }
    }

    /**
     * ثبت درخواست برداشت
     */
    public function store(): void
    {
                $userId = $this->userId();

        // Rate limiting: حداکثر 3 برداشت در ساعت
        ApiRateLimiter::enforce('withdrawal', $userId, is_ajax());

        // بررسی KYC
        $user = $this->userModel->find($userId);

        if (!$user || $user->kyc_status !== 'verified') {
            $this->session->setFlash('error', 'احراز هویت انجام نشده است');
            redirect('/user/kyc');
            return;
        }

        // بررسی درخواست در انتظار
        if ($this->withdrawalModel->hasPendingWithdrawal($userId)) {
            $this->session->setFlash('error', 'شما یک درخواست برداشت در انتظار دارید');
            redirect('/user/wallet');
            return;
        }

        $siteCurrency = config('site_currency', 'irt');
        
        // دریافت داده‌ها
        $data = [
            'currency' => $siteCurrency,
            'amount' => $this->request->input('amount'),
        ];

        // داده‌های اضافی بر اساس نوع ارز
        if ($siteCurrency === 'irt') {
            $data['card_id'] = $this->request->input('card_id');
        } else {
            $data['wallet_address'] = $this->request->input('wallet_address');
            $data['network'] = $this->request->input('network');
        }

        // اعتبارسنجی
        $rules = [
            'amount' => 'required|numeric|min:1',
        ];

        $messages = [
            'amount.required' => 'مبلغ الزامی است',
            'amount.numeric' => 'مبلغ باید عددی باشد',
        ];

        if ($siteCurrency === 'irt') {
            $rules['card_id'] = 'required|numeric';
            $messages['card_id.required'] = 'انتخاب کارت الزامی است';
        } else {
            $rules['wallet_address'] = 'required|min:26|max:42';
            $rules['network'] = 'required|in:bnb20,trc20';
            $messages['wallet_address.required'] = 'آدرس کیف پول الزامی است';
            $messages['network.required'] = 'انتخاب شبکه الزامی است';
        }

        $validator = new Validator($data, $rules, $messages);

        if ($validator->fails()) {
            $this->session->setFlash('error', $validator->errors()[0]);
            $this->session->setFlash('old', $data);
            redirect('/user/withdrawal/create');
            return;
        }

        try {
            $amount = (float)$data['amount'];

            // بررسی امکان برداشت
            $canWithdraw = $this->walletService->canWithdraw($userId, $amount, $siteCurrency);
            if (!$canWithdraw['can_withdraw']) {
                throw new \RuntimeException($canWithdraw['message']);
            }

            // بررسی کارت (برای IRT)
            if ($siteCurrency === 'irt') {
                $card = $this->cardModel->find((int)$data['card_id']);
                if (!$card || $card->user_id !== $userId || $card->status !== 'verified') {
                    throw new \RuntimeException('کارت نامعتبر است');
                }
            }

            // قفل موجودی و ثبت تراکنش
            $transaction = $this->walletService->withdraw($userId, $amount, $siteCurrency, [
                'description' => 'درخواست برداشت',
            ]);

            if (!$transaction) {
                throw new \RuntimeException('خطا در قفل کردن موجودی');
            }

            // ثبت درخواست برداشت
            $data['user_id'] = $userId;
            $data['status'] = 'pending';
            $data['transaction_id'] = $transaction->transaction_id;

            $withdrawal = $this->withdrawalModel->create($data);

            if (!$withdrawal) {
                // بازگشت موجودی در صورت خطا
                $this->walletService->cancelWithdrawal($userId, $amount, $siteCurrency, $transaction->transaction_id);
                throw new \RuntimeException('خطا در ثبت درخواست');
            }

            // ثبت لاگ
            log_activity(
                $userId,
                'withdrawal_requested',
                "درخواست برداشت {$amount} " . ($siteCurrency === 'usdt' ? 'USDT' : 'تومان'),
                ['withdrawal_id' => $withdrawal->id]
            );

            $this->session->setFlash('success', 'درخواست برداشت شما با موفقیت ثبت شد');
            redirect('/user/wallet');

        } catch (\Exception $e) {
            logger()->error('Withdrawal store failed', [
                'user_id' => $userId,
                'error' => $e->getMessage()
            ]);

            $this->session->setFlash('error', $e->getMessage());
            $this->session->setFlash('old', $data);
            redirect('/user/withdrawal/create');
        }
    }

    /**
     * لیست درخواست‌های برداشت کاربر
     */
    public function index(): void
    {
        $userId = $this->userId();

        try {
            $withdrawals = $this->withdrawalModel->getUserWithdrawals($userId);

            view('user.withdrawal.index', [
                'withdrawals' => $withdrawals,
                'pageTitle' => 'درخواست‌های برداشت'
            ]);

        } catch (\Exception $e) {
            logger()->error('Withdrawal index failed', [
                'user_id' => $userId,
                'error' => $e->getMessage()
            ]);

            $this->session->setFlash('error', 'خطا در دریافت لیست');
            redirect('/user/wallet');
        }
    }

    /**
     * نمایش محدودیت‌های برداشت برای کاربر جاری (JSON)
     * GET /user/withdrawal/limits?currency=IRT
     */
    public function limitsInfo(): void
    {
        $userId   = (int)user_id();
        $currency = strtoupper((new \Core\Request())->get('currency') ?? 'IRT');
        if (!in_array($currency, ['IRT', 'USDT'], true)) {
            $currency = 'IRT';
        }

        $limitService = new \App\Services\WithdrawalLimitService();
        $info = $limitService->getLimitsForUser($userId, $currency);

        $this->response->json([
            'success' => true,
            'limits'  => $info,
        ]);
    }
}