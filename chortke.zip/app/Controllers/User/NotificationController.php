<?php

namespace App\Controllers\User;

use App\Models\Notification;
use App\Models\NotificationPreference;
use App\Controllers\User\BaseUserController;

class NotificationController extends BaseUserController
{
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * لیست نوتیفیکیشن‌ها
     */
    public function index()
    {
        $userId = user_id();
        
        $notifications = (new Notification())->getUserNotifications($userId, false, 50);
        $unreadCount = (new Notification())->getUnreadCount($userId);
        
        return view('user/notifications/index', [
            'notifications' => $notifications,
            'unread_count' => $unreadCount
        ]);
    }
    
    /**
     * دریافت نوتیفیکیشن‌ها (Ajax)
     */
    public function get()
    {
                        
        $userId = user_id();
        $onlyUnread = $this->request->input('unread') === 'true';
        $limit = (int)($this->request->input('limit') ?? 20);
        
        $notifications = (new Notification())->getUserNotifications($userId, $onlyUnread, $limit);
        $unreadCount = (new Notification())->getUnreadCount($userId);
        
        return $this->response->json([
            'success' => true,
            'notifications' => $notifications,
            'unread_count' => $unreadCount
        ]);
    }
    
    /**
     * علامت‌گذاری به عنوان خوانده شده
     */
    public function markAsRead()
    {
                        
        $notificationId = (int)$this->request->input('notification_id');
        $userId = user_id();
        
        $result = (new Notification())->markAsRead($notificationId, $userId);
        
        return $this->response->json([
            'success' => $result,
            'message' => $result ? 'علامت‌گذاری شد' : 'خطا در علامت‌گذاری'
        ]);
    }
    
    /**
     * علامت‌گذاری همه به عنوان خوانده شده
     */
    public function markAllAsRead()
    {
                $userId = user_id();
        
        $count = (new Notification())->markAllAsRead($userId);
        
        return $this->response->json([
            'success' => true,
            'count' => $count,
            'message' => "{$count} نوتیفیکیشن علامت‌گذاری شد"
        ]);
    }
    
    /**
     * آرشیو کردن
     */
    public function archive()
    {
                        
        $notificationId = (int)$this->request->input('notification_id');
        $userId = user_id();
        
        $result = (new Notification())->archive($notificationId, $userId);
        
        return $this->response->json([
            'success' => $result,
            'message' => $result ? 'آرشیو شد' : 'خطا در آرشیو'
        ]);
    }
    
    /**
     * تنظیمات نوتیفیکیشن
     */
    public function preferences()
    {
        $userId = user_id();
        $prefs = (new NotificationPreference())->getOrCreate($userId);
        
        return view('user/notifications/preferences', [
            'preferences' => $prefs
        ]);
    }
    
    /**
     * ذخیره تنظیمات
     */
    public function updatePreferences()
    {
                        
        $userId = user_id();
        $data = $this->request->all();
        
        $prefModel = new NotificationPreference();
        $prefs = $prefModel->getOrCreate($userId);
        
        // فیلتر کردن فیلدهای مجاز
        $allowedFields = [
            'in_app_enabled', 'in_app_task', 'in_app_payment', 'in_app_withdrawal',
            'in_app_investment', 'in_app_lottery', 'in_app_referral', 'in_app_system',
            'email_enabled', 'email_task', 'email_payment', 'email_withdrawal',
            'email_investment', 'email_lottery', 'email_referral', 'email_system', 'email_marketing'
        ];
        
        $updateData = [];
        foreach ($allowedFields as $field) {
            $updateData[$field] = isset($data[$field]) ? 1 : 0;
        }
        
        $result = $prefModel->update($prefs->id, $updateData);
        
        return $this->response->json([
            'success' => $result,
            'message' => $result ? 'تنظیمات ذخیره شد' : 'خطا در ذخیره تنظیمات'
        ]);
    }
    
    /**
     * دریافت تعداد خوانده نشده (برای Badge)
     */
    public function unreadCount()
    {
                $userId = user_id();
        
        $count = (new Notification())->getUnreadCount($userId);
        
        return $this->response->json([
            'success' => true,
            'count' => $count
        ]);
    }
}