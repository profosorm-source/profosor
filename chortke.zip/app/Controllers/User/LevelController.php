<?php

namespace App\Controllers\User;

use App\Models\UserLevel;
use App\Models\UserLevelHistory;
use App\Services\UserLevelService;
use App\Controllers\User\BaseUserController;

class LevelController extends BaseUserController
{
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * صفحه سطح‌بندی کاربر
     */
    public function index()
    {
                $userId = $this->userId();

        $progress = $levelService->getProgress($userId);
        $allLevels = $levelModel->all(true);
        $history = $historyModel->getByUser($userId, 15, 0);
        $bonuses = $levelService->getUserBonuses($userId);

        $currencyMode = setting('currency_mode', 'irt');

        return view('user.level.index', [
            'progress' => $progress,
            'allLevels' => $allLevels,
            'history' => $history,
            'bonuses' => $bonuses,
            'currencyMode' => $currencyMode,
        ]);
    }

    /**
     * خرید سطح (Ajax)
     */
    public function purchase()
    {
                        
        $body = \json_decode(\file_get_contents('php://input'), true) ?? [];
        $levelSlug = $body['level'] ?? '';
        $currency = $body['currency'] ?? 'irt';

        if (!verify_csrf_token($body['csrf_token'] ?? '')) {
            $this->response->json(['success' => false, 'message' => 'توکن امنیتی نامعتبر'], 403);
            return;
        }

        $userId = $this->userId();
        $result = $levelService->purchaseLevel($userId, $levelSlug, $currency);

        $statusCode = $result['success'] ? 200 : 422;
        $this->response->json($result, $statusCode);
    }
}