<?php
// app/Controllers/User/SEOTaskController.php

namespace App\Controllers\User;

use App\Models\SEOKeyword;
use App\Models\SEOExecution;
use App\Services\SEOTaskService;
use App\Controllers\User\BaseUserController;

class SEOTaskController extends BaseUserController
{
    private SEOTaskService $service;

    public function __construct()
    {
        parent::__construct();
        $this->service = new SEOTaskService();
    }

    /**
     * لیست کلمات فعال
     */
    public function index()
    {
        $userId = user_id();
        $keywords = (new \App\Models\SEOKeyword())->getActiveForExecutor($userId, 15);
        $stats = (new \App\Models\SEOExecution())->getUserStats($userId);
        $todayCount = (new \App\Models\SEOExecution())->countByExecutorToday($userId);

        return view('user.seo-tasks.index', [
            'keywords'   => $keywords,
            'stats'      => $stats,
            'todayCount' => $todayCount,
        ]);
    }

    /**
     * شروع — Ajax
     */
    public function start(): void
    {
        $body      = $this->request->body();
        $keywordId = (int) ($body['keyword_id'] ?? 0);

        if ($keywordId <= 0) {
            $this->response->json(['success' => false, 'message' => 'کلمه نامعتبر.']);
            return;
        }

        $result = $this->service->start($keywordId, user_id());
        $this->response->json($result);
    }

    /**
     * صفحه اجرا
     */
    public function showExecute()
    {
                $id = (int) $this->request->param('id');

        $execution = (new \App\Models\SEOExecution())->find($id);
        if (!$execution || $execution->executor_id !== user_id()) {
            $this->session->setFlash('error', 'تسک یافت نشد.');
            return redirect(url('/user/seo-tasks'));
        }

        if (!\in_array($execution->status, ['started', 'browsing'])) {
            $this->session->setFlash('error', 'این تسک دیگر قابل انجام نیست.');
            return redirect(url('/user/seo-tasks'));
        }

        $keyword = (new \App\Models\SEOKeyword())->find($execution->keyword_id);

        return view('user.seo-tasks.execute', [
            'execution' => $execution,
            'keyword'   => $keyword,
        ]);
    }

    /**
     * تکمیل — Ajax
     */
    public function complete(): void
    {
        $id   = (int) $this->request->param('id');
        $body = $this->request->body();

        $result = $this->service->complete($id, user_id(), [
            'total_duration'  => (int) ($body['total_duration'] ?? 0),
            'scroll_duration' => (int) ($body['scroll_duration'] ?? 0),
            'browse_duration' => (int) ($body['browse_duration'] ?? 0),
            'scroll_data'     => $body['scroll_data'] ?? [],
            'behavior_data'   => $body['behavior_data'] ?? [],
        ]);

        $this->response->json($result);
    }

    /**
     * تاریخچه
     */
    public function history()
    {
        $userId = user_id();
        $page = (int) ($_GET['page'] ?? 1);
        $limit = 20;
        $offset = ($page - 1) * $limit;

        $executions = (new \App\Models\SEOExecution())->getByExecutor($userId, $limit, $offset);
        $total = (new \App\Models\SEOExecution())->countByExecutor($userId);
        $totalPages = \ceil($total / $limit);
        $stats = (new \App\Models\SEOExecution())->getUserStats($userId);

        return view('user.seo-tasks.history', [
            'executions' => $executions,
            'stats'      => $stats,
            'page'       => $page,
            'totalPages' => $totalPages,
            'total'      => $total,
        ]);
    }
}