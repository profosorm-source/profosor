<?php

namespace App\Controllers\User;

use App\Models\User;
use App\Controllers\User\BaseUserController;

class DashboardController extends BaseUserController
{
    
	
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * داشبورد کاربر
     */
    public function index(): void
    {
		
	if (!auth() || !user_id()) {
        redirect(url('/login'));
        return;
    }
		$panelService = new \App\Services\UserPanelService();
		
        // بررسی ورود کاربر
        $userId = $this->userId();
        if (!$userId) {
            $this->session->setFlash('error', 'لطفاً ابتدا وارد حساب کاربری خود شوید.');
            $this->response->redirect(url('/login'));
            return;
        }

        // بازیابی اطلاعات کاربر از دیتابیس
        $user = (new User())->find($userId);
        if (!$user) {
            $this->session->setFlash('error', 'کاربر یافت نشد.');
            $this->response->redirect(url('/login'));
            return;
        }

        // آمار کاربر
        $stats = $this->getStats($user->id);

        // کاربران اخیر (اختیاری، فقط برای نمایش در پنل کاربر)
        $recentUsers = $this->recentUsers();

        // نمایش ویو داشبورد کاربر
        view('user/dashboard', [
            'title' => 'داشبورد کاربری',
            'stats' => $stats,
            'recentUsers' => $recentUsers,
            'user' => $user
        ]);
		
    }

    /**
     * متد آمار
     */
    private function getStats(int $userId): array
    {
        // اینجا آمار واقعی برای کاربر را بازگردانید
        return [
            'balance' => 0,
            'tasks_today' => 0,
            'sub_users' => 0,
            'level' => 'Silver'
        ];
    }

    /**
     * متد کاربران اخیر
     */
    private function recentUsers(): array
    {
        // اینجا کاربران واقعی را بازگردانید
        return [];
    }
}
