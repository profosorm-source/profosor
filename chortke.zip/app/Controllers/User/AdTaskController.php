<?php
// app/Controllers/User/AdTaskController.php

namespace App\Controllers\User;

use App\Models\Advertisement;
use App\Models\Wallet;
use App\Models\SocialAccount;
use App\Services\AdTaskService;
use App\Services\UploadService;
use Core\Validator;
use App\Controllers\User\BaseUserController;

class AdTaskController extends BaseUserController
{
    private AdTaskService $service;

    private \App\Services\UploadService $uploadService;

    public function __construct()
    {
        parent::__construct();
        $this->service       = new AdTaskService(
            new \App\Services\WalletService()
        );
        $this->uploadService = new \App\Services\UploadService();
    }

    /**
     * لیست تسک‌های تبلیغ‌دهنده (تسک‌هایی که خودش ساخته)
     */
    public function myTasks()
    {
        $userId = user_id();
        $page = (int) ($_GET['page'] ?? 1);
        $limit = 20;
        $offset = ($page - 1) * $limit;

        $tasks = (new \App\Models\Advertisement())->getByAdvertiser($userId, $limit, $offset);
        $total = (new \App\Models\Advertisement())->countByAdvertiser($userId);
        $totalPages = \ceil($total / $limit);

        return view('user.ad-tasks.my-tasks', [
            'tasks'      => $tasks,
            'page'       => $page,
            'totalPages' => $totalPages,
            'total'      => $total,
        ]);
    }

    /**
     * فرم ایجاد تسک جدید (تبلیغ‌دهنده)
     */
    public function showCreate()
    {
        $userId = user_id();
        $wallet = (new \App\Models\Wallet())->findByUserId($userId);
        $currency = setting('currency_mode') ?? 'irt';
        $currencyLabel = ($currency === 'usdt') ? 'تتر (USDT)' : 'تومان';

        $platforms = [
            'instagram' => 'اینستاگرام',
            'youtube'   => 'یوتیوب',
            'telegram'  => 'تلگرام',
            'tiktok'    => 'تیک‌تاک',
            'twitter'   => 'توییتر (X)',
        ];

        $taskTypes = [
            'follow'       => 'فالو کردن',
            'subscribe'    => 'سابسکرایب',
            'join_channel' => 'عضویت کانال',
            'join_group'   => 'عضویت گروه',
            'like'         => 'لایک',
            'comment'      => 'کامنت',
            'view'         => 'بازدید ویدیو',
            'story_view'   => 'بازدید استوری',
        ];

        $commission = (float) (setting('ad_commission_percent') ?? 10);
        $tax = (float) (setting('ad_tax_percent') ?? 0);

        return view('user.ad-tasks.create', [
            'wallet'        => $wallet,
            'currency'      => $currency,
            'currencyLabel' => $currencyLabel,
            'platforms'     => $platforms,
            'taskTypes'     => $taskTypes,
            'commission'    => $commission,
            'tax'           => $tax,
        ]);
    }

    /**
     * ایجاد تسک — POST
     */
    public function store()
    {
                $data = $this->request->body();

        $validator = new Validator($data, [
            'platform'       => 'required|in:instagram,youtube,telegram,tiktok,twitter',
            'task_type'      => 'required|in:follow,subscribe,join_channel,join_group,like,comment,view,story_view',
            'target_url'     => 'required|string|max:500',
            'title'          => 'required|string|min:3|max:255',
            'price_per_task' => 'required|numeric|min:0.01',
            'total_count'    => 'required|numeric|min:1|max:10000',
        ]);

        if ($validator->fails()) {
            $this->session->setFlash('error', $validator->errors()[0] ?? 'اطلاعات نامعتبر.');
            return redirect(url('/user/ad-tasks/create'));
        }

        // آپلود تصویر نمونه
        if (!empty($_FILES['sample_image']['name'])) {
            $upload = $this->uploadService;
            $uploadResult = $upload->upload($_FILES['sample_image'], 'ad-tasks', ['jpg', 'jpeg', 'png', 'gif'], 2);
            if ($uploadResult['success']) {
                $data['sample_image'] = $uploadResult['path'];
            }
        }

        $result = $this->service->create(user_id(), $data);

        if ($result['success']) {
            $this->session->setFlash('success', $result['message']);
            return redirect(url('/user/ad-tasks'));
        }

        $this->session->setFlash('error', $result['message']);
        return redirect(url('/user/ad-tasks/create'));
    }

    /**
     * جزئیات تسک (تبلیغ‌دهنده)
     */
    public function show()
    {
                $id = (int) $this->request->param('id');

        $task = (new \App\Models\Advertisement())->find($id);
        if (!$task || $task->advertiser_id !== user_id()) {
            $this->session->setFlash('error', 'تسک یافت نشد.');
            return redirect(url('/user/ad-tasks'));
        }

        // لیست انجام‌شده‌ها
        $executions = (new \App\Models\TaskExecution())->getPendingForAdvertiser(user_id(), 50, 0);

        return view('user.ad-tasks.show', [
            'task'       => $task,
            'executions' => $executions,
        ]);
    }

    /**
     * توقف تسک — Ajax
     */
    public function pause(): void
    {
        $id = (int) $this->request->param('id');

        $result = $this->service->pause($id, user_id());
        $this->response->json($result);
    }

    /**
     * از سرگیری — Ajax
     */
    public function resume(): void
    {
        $id = (int) $this->request->param('id');

        $result = $this->service->resume($id, user_id());
        $this->response->json($result);
    }

    /**
     * لغو تسک — Ajax
     */
    public function cancel(): void
    {
        $id = (int) $this->request->param('id');

        $result = $this->service->cancel($id, user_id());
        $this->response->json($result);
    }

    /**
     * بررسی مدرک ارسال‌شده توسط انجام‌دهنده — صفحه
     */
    public function showReview()
    {
                $executionId = (int) $this->request->param('id');

        $execution = (new \App\Models\TaskExecution())->find($executionId);
        if (!$execution) {
            $this->session->setFlash('error', 'تسک یافت نشد.');
            return redirect(url('/user/ad-tasks'));
        }

        $task = (new \App\Models\Advertisement())->find($execution->advertisement_id);
        if (!$task || $task->advertiser_id !== user_id()) {
            $this->session->setFlash('error', 'دسترسی مجاز نیست.');
            return redirect(url('/user/ad-tasks'));
        }

        return view('user.ad-tasks.review', [
            'execution' => $execution,
            'task'      => $task,
        ]);
    }

    /**
     * تایید تسک توسط تبلیغ‌دهنده — Ajax
     */
    public function approveExecution(): void
    {
        $executionId = (int) $this->request->param('id');

        $execService = new \App\Services\TaskExecutionService(new \App\Services\WalletService());
        $result = $execService->approveByAdvertiser($executionId, user_id());

        $this->response->json($result);
    }

    /**
     * رد تسک توسط تبلیغ‌دهنده — Ajax
     */
    public function rejectExecution(): void
    {
        $executionId = (int) $this->request->param('id');

        $body   = $this->request->body();
        $reason = $body['reason'] ?? '';

        if (empty($reason)) {
            $this->response->json(['success' => false, 'message' => 'لطفاً دلیل رد را وارد کنید.']);
            return;
        }

        $execService = new \App\Services\TaskExecutionService(new \App\Services\WalletService());
        $result = $execService->rejectByAdvertiser($executionId, user_id(), $reason);

        $this->response->json($result);
    }
}