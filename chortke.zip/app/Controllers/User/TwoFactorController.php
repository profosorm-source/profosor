<?php
namespace App\Controllers\User;

use App\Services\TwoFactorService;
use App\Models\User;
use App\Models\ActivityLog;
use App\Controllers\User\BaseUserController;

/**
 * Two Factor Authentication Controller
 */
class TwoFactorController extends BaseUserController
{
    private $twoFactorService;
    private $userModel;
    private $activityLog;

    public function __construct()
    {
        parent::__construct();
        $this->twoFactorService = new TwoFactorService();
        $this->userModel = new User();
        $this->activityLog = new ActivityLog();
    }

    /**
     * نمایش صفحه 2FA
     */
    public function index(): void
    {
        $user = auth_user();

        if (!$user) {
            redirect(url('login'));
            return;
        }

        $data = [
            'title' => 'احراز هویت دو مرحله‌ای',
            'is_enabled' => $user['two_factor_enabled'] == 1
        ];

        // اگر فعال نیست، secret تولید کن
        if (!$data['is_enabled']) {
            if (!$user['two_factor_secret']) {
                $secret = $this->twoFactorService->generateSecret();
                $this->userModel->update($user['id'], ['two_factor_secret' => $secret]);
                $user['two_factor_secret'] = $secret;
            }

            $data['secret'] = $user['two_factor_secret'];
            $data['qr_code_url'] = $this->twoFactorService->getQRCodeUrl(
                $user['username'],
                $user['two_factor_secret']
            );
        }

        view('user.security.two-factor', $data);
    }

    /**
     * فعالسازی 2FA
     */
    public function enable(): void
    {
        $user = auth_user();

        if (!$user) {
            $this->response->json(['success' => false, 'message' => 'لطفاً وارد شوید.'], 401);
            return;
        }

        $code = $this->request->input('code');

        if (empty($code) || strlen($code) !== 6) {
            $this->response->json(['success' => false, 'message' => 'لطفاً کد 6 رقمی را وارد کنید.']);
            return;
        }

        $result = $this->twoFactorService->enable($user['id'], $code);

        if ($result['success']) {
            $this->activityLog->log('2fa_enabled', 'فعالسازی احراز هویت دو مرحله‌ای', $user['id']);
            $this->response->json([
                'success' => true,
                'message' => $result['message'],
                'recovery_codes' => $result['recovery_codes']
            ]);
            return;
        }

        $this->response->json(['success' => false, 'message' => $result['message']]);
    }

    /**
     * غیرفعالسازی 2FA
     */
    public function disable(): void
    {
        $user = auth_user();

        if (!$user) {
            $this->response->json(['success' => false, 'message' => 'لطفاً وارد شوید.'], 401);
            return;
        }

        $password = $this->request->input('password');

        if (empty($password)) {
            $this->response->json(['success' => false, 'message' => 'لطفاً رمز عبور خود را وارد کنید.']);
            return;
        }

        $result = $this->twoFactorService->disable($user['id'], $password);

        if ($result['success']) {
            $this->activityLog->log('2fa_disabled', 'غیرفعالسازی احراز هویت دو مرحله‌ای', $user['id']);
            $this->response->json(['success' => true, 'message' => $result['message']]);
            return;
        }

        $this->response->json(['success' => false, 'message' => $result['message']]);
    }

    /**
     * نمایش صفحه تایید 2FA (در زمان ورود)
     */
    public function showVerify(): void
    {
        $userId = $this->session->get('2fa_user_id');

        if (!$userId) {
            redirect(url('login'));
            return;
        }

        view('user.security.verify-2fa', [
            'title' => 'تایید احراز هویت'
        ]);
    }

    /**
     * تایید کد 2FA (در زمان ورود)
     */
    public function verify(): void
    {
        $userId = $this->session->get('2fa_user_id');

        if (!$userId) {
            $this->response->json(['success' => false, 'message' => 'نشست نامعتبر است.'], 401);
            return;
        }

        $code = $this->request->input('code');

        if (empty($code)) {
            $this->response->json(['success' => false, 'message' => 'لطفاً کد را وارد کنید.']);
            return;
        }

        $user = $this->userModel->find($userId);

        if (!$user || !$user['two_factor_secret']) {
            $this->response->json(['success' => false, 'message' => 'خطا در احراز هویت.']);
            return;
        }

        // تایید کد
        if ($this->twoFactorService->verifyCode($user['two_factor_secret'], $code)) {
            // حذف 2fa_user_id و ایجاد session کامل
            $this->session->remove('2fa_user_id');
            $this->session->set('user_id', $user['id']);
            $this->session->set('username', $user['username']);
            $this->session->set('email', $user['email']);
            $this->session->set('role', $user['role']);
            $this->session->set('is_admin', in_array($user['role'], ['admin', 'super_admin']));
            $this->session->set('logged_in', true);

            $this->activityLog->log('2fa_verified', 'تایید موفق احراز هویت دو مرحله‌ای', $user['id']);

            $this->response->json([
                'success'  => true,
                'message'  => 'ورود موفقیت‌آمیز بود.',
                'redirect' => url('dashboard')
            ]);
            return;
        }

        // افزایش Fraud Score
        $this->userModel->incrementFraudScore($userId, 5);

        $this->response->json(['success' => false, 'message' => 'کد وارد شده نامعتبر است.']);
    }
}