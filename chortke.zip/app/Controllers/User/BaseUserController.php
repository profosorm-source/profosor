<?php

namespace App\Controllers\User;

use App\Controllers\BaseController;
use App\Services\AuthService;
use App\Models\User;

abstract class BaseUserController extends BaseController
{
    protected AuthService $authService;
    protected User $userModel;

    public function __construct(?AuthService $authService = null, ?User $userModel = null)
    {
        parent::__construct();

        $this->authService = $authService ?? new AuthService();
        $this->userModel   = $userModel   ?? new User();
    }

    protected function userId(): ?int
    {
        $id = $this->session->get('user_id');
        return $id ? (int)$id : null;
    }

    protected function requireAuth(): void
    {
        if (!$this->userId()) {
            if (function_exists('is_ajax') && is_ajax()) {
                $this->response->error('احراز هویت لازم است', [], 401);
                exit;
            }

            $this->session->setFlash('error', 'ابتدا وارد حساب کاربری خود شوید.');
            $this->response->redirect(url('login'));
            exit;
        }
    }
}