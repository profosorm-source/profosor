<?php

namespace App\Controllers\User;

use App\Models\User;
use App\Models\PasswordReset;
use App\Services\AuthService;
use Core\Validator;
use PDOException;
use App\Controllers\BaseController;

class AuthController extends BaseController
{
    private AuthService $authService;
    private User $userModel;
    private PasswordReset $passwordResetModel;
   
    

    public function __construct()
    {
        parent::__construct();
        $this->authService = new AuthService();
        $this->userModel = new User();
        $this->passwordResetModel = new PasswordReset();
    }

    /**
     * نمایش فرم ورود
     */
    public function showLogin(): void
    {
        view('user/login', ['title' => 'ورود به سیستم']);
    }

    /**
     * پردازش ورود - از طریق AuthService
     */
    public function login(): void
    {
        // بررسی CAPTCHA
        $captchaToken = trim((string)($_POST['captcha_token'] ?? ''));
        $captchaResp  = trim((string)($_POST['captcha_response'] ?? ''));

        if ($captchaToken === '' || $captchaResp === '') {
            $this->session->setFlash('error', 'لطفاً کپچا را تکمیل کنید.');
            redirect('login');
            return;
        }

        $captchaService = new \App\Services\CaptchaService();
        if (!$captchaService->verify($captchaToken, $captchaResp)) {
            $this->session->setFlash('error', 'کپچا اشتباه است. لطفاً دوباره تلاش کنید.');
            redirect('login');
            return;
        }

        // اعتبارسنجی ورودی
        $data = $this->request->all();
        $validator = new Validator($data, [
            'email'    => 'required|email',
            'password' => 'required|min:6',
        ]);

        if ($validator->fails()) {
            $this->session->setFlash('error', 'لطفاً تمام فیلدها را به درستی پر کنید.');
            $this->session->setFlash('errors', $validator->errors());
            $this->session->setFlash('old', $data);
            $this->response->redirect(url('login'));
            return;
        }

        $remember = ($data['remember'] ?? '') === 'on';

        // ورود از طریق AuthService
        $result = $this->authService->login($data['email'], $data['password'], $remember);

        if (!$result['success']) {
            $this->session->setFlash('error', $result['message']);
            $this->session->setFlash('old', ['email' => $data['email']]);
            $this->response->redirect(url('login'));
            return;
        }

        // 2FA
        if (!empty($result['requires_2fa'])) {
            $this->session->set('pending_2fa_user', $result['user']['id'] ?? null);
            $this->response->redirect(url('two-factor'));
            return;
        }

        $this->session->setFlash('success', 'خوش آمدید!');
        $this->response->redirect(url('dashboard'));
    }

    /**
     * نمایش فرم ثبت‌نام
     */
    public function showRegister()
    {
        $ref = app()->request->query('ref', '');
        $ref = is_string($ref) ? trim($ref) : '';
        $ref = preg_replace('/\s+/', '', $ref);

        if ($ref !== '' && preg_match('/^[A-Za-z0-9_]{4,32}$/', $ref)) {
            $this->session->set('register_referral_code', $ref);
        }

        $referralCode = $this->session->get('register_referral_code');

        return view('user/register', ['referralCode' => $referralCode]);
    }

    /**
     * پردازش ثبت‌نام
     */
    public function register(): void
    {
        if (($_SERVER['REQUEST_METHOD'] ?? 'GET') !== 'POST') {
            redirect('register');
            return;
        }

        $fullName = $this->request->input('full_name');
        $email    = $this->request->input('email');
        $mobile   = $this->request->input('mobile');
        $password = $this->request->input('password');
        $passwordConfirmation = $this->request->input('password_confirmation');
        $terms    = $this->request->input('terms');

        $fullName = is_string($fullName) ? trim($fullName) : '';
        $email    = is_string($email) ? trim($email) : '';
        $mobile   = is_string($mobile) ? trim($mobile) : '';
        $password = is_string($password) ? $password : '';
        $passwordConfirmation = is_string($passwordConfirmation) ? $passwordConfirmation : '';

        if (function_exists('convert_persian_numbers')) {
            $mobile = convert_persian_numbers($mobile);
        }
        $mobile = preg_replace('/\s+/', '', $mobile);

        // اعتبارسنجی
        $errors = [];

        if ($fullName === '' || mb_strlen($fullName) < 3 || mb_strlen($fullName) > 100) {
            $errors[] = 'نام و نام خانوادگی باید بین ۳ تا ۱۰۰ کاراکتر باشد.';
        }

        if ($email === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $errors[] = 'ایمیل معتبر نیست.';
        }

        if ($mobile === '') {
            $errors[] = 'شماره موبایل الزامی است.';
        } elseif (!preg_match('/^09[0-9]{9}$/', $mobile)) {
            $errors[] = 'شماره موبایل نامعتبر است. مثال: 09123456789';
        }

        if ($password === '' || strlen($password) < 8) {
            $errors[] = 'رمز عبور باید حداقل ۸ کاراکتر باشد.';
        } elseif ($password !== $passwordConfirmation) {
            $errors[] = 'رمز عبور و تکرار آن یکسان نیستند.';
        }

        if ($terms !== 'on') {
            $this->session->setFlash('error', 'برای ثبت‌نام باید قوانین سایت را بپذیرید.');
            redirect('register');
            return;
        }

        if (!empty($errors)) {
            $this->session->setFlash('error', implode('<br>', $errors));
            redirect('register');
            return;
        }

        // بررسی تکراری بودن ایمیل/موبایل
        if ($this->userModel->emailExists($email)) {
            $this->session->setFlash('error', 'این ایمیل قبلاً ثبت شده است.');
            redirect('register');
            return;
        }

        if ($this->userModel->mobileExists($mobile)) {
            $this->session->setFlash('error', 'این شماره موبایل قبلاً ثبت شده است.');
            redirect('register');
            return;
        }

        // بررسی رفرال
        $refInput = $this->request->input('referral_code');
        $refInput = is_string($refInput) ? trim($refInput) : '';

        if ($refInput === '') {
            $refInput = (string)($this->session->get('register_referral_code') ?? '');
        }

        $refInput = preg_replace('/\s+/', '', $refInput);
        $referredBy = null;

        if ($refInput !== '') {
            if (!preg_match('/^[A-Za-z0-9_]{4,32}$/', $refInput)) {
                $this->session->setFlash('error', 'کد معرف نامعتبر است.');
                redirect('register');
                return;
            }

            $referrer = $this->userModel->findByReferralCode($refInput);
            if (!$referrer) {
                $this->session->setFlash('error', 'کد معرف یافت نشد.');
                redirect('register');
                return;
            }

            if (!empty($referrer->deleted_at) || in_array((string)($referrer->status ?? ''), ['banned', 'suspended'], true)) {
                $this->session->setFlash('error', 'کد معرف معتبر نیست.');
                redirect('register');
                return;
            }

            $referredBy = (int)$referrer->id;
        }

        // آماده‌سازی داده
        $data = [
            'full_name'  => $fullName,
            'email'      => $email,
            'mobile'     => $mobile,
            'password'   => $password,
            'role'       => 'user',
            'status'     => 'active',
        ];

        if ($referredBy) {
            $data['referred_by'] = $referredBy;
        }

        // ثبت‌نام از طریق AuthService
        try {
            $result = $this->authService->register($data);
        } catch (PDOException $e) {
            $driverCode = (int)($e->errorInfo[1] ?? 0);
            if ($driverCode === 1062) {
                $msg = $e->getMessage();
                if (strpos($msg, 'email') !== false) {
                    $this->session->setFlash('error', 'این ایمیل قبلاً ثبت شده است.');
                } elseif (strpos($msg, 'mobile') !== false) {
                    $this->session->setFlash('error', 'این شماره موبایل قبلاً ثبت شده است.');
                } else {
                    $this->session->setFlash('error', 'اطلاعات تکراری است. لطفاً ورودی‌ها را بررسی کنید.');
                }
                redirect('register');
                return;
            }
            throw $e;
        }

        if (!$result['success']) {
            $this->session->setFlash('error', $result['message']);
            redirect('register');
            return;
        }

        $this->session->set('register_referral_code', null);
        $this->session->setFlash('success', 'ثبت‌نام با موفقیت انجام شد. لطفاً وارد شوید.');
        redirect('login');
    }

    /**
     * نمایش فرم فراموشی رمز عبور
     */
    public function showForgotPassword(): void
    {
        view('user/forgot-password', ['title' => 'فراموشی رمز عبور']);
    }

    /**
     * پردازش فراموشی رمز عبور
     */
    public function forgotPassword(): void
    {
        $data = $this->request->all();

        $validator = new Validator($data, ['email' => 'required|email']);

        if ($validator->fails()) {
            $this->session->setFlash('error', 'لطفاً ایمیل معتبر وارد کنید.');
            $this->response->redirect(url('forgot-password'));
            return;
        }

        $result = $this->authService->requestPasswordReset($data['email']);

        $this->session->setFlash('success', $result['message']);
        $this->response->redirect(url('login'));
    }

    /**
     * نمایش فرم تنظیم مجدد رمز عبور
     */
    public function showResetPassword(): void
    {
        $token = $this->request->get('token');
        if (!$token) {
            $this->session->setFlash('error', 'توکن نامعتبر است.');
            $this->response->redirect(url('login'));
            return;
        }

        view('user/reset-password', ['title' => 'تنظیم مجدد رمز عبور', 'token' => $token]);
    }

    /**
     * پردازش تنظیم مجدد رمز عبور
     */
    public function resetPassword(): void
    {
        $data = $this->request->all();

        $validator = new Validator($data, [
            'token'            => 'required',
            'password'         => 'required|min:8',
            'password_confirm' => 'required|same:password',
        ]);

        if ($validator->fails()) {
            $this->session->setFlash('error', 'لطفاً رمز عبور معتبر وارد کنید.');
            $this->response->redirect(url('reset-password?token=' . ($data['token'] ?? '')));
            return;
        }

        $result = $this->authService->resetPassword($data['token'], $data['password']);

        if (!$result['success']) {
            $this->session->setFlash('error', $result['message']);
            $this->response->redirect(url('forgot-password'));
            return;
        }

        $this->session->setFlash('success', 'رمز عبور با موفقیت تغییر یافت. اکنون وارد شوید.');
        $this->response->redirect(url('login'));
    }

    /**
     * تأیید ایمیل
     */
    public function verifyEmail(): void
    {
        $token = $this->request->get('token') ?? '';

        if (!$token) {
            $this->session->setFlash('error', 'توکن نامعتبر است.');
            $this->response->redirect(url('login'));
            return;
        }

        $result = $this->authService->verifyEmail($token);

        if (!$result['success']) {
            $this->session->setFlash('error', $result['message']);
        } else {
            $this->session->setFlash('success', $result['message']);
        }

        $this->response->redirect(url('login'));
    }

    /**
     * خروج از سیستم
     */
    public function logout(): void
    {
        $this->authService->logout();
        $this->session->setFlash('success', 'با موفقیت خارج شدید.');
        $this->response->redirect(url('login'));
    }
}
