<?php
// app/Controllers/User/InvestmentController.php

namespace App\Controllers\User;

use App\Models\Investment;
use App\Models\TradingRecord;
use App\Models\InvestmentProfit;
use App\Models\InvestmentWithdrawal;
use App\Services\InvestmentService;
use Core\Validator;
use App\Services\ApiRateLimiter;
use App\Controllers\User\BaseUserController;

class InvestmentController extends BaseUserController
{
    private InvestmentService $investmentService;

    public function __construct()
{
    parent::__construct();

    $this->investmentService = new \App\Services\InvestmentService(
        new \App\Services\WalletService(),
        new \App\Services\NotificationService()
    );
}

    /**
     * داشبورد سرمایه‌گذاری
     */
    public function index()
    {
        $userId = user_id();
        $investModel = new Investment();
        $profitModel = new InvestmentProfit();
        $withdrawalModel = new InvestmentWithdrawal();
        $tradingModel = new TradingRecord();
        $activeInvestment = $investModel->getActiveByUser($userId);
        $investments = $investModel->getByUser($userId);
        $canWithdraw = $investModel->canWithdraw($userId);

        $profitHistory = [];
        $totalStats = null;
        if ($activeInvestment) {
            $profitHistory = $profitModel->getByInvestment($activeInvestment->id, 20);
            $totalStats = $profitModel->getTotalByInvestment($activeInvestment->id);
        }

        $recentTrades = $tradingModel->getRecentClosed(10);
        $withdrawals = $withdrawalModel->getByUser($userId, 10);

        $user = auth();
if (!$user) {
    $this->response->redirect(url('login'));
    exit;
}

        return view('user.investment.index', [
            'user' => $user,
            'activeInvestment' => $activeInvestment,
            'investments' => $investments,
            'profitHistory' => $profitHistory,
            'totalStats' => $totalStats,
            'recentTrades' => $recentTrades,
            'withdrawals' => $withdrawals,
            'canWithdraw' => $canWithdraw,
            'settings' => $this->investmentService->getSettings(),
            'isDepositLocked' => $investModel->isDepositLocked($userId),
        ]);
    }

    /**
     * صفحه ثبت سرمایه‌گذاری
     */
    public function create()
    {
        $investModel = new Investment();
        $userId = user_id();

        if ($investModel->hasActiveInvestment($userId)) {
                        $this->session->setFlash('error', 'شما یک پلن فعال دارید. امکان ایجاد پلن جدید نیست.');
            return redirect(url('/user/investment'));
        }

        $user = auth();
if (!$user) {
    $this->response->redirect(url('login'));
    exit;
}

        return view('user.investment.create', [
            'user' => $user,
            'riskWarning' => $this->investmentService->getRiskWarning(),
            'settings' => $this->investmentService->getSettings(),
            'isDepositLocked' => $investModel->isDepositLocked($userId),
        ]);
    }

    /**
     * ثبت سرمایه‌گذاری (POST - AJAX)
     */
    public function store()
    {
                $input = \json_decode(\file_get_contents('php://input'), true) ?? $_POST;

        $validator = new Validator($input, [
            'amount' => 'required|numeric|min:1',
            'risk_accepted' => 'required',
        ]);

        if ($validator->fails()) {
            return $this->response->json([
                'success' => false,
                'message' => 'اطلاعات ورودی نامعتبر است.',
                'errors' => $validator->errors()
            ], 422);
        }

        $data = $validator->data();

// ✅ قبل از آرایه
ApiRateLimiter::enforce('investment_create', (int)user_id(), is_ajax());

$result = $this->investmentService->createInvestment((int)user_id(), [
    'amount' => (float)($data['amount'] ?? 0),
    'risk_accepted' => (int)($data['risk_accepted'] ?? 0),
]);

$this->response->json($result, $result['success'] ? 200 : 422);
return;
}
    /**
     * درخواست برداشت (POST - AJAX)
     */
    public function withdraw()
    {
                $input = \json_decode(\file_get_contents('php://input'), true) ?? $_POST;

        $validator = new Validator($input, [
            'withdrawal_type' => 'required|in:profit_only,full_close',
        ]);

        if ($validator->fails()) {
            return $this->response->json([
                'success' => false,
                'message' => 'نوع برداشت را انتخاب کنید.',
                'errors' => $validator->errors()
            ], 422);
        }

        $data = $validator->data();
        $result = $this->investmentService->requestWithdrawal(user_id(), [
            'withdrawal_type' => $data->withdrawal_type,
        ]);

        return $this->response->json($result, $result['success'] ? 200 : 422);
    }

    /**
     * تاریخچه سود/ضرر
     */
    public function profitHistory()
    {
        $userId = user_id();
        $profitModel = new InvestmentProfit();

        $page = \max(1, (int)($_GET['page'] ?? 1));
        $perPage = 20;
        $offset = ($page - 1) * $perPage;

        $profits = $profitModel->getByUser($userId, $perPage, $offset);
        $total = $profitModel->countByUser($userId);
        $totalPages = \ceil($total / $perPage);

        $user = auth();
if (!$user) {
    $this->response->redirect(url('login'));
    exit;
}

        return view('user.investment.profit-history', [
            'user' => $user,
            'profits' => $profits,
            'total' => $total,
            'totalPages' => $totalPages,
            'currentPage' => $page,
        ]);
    }
}