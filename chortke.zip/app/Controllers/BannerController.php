<?php

namespace App\Controllers;

use App\Services\BannerService;
use App\Controllers\BaseController;

class BannerController extends BaseController
{
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * ثبت کلیک بنر (برای همه کاربران - حتی مهمان)
     */
    public function click()
    {
                        $id = (int)$this->request->param('id');

        $service = new BannerService();
        $result = $service->trackClick($id);

        if ($result['success'] && !empty($result['redirect'])) {
            return redirect($result['redirect']);
        }

        return redirect(url('/'));
    }
}