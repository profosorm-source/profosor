# راهنمای ساخت تصاویر برای چرتکه

## فایل‌های مورد نیاز:

### 1. Logo (لوگو)

#### `public/assets/images/logo-white.png`
- **ابعاد:** 200x80 پیکسل
- **فرمت:** PNG با پس‌زمینه شفاف
- **رنگ:** سفید (برای استفاده روی پس‌زمینه تیره)
- **محتوا:** نوشته "چرتکه" به فونت مناسب

#### `public/assets/images/logo-dark.png`
- **ابعاد:** 200x80 پیکسل
- **فرمت:** PNG با پس‌زمینه شفاف
- **رنگ:** تیره (#333 یا مشابه)
- **محتوا:** نوشته "چرتکه" به فونت مناسب

### 2. Favicon

#### `public/assets/images/favicon.png`
- **ابعاد:** 32x32 پیکسل یا 64x64 پیکسل
- **فرمت:** PNG
- **محتوا:** حرف "چ" یا نماد اختصاصی

#### `public/favicon.ico`
- **ابعاد:** 16x16, 32x32, 48x48 (multi-size)
- **فرمت:** ICO
- **تبدیل:** از favicon.png به ICO

---

## روش ساخت (بدون نرم‌افزار گرافیکی):

### گزینه 1: استفاده از ابزارهای آنلاین

1. **لوگو:**
   - به سایت https://www.canva.com بروید
   - قالب Logo را انتخاب کنید
   - متن "چرتکه" را با فونت Vazir یا Yekan اضافه کنید
   - دو نسخه (سفید و تیره) ذخیره کنید

2. **Favicon:**
   - به سایت https://favicon.io/favicon-generator/ بروید
   - حرف "چ" را وارد کنید
   - رنگ پس‌زمینه: #667eea
   - رنگ متن: سفید
   - دانلود و extract کنید

### گزینه 2: استفاده از Placeholder موقت

برای تست سریع، فایل‌های SVG ساده بسازید:

**logo-white.svg:**
```svg
<svg width="200" height="80" xmlns="http://www.w3.org/2000/svg">
  <text x="50%" y="50%" font-family="Arial" font-size="36" fill="white" text-anchor="middle" dominant-baseline="middle">
    چرتکه
  </text>
</svg>