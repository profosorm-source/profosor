<?php

/**
 * ═══════════════════════════════════════════════════════════════
 *  Security Helpers - پروژه چرتکه
 * ═══════════════════════════════════════════════════════════════
 *  توابع امنیتی اضافی
 * ═══════════════════════════════════════════════════════════════
 */

/**
 * Sanitize Input
 */
function sanitize(mixed $input): mixed
{
    if (is_array($input)) {
        return array_map('sanitize', $input);
    }
    
    if (is_string($input)) {
        return htmlspecialchars(strip_tags(trim($input)), ENT_QUOTES, 'UTF-8');
    }
    
    return $input;
}

/**
 * بررسی IP معتبر
 */
function is_valid_ip(string $ip): bool
{
    return filter_var($ip, FILTER_VALIDATE_IP) !== false;
}

/**
 * دریافت IP واقعی کاربر
 */
function get_real_ip(): string
{
    $headers = [
        'HTTP_CF_CONNECTING_IP', // Cloudflare
        'HTTP_X_REAL_IP',
        'HTTP_X_FORWARDED_FOR',
        'REMOTE_ADDR'
    ];
    
    foreach ($headers as $header) {
        if (!empty($_SERVER[$header]) && is_valid_ip($_SERVER[$header])) {
            return $_SERVER[$header];
        }
    }
    
    return $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
}

/**
 * دریافت User Agent
 */
function get_user_agent(): string
{
    return $_SERVER['HTTP_USER_AGENT'] ?? 'Unknown';
}

/**
 * تولید Hash امن
 */
function secure_hash(string $data): string
{
    return hash('sha256', $data . config('app.name'));
}

/**
 * بررسی قدرت Password
 */
function is_strong_password(string $password): bool
{
    $minLength = PASSWORD_MIN_LENGTH;
    
    if (strlen($password) < $minLength) {
        return false;
    }
    
    if (PASSWORD_REQUIRE_UPPERCASE && !preg_match('/[A-Z]/', $password)) {
        return false;
    }
    
    if (PASSWORD_REQUIRE_LOWERCASE && !preg_match('/[a-z]/', $password)) {
        return false;
    }
    
    if (PASSWORD_REQUIRE_NUMBER && !preg_match('/[0-9]/', $password)) {
        return false;
    }
    
    if (PASSWORD_REQUIRE_SPECIAL && !preg_match('/[^A-Za-z0-9]/', $password)) {
        return false;
    }
    
    return true;
}

/**
 * فیلتر Filename برای آپلود
 */
function safe_filename(string $filename): string
{
    $filename = preg_replace('/[^a-zA-Z0-9_\-\.]/', '_', $filename);
    return substr($filename, 0, 100);
}

/**
 * بررسی Extension فایل
 */
function is_allowed_extension(string $filename, array $allowed): bool
{
    $ext = strtolower(pathinfo($filename, PATHINFO_EXTENSION));
    return in_array($ext, $allowed);
}