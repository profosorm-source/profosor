<?php

/**
 * فرمت مبلغ تومان
 */
function format_irr(float $amount): string
{
    return \number_format($amount, 0, '.', ',') . ' تومان';
}

/**
 * فرمت مبلغ تتری
 */
function format_usdt(float $amount): string
{
    return \number_format($amount, 2, '.', ',') . ' USDT';
}

/**
 * بررسی محدودیت برداشت روزانه
 */
function can_withdraw_today(int $userId): array
{
    $today = \date('Y-m-d');
    
    $sql = "SELECT COUNT(*) as count FROM transactions 
            WHERE account = ? AND type = 'withdrawal' 
            AND DATE(created_at) = ? AND status = 'completed'";
    
    $result = db()->query($sql, ["user_wallet_{$userId}", $today])->fetch();
    
    if ($result && $result->count >= 1) {
        return [
            'can' => false,
            'reason' => 'شما امروز یک بار برداشت کرده‌اید. برداشت بعدی فردا امکان‌پذیر است.'
        ];
    }
    
    return ['can' => true];
}

/**
 * محاسبه کمیسیون
 */
function calculate_commission(float $amount, float $percent): float
{
    return \round($amount * ($percent / 100), 2);
}

/**
 * تولید Idempotency Key
 */
function generate_idempotency_key(int $userId, string $type): string
{
    return \hash('sha256', $userId . $type . \microtime(true));
}