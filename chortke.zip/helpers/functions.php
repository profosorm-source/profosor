<?php

use Core\Session;
use App\Services\SystemSettingService;
/**
 * توابع کمکی سراسری
 * 
 * این فایل شامل 40+ تابع کاربردی است
 */

if (!function_exists('env')) {
    /**
     * دریافت مقدار از .env
     */
    function env($key, $default = null)
    {
        static $env = null;
        
        if ($env === null) {
            $envFile = __DIR__ . '/../.env';
            if (file_exists($envFile)) {
                $env = parse_ini_file($envFile);
            } else {
                $env = [];
            }
        }
        
        if (isset($env[$key])) {
            $value = $env[$key];
            
            // تبدیل string boolean به boolean واقعی
            if ($value === 'true') return true;
            if ($value === 'false') return false;
            if ($value === 'null') return null;
            
            return $value;
        }
        
        return $default;
    }
}


if (!function_exists('feature')) {
    /**
     * بررسی فیچر
     */
    function feature(string $name, ?int $userId = null): bool
    {
        static $service = null;
        
        if ($service === null) {
            $service = new \App\Services\FeatureFlagService();
        }
        
        return $service->isEnabled($name, $userId);
    }
}

if (!function_exists('is_maintenance_mode')) {
    /**
     * بررسی حالت تعمیر
     */
    function is_maintenance_mode(): bool
    {
        return setting('maintenance_mode', false);
    }
}

if (!function_exists('is_safe_mode')) {
    /**
     * بررسی حالت امن
     */
    function is_safe_mode(): bool
    {
        return feature('safe_mode');
    }
/**
     * دریافت مقدار از config
     */
if (!function_exists('config')) {
    
    function config($key, $default = null)
    {
        static $config = null;
        
        if ($config === null) {
            $config = require __DIR__ . '/../config/config.php';
        }
        
        $keys = explode('.', $key);
        $value = $config;
        
        foreach ($keys as $k) {
            if (!isset($value[$k])) {
                return $default;
            }
            $value = $value[$k];
        }
        
        return $value;
    }
}

/**
 * بررسی احراز هویت کاربر
 */
function is_kyc_verified(?int $userId = null): bool
{
    $userId = $userId ?? user_id();
    if (!$userId) return false;

    $user = db()->query("SELECT kyc_status FROM users WHERE id = ?", [$userId])->fetch();
    return $user && $user->kyc_status === 'verified';
}

/**
 * دریافت وضعیت KYC کاربر
 */
function kyc_status(?int $userId = null): string
{
    $userId = $userId ?? user_id();
    if (!$userId) return 'none';

    $user = db()->query("SELECT kyc_status FROM users WHERE id = ?", [$userId])->fetch();
    return $user->kyc_status ?? 'none';
}

/**
 * بررسی اینکه آیا کاربر می‌تواند برداشت کند
 */
function can_withdraw(?int $userId = null): array
{
    $userId = $userId ?? user_id();
    
    if (!is_kyc_verified($userId)) {
        return [
            'can' => false,
            'reason' => 'برای برداشت وجه باید احراز هویت خود را تکمیل کنید'
        ];
    }

    return ['can' => true];
}
/**
     * دریافت Application Instance
     */
if (!function_exists('app')) {
    
    function app()
    {
        return \Core\Application::getInstance();
    }
}

/**
 * ساخت URL کامل (سازگار با localhost و هاست)
 */
function url(string $path = ''): string
{
    // تشخیص خودکار Base URL
    $protocol = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? 'https' : 'http';
    $host = $_SERVER['HTTP_HOST'] ?? 'localhost';
    
    // تشخیص خودکار Base Path
    $scriptName = $_SERVER['SCRIPT_NAME']; // "/chortke/public/index.php"
    $basePath = str_replace('/public/index.php', '', $scriptName); // "/chortke"
    $basePath = str_replace('\\', '/', $basePath); // Fix Windows
    
    // ساخت Base URL
    $baseUrl = $protocol . '://' . $host . $basePath;
    
    // اضافه کردن path
    $path = '/' . ltrim($path, '/');
    
    return rtrim($baseUrl, '/') . $path;
}


/**
 * دریافت URL فایل‌های استاتیک
 * 
 * مثال:
 * asset('assets/css/style.css') → http://localhost/chortke/assets/css/style.css
 * asset('uploads/avatars/user.jpg') → http://localhost/chortke/uploads/avatars/user.jpg
 * 
 * @param string $path مسیر نسبی فایل (از داخل public/)
 * @return string URL کامل
 */
function asset(string $path): string
{
    // حذف slash های اضافی
    $path = ltrim($path, '/');
    
    // دریافت URL پایه از config
    $baseUrl = config('app.url', 'http://localhost/chortke');
    $baseUrl = rtrim($baseUrl, '/');
    
    // ترکیب مستقیم
    return $baseUrl . '/' . $path;
}
if (!function_exists('redirect')) {
    /**
     * هدایت به URL
     */
    function redirect(string $path): void
{
    // اگه با http شروع میشه، مستقیم redirect کن
    if (strpos($path, 'http://') === 0 || strpos($path, 'https://') === 0) {
        header("Location: {$path}");
        exit;
    }
    
    // اگه با / شروع میشه، base path رو اضافه کن
    $basePath = env('APP_BASE_PATH', '');
    $url = rtrim($basePath, '/') . '/' . ltrim($path, '/');
    
    header("Location: {$url}");
    exit;
}
}

if (!function_exists('back')) {
    /**
     * برگشت به صفحه قبل
     */
    function back()
    {
        $referer = $_SERVER['HTTP_REFERER'] ?? url();
        redirect($referer);
    }
}

function old(string $key, $default = ''): string
{
    $old = app()->session->getFlash('old');
    
    if ($old === null) {
        return e($default);
    }
    
    if (!is_array($old)) {
        return e($default);
    }
    
    return e($old[$key] ?? $default);
}

/**
 * تولید Device Fingerprint
 */
function generate_device_fingerprint(): string
{
    $data = [
        $_SERVER['HTTP_USER_AGENT'] ?? '',
        $_SERVER['HTTP_ACCEPT_LANGUAGE'] ?? '',
        $_SERVER['HTTP_ACCEPT_ENCODING'] ?? '',
    ];
    
    return md5(implode('|', $data));
}

/**
 * دریافت IP کاربر
 */
function get_client_ip(): string
{
    $ip = $_SERVER['REMOTE_ADDR'] ?? '';

    // اگر پشت proxy بودی
    if (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
        $parts = \explode(',', $_SERVER['HTTP_X_FORWARDED_FOR']);
        $candidate = \trim($parts[0] ?? '');
        if (\filter_var($candidate, FILTER_VALIDATE_IP)) {
            $ip = $candidate;
        }
    } elseif (!empty($_SERVER['HTTP_CLIENT_IP'])) {
        $candidate = \trim($_SERVER['HTTP_CLIENT_IP']);
        if (\filter_var($candidate, FILTER_VALIDATE_IP)) {
            $ip = $candidate;
        }
    }

    if (!\filter_var($ip, FILTER_VALIDATE_IP)) {
        $ip = '0.0.0.0';
    }

    return $ip;
}

/**
 * دریافت User Agent
 */
function get_user_agent(): string
{
    return $_SERVER['HTTP_USER_AGENT'] ?? 'Unknown';
}

/**
 * تاریخ امروز
 */
function today(): string
{
    return date('Y-m-d');
}
/**
 * بررسی وجود خطا
 */
function hasError(string $field): bool
{
    return error($field) !== null;
}
 /**
     * error
     */

function error(string $field): ?string
{
    $errors = app()->session->getFlash('errors');
    
    if ($errors === null || !is_array($errors)) {
        return null;
    }
    
    return $errors[$field] ?? null;
}
 /**
     * فیلد CSRF برای فرم
     */
function csrf_token(): string
{
    $session = app()->session;

    $token = $session->get('csrf_token');

    if (!is_string($token) || $token === '') {
        $token = bin2hex(random_bytes(32));
        $session->set('csrf_token', $token);
    }

    return $token;
}

function csrf_field(): string
{
    return '<input type="hidden" name="csrf_token" value="' . e(csrf_token()) . '">';
}

if (!function_exists('e')) {
    /**
     * Escape برای جلوگیری از XSS
     */
    function e($value)
    {
        return htmlspecialchars($value ?? '', ENT_QUOTES, 'UTF-8');
    }
}

/**
     * نمایش View
     */
if (!function_exists('view')) {

    function view($viewName, $data = [])
    {
        $session = \Core\Session::getInstance();

        $globals = [];

        $globals['isLoggedIn'] = $session->has('user_id');

        $globals['currentUser'] = null;

        if ($globals['isLoggedIn']) {
            $userModel = new \App\Models\User();
            $globals['currentUser'] = $userModel->find(
                $session->get('user_id')
            ) ?: null;
        }

        $globals['flashSuccess'] = $session->getFlash('success');
        $globals['flashError']   = $session->getFlash('error');
        $globals['flashWarning'] = $session->getFlash('warning');

        $data = array_merge($globals, (array)$data);

        extract($data);

        $viewPath = __DIR__ . '/../views/' . str_replace('.', '/', $viewName) . '.php';

        if (!file_exists($viewPath)) {
            throw new \Exception("View not found: {$viewName}");
        }

        require $viewPath;
    }
}

if (!function_exists('dd')) {
    /**
     * Dump and Die (برای دیباگ)
     */
    function dd(...$vars)
    {
        echo '<pre style="background: #1e1e1e; color: #ddd; padding: 20px; direction: ltr; text-align: left;">';
        foreach ($vars as $var) {
            var_dump($var);
        }
        echo '</pre>';
        die(1);
    }
}

function logger($a = null, $b = [], $c = 'INFO')
{
    static $logger = null;

    if ($logger === null) {
        $logger = new class {
            private string $logDir;

            public function __construct()
            {
                $this->logDir = dirname(__DIR__) . '/storage/logs/';
                if (!is_dir($this->logDir)) {
                    mkdir($this->logDir, 0755, true);
                }
            }

            public function info(string $message, array $context = []): void
            {
                $this->log('INFO', $message, $context);
            }

            public function warning(string $message, array $context = []): void
            {
                $this->log('WARNING', $message, $context);
            }

            public function error(string $message, array $context = []): void
            {
                $this->log('ERROR', $message, $context);
            }

            public function debug(string $message, array $context = []): void
            {
                // اگر خواستی فقط در debug لاگ کند:
                // if (!config('app.debug')) return;
                $this->log('DEBUG', $message, $context);
            }

            // ✅ فقط این متد از بیرون هم قابل صدا زدن است
            public function log(string $level, string $message, array $context = []): void
            {
                $level = strtoupper($level);
                $timestamp = date('Y-m-d H:i:s');
                $logFile = $this->logDir . date('Y-m-d') . '.log';

                $contextStr = '';
                if (!empty($context)) {
                    $contextStr = ' ' . json_encode($context, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
                }

                $line = "[{$timestamp}] [{$level}] {$message}{$contextStr}" . PHP_EOL;
                file_put_contents($logFile, $line, FILE_APPEND | LOCK_EX);
            }
        };
    }

    // 0 args => chaining: logger()->error(...)
    if ($a === null) {
        return $logger;
    }

    // helper
    $levels = ['INFO','ERROR','WARNING','DEBUG'];

    // حالت 1: logger('error', 'message', ['ctx'])
    if (is_string($a) && in_array(strtoupper($a), $levels, true)) {
        $level = strtoupper($a);
        $message = is_string($b) ? $b : 'No message';

        if (is_array($c)) {
            $context = $c;
        } else {
            // اگر اشتباهاً string دادند، تبدیلش می‌کنیم تا Fatal نده
            $context = ['context' => (string)$c];
        }

        $logger->log($level, $message, $context);
        return null;
    }

    // حالت 2: logger('message', ['ctx'], 'ERROR')
    if (is_string($a) && is_array($b)) {
        $message = $a;
        $context = $b;
        $level = is_string($c) ? strtoupper($c) : 'INFO';

        $logger->log($level, $message, $context);
        return null;
    }

    // حالت 3: logger('message')
    if (is_string($a) && $b === []) {
        $logger->log('INFO', $a, []);
        return null;
    }

    // حالت 4: هر چیز غیرمنتظره
    $logger->log('WARNING', 'Unknown logger call signature', [
        'args' => func_get_args()
    ]);
    return null;
}
if (!function_exists('str_random')) {
    /**
     * تولید رشته تصادفی
     */
    function str_random($length = 16)
    {
        $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
        $charactersLength = strlen($characters);
        $randomString = '';
        
        for ($i = 0; $i < $length; $i++) {
            $randomString .= $characters[random_int(0, $charactersLength - 1)];
        }
        
        return $randomString;
    }
}

if (!function_exists('hash_password')) {
    /**
     * Hash کردن رمز عبور (Argon2id)
     */
    function hash_password($password)
    {
        if (defined('PASSWORD_ARGON2ID')) {
            return password_hash($password, PASSWORD_ARGON2ID);
        }
        
        return password_hash($password, PASSWORD_BCRYPT, ['cost' => 12]);
    }
}

if (!function_exists('verify_password')) {
    /**
     * تایید رمز عبور
     */
    function verify_password($password, $hash)
    {
        return password_verify($password, $hash);
    }
}

if (!function_exists('sanitize')) {
    /**
     * پاکسازی ورودی
     */
    function sanitize($data)
    {
        if (is_array($data)) {
            return array_map('sanitize', $data);
        }
        
        return htmlspecialchars(strip_tags(trim($data)), ENT_QUOTES, 'UTF-8');
    }
}

if (!function_exists('is_ajax')) {
    /**
     * بررسی درخواست AJAX
     */
    function is_ajax()
    {
        return isset($_SERVER['HTTP_X_REQUESTED_WITH']) 
            && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest';
    }
}

if (!function_exists('json_response')) {
    /**
     * پاسخ JSON
     */
    function json_response($data, $statusCode = 200)
    {
        http_response_code($statusCode);
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode($data, JSON_UNESCAPED_UNICODE);
        exit;
    }
}
if (!function_exists('url_base')) {
    function url_base(): string
    {
        return \Core\PathResolver::getInstance()->base();
    }
}

if (!function_exists('path')) {
    function path(string $path = ''): string
    {
        return \Core\PathResolver::getInstance()->path($path);
    }
}

if (!function_exists('storage_path')) {
    function storage_path(string $path = ''): string
    {
        return \Core\PathResolver::getInstance()->storage($path);
    }
}

if (!function_exists('public_path')) {
    function public_path(string $path = ''): string
    {
        return \Core\PathResolver::getInstance()->public($path);
    }
}
if (!function_exists('success_response')) {
    /**
     * پاسخ موفق JSON
     */
    function success_response($message, $data = [])
    {
        json_response([
            'success' => true,
            'message' => $message,
            'data' => $data
        ]);
    }
}

if (!function_exists('error_response')) {
    /**
     * پاسخ خطا JSON
     */
    function error_response($message, $errors = [], $statusCode = 400)
    {
        json_response([
            'success' => false,
            'message' => $message,
            'errors' => $errors
        ], $statusCode);
    }
}

if (!function_exists('now')) {
    /**
     * تاریخ و زمان فعلی
     */
    function now()
    {
        return date('Y-m-d H:i:s');
    }
}

/**
 * دریافت Database Instance
 */
function db(): \Core\Database
{
    return app()->db;
}
/**
     * تاریخ امروز
     */
if (!function_exists('today')) {
    
    function today()
    {
        return date('Y-m-d');
    }
}

if (!function_exists('to_jalali')) {
    /**
     * تبدیل میلادی به شمسی و اعداد فارسی
     */
    function to_jalali($date, $format = 'Y/m/d', $persianNumbers = true)
    {
        if (empty($date)) return '';

        require_once __DIR__ . '/JalaliDate.php';

        $timestamp = is_numeric($date) ? $date : strtotime($date);
        $jalali = \Helpers\JalaliDate::format($format, $timestamp);

        if ($persianNumbers) {
            $englishNumbers = ['0','1','2','3','4','5','6','7','8','9'];
            $farsiNumbers   = ['۰','۱','۲','۳','۴','۵','۶','۷','۸','۹'];
            $jalali = str_replace($englishNumbers, $farsiNumbers, $jalali);
        }

        return $jalali;
    }
}

if (!function_exists('fa_number')) {
    function fa_number($value): string
    {
        $english = ['0','1','2','3','4','5','6','7','8','9'];
        $persian = ['۰','۱','۲','۳','۴','۵','۶','۷','۸','۹'];

        return str_replace($english, $persian, (string)$value);
    }
}

if (!function_exists('to_gregorian')) {
    /**
     * تبدیل شمسی به میلادی
     */
    function to_gregorian($jalaliDate)
    {
        if (empty($jalaliDate)) return '';
        
        require_once __DIR__ . '/JalaliDate.php';
        
        return \Helpers\JalaliDate::toGregorian($jalaliDate);
    }
}

if (!function_exists('format_price')) {
    /**
     * فرمت قیمت
     */
    function format_price($price, $currency = 'تومان')
    {
        return number_format($price, 0) . ' ' . $currency;
    }
}

if (!function_exists('upload_file')) {
    /**
     * آپلود فایل
     */
    function upload_file($file, $directory = 'general')
    {
        if (!isset($file['error']) || $file['error'] !== UPLOAD_ERR_OK) {
            throw new \Exception('خطا در آپلود فایل');
        }
        
        $uploadPath = __DIR__ . '/../public/uploads/' . $directory . '/';
        
        if (!is_dir($uploadPath)) {
            mkdir($uploadPath, 0755, true);
        }
        
        $extension = pathinfo($file['name'], PATHINFO_EXTENSION);
        $filename = uniqid() . '_' . time() . '.' . $extension;
        $destination = $uploadPath . $filename;
        
        if (!move_uploaded_file($file['tmp_name'], $destination)) {
            throw new \Exception('خطا در ذخیره فایل');
        }
        
        return 'public/uploads/' . $directory . '/' . $filename;
    }
}

/**
 * دریافت حالت ارزی فعلی
 */
function currency_mode(): string
{
    return \App\Services\CurrencyService::getCurrentMode();
}

/**
 * فرمت کردن مبلغ
 */
function format_amount(float $amount): string
{
    return \App\Services\CurrencyService::formatAmount($amount);
}

/**
 * آیا سایت در حالت تومان است؟
 */
function is_irt_mode(): bool
{
    return \App\Services\CurrencyService::isIRT();
}

/**
 * آیا سایت در حالت تتر است؟
 */
function is_usdt_mode(): bool
{
    return \App\Services\CurrencyService::isUSDT();
}

/**
 * دریافت ارز قسمت فعلی (برای سرمایه‌گذاری همیشه USDT)
 */
function section_currency(): string
{
    return \App\Services\CurrencyService::getSectionCurrency();
}

if (!function_exists('delete_file')) {
    /**
     * حذف فایل
     */
    function delete_file($path)
    {
        $fullPath = __DIR__ . '/../' . $path;
        
        if (file_exists($fullPath)) {
            return unlink($fullPath);
        }
        
        return false;
    }
}

if (!function_exists('get_client_ip')) {
    /**
     * دریافت IP کاربر
     */
    function get_client_ip()
    {
        $ip = '';
        
        if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
            $ip = $_SERVER['HTTP_CLIENT_IP'];
        } elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
            $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
        } else {
            $ip = $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
        }
        
        return $ip;
    }
}

if (!function_exists('get_user_agent')) {
    /**
     * دریافت User Agent
     */
    function get_user_agent()
    {
        return $_SERVER['HTTP_USER_AGENT'] ?? 'Unknown';
    }
}

if (!function_exists('is_mobile')) {
    /**
     * بررسی موبایل بودن
     */
    function is_mobile()
    {
        $userAgent = get_user_agent();
        return preg_match('/(android|iphone|ipad|mobile)/i', $userAgent);
    }
}

if (!function_exists('abort')) {
    /**
     * نمایش خطا و خروج
     */
    function abort($code = 404, $message = '')
    {
        http_response_code($code);
        
        $errorPage = __DIR__ . '/../views/errors/' . $code . '.php';
        
        if (file_exists($errorPage)) {
            require $errorPage;
        } else {
            echo "<h1>Error {$code}</h1>";
            if ($message) {
                echo "<p>{$message}</p>";
            }
        }
        
        exit;
    }
}

if (!function_exists('auth_user')) {
    /**
     * دریافت کاربر لاگین شده
     */
    function auth_user()
    {
        $userId = app()->session->get('user_id');
        
        if (!$userId) {
            return null;
        }
        
        static $user = null;
        
        if ($user === null) {
            $userModel = new \App\Models\User();
            $user = $userModel->find($userId);
        }
        
        return $user;
    }
}

if (!function_exists('is_admin')) {
    /**
     * بررسی ادمین بودن کاربر
     */
   function is_admin(): bool
{
    $session = Session::getInstance();
    return ($session->get('user_role') === 'admin');
}
}

/**
 * تبدیل تاریخ به فرمت نسبی (مثلاً "2 ساعت پیش")
 */
function time_ago(string $datetime): string
{
    $timestamp = \strtotime($datetime);
    $now = \time();
    $diff = $now - $timestamp;

    if ($diff < 60) {
        return 'همین الان';
    } elseif ($diff < 3600) {
        $minutes = \floor($diff / 60);
        return to_jalali((string)$minutes, '', true) . ' دقیقه پیش';
    } elseif ($diff < 86400) {
        $hours = \floor($diff / 3600);
        return to_jalali((string)$hours, '', true) . ' ساعت پیش';
    } elseif ($diff < 2592000) {
        $days = \floor($diff / 86400);
        return to_jalali((string)$days, '', true) . ' روز پیش';
    } elseif ($diff < 31536000) {
        $months = \floor($diff / 2592000);
        return to_jalali((string)$months, '', true) . ' ماه پیش';
    } else {
        $years = \floor($diff / 31536000);
        return to_jalali((string)$years, '', true) . ' سال پیش';
    }
}

/**
     * تولید اثر انگشت دستگاه
     */
	 
if (!function_exists('generate_device_fingerprint')) {
    
    function generate_device_fingerprint()
    {
        $data = [
            'ip' => get_client_ip(),
            'user_agent' => get_user_agent(),
            'accept_language' => $_SERVER['HTTP_ACCEPT_LANGUAGE'] ?? '',
            'accept_encoding' => $_SERVER['HTTP_ACCEPT_ENCODING'] ?? '',
        ];
        
        return hash('sha256', json_encode($data));
    }
}


/**
 * دریافت پیام Flash
 */
function flash(string $key): ?string
{
    $value = app()->session->getFlash($key);
    
    // Debug (موقتی - بعداً حذف کن)
    // echo "<!-- Flash {$key}: " . var_export($value, true) . " -->\n";
    
    return $value;
}

/**
     * دریافت پیام Flash
     */
if (!function_exists('get_flash')) {
    
    function get_flash($key, $default = null)
    {
        return app()->session->getFlash($key, $default);
    }
}
/**
 * در انتهای فایل helpers/functions.php این تابع را اضافه کنید:
 */
function fa_digits(string $value): string
{
    $map = ['0'=>'۰','1'=>'۱','2'=>'۲','3'=>'۳','4'=>'۴','5'=>'۵','6'=>'۶','7'=>'۷','8'=>'۸','9'=>'۹'];
    return \strtr($value, $map);
}
/**
 * ثبت فعالیت کاربر
 */
if (!function_exists('log_activity')) {
    /**
     * ثبت لاگ فعالیت
     */
    function log_activity(
    string $action,
    string $description,
    ?int $userId = null,
    array $metadata = [],
    ?string $ipAddress = null,
    ?string $userAgent = null
): void {
    try {
        \Core\Session::getInstance();

        $ipAddress = $ipAddress ?: get_client_ip();
        $ipAddress = (string)$ipAddress;

        if (!\filter_var($ipAddress, FILTER_VALIDATE_IP)) {
            $ipAddress = get_client_ip();
        }

        $userAgent = $userAgent ?: (get_user_agent() ?: ($_SERVER['HTTP_USER_AGENT'] ?? ''));
        $userAgent = (string)$userAgent;

        db()->query(
            "INSERT INTO activity_logs (user_id, action, description, metadata, ip_address, user_agent, created_at, updated_at)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
            [
                $userId,
                $action,
                $description,
                \json_encode($metadata, JSON_UNESCAPED_UNICODE),
                $ipAddress,
                $userAgent,
                \date('Y-m-d H:i:s'),
                \date('Y-m-d H:i:s'),
            ]
        );
    } catch (\Throwable $e) {
        \error_log('log_activity failed: ' . $e->getMessage());
    }
        }
}

/**
 * بررسی دسترسی کاربر فعلی
 * 
 * @param string $permission slug دسترسی
 * @return bool
 */
function can(string $permission): bool
{
    return \App\Middleware\PermissionMiddleware::check($permission);
}

/**
 * بررسی چند دسترسی (حداقل یکی)
 * 
 * @param array $permissions
 * @return bool
 */
function can_any(array $permissions): bool
{
    return \App\Middleware\PermissionMiddleware::checkAny($permissions);
}
	/**
 * تبدیل تاریخ میلادی به شمسی
 */
if (!function_exists('jdate')) {
    function jdate($datetime, $format = 'Y/m/d H:i')
    {
        if (empty($datetime)) {
            return '-';
        }

        $timestamp = is_numeric($datetime) ? (int)$datetime : strtotime($datetime);

        return jalali_date($format, $timestamp);
    }
}

if (!function_exists('jalali_date')) {
    function jalali_date($format, $timestamp)
    {
        $g_y = date('Y', $timestamp);
        $g_m = date('n', $timestamp);
        $g_d = date('j', $timestamp);

        list($j_y, $j_m, $j_d) = gregorian_to_jalali($g_y, $g_m, $g_d);

        $replacements = [
            'Y' => $j_y,
            'm' => str_pad($j_m, 2, '0', STR_PAD_LEFT),
            'd' => str_pad($j_d, 2, '0', STR_PAD_LEFT),
            'H' => date('H', $timestamp),
            'i' => date('i', $timestamp),
            's' => date('s', $timestamp),
        ];

        return strtr($format, $replacements);
    }
}

if (!function_exists('gregorian_to_jalali')) {
    function gregorian_to_jalali($g_y, $g_m, $g_d)
    {
        $g_days_in_month = [31,28,31,30,31,30,31,31,30,31,30,31];
        $j_days_in_month = [31,31,31,31,31,31,30,30,30,30,30,29];

        $gy = $g_y - 1600;
        $gm = $g_m - 1;
        $gd = $g_d - 1;

        $g_day_no = 365*$gy + intdiv($gy+3,4) - intdiv($gy+99,100) + intdiv($gy+399,400);

        for ($i=0; $i < $gm; ++$i)
            $g_day_no += $g_days_in_month[$i];

        if ($gm > 1 && (($gy%4==0 && $gy%100!=0) || ($gy%400==0)))
            $g_day_no++;

        $g_day_no += $gd;

        $j_day_no = $g_day_no - 79;

        $j_np = intdiv($j_day_no, 12053);
        $j_day_no %= 12053;

        $jy = 979 + 33*$j_np + 4*intdiv($j_day_no,1461);

        $j_day_no %= 1461;

        if ($j_day_no >= 366) {
            $jy += intdiv($j_day_no-1,365);
            $j_day_no = ($j_day_no-1)%365;
        }

        for ($i = 0; $i < 11 && $j_day_no >= $j_days_in_month[$i]; ++$i)
            $j_day_no -= $j_days_in_month[$i];

        $jm = $i + 1;
        $jd = $j_day_no + 1;

        return [$jy, $jm, $jd];
    }
}


function jtime(?string $mysqlDateTime, bool $seconds = false, bool $convertNumbers = true): string
{
    if (!$mysqlDateTime) return '-';

    $fmt = $seconds ? 'H:i:s' : 'H:i';
    $t = \date($fmt, \strtotime($mysqlDateTime));

    // تبدیل اعداد ساعت به فارسی (اگر خواستی)
    return $convertNumbers ? to_jalali($t, '', true) : $t;
}

function jdatetime(?string $mysqlDateTime, bool $seconds = false, bool $convertNumbers = true): string
{
    if (!$mysqlDateTime) return '-';

    $d = jdate($mysqlDateTime);
    $t = jtime($mysqlDateTime, $seconds, $convertNumbers);

    return $d . ' ' . $t;
}

/**
 * بررسی لاگین بودن کاربر
 */
if (!function_exists('auth')) {
    function auth(): ?object
    {
        static $cached = null;

        if ($cached !== null) {
            return $cached;
        }

        $session = \Core\Session::getInstance();
        if (!$session->has('user_id')) {
            $cached = null;
            return null;
        }

        $userId = (int)$session->get('user_id');
        $cached = (new \App\Models\User())->find($userId) ?: null;

        return $cached;
    }
}
/**
 * دریافت تنظیمات سایت
 */
function settings(bool $forceReload = false): array
{
    static $data = null;

    if ($forceReload) {
        $data = null;
    }

    if ($data !== null) return $data;

    $service = new \App\Services\SettingService();
    $data = $service->load(); // public only
    return $data;
}

function setting(string $key, mixed $default = null): mixed
{
    $all = settings();
    return $all[$key] ?? $default;
}
/**
 * دریافت ID کاربر فعلی
 */
function user_id(): ?int
{
    $session = Session::getInstance();
    $id = $session->get('user_id');
    return $id ? (int)$id : null;
}

/**
 * در انتهای فایل helpers/functions.php این خطوط را اضافه کنید:
 */

// بارگذاری Image Helpers
if (file_exists(__DIR__ . '/image.php')) {
    require_once __DIR__ . '/image.php';
}

// بارگذاری Validator Helpers
if (file_exists(__DIR__ . '/validator.php')) {
    require_once __DIR__ . '/validator.php';
}

// بارگذاری Response Helpers
if (file_exists(__DIR__ . '/response.php')) {
    require_once __DIR__ . '/response.php';
}

// بارگذاری jdf.php
if (file_exists(__DIR__ . '/jdf.php')) {
    require_once __DIR__ . '/jdf.php';
}

// بارگذاری wallet.php
if (file_exists(__DIR__ . '/wallet.php')) {
    require_once __DIR__ . '/wallet.php';
}


// بارگذاری notifications.php
if (file_exists(__DIR__ . '/notifications.php')) {
    require_once __DIR__ . '/notifications.php';
}
}

// بارگذاری captcha_helper.php
if (file_exists(__DIR__ . '/captcha_helper.php')) {
    require_once __DIR__ . '/captcha_helper.php';
}

// بارگذاری banner.php
if (file_exists(__DIR__ . '/banner.php')) {
    require_once __DIR__ . '/banner.php';

}
