<?php

/**
 * label_helpers.php
 * ─────────────────────────────────────────────────────────────────────────────
 * توابع global برای نمایش label، badge و کلاس CSS در views
 * همه‌ی این توابع stateless و pure هستند — هیچ وابستگی به DB ندارند
 * در views به جای فراخوانی استاتیک مدل (مثل AdTask::statusLabel) از این توابع استفاده کنید
 * ─────────────────────────────────────────────────────────────────────────────
 */

// ═══════════════════════════════════════════════════════════════════════════
// Advertisement / AdTask
// ═══════════════════════════════════════════════════════════════════════════

/**
 * نام فارسی نوع تسک تبلیغاتی
 */
function ad_task_type_label(string $type): string
{
    $labels = [
        'follow'       => 'فالو',
        'subscribe'    => 'سابسکرایب',
        'join_channel' => 'عضویت کانال',
        'join_group'   => 'عضویت گروه',
        'like'         => 'لایک',
        'comment'      => 'کامنت',
        'view'         => 'بازدید ویدیو',
        'story_view'   => 'بازدید استوری',
    ];
    return $labels[$type] ?? $type;
}

/**
 * نام فارسی وضعیت تبلیغ
 */
function ad_status_label(string $status): string
{
    $labels = [
        'pending'   => 'در انتظار تایید',
        'active'    => 'فعال',
        'paused'    => 'متوقف',
        'completed' => 'تکمیل شده',
        'cancelled' => 'لغو شده',
        'rejected'  => 'رد شده',
    ];
    return $labels[$status] ?? $status;
}

/**
 * کلاس CSS badge وضعیت تبلیغ
 */
function ad_status_badge(string $status): string
{
    $badges = [
        'pending'   => 'warning',
        'active'    => 'success',
        'paused'    => 'info',
        'completed' => 'primary',
        'cancelled' => 'secondary',
        'rejected'  => 'danger',
    ];
    return $badges[$status] ?? 'secondary';
}

// ═══════════════════════════════════════════════════════════════════════════
// SocialAccount
// ═══════════════════════════════════════════════════════════════════════════

/**
 * نام فارسی پلتفرم شبکه اجتماعی
 */
function social_platform_label(string $platform): string
{
    $labels = [
        'instagram' => 'اینستاگرام',
        'telegram'  => 'تلگرام',
        'youtube'   => 'یوتیوب',
        'twitter'   => 'توییتر',
        'tiktok'    => 'تیک‌تاک',
        'linkedin'  => 'لینکدین',
        'aparat'    => 'آپارات',
    ];
    return $labels[$platform] ?? $platform;
}

/**
 * نام فارسی وضعیت حساب اجتماعی
 */
function social_status_label(string $status): string
{
    $labels = [
        'pending'  => 'در انتظار تایید',
        'active'   => 'فعال',
        'rejected' => 'رد شده',
        'inactive' => 'غیرفعال',
    ];
    return $labels[$status] ?? $status;
}

/**
 * کلاس CSS badge وضعیت حساب اجتماعی
 */
function social_status_badge(string $status): string
{
    $badges = [
        'pending'  => 'warning',
        'active'   => 'success',
        'rejected' => 'danger',
        'inactive' => 'secondary',
    ];
    return $badges[$status] ?? 'secondary';
}

// ═══════════════════════════════════════════════════════════════════════════
// TaskExecution
// ═══════════════════════════════════════════════════════════════════════════

/**
 * نام فارسی وضعیت اجرای تسک
 */
function task_execution_status_label(string $status): string
{
    $labels = [
        'pending'   => 'در انتظار بررسی',
        'approved'  => 'تایید شده',
        'rejected'  => 'رد شده',
        'expired'   => 'منقضی',
        'disputed'  => 'اختلاف',
        'cancelled' => 'لغو شده',
    ];
    return $labels[$status] ?? $status;
}

/**
 * کلاس CSS badge وضعیت اجرای تسک
 */
function task_execution_status_badge(string $status): string
{
    $badges = [
        'pending'   => 'warning',
        'approved'  => 'success',
        'rejected'  => 'danger',
        'expired'   => 'secondary',
        'disputed'  => 'info',
        'cancelled' => 'secondary',
    ];
    return $badges[$status] ?? 'secondary';
}

// ═══════════════════════════════════════════════════════════════════════════
// TaskDispute
// ═══════════════════════════════════════════════════════════════════════════

/**
 * نام فارسی وضعیت اختلاف
 */
function task_dispute_status_label(string $status): string
{
    $labels = [
        'open'            => 'باز',
        'under_review'    => 'در حال بررسی',
        'resolved_worker' => 'حل‌شده به نفع کارکن',
        'resolved_adv'    => 'حل‌شده به نفع تبلیغ‌دهنده',
        'closed'          => 'بسته',
    ];
    return $labels[$status] ?? $status;
}

/**
 * کلاس CSS badge وضعیت اختلاف
 */
function task_dispute_status_badge(string $status): string
{
    $badges = [
        'open'            => 'danger',
        'under_review'    => 'warning',
        'resolved_worker' => 'success',
        'resolved_adv'    => 'info',
        'closed'          => 'secondary',
    ];
    return $badges[$status] ?? 'secondary';
}

// ═══════════════════════════════════════════════════════════════════════════
// CustomTask
// ═══════════════════════════════════════════════════════════════════════════

/**
 * لیست انواع تسک سفارشی [key => label]
 */
function custom_task_types(): array
{
    return [
        'signup'  => 'ثبت‌نام',
        'install' => 'نصب برنامه',
        'review'  => 'نظر دادن',
        'vote'    => 'رأی دادن',
        'follow'  => 'دنبال کردن',
        'join'    => 'عضویت',
        'custom'  => 'سفارشی',
    ];
}

/**
 * لیست انواع مدرک تسک سفارشی [key => label]
 */
function custom_task_proof_types(): array
{
    return [
        'screenshot' => 'اسکرین‌شات',
        'text'       => 'متن',
        'video'      => 'ویدیو',
        'code'       => 'کد رفرال',
        'file'       => 'فایل',
    ];
}

/**
 * نام فارسی وضعیت تسک سفارشی
 */
function custom_task_status_label(string $status): string
{
    $labels = [
        'draft'          => 'پیشنویس',
        'review_pending' => 'در انتظار بررسی',
        'active'         => 'فعال',
        'paused'         => 'متوقف',
        'completed'      => 'تکمیل‌شده',
        'rejected'       => 'رد شده',
        'expired'        => 'منقضی',
    ];
    return $labels[$status] ?? $status;
}

/**
 * کلاس CSS badge وضعیت تسک سفارشی
 */
function custom_task_status_class(string $status): string
{
    $classes = [
        'draft'          => 'badge-secondary',
        'review_pending' => 'badge-warning',
        'active'         => 'badge-success',
        'paused'         => 'badge-info',
        'completed'      => 'badge-primary',
        'rejected'       => 'badge-danger',
        'expired'        => 'badge-danger',
    ];
    return $classes[$status] ?? 'badge-secondary';
}

// ═══════════════════════════════════════════════════════════════════════════
// CustomTaskSubmission
// ═══════════════════════════════════════════════════════════════════════════

/**
 * نام فارسی وضعیت ارسال تسک سفارشی
 */
function custom_submission_status_label(string $status): string
{
    $labels = [
        'pending'  => 'در انتظار بررسی',
        'approved' => 'تایید شده',
        'rejected' => 'رد شده',
        'expired'  => 'منقضی',
    ];
    return $labels[$status] ?? $status;
}

/**
 * کلاس CSS badge وضعیت ارسال تسک سفارشی
 */
function custom_submission_status_class(string $status): string
{
    $classes = [
        'pending'  => 'badge-warning',
        'approved' => 'badge-success',
        'rejected' => 'badge-danger',
        'expired'  => 'badge-secondary',
    ];
    return $classes[$status] ?? 'badge-secondary';
}

// ═══════════════════════════════════════════════════════════════════════════
// StoryOrder
// ═══════════════════════════════════════════════════════════════════════════

/**
 * نام فارسی وضعیت سفارش استوری
 */
function story_order_status_label(string $status): string
{
    $labels = [
        'pending'   => 'در انتظار',
        'active'    => 'فعال',
        'completed' => 'تکمیل‌شده',
        'cancelled' => 'لغو شده',
        'rejected'  => 'رد شده',
    ];
    return $labels[$status] ?? $status;
}

/**
 * کلاس CSS badge وضعیت سفارش استوری
 */
function story_order_status_class(string $status): string
{
    $classes = [
        'pending'   => 'badge-warning',
        'active'    => 'badge-success',
        'completed' => 'badge-primary',
        'cancelled' => 'badge-secondary',
        'rejected'  => 'badge-danger',
    ];
    return $classes[$status] ?? 'badge-secondary';
}

// ═══════════════════════════════════════════════════════════════════════════
// SEOExecution
// ═══════════════════════════════════════════════════════════════════════════

/**
 * نام فارسی وضعیت اجرای SEO
 */
function seo_execution_status_label(string $status): string
{
    $labels = [
        'pending'   => 'در انتظار',
        'approved'  => 'تایید شده',
        'rejected'  => 'رد شده',
        'expired'   => 'منقضی',
    ];
    return $labels[$status] ?? $status;
}

/**
 * کلاس CSS badge وضعیت اجرای SEO
 */
function seo_execution_status_badge(string $status): string
{
    $badges = [
        'pending'  => 'warning',
        'approved' => 'success',
        'rejected' => 'danger',
        'expired'  => 'secondary',
    ];
    return $badges[$status] ?? 'secondary';
}


// ═══════════════════════════════════════════════════════════════════════════
// Map helpers (برای views که از array کامل نیاز دارند)
// ═══════════════════════════════════════════════════════════════════════════

function custom_task_status_labels_map(): array  { return ['draft'=>'پیشنویس','review_pending'=>'در انتظار بررسی','active'=>'فعال','paused'=>'متوقف','completed'=>'تکمیل‌شده','rejected'=>'رد شده','expired'=>'منقضی']; }
function custom_task_status_classes_map(): array { return ['draft'=>'badge-secondary','review_pending'=>'badge-warning','active'=>'badge-success','paused'=>'badge-info','completed'=>'badge-primary','rejected'=>'badge-danger','expired'=>'badge-danger']; }
function custom_submission_status_labels_map(): array  { return ['pending'=>'در انتظار بررسی','approved'=>'تایید شده','rejected'=>'رد شده','expired'=>'منقضی']; }
function custom_submission_status_classes_map(): array { return ['pending'=>'badge-warning','approved'=>'badge-success','rejected'=>'badge-danger','expired'=>'badge-secondary']; }
function story_order_status_labels_map(): array  { return ['pending'=>'در انتظار','active'=>'فعال','completed'=>'تکمیل‌شده','cancelled'=>'لغو شده','rejected'=>'رد شده']; }
function story_order_status_classes_map(): array { return ['pending'=>'badge-warning','active'=>'badge-success','completed'=>'badge-primary','cancelled'=>'badge-secondary','rejected'=>'badge-danger']; }
