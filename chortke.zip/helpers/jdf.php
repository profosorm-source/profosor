<?php

/**
 * تابع تبدیل تاریخ میلادی به شمسی
 * نسخه ساده
 */
if (!function_exists('jdate')) {
    function jdate($format, $timestamp = null)
    {
        $timestamp = $timestamp ?? time();
        
        // آرایه تبدیل ماه‌ها
        $months = [
            'فروردین', 'اردیبهشت', 'خرداد', 'تیر', 
            'مرداد', 'شهریور', 'مهر', 'آبان', 
            'آذر', 'دی', 'بهمن', 'اسفند'
        ];
        
        // آرایه تبدیل روزهای هفته
        $days = [
            'یکشنبه', 'دوشنبه', 'سه‌شنبه', 
            'چهارشنبه', 'پنجشنبه', 'جمعه', 'شنبه'
        ];
        
        // تبدیل تاریخ میلادی به شمسی
        list($year, $month, $day) = gregorian_to_jalali(
            date('Y', $timestamp),
            date('m', $timestamp),
            date('d', $timestamp)
        );
        
        // جایگزینی فرمت‌ها
        $format = str_replace('Y', $year, $format);
        $format = str_replace('m', sprintf('%02d', $month), $format);
        $format = str_replace('d', sprintf('%02d', $day), $format);
        $format = str_replace('H', date('H', $timestamp), $format);
        $format = str_replace('i', date('i', $timestamp), $format);
        $format = str_replace('s', date('s', $timestamp), $format);
        $format = str_replace('F', $months[$month - 1], $format);
        $format = str_replace('l', $days[date('w', $timestamp)], $format);
        
        return $format;
    }
}

/**
 * تبدیل تاریخ میلادی به شمسی
 */
if (!function_exists('gregorian_to_jalali')) {
    function gregorian_to_jalali($gy, $gm, $gd)
    {
        $g_d_m = [0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334];
        
        $gy2 = ($gm > 2) ? ($gy + 1) : $gy;
        $days = 355666 + (365 * $gy) + ((int)(($gy2 + 3) / 4)) - ((int)(($gy2 + 99) / 100)) + ((int)(($gy2 + 399) / 400)) + $gd + $g_d_m[$gm - 1];
        $jy = -1595 + (33 * ((int)($days / 12053)));
        $days %= 12053;
        $jy += 4 * ((int)($days / 1461));
        $days %= 1461;
        
        if ($days > 365) {
            $jy += (int)(($days - 1) / 365);
            $days = ($days - 1) % 365;
        }
        
        if ($days < 186) {
            $jm = 1 + (int)($days / 31);
            $jd = 1 + ($days % 31);
        } else {
            $jm = 7 + (int)(($days - 186) / 30);
            $jd = 1 + (($days - 186) % 30);
        }
        
        return [$jy, $jm, $jd];
    }
}

/**
 * تبدیل تاریخ شمسی به میلادی
 */
if (!function_exists('jalali_to_gregorian')) {
    function jalali_to_gregorian($jy, $jm, $jd)
    {
        $jy += 1595;
        $days = 365 * $jy + ((int)($jy / 33)) * 8 + (int)(($jy % 33 + 3) / 4) + 78 + $jd + (($jm < 7) ? ($jm - 1) * 31 : (($jm - 7) * 30) + 186);
        $gy = 400 * ((int)($days / 146097));
        $days %= 146097;
        
        $flag = true;
        if ($days >= 36525) {
            $days--;
            $gy += 100 * ((int)($days / 36524));
            $days %= 36524;
            if ($days >= 365) $days++;
            else $flag = false;
        }
        
        if ($flag) {
            $gy += 4 * ((int)($days / 1461));
            $days %= 1461;
            if ($days >= 366) {
                $days--;
                $gy += (int)($days / 365);
                $days = $days % 365;
            }
        }
        
        $gd = $days + 1;
        $sal_a = [0, 31, (($gy % 4 == 0 && $gy % 100 != 0) || ($gy % 400 == 0)) ? 29 : 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
        
        for ($gm = 0; $gm < 13 && $gd > $sal_a[$gm]; $gm++)
            $gd -= $sal_a[$gm];
        
        return [$gy, $gm, $gd];
    }
}