<?php

function notify_admins(string $type, string $title, string $message, ?string $url = null, ?array $data = null): int
{
    $service = new \App\Services\NotificationService();
    return $service->sendToAll($type, $title, $message, $url, null, 'normal', $data);
}

function notify_user(int $userId, string $type, string $title, string $message, ?string $url = null, ?array $data = null): bool
{
    $service = new \App\Services\NotificationService();
    return $service->send($userId, $type, $title, $message, $url, null, 'normal', $data);
}

function unread_notifications_count(?int $userId = null): int
{
    $service = new \App\Services\NotificationService();
    return $service->getUnreadCount($userId);
}