<?php

if (!function_exists('captcha')) {
    /**
     * تولید CAPTCHA
     */
    function captcha(string $type = null): array
    {
        $service = new \App\Services\CaptchaService();
        return $service->generate($type);
    }
}

if (!function_exists('captcha_field')) {
    /**
     * فیلد CAPTCHA برای فرم
     */
    function captcha_field(string $type = null): string
    {
        $service = new \App\Services\CaptchaService();
        
        if (!$service->isEnabled()) {
            return '';
        }
        
        $captcha = $service->generate($type);
        
        ob_start();
        
        switch ($captcha['type']) {
            case 'math':
                ?>
                <div class="form-group captcha-container">
                    <label>حل کنید: <?= e($captcha['question']) ?></label>
                    <input type="hidden" name="captcha_token" value="<?= e($captcha['token']) ?>">
                    <input type="text" name="captcha_response" class="form-control" required autocomplete="off">
                </div>
                <?php
                break;
            
            case 'image':
                ?>
				<?php
                case 'image':
    // $captcha['image'] احتمالاً: storage/captcha/captcha_xxx.png
    $image = (string)($captcha['image'] ?? '');
    $image = ltrim($image, '/');

    // filename از هر مسیری
    $filename = basename($image);

    // ✅ URL صحیح از طریق FileController + ضد کش
    $imgUrl = url('file/view/captcha/' . $filename) . '?t=' . time();
    ?>
    <div class="form-group captcha-container">
        <label>کد تصویر را وارد کنید:</label>

        <div class="mb-2" style="display:flex;align-items:center;gap:10px;">
            <img
                id="captchaImage"
                src="<?= e($imgUrl) ?>"
                alt="CAPTCHA"
                style="border:1px solid #ddd;border-radius:4px;height:44px;"
            >

            <button type="button" class="btn btn-secondary"
                    onclick="document.getElementById('captchaImage').src='<?= e(url('file/view/captcha/' . $filename)) ?>?t=' + Date.now();">
                تغییر
            </button>
        </div>

        <input type="hidden" name="captcha_token" value="<?= e($captcha['token']) ?>">
        <input type="text" name="captcha_response" class="form-control" required autocomplete="off">
    </div>
    
                <?php
                break;
            
            case 'recaptcha_v2':
                ?>
                <div class="form-group captcha-container">
                    <div class="g-recaptcha" data-sitekey="<?= e($captcha['site_key']) ?>"></div>
                </div>
                <script src="https://www.google.com/recaptcha/api.js" async defer></script>
                <?php
                break;
            
            case 'recaptcha_v3':
                ?>
                <input type="hidden" id="recaptcha_response" name="recaptcha_response">
                <script src="https://www.google.com/recaptcha/api.js?render=<?= e($captcha['site_key']) ?>"></script>
                <script>
                grecaptcha.ready(function() {
                    grecaptcha.execute('<?= e($captcha['site_key']) ?>', {action: 'submit'}).then(function(token) {
                        document.getElementById('recaptcha_response').value = token;
                    });
                });
                </script>
                <?php
                break;
            
            case 'behavioral':
                ?>
                <input type="hidden" name="captcha_token" value="<?= e($captcha['token']) ?>">
                <div class="alert alert-info" style="font-size: 13px;">
                    <i class="material-icons" style="vertical-align: middle;">touch_app</i>
                    <?= e($captcha['instruction']) ?>
                </div>
                <?php
                break;
        }
        
        return ob_get_clean();
    }
}

if (!function_exists('verify_captcha')) {
    /**
     * بررسی CAPTCHA
     */
    function verify_captcha(): bool
    {
        $service = new \App\Services\CaptchaService();
        
        if (!$service->isEnabled()) {
            return true;
        }
        
        $token = $_POST['captcha_token'] ?? '';
        $response = $_POST['captcha_response'] ?? '';
        $recaptchaResponse = $_POST['g-recaptcha-response'] ?? $_POST['recaptcha_response'] ?? null;
        
        return $service->verify($token, $response, $recaptchaResponse);
    }
}