<?php
/**
 * Validator Helper Functions
 */

if (!function_exists('validate_mobile')) {
    /**
     * اعتبارسنجی شماره موبایل ایران
     */
    function validate_mobile($mobile)
    {
        // حذف فاصله‌ها و خط‌تیره‌ها
        $mobile = preg_replace('/[\s\-]+/', '', $mobile);
        
        // بررسی فرمت
        if (preg_match('/^(09|9)[0-9]{9}$/', $mobile)) {
            return true;
        }
        
        return false;
    }
}

if (!function_exists('validate_national_id')) {
    /**
     * اعتبارسنجی کد ملی ایران
     */
    function validate_national_id($code)
    {
        if (!preg_match('/^[0-9]{10}$/', $code)) {
            return false;
        }
        
        $check = (int) $code[9];
        $sum = 0;
        
        for ($i = 0; $i < 9; $i++) {
            $sum += ((int) $code[$i]) * (10 - $i);
        }
        
        $remainder = $sum % 11;
        
        return ($remainder < 2 && $check == $remainder) || ($remainder >= 2 && $check == (11 - $remainder));
    }
}

if (!function_exists('validate_card_number')) {
    /**
     * اعتبارسنجی شماره کارت بانکی
     */
    function validate_card_number($number)
    {
        $number = preg_replace('/[\s\-]+/', '', $number);
        
        if (!preg_match('/^[0-9]{16}$/', $number)) {
            return false;
        }
        
        // الگوریتم Luhn
        $sum = 0;
        $numDigits = strlen($number);
        $parity = $numDigits % 2;
        
        for ($i = 0; $i < $numDigits; $i++) {
            $digit = (int) $number[$i];
            
            if ($i % 2 == $parity) {
                $digit *= 2;
            }
            
            if ($digit > 9) {
                $digit -= 9;
            }
            
            $sum += $digit;
        }
        
        return ($sum % 10) == 0;
    }
}

if (!function_exists('validate_iban')) {
    /**
     * اعتبارسنجی شبا (IBAN)
     */
    function validate_iban($iban)
    {
        $iban = strtoupper(preg_replace('/[\s\-]+/', '', $iban));
        
        // شبای ایران باید با IR شروع شود و 26 کاراکتر باشد
        if (!preg_match('/^IR[0-9]{24}$/', $iban)) {
            return false;
        }
        
        return true;
    }
}

if (!function_exists('validate_url')) {
    /**
     * اعتبارسنجی URL
     */
    function validate_url($url, $schemes = ['http', 'https'])
    {
        if (!filter_var($url, FILTER_VALIDATE_URL)) {
            return false;
        }
        
        $parsed = parse_url($url);
        
        if (!isset($parsed['scheme']) || !in_array($parsed['scheme'], $schemes)) {
            return false;
        }
        
        return true;
    }
}

if (!function_exists('validate_username')) {
    /**
     * اعتبارسنجی نام کاربری
     */
    function validate_username($username)
    {
        // فقط حروف انگلیسی، اعداد و زیرخط
        // طول 3 تا 50 کاراکتر
        return preg_match('/^[a-zA-Z0-9_]{3,50}$/', $username);
    }
}

if (!function_exists('validate_persian_text')) {
    /**
     * اعتبارسنجی متن فارسی
     */
    function validate_persian_text($text)
    {
        // حداقل شامل یک حرف فارسی باشد
        return preg_match('/[\x{0600}-\x{06FF}]/u', $text);
    }
}