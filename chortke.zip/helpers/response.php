<?php
/**
 * Response Helper Functions
 */

if (!function_exists('api_response')) {
    /**
     * پاسخ API استاندارد
     */
    function api_response($success, $message, $data = [], $statusCode = 200)
    {
        header('Content-Type: application/json; charset=utf-8');
        http_response_code($statusCode);
        
        echo json_encode([
            'success' => $success,
            'message' => $message,
            'data' => $data,
            'timestamp' => time()
        ], JSON_UNESCAPED_UNICODE);
        
        exit;
    }
}

if (!function_exists('paginated_response')) {
    /**
     * پاسخ صفحه‌بندی شده
     */
    function paginated_response($items, $total, $page, $perPage)
    {
        return [
            'items' => $items,
            'pagination' => [
                'total' => $total,
                'per_page' => $perPage,
                'current_page' => $page,
                'last_page' => ceil($total / $perPage),
                'from' => ($page - 1) * $perPage + 1,
                'to' => min($page * $perPage, $total)
            ]
        ];
    }
}

if (!function_exists('download_file')) {
    /**
     * دانلود فایل
     */
    function download_file($filePath, $downloadName = null)
    {
        if (!file_exists($filePath)) {
            abort(404, 'فایل یافت نشد');
        }
        
        $downloadName = $downloadName ?: basename($filePath);
        
        header('Content-Type: application/octet-stream');
        header('Content-Disposition: attachment; filename="' . $downloadName . '"');
        header('Content-Length: ' . filesize($filePath));
        header('Cache-Control: no-cache');
        
        readfile($filePath);
        exit;
    }
}