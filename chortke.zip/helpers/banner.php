<?php

/**
 * نمایش بنرهای یک جایگاه
 * این تابع را در layout ها استفاده کنید
 * 
 * @param string $placement - slug جایگاه (header, footer, sidebar, homepage, etc.)
 * @return string HTML خروجی بنرها
 */
function render_banners(string $placement): string
{
    $service = new \App\Services\BannerService();
    $result = $service->getActiveBanners($placement);

    if (empty($result['banners'])) {
        return '';
    }

    $banners = $result['banners'];
    $placementObj = $result['placement'];
    $rotationSpeed = $placementObj->rotation_speed ?? 5000;
    $uniqueId = 'banner-carousel-' . $placement . '-' . \mt_rand(1000, 9999);

    $html = '<div class="chortke-banner-container" id="' . e($uniqueId) . '" data-speed="' . $rotationSpeed . '">';

    if (\count($banners) === 1) {
        // فقط یک بنر - بدون چرخش
        $banner = $banners[0];
        $html .= render_single_banner($banner);
    } else {
        // چند بنر - با چرخش
        foreach ($banners as $index => $banner) {
            $activeClass = $index === 0 ? ' active' : '';
            $html .= '<div class="chortke-banner-slide' . $activeClass . '">';
            $html .= render_single_banner($banner);
            $html .= '</div>';
        }

        // نقاط (dots)
        if (\count($banners) > 1) {
            $html .= '<div class="chortke-banner-dots">';
            foreach ($banners as $i => $b) {
                $dotActive = $i === 0 ? ' active' : '';
                $html .= '<span class="chortke-banner-dot' . $dotActive . '" data-index="' . $i . '"></span>';
            }
            $html .= '</div>';
        }
    }

    $html .= '</div>';

    return $html;
}

/**
 * رندر یک بنر
 */
function render_single_banner(\App\Models\Banner $banner): string
{
    $clickUrl = url('/banner/click/' . $banner->id);
    $target = e($banner->target ?? '_blank');

    if ($banner->type === 'code' && $banner->custom_code) {
        return '<div class="chortke-banner-item chortke-banner-code">' . $banner->custom_code . '</div>';
    }

    $html = '<a href="' . e($clickUrl) . '" target="' . $target . '" class="chortke-banner-item chortke-banner-link" data-banner-id="' . $banner->id . '" rel="noopener noreferrer">';

    if ($banner->image_path) {
        $imgUrl = asset($banner->image_path);
        $alt = e($banner->alt_text ?: $banner->title);
        $html .= '<img src="' . $imgUrl . '" alt="' . $alt . '" class="chortke-banner-img" loading="lazy">';
    }

    $html .= '</a>';

    return $html;
}

/**
 * آیا جایگاه فعال است؟
 */
function is_placement_active(string $slug): bool
{
    $placement = \App\Models\BannerPlacement::findBySlug($slug);
    return $placement && $placement->is_active;
}