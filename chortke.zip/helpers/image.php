<?php
/**
 * Image Helper Functions
 * 
 * توابع کمکی برای کار با تصاویر
 */

if (!function_exists('compress_image')) {
    /**
     * فشرده‌سازی تصویر
     */
    function compress_image($source, $destination, $quality = 80)
    {
        $info = getimagesize($source);
        
        if (!$info) {
            return false;
        }
        
        $mime = $info['mime'];
        
        // ایجاد تصویر از فایل مبدا
        switch ($mime) {
            case 'image/jpeg':
                $image = imagecreatefromjpeg($source);
                break;
            case 'image/png':
                $image = imagecreatefrompng($source);
                break;
            case 'image/gif':
                $image = imagecreatefromgif($source);
                break;
            default:
                return false;
        }
        
        // ذخیره تصویر فشرده شده
        $result = imagejpeg($image, $destination, $quality);
        
        imagedestroy($image);
        
        return $result;
    }
}

if (!function_exists('resize_image')) {
    /**
     * تغییر اندازه تصویر
     */
    function resize_image($source, $destination, $maxWidth, $maxHeight = null)
    {
        if ($maxHeight === null) {
            $maxHeight = $maxWidth;
        }
        
        $info = getimagesize($source);
        
        if (!$info) {
            return false;
        }
        
        list($width, $height) = $info;
        $mime = $info['mime'];
        
        // محاسبه نسبت
        $ratio = min($maxWidth / $width, $maxHeight / $height);
        
        $newWidth = $width * $ratio;
        $newHeight = $height * $ratio;
        
        // ایجاد تصویر جدید
        $newImage = imagecreatetruecolor($newWidth, $newHeight);
        
        // حفظ شفافیت برای PNG
        if ($mime === 'image/png') {
            imagealphablending($newImage, false);
            imagesavealpha($newImage, true);
        }
        
        // بارگذاری تصویر مبدا
        switch ($mime) {
            case 'image/jpeg':
                $image = imagecreatefromjpeg($source);
                break;
            case 'image/png':
                $image = imagecreatefrompng($source);
                break;
            case 'image/gif':
                $image = imagecreatefromgif($source);
                break;
            default:
                return false;
        }
        
        // تغییر اندازه
        imagecopyresampled($newImage, $image, 0, 0, 0, 0, $newWidth, $newHeight, $width, $height);
        
        // ذخیره
        switch ($mime) {
            case 'image/jpeg':
                $result = imagejpeg($newImage, $destination, 85);
                break;
            case 'image/png':
                $result = imagepng($newImage, $destination, 8);
                break;
            case 'image/gif':
                $result = imagegif($newImage, $destination);
                break;
            default:
                $result = false;
        }
        
        imagedestroy($image);
        imagedestroy($newImage);
        
        return $result;
    }
}

if (!function_exists('upload_and_compress')) {
    /**
     * آپلود و فشرده‌سازی خودکار
     */
    function upload_and_compress($file, $directory = 'general', $maxWidth = 1200)
    {
        // آپلود اولیه
        $path = upload_file($file, $directory);
        
        $fullPath = __DIR__ . '/../' . $path;
        
        // فشرده‌سازی
        $tempPath = $fullPath . '.temp';
        
        if (resize_image($fullPath, $tempPath, $maxWidth)) {
            unlink($fullPath);
            rename($tempPath, $fullPath);
        }
        
        return $path;
    }
}