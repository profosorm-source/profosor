<!-- footer.php -->
<footer class="guest-footer">
    <div class="footer-inner">
        <div class="footer-grid">

            <!-- درباره -->
            <div class="footer-col">
                <h4><?= e(setting('site_name', 'چرتکه')) ?></h4>
                <p class="footer-about-text">
                    <?= e(setting('site_name', 'چرتکه')) ?> یک پلتفرم حرفه‌ای و امن برای کسب درآمد آنلاین است.
                    با انجام تسک‌ها، سرمایه‌گذاری، قرعه‌کشی و تولید محتوا درآمد واقعی کسب کنید.
                </p>
                <div class="footer-social">
                    <?php $telegram = setting('telegram_support'); if ($telegram): ?>
                        <a href="https://t.me/<?= e($telegram) ?>" target="_blank"><span class="material-icons">send</span></a>
                    <?php endif; ?>
                    <?php $whatsapp = setting('whatsapp_support'); if ($whatsapp): ?>
                        <a href="https://wa.me/<?= e($whatsapp) ?>" target="_blank"><span class="material-icons">chat</span></a>
                    <?php endif; ?>
                    <?php $email = setting('contact_email'); if ($email): ?>
                        <a href="mailto:<?= e($email) ?>"><span class="material-icons">email</span></a>
                    <?php endif; ?>
                </div>
            </div>

            <!-- لینک‌ها -->
            <div class="footer-col">
                <h4>دسترسی سریع</h4>
                <ul>
                    <li><a href="<?= url('/') ?>"><span class="material-icons">home</span> صفحه اصلی</a></li>
                    <li><a href="<?= url('/pages/guide') ?>"><span class="material-icons">menu_book</span> راهنما</a></li>
                    <li><a href="<?= url('/pages/terms') ?>"><span class="material-icons">gavel</span> قوانین</a></li>
                    <li><a href="<?= url('/pages/privacy') ?>"><span class="material-icons">privacy_tip</span> حریم خصوصی</a></li>
                    <li><a href="<?= url('/pages/about') ?>"><span class="material-icons">info</span> درباره ما</a></li>
                </ul>
            </div>

            <!-- خدمات -->
            <div class="footer-col">
                <h4>خدمات ما</h4>
                <ul>
                    <?php $link = $isLoggedIn ? '/user/' : '/register'; ?>
                    <li><a href="<?= url($link . ($isLoggedIn ? 'tasks' : '')) ?>"><span class="material-icons">task_alt</span> تسک‌ها</a></li>
                    <li><a href="<?= url($link . ($isLoggedIn ? 'investment' : '')) ?>"><span class="material-icons">trending_up</span> سرمایه‌گذاری</a></li>
                    <li><a href="<?= url($link . ($isLoggedIn ? 'lottery' : '')) ?>"><span class="material-icons">casino</span> قرعه‌کشی</a></li>
                    <li><a href="<?= url($link . ($isLoggedIn ? 'story-orders' : '')) ?>"><span class="material-icons">camera_alt</span> سفارش استوری</a></li>
                    <li><a href="<?= url($link . ($isLoggedIn ? 'referral' : '')) ?>"><span class="material-icons">people</span> معرفی دوستان</a></li>
                </ul>
            </div>

            <!-- تماس -->
            <div class="footer-col">
                <h4>ارتباط با ما</h4>
                <ul>
                    <?php if ($email): ?><li><a href="mailto:<?= e($email) ?>"><span class="material-icons">email</span> <?= e($email) ?></a></li><?php endif; ?>
                    <?php if ($telegram): ?><li><a href="https://t.me/<?= e($telegram) ?>" target="_blank"><span class="material-icons">send</span> تلگرام</a></li><?php endif; ?>
                    <?php if ($whatsapp): ?><li><a href="https://wa.me/<?= e($whatsapp) ?>" target="_blank"><span class="material-icons">chat</span> واتساپ</a></li><?php endif; ?>
                    <li><a href="<?= url('/pages/contact') ?>"><span class="material-icons">contact_support</span> فرم تماس</a></li>
                </ul>
            </div>

        </div>

        <!-- درگاه‌ها -->
        <div class="footer-gateways">
            <span class="footer-gateways-label">درگاه‌های پرداخت:</span>
            <div class="footer-gateway-chip"><span class="material-icons">credit_card</span> زرین‌پال</div>
            <div class="footer-gateway-chip"><span class="material-icons">credit_card</span> آی‌دی‌پی</div>
            <div class="footer-gateway-chip"><span class="material-icons">credit_card</span> نکست‌پی</div>
            <div class="footer-gateway-chip"><span class="material-icons">credit_card</span> دی‌جی‌پی</div>
            <span class="footer-gateways-label">ارز دیجیتال:</span>
            <div class="footer-gateway-chip"><span class="material-icons">currency_bitcoin</span> USDT TRC20</div>
            <div class="footer-gateway-chip"><span class="material-icons">currency_bitcoin</span> USDT BEP20</div>
        </div>

        <!-- کپی‌رایت -->
        <div class="footer-bottom">
            © <?= to_jalali(date('Y'), '', true) ?> <a href="<?= url('/') ?>"><?= e(setting('site_name', 'چرتکه')) ?></a> — تمامی حقوق محفوظ است.
        </div>
    </div>
</footer>


<style>
.guest-footer {
    background: #1f1f1f;
    color: #fff;
    padding: 30px 15px;
    font-size: 14px;
}

.footer-inner {
    max-width: 1200px;
    margin: 0 auto;
}

.footer-grid {
    display: flex;
    flex-wrap: wrap;
    gap: 20px;
}

.footer-col {
    flex: 1 1 200px;
    min-width: 150px;
}

.footer-col h4 {
    font-size: 16px;
    margin-bottom: 10px;
}

.footer-about-text {
    font-size: 13px;
    line-height: 1.5;
}

.footer-social a {
    margin-right: 8px;
    font-size: 18px;
}

.footer-gateways {
    margin-top: 15px;
    display: flex;
    flex-wrap: wrap;
    gap: 10px;
    font-size: 13px;
}

.footer-gateway-chip {
    background: #333;
    padding: 5px 10px;
    border-radius: 5px;
    display: flex;
    align-items: center;
    gap: 5px;
}

.footer-bottom {
    margin-top: 15px;
    font-size: 12px;
    text-align: center;
    border-top: 1px solid #333;
    padding-top: 10px;
}

/* موبایل */
@media (max-width: 768px) {
    .footer-grid {
        flex-direction: column;
        gap: 15px;
    }
    .footer-col {
        min-width: 100%;
    }
}
.page-wrapper {
    display: flex;
    min-height: calc(100vh - 0px); /* ارتفاع کامل صفحه */
}

/* سایدبار */
.ck-sidebar {
    width: 250px; /* میتونی کوچکتر یا بزرگتر کنی */
    flex-shrink: 0; /* از اندازه اصلی کم نشه */
}

/* محتوا */
.main-content {
    flex: 1;
    padding: 15px;
}

/* فوتر */
.guest-footer {
    background: #1f1f1f;
    color: #fff;
    padding: 15px 20px; /* کمتر از قبل */
    font-size: 13px;
    clear: both; /* اطمینان از اینکه زیر همه میاد */
}
.footer-inner {
    max-width: 1200px;
    margin: 0 auto;
}
.footer-grid {
    display: flex;
    flex-wrap: wrap;
    gap: 15px;
}
.footer-col {
    flex: 1 1 200px;
    min-width: 150px;
}
.footer-bottom {
    text-align: center;
    margin-top: 10px;
    font-size: 12px;
    border-top: 1px solid #333;
    padding-top: 10px;
}

</style>
