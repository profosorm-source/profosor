<?php

// ✅ فقط از auth() (که شما داری و در تست هم کار کرد)
$currentUser = $isLoggedIn ? auth() : null;
if ($isLoggedIn) {
    $currentUser = (new \App\Models\User())->findById((int)$session->get('user_id'));
}

// مقدارهای پیشفرض برای navbar
$fullName = 'کاربر';
$firstLetter = 'ک';

if ($currentUser && !empty($currentUser->full_name)) {
    $fullName = (string)$currentUser->full_name;
    $firstLetter = mb_substr(trim($fullName), 0, 1, 'UTF-8');
}


// سایر پیشفرض‌ها (همان‌هایی که دارید)
$tier = $tier ?? 'SILVER';
$kycStatus = $kycStatus ?? 'pending';
$kycMap = [
    'verified' => 'تایید شده',
    'pending' => 'در انتظار',
    'review_under' => 'در بررسی',
    'rejected' => 'رد شده',
    'expired' => 'منقضی',
];
$kycLabel = $kycMap[$kycStatus] ?? 'ناقص';

$notifCount = $notifCount ?? 0;
$topNotifications = $topNotifications ?? [];

$uri = $_SERVER['REQUEST_URI'] ?? '/';
$active = function(string $path) use ($uri): bool {
    return strpos($uri, $path) !== false;
};
$anyActive = function(array $paths) use ($active): bool {
    foreach ($paths as $p) { if ($active($p)) return true; }
    return false;
};

// آواتار null-safe
$avatarFile = ($currentUser && !empty($currentUser->avatar)) ? $currentUser->avatar : 'default-avatar.png';
$avatarUrl  = asset('uploads/avatars/' . $avatarFile);
?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $title ?? 'پنل کاربری' ?> |<?= e(setting('site_name', 'چرتکه')) ?></title>
    
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.rtl.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/notyf@3/notyf.min.css">
	<link rel="stylesheet" href="<?= asset('assets/css/user.css') ?>">
	<link rel="stylesheet" href="<?= asset('assets/vendor/sweetalert2/sweetalert2.min.css') ?>">
    
    <?= $styles ?? '' ?>
</head>
<body>

<!-- Topbar -->
<div class="topbar">

    <button class="btn btn-light d-lg-none me-2" id="sidebarToggle">
        <span class="material-icons">menu</span>
    </button>
    
    <h4 class="mb-0"><?= $title ?? 'داشبورد' ?></h4>
    
    <div class="topbar-actions">
        <!-- User Info -->
        <div class="user-info">
            <div class="user-details">
                <p class="user-name"><?= e($fullName) ?></p>
                <p class="user-role"><?= e(strtoupper((string)$tier)) ?> | <?= e($kycLabel) ?></p>
            </div>
            <div class="user-avatar">
    <img src="<?= e($avatarUrl) ?>" alt="<?= e($fullName) ?>">
</div>
        </div>

        <!-- Notifications -->
        <div class="topbar-icon" data-dd-toggle="notif" title="اعلان‌ها">
            <span class="material-icons">notifications</span>
            <?php if ((int)$notifCount > 0): ?>
                <span class="badge"><?= (int)$notifCount ?></span>
            <?php endif; ?>
        </div>

        <!-- Settings -->
        <div class="topbar-icon" data-dd-toggle="settings" title="تنظیمات">
            <span class="material-icons">settings</span>
        </div>

        <!-- Logout -->
        <div class="topbar-icon" onclick="document.getElementById('logout-form').submit()" title="خروج">
            <span class="material-icons">logout</span>
        </div>
        <form id="logout-form" method="POST" action="<?= url('/logout') ?>" style="display: none;">
            <?= csrf_field() ?>
        </form>
    </div>
    
    <!-- Dropdown Menus -->
    <div data-dd-menu="notif" class="dropdown-menu-custom">
        <div class="dd-header">
            اعلان‌ها
            <a href="<?= url('/user/notifications') ?>" class="dd-view-all">مشاهده همه</a>
        </div>
        <div class="dd-divider"></div>
        
        <?php if (empty($topNotifications)): ?>
            <div class="dd-empty">اعلان جدیدی ندارید.</div>
        <?php else: ?>
            <?php foreach ($topNotifications as $n): ?>
                <?php $n = is_array($n) ? (object)$n : $n; ?>
                <a href="<?= url('/user/notifications') ?>" data-dd-item>
                    <span class="material-icons">notifications</span>
                    <span>
                        <div class="dd-title"><?= e($n->title ?? 'اعلان') ?></div>
                        <div class="dd-message"><?= e($n->message ?? '') ?></div>
                        <div class="dd-time"><?= e($n->time ?? '') ?></div>
                    </span>
                </a>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>

    <div data-dd-menu="settings" class="dropdown-menu-custom">
        <a href="<?= url('/user/profile') ?>" data-dd-item>
            <span class="material-icons">person</span>
            <span>ویرایش پروفایل</span>
        </a>
        <a href="<?= url('/user/kyc') ?>" data-dd-item>
            <span class="material-icons">verified_user</span>
            <span>احراز هویت (KYC)</span>
        </a>
        <a href="<?= url('/user/bank-cards') ?>" data-dd-item>
            <span class="material-icons">credit_card</span>
            <span>کارت‌های بانکی</span>
        </a>
         <a href="<?= url('/user/security') ?>" data-dd-item>
                    <span class="material-icons">lock</span>
                    
					<span>امنیت</span>
                </a>
                <a href="<?= url('/user/coupons') ?>" data-dd-item>
                    <span class="material-icons">confirmation_number</span>
                    <span>تخفیف ها</span>
                </a>
                <a href="<?= url('/user/sessions') ?>" data-dd-item>
                    <span class="material-icons">devices</span>
                    <span>نشست‌های فعال</span>
                </a>
    </div>
</div>

<!-- Sidebar -->
<div class="sidebar" id="mainSidebar">
    <div class="sidebar-overlay" id="sidebarOverlay"></div>
    
    <div class="sidebar-header">
        <h3><?= e(setting('site_name', 'چرتکه')) ?></h3>
    </div>
    
    <ul class="sidebar-menu">
        <li>
            <a href="<?= url('/dashboard') ?>" class="<?= (strpos($_SERVER['REQUEST_URI'], '/dashboard') !== false) ? 'active' : '' ?>">
                <span class="material-icons">dashboard</span>
                <span>داشبورد</span>
            </a>
        </li>
		<!-- ====== کسب درآمد ====== -->
    <li class="menu-section-title"><span>کسب درآمد</span></li>

    <?php $earnOpen = $anyActive(['/tasks','/custom-tasks','/seo-boost','/lottery','/content','/referral']); ?>
    <li class="has-submenu <?= $earnOpen ? 'open' : '' ?>">
        <a href="#" class="<?= $earnOpen ? 'active' : '' ?>" data-submenu-toggle="earn">
            <span class="material-icons">paid</span>
            <span class="menu-title">کسب درآمد</span>
            <span class="material-icons submenu-arrow">expand_more</span>
        </a>

        <ul class="submenu">
            <li>
                <a href="<?= url('/tasks') ?>" class="<?= $active('user/tasks') ? 'active' : '' ?>">
                    <span class="material-icons">task</span>
                    <span class="menu-title">تسک‌ها</span>
                </a>
            </li>
            <li>
                <a href="<?= url('/custom-tasks') ?>" class="<?= $active('user/custom-tasks') ? 'active' : '' ?>">
                    <span class="material-icons">work</span>
                    <span class="menu-title">تسک‌های سفارشی</span>
                </a>
            </li>
            <li>
                <a href="<?= url('/seo-boost') ?>" class="<?= $active('/seo-boost') ? 'active' : '' ?>">
                    <span class="material-icons">travel_explore</span>
                    <span class="menu-title">افزایش رتبه گوگل</span>
                </a>
            </li>
            
            <li>
                <a href="<?= url('/content') ?>" class="<?= $active('/content') ? 'active' : '' ?>">
                    <span class="material-icons">video_library</span>
                    <span class="menu-title">درآمد از استعداد (محتوا)</span>
                </a>
            </li>
           
        </ul>
    </li>
         <!-- ====== تبلیغات ====== -->
    <li class="menu-section-title"><span>تبلیغات</span></li>

    <?php $adsOpen = $anyActive(['/ads','/story-orders','/influencers','/promotion-story']); ?>
    <li class="has-submenu <?= $adsOpen ? 'open' : '' ?>">
        <a href="#" class="<?= $adsOpen ? 'active' : '' ?>" data-submenu-toggle="ads">
            <span class="material-icons">campaign</span>
            <span class="menu-title">تبلیغات و کمپین‌ها</span>
            <span class="material-icons submenu-arrow">expand_more</span>
        </a>

        <ul class="submenu">
            <li>
                <a href="<?= url('/ads') ?>" class="<?= $active('/ads') ? 'active' : '' ?>">
                    <span class="material-icons">campaign</span>
                    <span class="menu-title">لیست تبلیغات</span>
                </a>
            </li>
            <li>
                <a href="<?= url('/ads/create') ?>" class="<?= $active('/ads/create') ? 'active' : '' ?>">
                    <span class="material-icons">add_circle</span>
                    <span class="menu-title">ثبت تبلیغ جدید</span>
                </a>
            </li>

            <li class="submenu-divider"></li>

            <li>
                <a href="<?= url('/story-orders') ?>" class="<?= $active('/story-orders') ? 'active' : '' ?>">
                    <span class="material-icons">collections</span>
                    <span class="menu-title">سفارش‌های استوری</span>
                </a>
            </li>
            <li>
                <a href="<?= url('/influencers') ?>" class="<?= $active('/influencers') ? 'active' : '' ?>">
                    <span class="material-icons">stars</span>
                    <span class="menu-title">پیج‌های اینفلوئنسر</span>
                </a>
            </li>
        </ul>
    </li>


    <!-- ====== درآمدها و برداشت‌ها (مالی) ====== -->
    <li class="menu-section-title"><span>مالی</span></li>

    <?php $financeOpen = $anyActive(['/wallet','/transactions','/user/bank-cards']); ?>
    <li class="has-submenu <?= $financeOpen ? 'open' : '' ?>">
        <a href="#" class="<?= $financeOpen ? 'active' : '' ?>" data-submenu-toggle="finance">
            <span class="material-icons">account_balance_wallet</span>
            <span class="menu-title">درآمدها و برداشت‌ها</span>
            <span class="material-icons submenu-arrow">expand_more</span>
        </a>

        <ul class="submenu">
            <li>
                <a href="<?= url('/wallet') ?>" class="<?= $active('/wallet') ? 'active' : '' ?>">
                    <span class="material-icons">account_balance_wallet</span>
                    <span class="menu-title">کیف پول</span>
                </a>
            </li>
            <li>
                <a href="<?= url('/wallet/deposit') ?>" class="<?= $active('/wallet/deposit') ? 'active' : '' ?>">
                    <span class="material-icons">add_circle</span>
                    <span class="menu-title">افزایش موجودی</span>
                </a>
            </li>
            <li>
                <a href="<?= url('/wallet/withdraw') ?>" class="<?= $active('/wallet/withdraw') ? 'active' : '' ?>">
                    <span class="material-icons">remove_circle</span>
                    <span class="menu-title">برداشت وجه</span>
                </a>
            </li>
            <li>
                <a href="<?= url('/transactions') ?>" class="<?= $active('/transactions') ? 'active' : '' ?>">
                    <span class="material-icons">receipt_long</span>
                    <span class="menu-title">تراکنش‌ها</span>
                </a>
            </li>
            <li>
      
       
    </ul>
	    <!-- ====== سرمایه‌گذاری ====== -->
    <li class="menu-section-title"><span>سرمایه‌گذاری</span></li>

    <?php $invOpen = $anyActive(['/investment']); ?>
    <li class="has-submenu <?= $invOpen ? 'open' : '' ?>">
        <a href="#" class="<?= $invOpen ? 'active' : '' ?>" data-submenu-toggle="investment">
            <span class="material-icons">trending_up</span>
            <span class="menu-title">سرمایه‌گذاری</span>
            <span class="material-icons submenu-arrow">expand_more</span>
        </a>

        <ul class="submenu">
            <li>
                <a href="<?= url('/investment') ?>" class="<?= $active('/investment') ? 'active' : '' ?>">
                    <span class="material-icons">analytics</span>
                    <span class="menu-title">پلن‌های من</span>
                </a>
            </li>
            <li>
                <a href="<?= url('/investment/create') ?>" class="<?= $active('/investment/create') ? 'active' : '' ?>">
                    <span class="material-icons">add_business</span>
                    <span class="menu-title">سرمایه‌گذاری جدید</span>
                </a>
            </li>
            <li>
                <a href="<?= url('/investment/withdraw') ?>" class="<?= $active('/investment/withdraw') ? 'active' : '' ?>">
                    <span class="material-icons">payments</span>
                    <span class="menu-title">برداشت سود</span>
                </a>
            </li>
        </ul>
    </li>
	
	 <li>
            <a href="<?= url('/lottery') ?>" class="<?= (strpos($_SERVER['REQUEST_URI'], '/lottery') !== false) ? 'active' : '' ?>">
                <span class="material-icons">card_giftcard</span>
                <span>قرعه‌کشی</span>
            </a>
        </li>
        <li>
                <a href="<?= url('user/referral') ?>" class="<?= $active('user/referral') ? 'active' : '' ?>">
                    <span class="material-icons">group_add</span>
                    <span class="menu-title">دعوت از دوستان</span>
                </a>
            </li>
       
        <li>
            <a href="<?= url('/support') ?>" class="<?= (strpos($_SERVER['REQUEST_URI'], '/support') !== false) ? 'active' : '' ?>">
                <span class="material-icons">support_agent</span>
                <span>پشتیبانی</span>
            </a>
        </li>
		</ul>
</div>

<!-- Main Content -->
<div class="main-content">
    <div class="content-wrapper">
        
        <!-- KYC Warning -->
        <?php if ($isLoggedIn && (!isset($currentUser->kyc_verified) || $currentUser->kyc_verified != 1)): ?>
            <div class="alert alert-warning d-flex align-items-center">
                <span class="material-icons me-2">warning</span>
                <span>
                    لطفاً برای استفاده کامل از امکانات، 
                    <a href="<?= url('/user/kyc') ?>" class="alert-link fw-bold">احراز هویت</a> 
                    خود را تکمیل کنید.
                </span>
            </div>
        <?php endif; ?>
        
        <?= $content ?? '' ?>
    </div>
    
    <!-- Footer -->
    <footer class="footer">
        <div class="container-fluid">
            <div class="row align-items-center">
                <div class="col-md-4 text-center text-md-start mb-3 mb-md-0">
                    <p class="mb-0 text-muted">© 2024 چرتکه. تمامی حقوق محفوظ است.</p>
                </div>
                <div class="col-md-8">
                    <div class="payment-icons">
                        <div class="payment-icon">💳 ZarinPal</div>
                        <div class="payment-icon">💳 NextPay</div>
                        <div class="payment-icon">💳 IDPay</div>
                        <div class="payment-icon">₮ USDT</div>
                        <div class="payment-icon">🔶 BNB</div>
                        <div class="payment-icon">⚡ TRX</div>
                    </div>
                </div>
            </div>
            <div class="row mt-3">
                <div class="col-12 text-center">
                    <a href="<?= url('/terms') ?>" class="footer-link">قوانین و مقررات</a>
                    <a href="<?= url('/privacy') ?>" class="footer-link">حریم خصوصی</a>
                    <a href="<?= url('/help') ?>" class="footer-link">راهنما</a>
                    <a href="<?= url('/contact') ?>" class="footer-link">تماس با ما</a>
                </div>
            </div>
        </div>
    </footer>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/notyf@3/notyf.min.js"></script>
<script src="<?= asset('assets/js/app.js') ?>"></script>
<script src="<?= asset('assets/vendor/sweetalert2/sweetalert2.all.min.js') ?>"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script src="<?= asset('assets/js/swal-init.js') ?>?v=<?= time() ?>"></script>
<script>
// Initialize Notyf
const notyf = new Notyf({
    duration: 5000,
    position: { x: 'left', y: 'top' },
    dismissible: true
});

<?php if($flashSuccess): ?>
    notyf.success("<?= addslashes($flashSuccess) ?>");
<?php endif; ?>

<?php if($flashError): ?>
    notyf.error("<?= addslashes($flashError) ?>");
<?php endif; ?>
<?php if(!empty($flashWarning)): ?>
 notyf.open({ type: 'warning', message: "<?= addslashes($flashWarning) ?>" });
<?php endif; ?>
</script>


</body>
</html>