<?php
$currentUser = $user ?? null;
$fullName = 'مدیر';
$firstLetter = 'م';
if ($currentUser && isset($currentUser->full_name) && !empty($currentUser->full_name)) {
    $fullName = $currentUser->full_name;
    $firstLetter = mb_substr($fullName, 0, 1, 'UTF-8');
}
$roleNames = [
    'admin'   => 'مدیر کل',
    'support' => 'پشتیبان',
    'user'    => 'کاربر'
];
$userRole = isset($currentUser->role) ? ($roleNames[$currentUser->role] ?? 'کاربر') : 'کاربر';
?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $title ?? 'پنل مدیریت' ?> | چرتکه</title>
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.rtl.min.css">
    <link rel="stylesheet" href="<?= asset('assets/css/admin.css') ?>">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/notyf@3/notyf.min.css">
    <link rel="stylesheet" href="<?= asset('assets/vendor/sweetalert2/sweetalert2.min.css') ?>">
	<link rel="stylesheet" href="<?= asset('/assets/vendor/notyf/notyf.min.css') ?>">
    <?= $styles ?? '' ?>
</head>
<body>
    
    <!-- Sidebar -->
    <div class="sidebar">
        <div class="sidebar-header">
            <h3>🎯 چرتکه</h3>
            <p>پنل مدیریت</p>
        </div>
        
        <ul class="sidebar-menu">

     <!-- مدیریت کاربران (کشویی) -->
    <li class="menu-section">
        <div class="section-title">
            <i class="material-icons">people</i>
            <span>مدیریت کاربران</span>
            <i class="material-icons toggle-icon">expand_more</i>
        </div>
        <ul class="submenu">
            <li class="<?= strpos($_SERVER['REQUEST_URI'], '/admin/users') !== false ? 'active' : '' ?>">
                <a href="<?= url('/admin/users') ?>">
                    <i class="material-icons">group</i>
                    <span>لیست کاربران</span>
                </a>
            </li>
            <li class="<?= str_contains($_SERVER['REQUEST_URI'] ?? '', '/admin/roles') ? 'active' : '' ?>">
                <a href="<?= url('/admin/roles') ?>">
                    <i class="material-icons">admin_panel_settings</i>
                    <span>نقش‌ها و دسترسی‌ها</span>
                </a>
            </li>
            <li class="<?= str_contains($_SERVER['REQUEST_URI'] ?? '', '/admin/levels') ? 'active' : '' ?>">
                <a href="<?= url('/admin/levels') ?>">
                    <i class="material-icons">workspace_premium</i>
                    <span>سطح‌بندی کاربران</span>
                </a>
            </li>
            <li class="<?= str_contains($_SERVER['REQUEST_URI'] ?? '', '/admin/referral') ? 'active' : '' ?>">
                <a href="<?= url('/admin/referral') ?>">
                    <i class="material-icons">share</i>
                    <span>سیستم معرفی</span>
                </a>
            </li>
        </ul>
    </li>
           <!-- مالی (کشویی) -->
    <li class="menu-section">
        <div class="section-title">
            <i class="material-icons">account_balance</i>
            <span>مالی</span>
            <i class="material-icons toggle-icon">expand_more</i>
        </div>
        <ul class="submenu">
            <li class="<?= strpos($_SERVER['REQUEST_URI'], '/admin/transactions') !== false ? 'active' : '' ?>">
                <a href="<?= url('/admin/transactions') ?>">
                    <i class="material-icons">receipt_long</i>
                    <span>تراکنش‌ها</span>
                </a>
            </li>
            <li class="<?= strpos($_SERVER['REQUEST_URI'], '/admin/manual-deposits') !== false ? 'active' : '' ?>">
                <a href="<?= url('/admin/manual-deposits') ?>">
                    <i class="material-icons">account_balance</i>
                    <span>واریزهای دستی</span>
                    <?php
                    $pendingCount = 0;
                    if ($pendingCount > 0):
                    ?>
                    <span class="badge badge-danger"><?= to_jalali($pendingCount, '', true) ?></span>
                    <?php endif; ?>
                </a>
            </li>
            <li class="<?= strpos($_SERVER['REQUEST_URI'], '/admin/crypto-deposits') !== false ? 'active' : '' ?>">
                <a href="<?= url('/admin/crypto-deposits') ?>">
                    <i class="material-icons">currency_bitcoin</i>
                    <span>واریزهای کریپتو</span>
                </a>
            </li>
            <li class="<?= strpos($_SERVER['REQUEST_URI'], '/admin/withdrawals') !== false ? 'active' : '' ?>">
                <a href="<?= url('/admin/withdrawals') ?>">
                    <i class="material-icons">payments</i>
                    <span>درخواست برداشت</span>
                </a>
            </li>
            <li class="<?= strpos($_SERVER['REQUEST_URI'], '/admin/bank-cards') !== false ? 'active' : '' ?>">
                <a href="<?= url('/admin/bank-cards') ?>">
                    <i class="material-icons">credit_card</i>
                    <span>کارت‌های بانکی</span>
                </a>
            </li>
        </ul>
    </li>
	 <!-- سرمایه‌گذاری (کشویی) -->
    <li class="menu-section">
        <div class="section-title">
            <i class="material-icons">trending_up</i>
            <span>سرمایه‌گذاری</span>
            <i class="material-icons toggle-icon">expand_more</i>
        </div>
        <ul class="submenu">
            <li class="<?= str_contains($_SERVER['REQUEST_URI'] ?? '', '/admin/investment') && !str_contains($_SERVER['REQUEST_URI'] ?? '', '/trades') && !str_contains($_SERVER['REQUEST_URI'] ?? '', '/apply-profit') && !str_contains($_SERVER['REQUEST_URI'] ?? '', '/investment/withdrawals') ? 'active' : '' ?>">
                <a href="<?= url('/admin/investment') ?>">
                    <i class="material-icons">analytics</i>
                    <span>سرمایه‌گذاری‌ها</span>
                </a>
            </li>
            <li class="<?= str_contains($_SERVER['REQUEST_URI'] ?? '', '/admin/investment/trades') ? 'active' : '' ?>">
                <a href="<?= url('/admin/investment/trades') ?>">
                    <i class="material-icons">swap_horiz</i>
                    <span>تریدها</span>
                </a>
            </li>
            <li class="<?= str_contains($_SERVER['REQUEST_URI'] ?? '', '/admin/investment/apply-profit') ? 'active' : '' ?>">
                <a href="<?= url('/admin/investment/apply-profit') ?>">
                    <i class="material-icons">calculate</i>
                    <span>اعمال سود/ضرر</span>
                </a>
            </li>
            <li class="<?= str_contains($_SERVER['REQUEST_URI'] ?? '', '/admin/investment/withdrawals') ? 'active' : '' ?>">
                <a href="<?= url('/admin/investment/withdrawals') ?>">
                    <i class="material-icons">money_off</i>
                    <span>برداشت‌ها</span>
                </a>
            </li>
        </ul>
    </li>

    <!-- محتوا و تبلیغات (کشویی) -->
    <li class="menu-section">
        <div class="section-title">
            <i class="material-icons">campaign</i>
            <span>محتوا و تبلیغات</span>
            <i class="material-icons toggle-icon">expand_more</i>
        </div>
        <ul class="submenu">
            <li class="<?= str_contains($_SERVER['REQUEST_URI'] ?? '', '/admin/content') && !str_contains($_SERVER['REQUEST_URI'] ?? '', '/revenues') ? 'active' : '' ?>">
                <a href="<?= url('/admin/content') ?>">
                    <i class="material-icons">video_library</i>
                    <span>مدیریت محتوا</span>
                </a>
            </li>
            <li class="<?= str_contains($_SERVER['REQUEST_URI'] ?? '', '/admin/content/revenues') ? 'active' : '' ?>">
                <a href="<?= url('/admin/content/revenues') ?>">
                    <i class="material-icons">monetization_on</i>
                    <span>درآمد محتوا</span>
                </a>
            </li>
            <li class="<?= str_contains($_SERVER['REQUEST_URI'] ?? '', '/admin/custom-tasks') ? 'active' : '' ?>">
                <a href="<?= url('/admin/custom-tasks') ?>">
                    <i class="material-icons">assignment</i>
                    <span>وظایف سفارشی</span>
                </a>
            </li>
            <li class="<?= str_contains($_SERVER['REQUEST_URI'] ?? '', '/admin/stories') ? 'active' : '' ?>">
                <a href="<?= url('/admin/stories') ?>">
                    <i class="material-icons">camera_alt</i>
                    <span>تبلیغات استوری</span>
                </a>
            </li>
            <li class="<?= str_contains($_SERVER['REQUEST_URI'] ?? '', '/admin/banners') ? 'active' : '' ?>">
                <a href="<?= url('/admin/banners') ?>">
                    <i class="material-icons">view_carousel</i>
                    <span>مدیریت بنرها</span>
                </a>
            </li>
        </ul>
    </li>
	
    <!-- قرعه‌کشی -->
    <li class="nav-item <?= str_contains($_SERVER['REQUEST_URI'] ?? '', '/admin/lottery') ? 'active' : '' ?>">
        <a class="nav-link" href="<?= url('/admin/lottery') ?>">
            <i class="material-icons">casino</i>
            <span>مدیریت قرعه‌کشی</span>
        </a>
    </li>

    <!-- تسک‌ها و تبلیغات آینده (کشویی) -->
    <li class="menu-section">
        <div class="section-title">
            <i class="material-icons">task</i>
            <span>تسک‌ها و تبلیغات</span>
            <i class="material-icons toggle-icon">expand_more</i>
        </div>
        <ul class="submenu">
            <li>
                <a href="#">
                    <i class="material-icons">list_alt</i>
                    <span>مدیریت تسک‌ها</span>
                    <span class="badge badge-primary">به‌زودی</span>
                </a>
            </li>
            <li>
                <a href="#">
                    <i class="material-icons">campaign</i>
                    <span>تبلیغات ویژه</span>
                    <span class="badge badge-primary">به‌زودی</span>
                </a>
            </li>
        </ul>
    </li>

    <!-- SEO (کشویی) -->
    <li class="menu-section">
        <div class="section-title">
            <i class="material-icons">search</i>
            <span>SEO</span>
            <i class="material-icons toggle-icon">expand_more</i>
        </div>
        <ul class="submenu">
            <li class="<?= str_contains($_SERVER['REQUEST_URI'] ?? '', '/admin/seo-keywords') ? 'active' : '' ?>">
                <a href="<?= url('/admin/seo-keywords') ?>">
                    <i class="material-icons">key</i>
                    <span>کلمات کلیدی SEO</span>
                </a>
            </li>
        </ul>
    </li>

    <!-- گزارش‌ها و آنالیتیکس (کشویی) -->
    <li class="menu-section">
        <div class="section-title">
            <i class="material-icons">assessment</i>
            <span>گزارش‌ها و آنالیتیکس</span>
            <i class="material-icons toggle-icon">expand_more</i>
        </div>
        <ul class="submenu">
            <li class="<?= strpos($_SERVER['REQUEST_URI'], '/admin/activity-logs') !== false ? 'active' : '' ?>">
                <a href="<?= url('/admin/activity-logs') ?>">
                    <i class="material-icons">history</i>
                    <span>لاگ فعالیت‌ها</span>
                </a>
            </li>
            <li class="<?= str_contains($_SERVER['REQUEST_URI'] ?? '', '/admin/bug-reports') ? 'active' : '' ?>">
                <a href="<?= url('/admin/bug-reports') ?>">
                    <i class="material-icons">bug_report</i>
                    <span>گزارش‌های باگ</span>
                </a>
            </li>
            <li class="<?= str_contains($_SERVER['REQUEST_URI'] ?? '', '/admin/kpi') ? 'active' : '' ?>">
                <a href="<?= url('/admin/kpi') ?>">
                    <i class="material-icons">analytics</i>
                    <span>KPI و آنالیتیکس</span>
                </a>
            </li>
            <li class="<?= str_contains($_SERVER['REQUEST_URI'] ?? '', '/admin/audit-trail') ? 'active' : '' ?>">
                <a href="<?= url('/admin/audit-trail') ?>">
                    <i class="material-icons">manage_search</i>
                    <span>Audit Trail</span>
                </a>
            </li>
            <li class="<?= str_contains($_SERVER['REQUEST_URI'] ?? '', '/admin/export') ? 'active' : '' ?>">
                <a href="<?= url('/admin/export') ?>">
                    <i class="material-icons">file_download</i>
                    <span>خروجی CSV</span>
                </a>
            </li>
        </ul>
    </li>

    <!-- تنظیمات (کشویی) -->
    <li class="menu-section">
        <div class="section-title">
            <i class="material-icons">settings</i>
            <span> تنظیمات کلی</span>
            <i class="material-icons toggle-icon">expand_more</i>
			
        </div>
        <ul class="submenu">
            <li>
                <a href="<?= url('/admin/settings') ?>">
                    <span class="material-icons">settings</span>
                    <span>تنظیمات</span>
                </a>
            </li>
            <li>
                <a href="#">
                    <i class="material-icons">payment</i>
                    <span>درگاه‌های پرداخت</span>
                    <span class="badge badge-primary">به‌زودی</span>
                </a>
            </li>
        </ul>
    </li>

</ul>

    <!-- ======= قابلیت‌های جدید ======= -->
    <li class="menu-section <?= str_contains($_SERVER['REQUEST_URI'] ?? '', '/admin/cron') || str_contains($_SERVER['REQUEST_URI'] ?? '', '/admin/email-queue') || str_contains($_SERVER['REQUEST_URI'] ?? '', '/admin/api-tokens') ? 'open' : '' ?>">
        <div class="section-title">
            <i class="material-icons">auto_fix_high</i>
            <span>سیستم و API</span>
            <i class="material-icons toggle-icon">expand_more</i>
        </div>
        <ul class="submenu">
            <li class="<?= str_contains($_SERVER['REQUEST_URI'] ?? '', '/admin/cron') ? 'active' : '' ?>">
                <a href="<?= url('/admin/cron') ?>">
                    <span class="material-icons">schedule</span>
                    <span>مدیریت Cron Jobs</span>
                </a>
            </li>
            <li class="<?= str_contains($_SERVER['REQUEST_URI'] ?? '', '/admin/email-queue') ? 'active' : '' ?>">
                <a href="<?= url('/admin/email-queue') ?>">
                    <span class="material-icons">mark_email_unread</span>
                    <span>صف ایمیل</span>
                </a>
            </li>
            <li class="<?= str_contains($_SERVER['REQUEST_URI'] ?? '', '/admin/api-tokens') ? 'active' : '' ?>">
                <a href="<?= url('/admin/api-tokens') ?>">
                    <span class="material-icons">vpn_key</span>
                    <span>توکن‌های API</span>
                </a>
            </li>
            <li class="<?= str_contains($_SERVER['REQUEST_URI'] ?? '', '/admin/cache') ? 'active' : '' ?>">
                <a href="<?= url('/admin/cache') ?>">
                    <span class="material-icons">cached</span>
                    <span>مدیریت Cache</span>
                </a>
            </li>
        </ul>
    </li>

</ul>
            <li>
                <a href="<?= url('/dashboard') ?>">
                    <span class="material-icons">home</span>
                    <span>بازگشت به سایت</span>
                </a>
            </li>
        </ul>
    </div>
    
    <!-- Main Content -->
    <div class="main-content">
        <!-- Topbar -->
        <div class="topbar">
            <h4><?= $title ?? 'پنل مدیریت' ?></h4>

            <!-- Admin Global Search -->
            <div style="position:relative">
                <div class="input-group input-group-sm" style="width:230px">
                    <span class="input-group-text bg-light border-end-0">
                        <i class="material-icons" style="font-size:16px">search</i>
                    </span>
                    <input type="text" id="adminSearchInput" class="form-control border-start-0 bg-light"
                           placeholder="جستجو کاربر، تراکنش..." autocomplete="off">
                </div>
                <div id="adminSearchResults" class="position-absolute bg-white border rounded shadow mt-1 d-none"
                     style="z-index:9999;width:340px;max-height:420px;overflow-y:auto;right:0"></div>
            </div>

            <div class="topbar-actions">
                <div class="topbar-icon">
                    <span class="material-icons"><a href="<?= url('/admin/notifications') ?>" 
   class="menu-item <?= \strpos($_SERVER['REQUEST_URI'], '/admin/notifications') === 0 ? 'active' : '' ?>">
    <i class="material-icons">notifications</i>
    
    <?php
    $unreadCount = unread_notifications_count(is_admin() ? user_id() : null);
    if ($unreadCount > 0):
    ?>
        <span class="badge bg-danger ms-auto"><?= $unreadCount > 99 ? '99+' : $unreadCount ?></span>
    <?php endif; ?>
</a></span>
                    
                </div>
                
                <div class="topbar-icon" onclick="window.location.href='<?= url('/profile') ?>'">
                    <span class="material-icons">person</span>
                </div>
                
                <div class="topbar-icon" onclick="document.getElementById('logout-form').submit()">
                    <span class="material-icons">logout</span>
                </div>
                
                <form id="logout-form" method="POST" action="<?= url('/logout') ?>" style="display: none;">
                    <?= csrf_field() ?>
                </form>
                
                <div class="user-info">
                    <div class="user-details">
                        <p class="user-name"><?= e($fullName) ?></p>
                        <p class="user-role"><?= $userRole ?></p>
                    </div>
                    <div class="user-avatar"><?= strtoupper($firstLetter) ?></div>
                </div>
            </div>
        </div>
        
        <!-- Content -->
        <div class="content-wrapper">
            <div id="toast-container"></div>
            
            <?= $content ?? '' ?>
        </div>
    </div>
	<!-- Sidebar CSS برای منوی تاشو -->
<style>
.menu-section {
    margin: 5px 0;
}
.menu-section .section-title {
    display: flex;
    align-items: center;
    padding: 12px 20px;
    cursor: pointer;
    transition: all 0.3s ease;
    border-radius: 8px;
    margin: 0 10px;
}
.menu-section .section-title:hover {
    background: rgba(79, 195, 247, 0.1);
}
.menu-section .section-title i.material-icons:first-child {
    font-size: 20px;
    margin-left: 10px;
    color: #4fc3f7;
}
.menu-section .section-title span {
    flex: 1;
    font-size: 13px;
    font-weight: 600;
    color: #333;
}
.menu-section .section-title .toggle-icon {
    font-size: 18px;
    color: #999;
    transition: transform 0.3s ease;
}
.menu-section.open .section-title .toggle-icon {
    transform: rotate(180deg);
}
.menu-section .submenu {
    max-height: 0;
    overflow: hidden;
    transition: max-height 0.3s ease;
    padding: 0;
    margin: 0;
    list-style: none;
}
.menu-section.open .submenu {
    max-height: 500px;
}
.menu-section .submenu li {
    margin: 0;
}
.menu-section .submenu li a {
    padding: 10px 20px 10px 50px;
    font-size: 13px;
    display: flex;
    align-items: center;
    color: #666;
    position: relative;
}
.menu-section .submenu li a i.material-icons {
    font-size: 18px;
    margin-left: 8px;
}
.menu-section .submenu li.active a,
.menu-section .submenu li a:hover {
    background: rgba(79, 195, 247, 0.1);
    color: #4fc3f7;
    border-right: 3px solid #4fc3f7;
}
.badge {
    padding: 2px 8px;
    font-size: 10px;
    border-radius: 12px;
    margin-right: auto;
}
.badge-primary {
    background: #ffa726;
    color: white;
}
.badge-danger {
    background: #f44336;
    color: white;
}
</style>

<!-- Sidebar JavaScript برای تاشو -->
<!-- Sidebar JavaScript برای تاشو -->
<script>
document.addEventListener('DOMContentLoaded', function() {
    const menuSections = document.querySelectorAll('.menu-section');
    menuSections.forEach(section => {
        const title = section.querySelector('.section-title');
        // باز کردن منوی فعال به صورت پیش‌فرض
        const hasActive = section.querySelector('.submenu li.active');
        if (hasActive) {
            section.classList.add('open');
        }
        title.addEventListener('click', function() {
            section.classList.toggle('open');
        });
    });
});
</script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/notyf@3/notyf.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script src="<?= asset('assets/js/swal-init.js') ?>?v=<?= time() ?>"></script>
<script src="<?= asset('/assets/vendor/notyf/notyf.min.js') ?>"></script>


    <script>
/* =========================================================
   Admin Notifications – Inline Version
   (Later: can be moved to /assets/js/admin-notifications.js)
========================================================= */

/* ---------- Config ---------- */
const ADMIN_NOTIF_ENDPOINT = '/admin/notifications';
const ADMIN_NOTIF_MARK_READ = '/admin/notifications/read';
const ADMIN_NOTIF_CLEANUP  = '/admin/notifications/cleanup';
const ADMIN_NOTIF_POLLING_INTERVAL = 30000; // 30s

/* اگر CSRF داری */
window.csrfToken = window.csrfToken || '<?= csrf_token() ?? '' ?>';

/* ---------- State ---------- */
let adminNotifInterval = null;

/* ---------- Helpers ---------- */
function isNotificationMuted() {
    return localStorage.getItem('admin_notifications_muted') === '1';
}

function muteNotifications() {
    localStorage.setItem('admin_notifications_muted', '1');
}

function unmuteNotifications() {
    localStorage.removeItem('admin_notifications_muted');
}

/* ---------- Load Notifications ---------- */
function loadNotifications() {
    fetch(ADMIN_NOTIF_ENDPOINT)
        .then(res => res.json())
        .then(data => {
            if (!data.success) return;

            const list  = document.getElementById('admin-notification-list');
            const badge = document.getElementById('admin-notification-badge');

            if (!list) return;

            badge.textContent = data.unread_count > 0 ? data.unread_count : '';
            badge.style.display = data.unread_count > 0 ? 'inline-block' : 'none';

            if (!data.notifications.length) {
                list.innerHTML = `
                    <li class="dropdown-item text-center text-muted small">
                        نوتیفیکیشنی وجود ندارد
                    </li>
                `;
                return;
            }

            list.innerHTML = data.notifications.map(notif => `
                <li>
                    <a href="${notif.link || '#'}"
                       class="dropdown-item notification-item ${notif.is_read ? '' : 'unread'}"
                       data-id="${notif.id}"
                       onclick="markNotificationAsRead(${notif.id})">
                        <div class="d-flex align-items-start">
                            <i class="material-icons text-${notif.color} me-2">
                                ${notif.icon}
                            </i>
                            <div class="flex-grow-1">
                                <div class="small fw-bold">${notif.title}</div>
                                <div class="small text-muted">${notif.message}</div>
                                <div class="small text-muted">
                                    ${notif.time_ago}
                                </div>
                            </div>
                        </div>
                    </a>
                </li>
            `).join('');
        })
        .catch(() => {});
}

/* ---------- Mark as Read ---------- */
function markNotificationAsRead(id) {
    fetch(ADMIN_NOTIF_MARK_READ + '/' + id, {
        method: 'POST',
        headers: {
            'X-CSRF-TOKEN': window.csrfToken
        }
    }).then(() => loadNotifications());
}

/* ---------- Polling ---------- */
function startNotificationPolling() {
    stopNotificationPolling();

    adminNotifInterval = setInterval(() => {
        if (!isNotificationMuted()) {
            loadNotifications();
        }
    }, ADMIN_NOTIF_POLLING_INTERVAL);
}

function stopNotificationPolling() {
    if (adminNotifInterval) {
        clearInterval(adminNotifInterval);
        adminNotifInterval = null;
    }
}

/* ---------- Toggle Mute ---------- */
function toggleNotificationMute(btn) {
    if (isNotificationMuted()) {
        unmuteNotifications();
        btn.innerHTML = '🔔';
        startNotificationPolling();
    } else {
        muteNotifications();
        btn.innerHTML = '🔕';
        stopNotificationPolling();
    }
}

/* ---------- Auto Cleanup ---------- */
function autoCleanNotifications() {
    fetch(ADMIN_NOTIF_CLEANUP, {
        method: 'POST',
        headers: {
            'X-CSRF-TOKEN': window.csrfToken
        }
    });
}

/* ---------- Init ---------- */
document.addEventListener('DOMContentLoaded', () => {
    loadNotifications();
    startNotificationPolling();

    // هر 6 ساعت پاک‌سازی
    setInterval(autoCleanNotifications, 6 * 60 * 60 * 1000);
});
</script>
<script>
  window.csrfToken = "<?= csrf_token() ?>";

  // ✅ مسیرهای درست با base path (مثل /chortke)
  const ADMIN_NOTIF_LIST_URL      = "<?= url('/admin/notifications') ?>";
  const ADMIN_NOTIF_MARK_READ_URL = "<?= url('/admin/notifications/read') ?>"; 
</script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="<?= asset('assets/js/app.js') ?>"></script>
    
    <?= $scripts ?? '' ?>

<script>
// ─── Admin Global Search ───────────────────────────────────
(function() {
    const input   = document.getElementById('adminSearchInput');
    const results = document.getElementById('adminSearchResults');
    if (!input || !results) return;

    let timer = null;

    input.addEventListener('input', () => {
        clearTimeout(timer);
        const q = input.value.trim();
        if (q.length < 2) { results.classList.add('d-none'); results.innerHTML = ''; return; }
        timer = setTimeout(() => doSearch(q), 300);
    });

    document.addEventListener('click', e => {
        if (!input.contains(e.target) && !results.contains(e.target)) {
            results.classList.add('d-none');
        }
    });

    async function doSearch(q) {
        results.classList.remove('d-none');
        results.innerHTML = '<div class="p-3 text-center text-muted small">در حال جستجو...</div>';

        const r = await fetch(`<?= url('/admin/search') ?>?q=${encodeURIComponent(q)}`)
                        .then(r => r.json())
                        .catch(() => null);

        if (!r || !r.results) {
            results.innerHTML = '<div class="p-3 text-center text-danger small">خطا در جستجو</div>';
            return;
        }

        const data = r.results;
        let html = '';

        const sections = [
            { key: 'users',        label: 'کاربران',    icon: 'person',           url: id => `<?= url('/admin/users') ?>/${id}/edit` },
            { key: 'transactions', label: 'تراکنش‌ها', icon: 'receipt',           url: id => `<?= url('/admin/transactions') ?>` },
            { key: 'tickets',      label: 'تیکت‌ها',    icon: 'confirmation_number', url: id => `<?= url('/admin/tickets') ?>/${id}` },
            { key: 'withdrawals',  label: 'برداشت‌ها',  icon: 'account_balance',  url: id => `<?= url('/admin/withdrawals') ?>` },
            { key: 'ads',          label: 'کمپین‌ها',   icon: 'campaign',          url: id => `<?= url('/admin/ad-tasks') ?>/${id}` },
        ];

        for (const sec of sections) {
            const items = data[sec.key] ?? [];
            if (!items.length) continue;

            html += `<div class="px-3 py-1 bg-light border-bottom">
                         <small class="text-muted fw-semibold">
                             <i class="material-icons align-middle" style="font-size:14px">${sec.icon}</i>
                             ${sec.label}
                         </small>
                     </div>`;

            for (const item of items) {
                const label = item.full_name || item.subject || item.title || `#${item.id}`;
                const sub   = item.email || item.description || item.status || '';
                html += `<a href="${sec.url(item.id)}" class="d-flex align-items-center gap-2 px-3 py-2 text-decoration-none text-dark border-bottom search-result-item" style="font-size:13px">
                             <i class="material-icons text-muted" style="font-size:16px">${sec.icon}</i>
                             <div>
                                 <div>${label}</div>
                                 ${sub ? `<div class="text-muted" style="font-size:11px">${sub}</div>` : ''}
                             </div>
                         </a>`;
            }
        }

        if (!html) {
            html = '<div class="p-3 text-center text-muted small">نتیجه‌ای یافت نشد</div>';
        }

        results.innerHTML = html;
    }
})();
</script>
<style>
.search-result-item:hover { background: #f8f9fa; }
</style>

</body>
</html>