<?php
$pageTitle = 'تماس با ما';
require_once __DIR__ . '/../layouts/header.php';
?>

<div class="container py-5">
    <div class="row">
        <!-- اطلاعات تماس -->
        <div class="col-lg-4 mb-4">
            <div class="card h-100">
                <div class="card-body">
                    <h4 class="mb-4">راه‌های ارتباطی</h4>
                    
                    <div class="contact-item mb-4">
                        <i class="material-icons text-primary">email</i>
                        <div>
                            <strong>ایمیل:</strong><br>
                            <a href="mailto:<?= setting('contact_email') ?>"><?= e(setting('contact_email')) ?></a>
                        </div>
                    </div>
                    
                    <div class="contact-item mb-4">
                        <i class="material-icons text-primary">phone</i>
                        <div>
                            <strong>تلفن:</strong><br>
                            <?= e(setting('contact_phone')) ?>
                        </div>
                    </div>
                    
                    <div class="contact-item mb-4">
                        <i class="material-icons text-primary">send</i>
                        <div>
                            <strong>تلگرام:</strong><br>
                            <a href="https://t.me/<?= e(setting('telegram_support')) ?>" target="_blank">
                                <?= e(setting('telegram_support')) ?>
                            </a>
                        </div>
                    </div>
                    
                    <div class="contact-item">
                        <i class="material-icons text-primary" style="color: #25D366;">chat</i>
                        <div>
                            <strong>واتساپ:</strong><br>
                            <a href="https://wa.me/<?= e(setting('whatsapp_support')) ?>" target="_blank">
                                <?= e(setting('whatsapp_support')) ?>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- فرم تماس -->
        <div class="col-lg-8">
            <div class="card">
                <div class="card-body">
                    <h4 class="mb-4">ارسال پیام</h4>
                    
                    <form method="POST" action="<?= url('/contact/send') ?>">
                        <?= csrf_field() ?>
                        
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>نام و نام خانوادگی <span class="text-danger">*</span></label>
                                    <input type="text" name="name" class="form-control" required>
                                </div>
                            </div>
                            
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>ایمیل <span class="text-danger">*</span></label>
                                    <input type="email" name="email" class="form-control" required>
                                </div>
                            </div>
                        </div>
                        
                        <div class="form-group">
                            <label>موضوع <span class="text-danger">*</span></label>
                            <select name="subject" class="form-control" required>
                                <option value="">انتخاب کنید</option>
                                <option value="support">پشتیبانی فنی</option>
                                <option value="financial">مسائل مالی</option>
                                <option value="suggestions">پیشنهادات</option>
                                <option value="complaint">شکایت</option>
                                <option value="other">سایر موارد</option>
                            </select>
                        </div>
                        
                        <div class="form-group">
                            <label>پیام <span class="text-danger">*</span></label>
                            <textarea name="message" class="form-control" rows="6" required></textarea>
                        </div>
                        
                        <?= captcha_field() ?>
                        
                        <button type="submit" class="btn btn-primary btn-lg">
                            <i class="material-icons">send</i>
                            ارسال پیام
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
.contact-item {
    display: flex;
    align-items: flex-start;
    gap: 15px;
}

.contact-item i {
    font-size: 32px;
}

.contact-item a {
    color: #4fc3f7;
    text-decoration: none;
}

.contact-item a:hover {
    text-decoration: underline;
}
</style>

<?php require_once __DIR__ . '/../layouts/footer.php'; ?>