<?php ob_start(); ?>

<div class="container py-5">
    <div class="row justify-content-center">
        <div class="col-lg-10">
            
            <div class="card border-0 shadow-sm">
                <div class="card-body p-5">
                    
                    <h1 class="text-center mb-4">درباره چرتکه</h1>
                    <p class="text-center text-muted mb-5">پلتفرم جامع کسب درآمد آنلاین</p>
                    
                    <hr>
                    
                    <!-- مقدمه -->
                    <div class="text-center mb-5">
                        <img src="<?= asset('images/logo-dark.png') ?>" alt="چرتکه" style="height: 100px;" class="mb-4">
                        <h3 class="mb-3">چرتکه چیست؟</h3>
                        <p class="lead">
                            چرتکه یک پلتفرم نوین و کامل برای کسب درآمد آنلاین است که با ارائه خدمات متنوع،
                            امکان کسب درآمد را برای همه فراهم می‌کند.
                        </p>
                    </div>
                    
                    <!-- ماموریت -->
                    <div class="row mb-5">
                        <div class="col-md-12">
                            <div class="card bg-primary bg-opacity-10 border-0">
                                <div class="card-body p-4">
                                    <h4 class="text-primary mb-3">
                                        <i class="material-icons-outlined">flag</i>
                                        ماموریت ما
                                    </h4>
                                    <p class="mb-0">
                                        ما متعهدیم که بستری امن، شفاف و کارآمد برای کسب درآمد آنلاین فراهم کنیم.
                                        هدف ما ایجاد فرصت‌های برابر برای همه افراد، صرف‌نظر از سن، جنسیت یا موقعیت جغرافیایی است.
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- چشم‌انداز -->
                    <div class="row mb-5">
                        <div class="col-md-12">
                            <div class="card bg-success bg-opacity-10 border-0">
                                <div class="card-body p-4">
                                    <h4 class="text-success mb-3">
                                        <i class="material-icons-outlined">visibility</i>
                                        چشم‌انداز ما
                                    </h4>
                                    <p class="mb-0">
                                        تبدیل شدن به بزرگ‌ترین و معتبرترین پلتفرم کسب درآمد آنلاین در ایران 
                                        و ارائه خدمات نوآورانه که زندگی کاربران را بهبود بخشد.
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- خدمات ما -->
                    <h3 class="text-center mb-4">خدمات ما</h3>
                    <div class="row g-4 mb-5">
                        
                        <div class="col-md-4">
                            <div class="card h-100 border-0 shadow-sm">
                                <div class="card-body text-center p-4">
                                    <i class="material-icons-outlined text-primary mb-3" style="font-size: 60px;">task</i>
                                    <h5>انجام تسک</h5>
                                    <p class="text-muted small">
                                        با انجام تسک‌های ساده در شبکه‌های اجتماعی درآمد کسب کنید
                                    </p>
                                </div>
                            </div>
                        </div>
                        
                        <div class="col-md-4">
                            <div class="card h-100 border-0 shadow-sm">
                                <div class="card-body text-center p-4">
                                    <i class="material-icons-outlined text-success mb-3" style="font-size: 60px;">trending_up</i>
                                    <h5>سرمایه‌گذاری</h5>
                                    <p class="text-muted small">
                                        سرمایه‌گذاری امن در بازار طلا و کسب سود هفتگی
                                    </p>
                                </div>
                            </div>
                        </div>
                        
                        <div class="col-md-4">
                            <div class="card h-100 border-0 shadow-sm">
                                <div class="card-body text-center p-4">
                                    <i class="material-icons-outlined text-warning mb-3" style="font-size: 60px;">casino</i>
                                    <h5>قرعه‌کشی</h5>
                                    <p class="text-muted small">
                                        شرکت در قرعه‌کشی‌های روزانه و برنده شدن جوایز نقدی
                                    </p>
                                </div>
                            </div>
                        </div>
                        
                        <div class="col-md-4">
                            <div class="card h-100 border-0 shadow-sm">
                                <div class="card-body text-center p-4">
                                    <i class="material-icons-outlined text-info mb-3" style="font-size: 60px;">share</i>
                                    <h5>سیستم ارجاع</h5>
                                    <p class="text-muted small">
                                        از معرفی دوستان کمیسیون دریافت کنید
                                    </p>
                                </div>
                            </div>
                        </div>
                        
                        <div class="col-md-4">
                            <div class="card h-100 border-0 shadow-sm">
                                <div class="card-body text-center p-4">
                                    <i class="material-icons-outlined text-danger mb-3" style="font-size: 60px;">movie</i>
                                    <h5>کسب درآمد از استعداد</h5>
                                    <p class="text-muted small">
                                        محتوای خود را تولید و درآمد کسب کنید
                                    </p>
                                </div>
                            </div>
                        </div>
                        
                        <div class="col-md-4">
                            <div class="card h-100 border-0 shadow-sm">
                                <div class="card-body text-center p-4">
                                    <i class="material-icons-outlined text-purple mb-3" style="font-size: 60px;">campaign</i>
                                    <h5>سفارش استوری</h5>
                                    <p class="text-muted small">
                                        از تبلیغات در پیج اینستاگرام خود درآمد کسب کنید
                                    </p>
                                </div>
                            </div>
                        </div>
                        
                    </div>
                    
                    <!-- چرا چرتکه؟ -->
                    <h3 class="text-center mb-4">چرا چرتکه؟</h3>
                    <div class="row g-4 mb-5">
                        
                        <div class="col-md-6">
                            <div class="d-flex">
                                <i class="material-icons-outlined text-success me-3" style="font-size: 40px;">verified_user</i>
                                <div>
                                    <h5>امنیت بالا</h5>
                                    <p class="text-muted small">
                                        استفاده از جدیدترین تکنولوژی‌های امنیتی برای محافظت از اطلاعات و دارایی شما
                                    </p>
                                </div>
                            </div>
                        </div>
                        
                        <div class="col-md-6">
                            <div class="d-flex">
                                <i class="material-icons-outlined text-primary me-3" style="font-size: 40px;">account_balance</i>
                                <div>
                                    <h5>پرداخت سریع</h5>
                                    <p class="text-muted small">
                                        برداشت درآمد خود را با سرعت بالا و بدون دردسر دریافت کنید
                                    </p>
                                </div>
                            </div>
                        </div>
                        
                        <div class="col-md-6">
                            <div class="d-flex">
                                <i class="material-icons-outlined text-warning me-3" style="font-size: 40px;">support_agent</i>
                                <div>
                                    <h5>پشتیبانی 24/7</h5>
                                    <p class="text-muted small">
                                        تیم پشتیبانی ما همیشه آماده پاسخگویی به سوالات شماست
                                    </p>
                                </div>
                            </div>
                        </div>
                        
                        <div class="col-md-6">
                            <div class="d-flex">
                                <i class="material-icons-outlined text-info me-3" style="font-size: 40px;">workspace_premium</i>
                                <div>
                                    <h5>شفافیت کامل</h5>
                                    <p class="text-muted small">
                                        تمامی فعالیت‌ها و تراکنش‌ها به صورت شفاف قابل مشاهده است
                                    </p>
                                </div>
                            </div>
                        </div>
                        
                    </div>
                    
                    <!-- آمار -->
                    <div class="row text-center mb-5">
                        <div class="col-md-3 mb-3">
                            <div class="card bg-light border-0">
                                <div class="card-body">
                                    <h2 class="text-primary mb-0">10,000+</h2>
                                    <small class="text-muted">کاربر فعال</small>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3 mb-3">
                            <div class="card bg-light border-0">
                                <div class="card-body">
                                    <h2 class="text-success mb-0">50,000+</h2>
                                    <small class="text-muted">تسک انجام شده</small>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3 mb-3">
                            <div class="card bg-light border-0">
                                <div class="card-body">
                                    <h2 class="text-warning mb-0">5 میلیارد+</h2>
                                    <small class="text-muted">تومان پرداختی</small>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3 mb-3">
                            <div class="card bg-light border-0">
                                <div class="card-body">
                                    <h2 class="text-info mb-0">99%</h2>
                                    <small class="text-muted">رضایت کاربران</small>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- تماس -->
                    <div class="text-center mt-5">
                        <h4 class="mb-3">آماده شروع هستید؟</h4>
                        <a href="<?= url('register') ?>" class="btn btn-primary btn-lg me-2">
                            <i class="material-icons-outlined">person_add</i>
                            ثبت‌نام رایگان
                        </a>
                        <a href="<?= url('contact') ?>" class="btn btn-outline-secondary btn-lg">
                            <i class="material-icons-outlined">mail</i>
                            تماس با ما
                        </a>
                    </div>
                    
                </div>
            </div>
            
        </div>
    </div>
</div>

<?php
$content = ob_get_clean();
$layout = __DIR__ . '/../layouts/app.php';
require $layout;
?>