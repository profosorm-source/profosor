<?php
$pageTitle = $page->title;
require_once __DIR__ . '/../layouts/header.php';
?>

<div class="container py-5">
    <div class="row justify-content-center">
        <div class="col-lg-10">
            <div class="card">
                <div class="card-body p-5">
                    <h1 class="mb-4"><?= e($page->title) ?></h1>
                    
                    <div class="content">
                        <?= $page->content ?>
                    </div>
                    
                    <hr class="my-5">
                    
                    <div class="text-muted small">
                        آخرین بروزرسانی: <?= to_jalali($page->updated_at) ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
.content {
    line-height: 1.8;
    font-size: 15px;
}

.content h2 {
    color: #4fc3f7;
    margin-top: 30px;
    margin-bottom: 15px;
    font-size: 24px;
}

.content h3 {
    color: #666;
    margin-top: 20px;
    margin-bottom: 10px;
    font-size: 20px;
}

.content p {
    margin-bottom: 15px;
}

.content ul, .content ol {
    margin-bottom: 15px;
    padding-right: 20px;
}

.content li {
    margin-bottom: 8px;
}

.content a {
    color: #4fc3f7;
    text-decoration: none;
}

.content a:hover {
    text-decoration: underline;
}

.content table {
    width: 100%;
    margin-bottom: 20px;
    border-collapse: collapse;
}

.content table th,
.content table td {
    padding: 10px;
    border: 1px solid #ddd;
    text-align: right;
}

.content table th {
    background: #f5f5f5;
    font-weight: bold;
}

.content blockquote {
    border-right: 4px solid #4fc3f7;
    padding: 10px 20px;
    margin: 20px 0;
    background: #f9f9f9;
    font-style: italic;
}

.content code {
    background: #f5f5f5;
    padding: 2px 6px;
    border-radius: 3px;
    font-family: monospace;
    font-size: 14px;
}

.content pre {
    background: #f5f5f5;
    padding: 15px;
    border-radius: 5px;
    overflow-x: auto;
}
</style>

<?php require_once __DIR__ . '/../layouts/footer.php'; ?>