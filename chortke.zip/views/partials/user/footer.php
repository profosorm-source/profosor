<footer class="u-footer">
  <div class="container-fluid">
    <div class="u-footer__row">
      <div class="u-footer__links">
        <a href="<?= url('/pages/rules') ?>">قوانین</a>
        <a href="<?= url('/pages/privacy') ?>">حریم خصوصی</a>
        <a href="<?= url('/pages/help') ?>">راهنما</a>
        <a href="<?= url('/contact') ?>">تماس</a>
      </div>
      <div class="u-footer__copy">
        © <?= date('Y') ?> <?= e(setting('site_name') ?? 'چرتکه') ?> - همه حقوق محفوظ است.
      </div>
    </div>
  </div>
</footer>