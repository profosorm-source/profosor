<?php
$panel = $panel ?? [];
if (\is_object($panel)) $panel = (array)$panel;

// سازگاری با auth()
$auth = auth();
$authUser = (\is_object($auth) && \method_exists($auth, 'user')) ? $auth->user() : (\is_object($auth) ? $auth : null);
$user = $panel['user'] ?? $authUser;

$badges = $panel['badges'] ?? ['notif_unread' => 0];

$tier = $panel['tier'] ?? ($user->tier_level ?? 'silver');
$kycStatus = $panel['kyc']['status'] ?? 'pending';

$kycLabelMap = [
  'verified' => 'KYC تایید',
  'pending' => 'KYC ناقص',
  'under_review' => 'در بررسی',
  'rejected' => 'رد شده',
  'expired' => 'منقضی',
];
$kycLabel = $kycLabelMap[$kycStatus] ?? 'KYC ناقص';
$kycClass = ($kycStatus === 'verified') ? 'u-chip u-chip--ok' : 'u-chip u-chip--warn';

$pageTitle = $pageTitle ?? ($title ?? 'پنل کاربری');
?>
<header class="u-navbar">
  <div class="u-navbar__left">
    <button class="u-btn-icon d-lg-none" type="button" data-sidebar-open aria-label="باز کردن منو">
      <span class="material-icons">menu</span>
    </button>

    <div class="u-navbar__title">
      <div class="u-navbar__h"><?= e($pageTitle) ?></div>
      <div class="u-navbar__sub"><?= e(to_jalali(date('Y-m-d'))) ?></div>
    </div>
  </div>

  <div class="u-navbar__right">
    <!-- User Info (در ناوبار) -->
    <a class="u-userinfo" href="<?= url('/user/profile') ?>" title="پروفایل">
      <img class="u-userinfo__avatar" src="<?= asset('img/avatar-default.png') ?>" alt="avatar">
      <div class="u-userinfo__meta d-none d-md-block">
        <div class="u-userinfo__name"><?= e($user?->full_name ?? 'کاربر') ?></div>
        <div class="u-userinfo__chips">
          <span class="u-chip u-chip--tier"><?= e(\strtoupper((string)$tier)) ?></span>
          <span class="<?= $kycClass ?>"><?= e($kycLabel) ?></span>
        </div>
      </div>
    </a>

    <div class="u-topicons">
      <!-- Notifications -->
      <a class="u-iconbtn" href="<?= url('/user/notifications') ?>" title="اعلان‌ها">
        <span class="material-icons">notifications</span>
        <?php if ((int)($badges['notif_unread'] ?? 0) > 0): ?>
          <span class="u-iconbtn__badge"><?= (int)$badges['notif_unread'] ?></span>
        <?php endif; ?>
        <span class="u-iconbtn__label">نوتیف</span>
      </a>

      <!-- Settings Dropdown (custom) -->
      <div class="u-dd-wrap">
        <button class="u-iconbtn u-iconbtn--settings"
                type="button"
                data-u-dd-toggle="settings"
                aria-expanded="false"
                title="تنظیمات">
          <span class="material-icons">settings</span>
          <span class="u-iconbtn__label">ریز تنظیمات</span>
        </button>

        <div class="u-dd" data-u-dd-menu="settings" role="menu" aria-label="منوی تنظیمات">
          <a class="u-dd__item" href="<?= url('/user/profile') ?>">
            <span class="material-icons">person</span>
            <span>ویرایش پروفایل</span>
          </a>

          <a class="u-dd__item" href="<?= url('/user/kyc') ?>">
            <span class="material-icons">verified_user</span>
            <span>احراز هویت (KYC)</span>
          </a>

          <a class="u-dd__item" href="<?= url('/user/bank-cards') ?>">
            <span class="material-icons">credit_card</span>
            <span>کارت‌های بانکی</span>
          </a>

          <a class="u-dd__item" href="<?= url('/user/coupons') ?>">
            <span class="material-icons">confirmation_number</span>
            <span>کوپن‌ها</span>
          </a>

          <a class="u-dd__item" href="<?= url('/user/profile?tab=avatar') ?>">
            <span class="material-icons">photo_camera</span>
            <span>تغییر آواتار</span>
          </a>

          <a class="u-dd__item" href="<?= url('/user/security') ?>">
            <span class="material-icons">lock</span>
            <span>امنیت و نشست‌ها</span>
          </a>
        </div>
      </div>

      <!-- Logout -->
      <a class="u-iconbtn u-iconbtn--logout" href="<?= url('/logout') ?>" title="خروج">
        <span class="material-icons">logout</span>
        <span class="u-iconbtn__label">خروج</span>
      </a>
    </div>
  </div>
</header>