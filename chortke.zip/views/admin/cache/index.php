<?php
// views/admin/cache/index.php
/** @var array $stats آمار cache */
$title = 'مدیریت Cache';
include BASE_PATH . '/views/layouts/admin.php';
?>

<div class="main-content">
<div class="container-fluid py-4">

    <div class="d-flex justify-content-between align-items-center mb-4">
        <h4 class="mb-0">🗄️ مدیریت Cache</h4>
        <div class="d-flex gap-2">
            <button class="btn btn-warning btn-sm" onclick="clearCache('settings')">
                <span class="material-icons align-middle" style="font-size:18px">settings</span>
                پاک‌سازی تنظیمات
            </button>
            <button class="btn btn-warning btn-sm" onclick="clearCache('kpi')">
                <span class="material-icons align-middle" style="font-size:18px">analytics</span>
                پاک‌سازی KPI
            </button>
            <button class="btn btn-danger btn-sm" onclick="clearCache('all')">
                <span class="material-icons align-middle" style="font-size:18px">delete_sweep</span>
                پاک‌سازی کامل
            </button>
        </div>
    </div>

    <!-- آمار -->
    <div class="row g-3 mb-4">
        <div class="col-md-3 col-6">
            <div class="card border-0 shadow-sm">
                <div class="card-body text-center py-3">
                    <span class="material-icons text-primary fs-3">folder</span>
                    <h4 class="mb-0 mt-1"><?= number_format($stats['total_files'] ?? 0) ?></h4>
                    <small class="text-muted">فایل cache</small>
                </div>
            </div>
        </div>
        <div class="col-md-3 col-6">
            <div class="card border-0 shadow-sm">
                <div class="card-body text-center py-3">
                    <span class="material-icons text-success fs-3">check_circle</span>
                    <h4 class="mb-0 mt-1"><?= number_format($stats['valid_files'] ?? 0) ?></h4>
                    <small class="text-muted">معتبر</small>
                </div>
            </div>
        </div>
        <div class="col-md-3 col-6">
            <div class="card border-0 shadow-sm">
                <div class="card-body text-center py-3">
                    <span class="material-icons text-warning fs-3">timer_off</span>
                    <h4 class="mb-0 mt-1"><?= number_format($stats['expired_files'] ?? 0) ?></h4>
                    <small class="text-muted">منقضی</small>
                </div>
            </div>
        </div>
        <div class="col-md-3 col-6">
            <div class="card border-0 shadow-sm">
                <div class="card-body text-center py-3">
                    <span class="material-icons text-info fs-3">storage</span>
                    <h4 class="mb-0 mt-1"><?= $stats['total_size_kb'] ?? '0' ?> KB</h4>
                    <small class="text-muted">حجم کل</small>
                </div>
            </div>
        </div>
    </div>

    <!-- cache keys -->
    <div class="card border-0 shadow-sm">
        <div class="card-header bg-white">
            <h6 class="mb-0">کلیدهای Cache فعال</h6>
        </div>
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover mb-0 small">
                    <thead class="table-light">
                        <tr>
                            <th>کلید</th>
                            <th>انقضا</th>
                            <th>حجم</th>
                            <th>وضعیت</th>
                            <th></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($stats['keys'])): ?>
                            <tr><td colspan="5" class="text-center py-4 text-muted">Cache خالی است</td></tr>
                        <?php else: ?>
                        <?php foreach ($stats['keys'] as $item): $item = (object)$item; ?>
                        <tr>
                            <td><code><?= e($item->key) ?></code></td>
                            <td class="text-muted">
                                <?php if ($item->expire_at > time()): ?>
                                    <?= to_jalali(date('Y-m-d H:i:s', $item->expire_at)) ?>
                                    <span class="text-success small">(<?= round(($item->expire_at - time()) / 60) ?> دقیقه دیگر)</span>
                                <?php else: ?>
                                    <span class="text-danger">منقضی</span>
                                <?php endif; ?>
                            </td>
                            <td class="text-muted"><?= $item->size_bytes ?? '-' ?> B</td>
                            <td>
                                <?php if ($item->expire_at > time()): ?>
                                    <span class="badge bg-success">معتبر</span>
                                <?php else: ?>
                                    <span class="badge bg-warning text-dark">منقضی</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <button class="btn btn-xs btn-outline-danger"
                                        onclick="clearCacheKey('<?= e(addslashes($item->key)) ?>')">
                                    <span class="material-icons" style="font-size:14px">delete</span>
                                </button>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
</div>

<script>
const csrfToken = '<?= csrf_token() ?>';

function clearCache(type) {
    const labels = {all:'کل cache', settings:'cache تنظیمات', kpi:'cache KPI'};
    if (!confirm(`${labels[type]} پاک شود؟`)) return;

    fetch('<?= url('/admin/cache/clear') ?>', {
        method: 'POST',
        headers: {'Content-Type':'application/json','X-CSRF-TOKEN':csrfToken},
        body: JSON.stringify({type})
    }).then(r => r.json()).then(d => {
        notyf.success(d.message || 'Cache پاک شد');
        setTimeout(() => location.reload(), 1000);
    });
}

function clearCacheKey(key) {
    fetch('<?= url('/admin/cache/forget') ?>', {
        method: 'POST',
        headers: {'Content-Type':'application/json','X-CSRF-TOKEN':csrfToken},
        body: JSON.stringify({key})
    }).then(r => r.json()).then(d => {
        notyf.success('کلید حذف شد');
        setTimeout(() => location.reload(), 500);
    });
}
</script>
