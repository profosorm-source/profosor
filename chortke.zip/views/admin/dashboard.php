<?php
ob_start();
?>

<!-- CSRF فرم مخفی عمومی -->
<form method="POST" style="display:none;">
    <?= csrf_field() ?>
</form>

<!-- آمار کلی -->
<div class="row g-3 mb-4">
    <div class="col-xl-3 col-md-6">
        <div class="stat-card stat-primary">
            <span class="material-icons">people</span>
            <div class="stat-value"><?= number_format($stats['total_users'] ?? 0) ?></div>
            <div class="stat-label">کل کاربران</div>
        </div>
    </div>

    <div class="col-xl-3 col-md-6">
        <div class="stat-card stat-danger">
            <span class="material-icons">person_add</span>
            <div class="stat-value"><?= number_format($stats['today_users'] ?? 0) ?></div>
            <div class="stat-label">ثبت‌نام امروز</div>
        </div>
    </div>

    <div class="col-xl-3 col-md-6">
        <div class="stat-card stat-info">
            <span class="material-icons">check_circle</span>
            <div class="stat-value"><?= number_format($stats['active_users'] ?? 0) ?></div>
            <div class="stat-label">کاربران فعال</div>
        </div>
    </div>

    <div class="col-xl-3 col-md-6">
        <div class="stat-card stat-warning">
            <span class="material-icons">block</span>
            <div class="stat-value"><?= number_format($stats['banned_users'] ?? 0) ?></div>
            <div class="stat-label">کاربران بن شده</div>
        </div>
    </div>
</div>

<!-- نمودارها -->
<div class="row g-3 mb-4">
    <div class="col-lg-8">
        <div class="card">
            <div class="card-header">
                📊 نمودار کاربران (30 روز اخیر)
            </div>
            <div class="card-body">
                <canvas id="usersChart" height="80"></canvas>
            </div>
        </div>
    </div>

    <div class="col-lg-4">
        <div class="card">
            <div class="card-header">
                💰 درآمد امروز
            </div>
            <div class="card-body text-center">
                <h2 class="text-success mb-2">۰ تومان</h2>
                <p class="text-muted small mb-0">درآمد کل: ۰ تومان</p>
            </div>
        </div>
    </div>
</div>

<!-- کاربران اخیر -->
<div class="card">
    <div class="card-header d-flex justify-content-between align-items-center">
        <span>👥 کاربران اخیر</span>
        <a href="<?= url('/admin/users') ?>" class="btn btn-sm btn-primary">مشاهده همه</a>
    </div>

    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table table-hover mb-0">
                <thead>
                    <tr>
                        <th>شناسه</th>
                        <th>نام و نام خانوادگی</th>
                        <th>ایمیل</th>
                        <th>موبایل</th>
                        <th>نقش</th>
                        <th>وضعیت</th>
                        <th>تاریخ ثبت‌نام</th>
                    </tr>
                </thead>
                <tbody>
                <?php if (empty($recentUsers)): ?>
                    <tr>
                        <td colspan="7" class="text-center py-4 text-muted">
                            هیچ کاربری یافت نشد
                        </td>
                    </tr>
                <?php else: ?>
                    <?php foreach ($recentUsers as $userItem): ?>
                        <tr>
                            <td><?= e($userItem->id) ?></td>
                            <td><?= e($userItem->full_name) ?></td>
                            <td><?= e($userItem->email) ?></td>
                            <td><?= e($userItem->mobile) ?></td>
                            <td>
                                <?php
                                $roleColors = ['admin' => 'danger', 'support' => 'warning', 'user' => 'secondary'];
                                $roleNames  = ['admin' => 'مدیر', 'support' => 'پشتیبان', 'user' => 'کاربر'];
                                ?>
                                <span class="badge bg-<?= $roleColors[$userItem->role] ?? 'secondary' ?>">
                                    <?= $roleNames[$userItem->role] ?? 'کاربر' ?>
                                </span>
                            </td>
                            <td>
                                <?php
                                $statusColors = ['active' => 'success', 'inactive' => 'secondary', 'suspended' => 'warning', 'banned' => 'danger'];
                                $statusNames  = ['active' => 'فعال', 'inactive' => 'غیرفعال', 'suspended' => 'تعلیق', 'banned' => 'بن شده'];
                                ?>
                                <span class="badge bg-<?= $statusColors[$userItem->status] ?? 'secondary' ?>">
                                    <?= $statusNames[$userItem->status] ?? 'نامشخص' ?>
                                </span>
                            </td>
                            <td>
                                <small class="text-muted">
                                    <?= jdate('Y/m/d H:i', strtotime($userItem->created_at)) ?>
                                </small>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php
$content = ob_get_clean();

$scripts = '
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
<script>
const ctx = document.getElementById("usersChart");
if (ctx) {
    new Chart(ctx, {
        type: "line",
        data: {
            labels: Array.from({length: 30}, (_, i) => i + 1),
            datasets: [{
                label: "تعداد کاربران جدید",
                data: [3,5,2,8,12,6,9,14,7,11,5,13,8,10,6,15,9,7,12,8,11,6,14,10,9,13,7,11,8,12],
                borderColor: "#00bcd4",
                backgroundColor: "rgba(0,188,212,0.1)",
                tension: 0.4,
                fill: true
            }]
        },
        options: {
            responsive: true,
            plugins: { legend: { display: false } },
            scales: { y: { beginAtZero: true } }
        }
    });
}
</script>
';

require_once __DIR__ . '/../layouts/admin.php';
