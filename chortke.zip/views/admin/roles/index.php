<?php
$title = 'مدیریت نقش‌ها و دسترسی‌ها';
$layout = 'admin';
ob_start();
?>

<div class="content-header">
    <div class="d-flex justify-content-between align-items-center">
        <div>
            <h4 class="page-title mb-1">
                <i class="material-icons text-primary">admin_panel_settings</i>
                مدیریت نقش‌ها
            </h4>
            <p class="text-muted mb-0" style="font-size:12px;">تعریف نقش‌ها و تنظیم سطح دسترسی‌ها</p>
        </div>
        <a href="<?= url('/admin/roles/create') ?>" class="btn btn-primary btn-sm">
            <i class="material-icons" style="font-size:16px;vertical-align:middle;">add</i>
            نقش جدید
        </a>
    </div>
</div>

<!-- پیام‌های فلش -->
<?php if ($flash = \Core\Session::getInstance()->getFlash('success')): ?>
<div class="alert alert-success alert-dismissible fade show mt-3" role="alert">
    <i class="material-icons" style="font-size:18px;vertical-align:middle;">check_circle</i>
    <?= e($flash) ?>
    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
</div>
<?php endif; ?>

<?php if ($flash = \Core\Session::getInstance()->getFlash('error')): ?>
<div class="alert alert-danger alert-dismissible fade show mt-3" role="alert">
    <i class="material-icons" style="font-size:18px;vertical-align:middle;">error</i>
    <?= e($flash) ?>
    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
</div>
<?php endif; ?>

<!-- جدول نقش‌ها -->
<div class="card mt-3">
    <div class="card-header">
        <h6 class="card-title mb-0">
            <i class="material-icons text-primary" style="font-size:18px;vertical-align:middle;">security</i>
            لیست نقش‌ها
        </h6>
    </div>
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table table-hover mb-0">
                <thead>
                    <tr>
                        <th style="width:50px;">#</th>
                        <th>نام نقش</th>
                        <th>شناسه</th>
                        <th>توضیحات</th>
                        <th style="width:100px;">کاربران</th>
                        <th style="width:90px;">وضعیت</th>
                        <th style="width:80px;">نوع</th>
                        <th style="width:140px;">عملیات</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($roles)): ?>
                    <tr>
                        <td colspan="8" class="text-center text-muted py-4">
                            <i class="material-icons" style="font-size:40px;opacity:0.3;">folder_off</i>
                            <p class="mt-2">هیچ نقشی یافت نشد.</p>
                        </td>
                    </tr>
                    <?php else: ?>
                    <?php foreach ($roles as $index => $role): ?>
                    <tr id="role-row-<?= $role->id ?>">
                        <td class="text-muted"><?= $index + 1 ?></td>
                        <td>
                            <strong><?= e($role->name) ?></strong>
                        </td>
                        <td>
                            <code style="font-size:11px;"><?= e($role->slug) ?></code>
                        </td>
                        <td class="text-muted" style="font-size:12px;">
                            <?= e($role->description ?? '—') ?>
                        </td>
                        <td>
                            <span class="badge bg-info"><?= number_format($role->user_count) ?> نفر</span>
                        </td>
                        <td>
                            <?php if ($role->is_active): ?>
                                <span class="badge badge-success">فعال</span>
                            <?php else: ?>
                                <span class="badge badge-danger">غیرفعال</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php if ($role->is_system): ?>
                                <span class="badge" style="background:#fff3e0;color:#ff9800;font-size:10px;">
                                    <i class="material-icons" style="font-size:12px;vertical-align:middle;">lock</i>
                                    سیستمی
                                </span>
                            <?php else: ?>
                                <span class="badge" style="background:#e8f5e9;color:#4caf50;font-size:10px;">سفارشی</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <div class="d-flex gap-1">
                                <a href="<?= url('/admin/roles/' . $role->id . '/edit') ?>" 
                                   class="btn btn-sm btn-outline-primary" title="ویرایش">
                                    <i class="material-icons" style="font-size:16px;">edit</i>
                                </a>
                                
                                <?php if (!$role->is_system): ?>
                                <button class="btn btn-sm btn-outline-warning btn-toggle-role" 
                                        data-id="<?= $role->id ?>"
                                        data-status="<?= $role->is_active ?>"
                                        title="<?= $role->is_active ? 'غیرفعال‌سازی' : 'فعال‌سازی' ?>">
                                    <i class="material-icons" style="font-size:16px;">
                                        <?= $role->is_active ? 'toggle_on' : 'toggle_off' ?>
                                    </i>
                                </button>
                                
                                <button class="btn btn-sm btn-outline-danger btn-delete-role" 
                                        data-id="<?= $role->id ?>"
                                        data-name="<?= e($role->name) ?>"
                                        data-users="<?= $role->user_count ?>"
                                        title="حذف">
                                    <i class="material-icons" style="font-size:16px;">delete</i>
                                </button>
                                <?php endif; ?>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- راهنما -->
<div class="alert mt-3" style="background:linear-gradient(135deg,#fff3e0 0%,#ffe0b2 100%);border-right:4px solid #ffa726;">
    <div class="d-flex align-items-start">
        <i class="material-icons me-2" style="color:#f57c00;">info</i>
        <div style="font-size:13px;color:#e65100;">
            <strong>راهنما:</strong>
            <ul class="mb-0 mt-1" style="padding-right:20px;">
                <li>نقش‌های <strong>سیستمی</strong> (مدیر کل، مدیر، پشتیبانی، کاربر) قابل حذف نیستند.</li>
                <li>برای تغییر دسترسی‌های هر نقش، روی <strong>ویرایش</strong> کلیک کنید.</li>
                <li>نقش «مدیر کل» به‌صورت پیش‌فرض تمام دسترسی‌ها را دارد.</li>
                <li>نقش‌هایی که <strong>کاربر فعال</strong> دارند، قابل حذف نیستند.</li>
            </ul>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    
    // حذف نقش
    document.querySelectorAll('.btn-delete-role').forEach(function(btn) {
        btn.addEventListener('click', function() {
            const id = this.dataset.id;
            const name = this.dataset.name;
            const users = parseInt(this.dataset.users);
            
            if (users > 0) {
                Swal.fire({
                    title: 'عملیات غیرممکن',
                    text: 'این نقش ' + users + ' کاربر فعال دارد. ابتدا نقش کاربران را تغییر دهید.',
                    icon: 'warning',
                    confirmButtonText: 'متوجه شدم'
                });
                return;
            }
            
            Swal.fire({
                title: 'حذف نقش',
                text: 'آیا از حذف نقش «' + name + '» اطمینان دارید؟',
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#f44336',
                cancelButtonColor: '#999',
                confirmButtonText: 'بله، حذف شود',
                cancelButtonText: 'انصراف'
            }).then(function(result) {
                if (result.isConfirmed) {
                    fetch('<?= url('/admin/roles/') ?>' + id + '/delete', {
                        method: 'POST',
                        headers: {
                            'X-Requested-With': 'XMLHttpRequest',
                            'Content-Type': 'application/json',
                            'X-CSRF-TOKEN': '<?= csrf_token() ?>'
                        },
                        body: JSON.stringify({csrf_token: '<?= csrf_token() ?>'})
                    })
                    .then(function(r) { return r.json(); })
                    .then(function(data) {
                        if (data.success) {
                            var notyf = new Notyf({duration: 3000, position: {x:'left',y:'top'}});
                            notyf.success(data.message);
                            var row = document.getElementById('role-row-' + id);
                            if (row) row.remove();
                        } else {
                            var notyf = new Notyf({duration: 4000, position: {x:'left',y:'top'}});
                            notyf.error(data.message);
                        }
                    })
                    .catch(function() {
                        var notyf = new Notyf({duration: 4000, position: {x:'left',y:'top'}});
                        notyf.error('خطا در ارتباط با سرور');
                    });
                }
            });
        });
    });
    
    // تغییر وضعیت نقش
    document.querySelectorAll('.btn-toggle-role').forEach(function(btn) {
        btn.addEventListener('click', function() {
            const id = this.dataset.id;
            const currentStatus = parseInt(this.dataset.status);
            const action = currentStatus ? 'غیرفعال' : 'فعال';
            const btnEl = this;
            
            fetch('<?= url('/admin/roles/') ?>' + id + '/toggle', {
                method: 'POST',
                headers: {
                    'X-Requested-With': 'XMLHttpRequest',
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': '<?= csrf_token() ?>'
                },
                body: JSON.stringify({csrf_token: '<?= csrf_token() ?>'})
            })
            .then(function(r) { return r.json(); })
            .then(function(data) {
                if (data.success) {
                    var notyf = new Notyf({duration: 3000, position: {x:'left',y:'top'}});
                    notyf.success(data.message);
                    
                    btnEl.dataset.status = data.new_status;
                    var icon = btnEl.querySelector('i');
                    icon.textContent = data.new_status ? 'toggle_on' : 'toggle_off';
                    
                    // بروزرسانی بج وضعیت
                    var row = document.getElementById('role-row-' + id);
                    if (row) {
                        var badge = row.querySelector('td:nth-child(6) span');
                        if (data.new_status) {
                            badge.className = 'badge badge-success';
                            badge.textContent = 'فعال';
                        } else {
                            badge.className = 'badge badge-danger';
                            badge.textContent = 'غیرفعال';
                        }
                    }
                } else {
                    var notyf = new Notyf({duration: 4000, position: {x:'left',y:'top'}});
                    notyf.error(data.message);
                }
            })
            .catch(function() {
                var notyf = new Notyf({duration: 4000, position: {x:'left',y:'top'}});
                notyf.error('خطا در ارتباط با سرور');
            });
        });
    });
});
</script>

<?php
$content = ob_get_clean();
include __DIR__ . '/../../layouts/' . $layout . '.php';
?>