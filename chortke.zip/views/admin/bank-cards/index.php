<?php
$title = 'مدیریت کارت‌های بانکی';
$layout = 'admin';
ob_start();
?>
<?php
$pageTitle = $pageTitle ?? 'کارت‌های بانکی در انتظار';
$cards = $cards ?? [];
$currentPage = $currentPage ?? 1;
$totalPages = $totalPages ?? 1;
$total = $total ?? 0;
?>

<div class="main-content">
    <!-- Header -->
    <div class="content-header">
        <h1>بررسی کارت‌های بانکی</h1>
        <div class="header-stats">
            <div class="stat-badge pending">
                <i class="material-icons">schedule</i>
                <span><?= to_jalali($total, '', true) ?> در انتظار</span>
            </div>
        </div>
    </div>

    <!-- جدول -->
    <div class="table-card">
        <?php if (empty($cards)): ?>
        <div class="empty-state">
            <i class="material-icons">credit_card</i>
            <h3>کارت در انتظار وجود ندارد</h3>
            <p>همه کارت‌های ثبت شده بررسی شده‌اند</p>
        </div>
        <?php else: ?>
        <div class="table-responsive">
            <table class="data-table">
                <thead>
                    <tr>
                        <th>کاربر</th>
                        <th>شماره کارت</th>
                        <th>نام بانک</th>
                        <th>صاحب کارت</th>
                        <th>شماره شبا</th>
                        <th>تاریخ ثبت</th>
                        <th>عملیات</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($cards as $card): ?>
                    <tr>
                        <td>
                            <div class="user-info">
                                <strong><?= e($card->full_name ?? 'نامشخص') ?></strong>
                                <small><?= e($card->email ?? '') ?></small>
                            </div>
                        </td>
                        <td>
                            <code class="card-number">
                                <?= substr($card->card_number, 0, 4) ?>-****-****-<?= substr($card->card_number, -4) ?>
                            </code>
                        </td>
                        <td><?= e($card->bank_name) ?></td>
                        <td><?= e($card->cardholder_name) ?></td>
                        <td>
                            <?php if ($card->sheba): ?>
                            <code class="sheba-number" dir="ltr">IR<?= e($card->sheba) ?></code>
                            <?php else: ?>
                            <span class="text-muted">-</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <span class="date-badge"><?= to_jalali($card->created_at) ?></span>
                        </td>
                        <td>
                            <div class="action-buttons">
                                <a href="<?= url('/admin/bank-cards/review?id=' . $card->id) ?>" 
                                   class="btn-icon" 
                                   title="بررسی جزئیات">
                                    <i class="material-icons">visibility</i>
                                </a>
                                <button class="btn-icon success" 
                                        onclick="verifyCard(<?= $card->id ?>)" 
                                        title="تأیید">
                                    <i class="material-icons">check_circle</i>
                                </button>
                                <button class="btn-icon danger" 
                                        onclick="showRejectModal(<?= $card->id ?>)" 
                                        title="رد">
                                    <i class="material-icons">cancel</i>
                                </button>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>

        <!-- Pagination -->
        <?php if ($totalPages > 1): ?>
        <div class="pagination">
            <?php if ($currentPage > 1): ?>
            <a href="?page=<?= $currentPage - 1 ?>" class="page-link">
                <i class="material-icons">chevron_right</i>
            </a>
            <?php endif; ?>

            <?php for ($i = max(1, $currentPage - 2); $i <= min($totalPages, $currentPage + 2); $i++): ?>
            <a href="?page=<?= $i ?>" class="page-link <?= $i === $currentPage ? 'active' : '' ?>">
                <?= to_jalali($i, '', true) ?>
            </a>
            <?php endfor; ?>

            <?php if ($currentPage < $totalPages): ?>
            <a href="?page=<?= $currentPage + 1 ?>" class="page-link">
                <i class="material-icons">chevron_left</i>
            </a>
            <?php endif; ?>
        </div>
        <?php endif; ?>
        <?php endif; ?>
    </div>
</div>

<!-- مودال رد کارت -->
<div class="modal" id="rejectModal">
    <div class="modal-content">
        <div class="modal-header">
            <h3>رد کارت بانکی</h3>
            <button class="modal-close" onclick="closeRejectModal()">
                <i class="material-icons">close</i>
            </button>
        </div>
        <form id="rejectForm">
            <?= csrf_field() ?>
            <input type="hidden" id="reject_card_id" name="card_id">
            
            <div class="modal-body">
                <div class="form-group">
                    <label for="rejection_reason">دلیل رد: <span class="required">*</span></label>
                    <textarea id="rejection_reason" 
                              name="rejection_reason" 
                              class="form-control" 
                              rows="4"
                              placeholder="لطفاً دلیل رد کارت را به صورت واضح توضیح دهید..."
                              required></textarea>
                    <small class="form-text">این پیام به کاربر نمایش داده می‌شود</small>
                </div>

                <div class="common-reasons">
                    <strong>دلایل متداول:</strong>
                    <button type="button" class="reason-btn" onclick="setReason('نام صاحب کارت با نام کاربر مطابقت ندارد')">
                        عدم تطابق نام
                    </button>
                    <button type="button" class="reason-btn" onclick="setReason('تصویر کارت واضح نیست')">
                        تصویر نامناسب
                    </button>
                    <button type="button" class="reason-btn" onclick="setReason('اطلاعات وارد شده نادرست است')">
                        اطلاعات نادرست
                    </button>
                </div>
            </div>

            <div class="modal-footer">
                <button type="button" class="btn btn-outline" onclick="closeRejectModal()">انصراف</button>
                <button type="submit" class="btn btn-danger">
                    <i class="material-icons">cancel</i>
                    رد کارت
                </button>
            </div>
        </form>
    </div>
</div>

<style>
.header-stats {
    display: flex;
    gap: 15px;
}

.stat-badge {
    display: flex;
    align-items: center;
    gap: 8px;
    padding: 10px 20px;
    border-radius: 20px;
    font-size: 14px;
    font-weight: 500;
}

.stat-badge.pending {
    background: rgba(255, 167, 38, 0.1);
    color: #ffa726;
}

.stat-badge i {
    font-size: 20px;
}

.user-info {
    display: flex;
    flex-direction: column;
    gap: 3px;
}

.user-info strong {
    font-size: 14px;
    color: #333;
}

.user-info small {
    font-size: 12px;
    color: #999;
}

.card-number,
.sheba-number {
    font-family: monospace;
    font-size: 12px;
    background: #f5f5f5;
    padding: 4px 8px;
    border-radius: 4px;
}

.date-badge {
    font-size: 12px;
    color: #666;
    direction: ltr;
    display: inline-block;
}

.action-buttons {
    display: flex;
    gap: 5px;
}

.btn-icon {
    width: 36px;
    height: 36px;
    display: flex;
    align-items: center;
    justify-content: center;
    border: none;
    border-radius: 8px;
    cursor: pointer;
    transition: all 0.3s ease;
    background: #f5f5f5;
    color: #666;
}

.btn-icon:hover {
    transform: scale(1.1);
}

.btn-icon.success {
    background: rgba(76, 175, 80, 0.1);
    color: #4caf50;
}

.btn-icon.success:hover {
    background: #4caf50;
    color: white;
}

.btn-icon.danger {
    background: rgba(244, 67, 54, 0.1);
    color: #f44336;
}

.btn-icon.danger:hover {
    background: #f44336;
    color: white;
}

.common-reasons {
    margin-top: 15px;
    padding: 15px;
    background: #f5f5f5;
    border-radius: 8px;
}

.common-reasons strong {
    display: block;
    margin-bottom: 10px;
    font-size: 13px;
    color: #666;
}

.reason-btn {
    display: inline-block;
    margin: 5px 5px 5px 0;
    padding: 6px 12px;
    background: white;
    border: 1px solid #e0e0e0;
    border-radius: 6px;
    font-size: 12px;
    cursor: pointer;
    transition: all 0.3s ease;
}

.reason-btn:hover {
    border-color: #4fc3f7;
    color: #4fc3f7;
}
</style>

<script>
function verifyCard(cardId) {
    Swal.fire({
        title: 'تأیید کارت بانکی',
        text: 'آیا از تأیید این کارت اطمینان دارید؟',
        icon: 'question',
        showCancelButton: true,
        confirmButtonColor: '#4caf50',
        cancelButtonColor: '#999',
        confirmButtonText: 'بله، تأیید شود',
        cancelButtonText: 'انصراف'
    }).then((result) => {
        if (result.isConfirmed) {
            const formData = new FormData();
            formData.append('card_id', cardId);
            formData.append('<?= csrf_token() ?>', '<?= csrf_token() ?>');

            fetch('<?= url('/admin/bank-cards/verify') ?>', {
                method: 'POST',
                body: formData
            })
            .then(res => res.json())
            .then(data => {
                if (data.success) {
                    notyf.success(data.message);
                    setTimeout(() => location.reload(), 1000);
                } else {
                    notyf.error(data.message);
                }
            })
            .catch(err => {
                notyf.error('خطا در ارتباط با سرور');
            });
        }
    });
}

function showRejectModal(cardId) {
    document.getElementById('reject_card_id').value = cardId;
    document.getElementById('rejection_reason').value = '';
    document.getElementById('rejectModal').classList.add('show');
}

function closeRejectModal() {
    document.getElementById('rejectModal').classList.remove('show');
}

function setReason(reason) {
    document.getElementById('rejection_reason').value = reason;
}

document.getElementById('rejectForm').addEventListener('submit', function(e) {
    e.preventDefault();
    
    const formData = new FormData(this);
    
    fetch('<?= url('/admin/bank-cards/reject') ?>', {
        method: 'POST',
        body: formData
    })
    .then(res => res.json())
    .then(data => {
        if (data.success) {
            closeRejectModal();
            notyf.success(data.message);
            setTimeout(() => location.reload(), 1000);
        } else {
            notyf.error(data.message);
        }
    })
    .catch(err => {
        notyf.error('خطا در ارتباط با سرور');
    });
});
</script>

<?php
$content = ob_get_clean();
include __DIR__ . '/../../layouts/' . $layout . '.php';
?>