<?php
$title = 'بررسی کارت بانکی';
$layout = 'admin';
ob_start();
$card = $card ?? null;
$user = $user ?? null;
?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <h4 class="mb-0">بررسی کارت بانکی #<?= (int)($card->id ?? 0) ?></h4>
    <a href="<?= url('/admin/bank-cards') ?>" class="btn btn-outline-secondary btn-sm">
        <i class="material-icons align-middle">arrow_forward</i> بازگشت
    </a>
</div>

<div class="row g-4">
    <div class="col-md-5">
        <div class="card">
            <div class="card-header"><h6 class="mb-0">اطلاعات صاحب کارت</h6></div>
            <div class="card-body">
                <p><strong>نام:</strong> <?= e($user->full_name ?? '—') ?></p>
                <p><strong>ایمیل:</strong> <?= e($user->email ?? '—') ?></p>
                <p><strong>موبایل:</strong> <?= e($user->mobile ?? '—') ?></p>
                <p><strong>KYC:</strong>
                    <?php $kyc = $user->kyc_status ?? 'none'; ?>
                    <span class="badge bg-<?= $kyc === 'verified' ? 'success' : 'warning' ?>">
                        <?= $kyc === 'verified' ? 'تأیید شده' : 'در انتظار' ?>
                    </span>
                </p>
            </div>
        </div>
    </div>

    <div class="col-md-7">
        <div class="card">
            <div class="card-header"><h6 class="mb-0">اطلاعات کارت</h6></div>
            <div class="card-body">
                <p><strong>شماره کارت:</strong>
                    <span class="font-monospace fs-5"><?= e($card->card_number ?? '—') ?></span>
                </p>
                <p><strong>بانک:</strong> <?= e($card->bank_name ?? '—') ?></p>
                <p><strong>نام صاحب حساب:</strong> <?= e($card->account_holder ?? '—') ?></p>
                <p><strong>شبا:</strong>
                    <span class="font-monospace"><?= !empty($card->sheba) ? 'IR' . e($card->sheba) : '—' ?></span>
                </p>
                <p><strong>تاریخ ثبت:</strong> <?= to_jalali($card->created_at) ?></p>
                <p><strong>وضعیت:</strong>
                    <?php
                    $stMap = ['pending'=>['label'=>'در انتظار','cls'=>'warning'],'verified'=>['label'=>'تأیید شده','cls'=>'success'],'rejected'=>['label'=>'رد شده','cls'=>'danger']];
                    $si = $stMap[$card->status ?? ''] ?? ['label'=>e($card->status),'cls'=>'secondary'];
                    ?>
                    <span class="badge bg-<?= $si['cls'] ?>"><?= $si['label'] ?></span>
                </p>
            </div>
        </div>

        <?php if (($card->status ?? '') === 'pending'): ?>
        <div class="card mt-3">
            <div class="card-header"><h6 class="mb-0">عملیات</h6></div>
            <div class="card-body">
                <div class="d-flex gap-2 mb-2">
                    <button class="btn btn-success" onclick="doVerify()">
                        <i class="material-icons align-middle">check_circle</i> تأیید کارت
                    </button>
                    <button class="btn btn-danger" onclick="showReject()">
                        <i class="material-icons align-middle">cancel</i> رد کارت
                    </button>
                </div>
                <div id="rejectBox" style="display:none;" class="mt-2">
                    <textarea id="rejectReason" class="form-control" rows="2" placeholder="دلیل رد..."></textarea>
                    <button class="btn btn-danger btn-sm mt-2" onclick="doReject()">تأیید رد</button>
                </div>
            </div>
        </div>
        <?php endif; ?>
    </div>
</div>

<script>
const cardId = <?= (int)($card->id ?? 0) ?>;
const csrf = '<?= csrf_token() ?>';
const base = '<?= url('/admin/bank-cards') ?>';

function doVerify() {
    if (!confirm('آیا از تأیید این کارت مطمئنید؟')) return;
    fetch(`${base}/${cardId}/verify`, {
        method:'POST', headers:{'Content-Type':'application/json','X-CSRF-TOKEN':csrf}
    }).then(r=>r.json()).then(res => {
        if (res.success) location.href = base; else alert(res.message||'خطا');
    });
}

function showReject() { document.getElementById('rejectBox').style.display='block'; }

function doReject() {
    const reason = document.getElementById('rejectReason').value;
    fetch(`${base}/${cardId}/reject`, {
        method:'POST', headers:{'Content-Type':'application/json','X-CSRF-TOKEN':csrf},
        body: JSON.stringify({reason})
    }).then(r=>r.json()).then(res => {
        if (res.success) location.href = base; else alert(res.message||'خطا');
    });
}
</script>

<?php $content = ob_get_clean(); include __DIR__ . '/../../layouts/admin.php'; ?>
