<?php
use Core\Session;
$session = Session::getInstance();
$errors = $session->getFlash('errors') ?? [];
$old = $session->getFlash('old') ?? [];
?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ورود مدیریت | چرتکه</title>
    
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.rtl.min.css">
    
    <style>
        :root {
            --primary: #4fc3f7;
            --primary-dark: #29b6f6;
        }
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }
        
        .admin-login-container {
            width: 100%;
            max-width: 420px;
        }
        
        .admin-login-card {
            background: white;
            border-radius: 15px;
            box-shadow: 0 15px 50px rgba(0,0,0,0.2);
            overflow: hidden;
        }
        
        .admin-login-header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            padding: 40px 30px;
            text-align: center;
        }
        
        .admin-icon {
            width: 80px;
            height: 80px;
            background: white;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 15px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.2);
        }
        
        .admin-icon .material-icons {
            font-size: 48px;
            color: #667eea;
        }
        
        .admin-login-header h3 {
            color: white;
            font-size: 24px;
            font-weight: 700;
            margin: 0 0 5px 0;
        }
        
        .admin-login-header p {
            color: rgba(255,255,255,0.9);
            font-size: 14px;
            margin: 0;
        }
        
        .admin-login-body {
            padding: 35px 30px;
        }
        
        .form-group {
            margin-bottom: 20px;
        }
        
        .form-label {
            font-size: 13px;
            font-weight: 600;
            color: #555;
            margin-bottom: 8px;
            display: flex;
            align-items: center;
            gap: 5px;
        }
        
        .form-label .material-icons {
            font-size: 18px;
            color: #667eea;
        }
        
        .input-group {
            position: relative;
        }
        
        .input-group .material-icons {
            position: absolute;
            right: 15px;
            top: 50%;
            transform: translateY(-50%);
            color: #999;
            font-size: 20px;
        }
        
        .form-control {
            border: 2px solid #e0e0e0;
            border-radius: 10px;
            padding: 12px 15px 12px 45px;
            font-size: 14px;
            transition: all 0.3s;
        }
        
        .form-control:focus {
            border-color: #667eea;
            box-shadow: 0 0 0 4px rgba(102, 126, 234, 0.1);
            outline: none;
        }
        
        .form-control.is-invalid {
            border-color: #f44336;
        }
        
        .invalid-feedback {
            font-size: 12px;
            color: #f44336;
            margin-top: 5px;
        }
        
        .btn-admin-login {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            border: none;
            border-radius: 10px;
            padding: 14px;
            font-size: 15px;
            font-weight: 600;
            color: white;
            width: 100%;
            transition: all 0.3s;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            cursor: pointer;
        }
        
        .btn-admin-login:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 25px rgba(102, 126, 234, 0.4);
        }
        
        .btn-admin-login .material-icons {
            font-size: 20px;
        }
        
        .admin-login-footer {
            padding: 20px 30px;
            background: #f8f9fa;
            text-align: center;
            border-top: 1px solid #e0e0e0;
        }
        
        .admin-login-footer a {
            color: #667eea;
            text-decoration: none;
            font-weight: 500;
            font-size: 13px;
            transition: all 0.3s;
        }
        
        .admin-login-footer a:hover {
            color: #764ba2;
            text-decoration: underline;
        }
        
        .security-badge {
            background: rgba(102, 126, 234, 0.1);
            border: 1px solid rgba(102, 126, 234, 0.3);
            border-radius: 8px;
            padding: 12px;
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .security-badge .material-icons {
            color: #667eea;
            font-size: 24px;
        }
        
        .security-badge span {
            color: #555;
            font-size: 12px;
        }
        
        /* Alert Styles */
        .alert {
            border: none;
            border-radius: 10px;
            border-right: 4px solid;
            padding: 12px 20px;
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            gap: 10px;
            font-size: 14px;
            animation: slideIn 0.3s ease;
        }
        
        @keyframes slideIn {
            from {
                opacity: 0;
                transform: translateY(-10px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
        
        .alert .material-icons {
            font-size: 22px;
        }
        
        .alert-success {
            background: linear-gradient(135deg, #e8f5e9 0%, #c8e6c9 100%);
            color: #2e7d32;
            border-right-color: #4caf50;
        }
        
        .alert-success .material-icons {
            color: #4caf50;
        }
        
        .alert-danger {
            background: linear-gradient(135deg, #ffebee 0%, #ffcdd2 100%);
            color: #c62828;
            border-right-color: #f44336;
        }
        
        .alert-danger .material-icons {
            color: #f44336;
        }
        
        .btn-close {
            background: transparent;
            border: none;
            font-size: 20px;
            cursor: pointer;
            opacity: 0.5;
            padding: 0;
            margin-right: auto;
        }
        
        .btn-close:hover {
            opacity: 1;
        }
    </style>
</head>
<body>
    
    <div class="admin-login-container">
        <div class="admin-login-card">
            <div class="admin-login-header">
                <div class="admin-icon">
                    <span class="material-icons">admin_panel_settings</span>
                </div>
                <h3>پنل مدیریت</h3>
                <p>ورود به سیستم مدیریت چرتکه</p>
            </div>
            
            <div class="admin-login-body">
                <?php if ($session->hasFlash('success')): ?>
                    <div class="alert alert-success alert-dismissible fade show">
                        <span class="material-icons">check_circle</span>
                        <?= e($session->getFlash('success')) ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert">×</button>
                    </div>
                <?php endif; ?>
                
                <?php if ($session->hasFlash('error')): ?>
                    <div class="alert alert-danger alert-dismissible fade show">
                        <span class="material-icons">error</span>
                        <?= e($session->getFlash('error')) ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert">×</button>
                    </div>
                <?php endif; ?>
                
                <div class="security-badge">
                    <span class="material-icons">shield</span>
                    <span>این صفحه فقط برای مدیران و پشتیبانان سیستم است</span>
                </div>
                
                <form method="POST" action="<?= url('/admin/login') ?>">
                    <?= csrf_field() ?>
                    
                    <div class="form-group">
                        <label class="form-label">
                            <span class="material-icons">email</span>
                            ایمیل
                        </label>
                        <div class="input-group">
                            <span class="material-icons">person</span>
                            <input type="email" name="email" class="form-control <?= isset($errors['email']) ? 'is-invalid' : '' ?>" 
                                value="<?= e($old['email'] ?? '') ?>" placeholder="admin@chortke.com" required autofocus>
                        </div>
                        <?php if (isset($errors['email'])): ?>
                            <div class="invalid-feedback" style="display: block;">
                                <?= e($errors['email'][0]) ?>
                            </div>
                        <?php endif; ?>
                    </div>
                    
                    <div class="form-group">
                        <label class="form-label">
                            <span class="material-icons">lock</span>
                            رمز عبور
                        </label>
                        <div class="input-group">
                            <span class="material-icons">key</span>
                            <input type="password" name="password" class="form-control <?= isset($errors['password']) ? 'is-invalid' : '' ?>" 
                                placeholder="••••••••" required>
                        </div>
                        <?php if (isset($errors['password'])): ?>
                            <div class="invalid-feedback" style="display: block;">
                                <?= e($errors['password'][0]) ?>
                            </div>
                        <?php endif; ?>
                    </div>
                    
                    <div class="form-check mb-3" style="padding-right: 0;">
                        <input class="form-check-input" type="checkbox" name="remember" id="remember">
                        <label class="form-check-label" for="remember" style="font-size: 13px; color: #666;">
                            مرا به خاطر بسپار
                        </label>
                    </div>
                    
                    <button type="submit" class="btn-admin-login">
                        <span class="material-icons">login</span>
                        <span>ورود به پنل مدیریت</span>
                    </button>
                </form>
            </div>
            
            <div class="admin-login-footer">
                <a href="<?= url('/') ?>">
                    <span class="material-icons" style="vertical-align: middle; font-size: 16px;">arrow_back</span>
                    بازگشت به صفحه اصلی
                </a>
            </div>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Auto-hide alerts
        setTimeout(function() {
            const alerts = document.querySelectorAll('.alert');
            alerts.forEach(function(alert) {
                alert.style.opacity = '0';
                setTimeout(function() {
                    alert.remove();
                }, 300);
            });
        }, 5000);
    </script>
</body>
</html>