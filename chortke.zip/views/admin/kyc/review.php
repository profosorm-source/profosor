<?php
$title = 'بررسی احراز هویت';
$layout = 'admin';
ob_start();

$session = \Core\Session::getInstance();
?>

<div class="row">
    <div class="col-md-4">
        <div class="card mb-4">
            <div class="card-header">
                <h6 class="mb-0">اطلاعات کاربر</h6>
            </div>
            <div class="card-body">
                <div class="mb-2"><small class="text-muted">نام کامل:</small><div><?= e($user->full_name) ?></div></div>
                <div class="mb-2"><small class="text-muted">ایمیل:</small><div><?= e($user->email) ?></div></div>
                <div class="mb-2"><small class="text-muted">کد ملی:</small>
                    <div><?= e(to_jalali($kyc->national_code ?? '-', '', true)) ?></div>
                </div>
                <div class="mb-2"><small class="text-muted">تاریخ ثبت:</small>
                    <div><?= $kyc->submitted_at ? e(to_jalali(\date('Y/m/d H:i', \strtotime($kyc->submitted_at)))) : '-' ?></div>
                </div>
                <div class="mb-2"><small class="text-muted">IP:</small><div><code><?= e($kyc->ip_address ?? '-') ?></code></div></div>

                <?php if (!empty($photoshopCheck['suspicious'])): ?>
                    <hr>
                    <div class="alert alert-danger mb-0">
                        <strong>هشدار:</strong> تصویر مشکوک به ویرایش است.
                        <ul class="mb-0 mt-2 small">
                            <?php foreach (($photoshopCheck['reasons'] ?? []) as $r): ?>
                                <li><?= e($r) ?></li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                <?php endif; ?>
            </div>
        </div>

        <div class="card">
            <div class="card-header"><h6 class="mb-0">وضعیت</h6></div>
            <div class="card-body">
                <?php
                $statusLabels = [
                    'pending' => ['label' => 'در انتظار بررسی', 'color' => 'warning'],
                    'under_review' => ['label' => 'در حال بررسی', 'color' => 'info'],
                    'verified' => ['label' => 'تأیید شده', 'color' => 'success'],
                    'rejected' => ['label' => 'رد شده', 'color' => 'danger'],
                    'expired' => ['label' => 'منقضی شده', 'color' => 'secondary'],
                ];
                $st = $statusLabels[$kyc->status] ?? ['label' => $kyc->status, 'color' => 'secondary'];
                ?>
                <div class="alert alert-<?= $st['color'] ?> mb-0">
                    <strong><?= e($st['label']) ?></strong>
                </div>

                <?php if ($kyc->status === 'rejected' && !empty($kyc->rejection_reason)): ?>
                    <div class="alert alert-danger mt-3 mb-0">
                        <small><strong>دلیل رد:</strong><br><?= \nl2br(e($kyc->rejection_reason)) ?></small>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- تصویر + عملیات -->
    <div class="col-md-8">
        <div class="card mb-4">
            <div class="card-header d-flex justify-content-between align-items-center">
                <h5 class="mb-0">تصویر احراز هویت (یک عکس)</h5>
                <a href="<?= url('/admin/kyc') ?>" class="btn btn-sm btn-outline-secondary">بازگشت</a>
            </div>

            <div class="card-body">
                <?php if (($kyc->verification_image ?? '') === '[DELETED]' || empty($kyc->verification_image)): ?>
                    <div class="alert alert-secondary">تصویر موجود نیست یا حذف شده است.</div>
                <?php else: ?>
                    <div class="text-center">
                        <img
                            src="<?= url('/file/view/kyc/' . $kyc->verification_image) ?>"
                            class="img-fluid border rounded"
                            style="max-height: 600px; cursor: zoom-in;"
                            onclick="openImageModal(this.src)"
                            alt="تصویر احراز هویت"
                        >
                    </div>

                    <div class="mt-3 d-flex justify-content-center gap-2">
                        <a class="btn btn-sm btn-outline-primary" target="_blank"
                           href="<?= url('/file/view/kyc/' . $kyc->verification_image) ?>">
                            <i class="material-icons" style="font-size:16px;">open_in_new</i>
                            مشاهده در تب جدید
                        </a>
                    </div>
                <?php endif; ?>

                <hr>

                <?php if (\in_array($kyc->status, ['pending','under_review'], true)): ?>
                   
				   <!-- ✅ VERIFY = Form-based -->
                   <?php if (\in_array($kyc->status, ['pending','under_review'], true)): ?>
<?php endif; ?>
<form id="verifyForm" method="POST" action="<?= url('/admin/kyc/verify/' . $kyc->id) ?>" class="d-inline">
  <?= csrf_field() ?>
  <button type="submit" class="btn btn-success">
    <i class="material-icons" style="font-size:18px; vertical-align:middle;">check_circle</i>
    تأیید احراز هویت
  </button>
</form>

<button type="button" class="btn btn-danger" data-bs-toggle="modal" data-bs-target="#rejectModal">
    <i class="material-icons" style="font-size:18px; vertical-align:middle;">cancel</i>
    رد احراز هویت
</button>

<?php endif; ?>

            </div>
        </div>
    </div>
</div>

<!-- Modal Reject -->
<div class="modal fade" id="rejectModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">رد احراز هویت</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>

            <form id="rejectForm">
                <?= csrf_field() ?>
                <div class="modal-body">
                    <label class="form-label">دلیل رد <span class="text-danger">*</span></label>
                    <textarea name="reason" class="form-control" rows="4" required minlength="10"
                              placeholder="دلیل رد را واضح بنویسید..."></textarea>
                    <div class="invalid-feedback"></div>

                    <div class="alert alert-warning mt-3 mb-0">
                        <small>این دلیل برای کاربر نمایش داده می‌شود.</small>
                    </div>
                </div>

                <div class="modal-footer">
                    <button class="btn btn-secondary" type="button" data-bs-dismiss="modal">انصراف</button>
                    <button class="btn btn-danger" type="submit">رد شود</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Image Modal -->
<div class="modal fade" id="imageModal" tabindex="-1">
    <div class="modal-dialog modal-xl">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">نمایش تصویر</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body text-center">
                <img id="modalImage" src="" class="img-fluid">
            </div>
        </div>
    </div>
</div>

<script>
function openImageModal(src) {
    document.getElementById('modalImage').src = src;
    new bootstrap.Modal(document.getElementById('imageModal')).show();
}

// SweetAlert برای VERIFY (Form-based)
document.addEventListener('DOMContentLoaded', () => {
  const form = document.getElementById('verifyForm');
  if (!form) return;

  form.addEventListener('submit', async (e) => {
    e.preventDefault();

    if (typeof swalConfirm !== 'function') {
      // fallback اگر swal-init لود نشد
      if (confirm('آیا مطمئنید؟')) form.submit();
      return;
    }

    const res = await swalConfirm({
      title: 'تأیید احراز هویت',
      text: 'پس از تأیید، کاربر امکان برداشت خواهد داشت.',
      confirmButtonText: 'بله، تأیید شود',
      cancelButtonText: 'انصراف'
    });

    if (res.isConfirmed) form.submit();
  });
});
// Reject (Ajax JSON)
document.addEventListener('DOMContentLoaded', () => {
  const form = document.getElementById('rejectForm');
  if (!form) return;

  form.addEventListener('submit', async (e) => {
    e.preventDefault();

    const fd = new FormData(form);
    const token  = (fd.get('_token') || '').toString();
    const reason = (fd.get('reason') || '').toString().trim();

    try {
      const res = await fetch('<?= url('/admin/kyc/reject/' . $kyc->id) ?>', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'X-CSRF-TOKEN': token
        },
        body: JSON.stringify({ reason, _token: token })
      });

      const data = await res.json();

      if (data.success) {
        // پیام زیبا (اولویت: swalSuccess)
        try {
          if (typeof swalSuccess === 'function') {
            await swalSuccess({ title: 'رد شد', text: data.message || 'درخواست رد شد' });
          } else if (window.notyf) {
            notyf.success(data.message || 'درخواست رد شد');
          }
        } catch (x) {}

        // بستن مودال (اگر bootstrap موجود بود)
        try {
          const modalEl = document.getElementById('rejectModal');
          if (modalEl && typeof bootstrap !== 'undefined') {
            const modal = bootstrap.Modal.getInstance(modalEl) || new bootstrap.Modal(modalEl);
            modal.hide();
          }
        } catch (x) {}

        // ✅ ریدایرکت قطعی
        const target = data.redirect || '<?= url('/admin/kyc') ?>';
        window.location.replace(target);
        return;
      }

      // خطا
      const msg = (data.errors && data.errors.reason) ? data.errors.reason[0] : (data.message || 'خطا');
      if (window.notyf) notyf.error(msg); else alert(msg);

    } catch (err) {
      if (window.notyf) notyf.error('خطا در ارتباط با سرور'); else alert('خطا در ارتباط با سرور');
      console.log(err);
    }
  });
});
</script>

<?php
$content = ob_get_clean();
include __DIR__ . '/../../layouts/' . $layout . '.php';
?>