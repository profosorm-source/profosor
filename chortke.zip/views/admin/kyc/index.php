<?php
$title = 'مدیریت احراز هویت';
$layout = 'admin';
ob_start();
?>

<!-- آمار -->
<div class="row g-3 mb-4">
    <div class="col-md-3">
        <div class="card border-start border-warning border-3">
            <div class="card-body">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <h6 class="text-muted mb-1">در انتظار</h6>
                        <h3 class="mb-0"><?= number_format($stats['pending'] ?? 0) ?></h3>
                    </div>
                    <i class="material-icons text-warning" style="font-size: 40px;">schedule</i>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card border-start border-info border-3">
            <div class="card-body">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <h6 class="text-muted mb-1">در حال بررسی</h6>
                        <h3 class="mb-0"><?= number_format($stats['under_review'] ?? 0) ?></h3>
                    </div>
                    <i class="material-icons text-info" style="font-size: 40px;">pending</i>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card border-start border-success border-3">
            <div class="card-body">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <h6 class="text-muted mb-1">تأیید شده</h6>
                        <h3 class="mb-0"><?= number_format($stats['verified'] ?? 0) ?></h3>
                    </div>
                    <i class="material-icons text-success" style="font-size: 40px;">check_circle</i>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card border-start border-danger border-3">
            <div class="card-body">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <h6 class="text-muted mb-1">رد شده</h6>
                        <h3 class="mb-0"><?= number_format($stats['rejected'] ?? 0) ?></h3>
                    </div>
                    <i class="material-icons text-danger" style="font-size: 40px;">cancel</i>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="card">
    <div class="card-header d-flex justify-content-between align-items-center">
        <h5 class="mb-0">درخواست‌های احراز هویت (<?= number_format($total ?? 0) ?>)</h5>
    </div>

    <!-- فیلترها -->
    <div class="card-body border-bottom">
        <form method="get" action="<?= url('/admin/kyc') ?>" class="row g-3">
            <div class="col-md-5">
                <input type="text" name="search" class="form-control form-control-sm" 
                       placeholder="جستجو (نام، ایمیل، کد ملی)" value="<?= e($search ?? '') ?>">
            </div>
            <div class="col-md-4">
                <select name="status" class="form-select form-select-sm">
                    <option value="">همه وضعیت‌ها</option>
                    <option value="pending" <?= ($statusFilter ?? '') === 'pending' ? 'selected' : '' ?>>در انتظار</option>
                    <option value="under_review" <?= ($statusFilter ?? '') === 'under_review' ? 'selected' : '' ?>>در حال بررسی</option>
                    <option value="verified" <?= ($statusFilter ?? '') === 'verified' ? 'selected' : '' ?>>تأیید شده</option>
                    <option value="rejected" <?= ($statusFilter ?? '') === 'rejected' ? 'selected' : '' ?>>رد شده</option>
                    <option value="expired" <?= ($statusFilter ?? '') === 'expired' ? 'selected' : '' ?>>منقضی شده</option>
                </select>
            </div>
            <div class="col-md-3">
                <button type="submit" class="btn btn-secondary btn-sm w-100">فیلتر</button>
            </div>
        </form>
    </div>

    <!-- جدول -->
    <div class="table-responsive">
        <table class="table table-hover mb-0">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>کاربر</th>
                    <th>کد ملی</th>
                    <th>وضعیت</th>
                    <th>تاریخ ثبت</th>
                    <th>عملیات</th>
                </tr>
            </thead>
           <tbody>

<?php if (empty($kycs)): ?>
    <tr>
        <td colspan="6" class="text-center py-4 text-muted">درخواستی یافت نشد</td>
    </tr>
<?php else: ?>

    <?php $lastGroup = null; ?>

    <?php foreach ($kycs as $kyc): ?>

        <?php
        $group = in_array($kyc->status, ['pending','under_review'], true) 
            ? 'queue' 
            : 'archive';

        if ($group !== $lastGroup):
            $lastGroup = $group;
        ?>
            <tr class="table-light">
                <td colspan="6" class="fw-bold text-center">
                    <?= $group === 'queue' 
                        ? 'صف بررسی (قدیمی‌ترین‌ها اول)' 
                        : 'آرشیو (بررسی‌شده‌ها)' ?>
                </td>
            </tr>
        <?php endif; ?>

        <tr>
            <td><?= $kyc->id ?></td>
            <td>
                <div><?= e($kyc->full_name) ?></div>
                <small class="text-muted"><?= e($kyc->email) ?></small>
            </td>
            <td><?= e(fa_number($kyc->national_code ?? '-')) ?></td>
            <td>
                <?php
                $badges = [
                    'pending' => '<span class="badge bg-warning">در انتظار</span>',
                    'under_review' => '<span class="badge bg-info">در حال بررسی</span>',
                    'verified' => '<span class="badge bg-success">تأیید شده</span>',
                    'rejected' => '<span class="badge bg-danger">رد شده</span>',
                    'expired' => '<span class="badge bg-secondary">منقضی شده</span>'
                ];
                echo $badges[$kyc->status] ?? $kyc->status;
                ?>
            </td>
            <td><?= e(jdate($kyc->submitted_at ?? $kyc->created_at)) ?></td>
            <td>
                <a href="<?= url('/admin/kyc/review/' . $kyc->id) ?>" 
                   class="btn btn-sm btn-outline-primary">
                    <i class="material-icons" style="font-size: 16px;">visibility</i>
                    بررسی
                </a>
            </td>
        </tr>

    <?php endforeach; ?>

<?php endif; ?>

</tbody>

        </table>
    </div>

    <!-- Pagination -->
    <?php if (($totalPages ?? 0) > 1): ?>
        <div class="card-footer">
            <nav>
                <ul class="pagination pagination-sm mb-0 justify-content-center">
                    <?php for ($i = 1; $i <= $totalPages; $i++): ?>
                        <li class="page-item <?= $i === ($currentPage ?? 1) ? 'active' : '' ?>">
                            <a class="page-link" href="<?= url('/admin/kyc?page=' . $i . 
                                (!empty($search) ? '&search=' . urlencode($search) : '') .
                                (!empty($statusFilter) ? '&status=' . $statusFilter : '')) ?>">
                                <?= $i ?>
                            </a>
                        </li>
                    <?php endfor; ?>
                </ul>
            </nav>
        </div>
    <?php endif; ?>
</div>

<?php
$content = ob_get_clean();
include __DIR__ . '/../../layouts/' . $layout . '.php';
?>