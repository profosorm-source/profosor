<?php
$title = 'تنظیمات سیستم';
$layout = 'admin';
ob_start();
?>

<div class="container-fluid">
    <h4 class="mb-4">تنظیمات سیستم</h4>

    <!-- دسته‌بندی‌ها -->
    <ul class="nav nav-tabs mb-4">
        <?php foreach ($categories as $key => $label): ?>
        <li class="nav-item">
            <a class="nav-link <?= $currentCategory === $key ? 'active' : '' ?>" 
               href="<?= url('/admin/settings?category=' . $key) ?>">
                <?= $label ?>
            </a>
        </li>
        <?php endforeach; ?>
    </ul>

    <div class="card">
        <div class="card-body">
            <?php foreach ($settings as $setting): ?>
            <div class="form-group row">
                <label class="col-md-4 col-form-label">
                    <strong><?= e($setting->key) ?></strong>
                    <?php if ($setting->description): ?>
                        <br><small class="text-muted"><?= e($setting->description) ?></small>
                    <?php endif; ?>
                </label>
                <div class="col-md-6">
                    <?php if ($setting->type === 'boolean'): ?>
                        <select class="form-control" id="setting_<?= $setting->id ?>" data-key="<?= e($setting->key) ?>">
                            <option value="1" <?= $setting->value == '1' ? 'selected' : '' ?>>فعال</option>
                            <option value="0" <?= $setting->value == '0' ? 'selected' : '' ?>>غیرفعال</option>
                        </select>
                    <?php elseif ($setting->type === 'text'): ?>
                        <textarea class="form-control" rows="3" id="setting_<?= $setting->id ?>" data-key="<?= e($setting->key) ?>"><?= e($setting->value) ?></textarea>
                    <?php else: ?>
                        <input type="text" class="form-control" id="setting_<?= $setting->id ?>" 
                               data-key="<?= e($setting->key) ?>" value="<?= e($setting->value) ?>">
                    <?php endif; ?>
                </div>
                <div class="col-md-2">
                    <button type="button" class="btn btn-primary" onclick="updateSetting(<?= (int)$setting->id ?>)">
    <i class="material-icons">save</i>
    ذخیره
</button>
                </div>
            </div>
            <hr>
            <?php endforeach; ?>
        </div>
    </div>
</div>

<script>
function updateSetting(id) {
    const element = document.getElementById('setting_' + id);
    const key = element.dataset.key;
    const value = element.value;

    // مسیر درست با id
    const endpoint = "<?= url('/admin/settings') ?>/" + encodeURIComponent(id) + "/update";

    fetch(endpoint, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'X-CSRF-TOKEN': '<?= csrf_token() ?>'
        },
        credentials: 'same-origin',
        body: JSON.stringify({ id: id, key: key, value: value })
    })
    .then(r => r.json())
    .then(res => {
        if (!window.notyf) {
            window.notyf = new Notyf({
                duration: 5000,
                position: { x: 'left', y: 'top' },
                dismissible: true
            });
        }

        if (res.success) {
            window.notyf.success(res.message || 'تنظیمات با موفقیت ذخیره شد');
        } else {
            window.notyf.error(res.message || 'خطا در ذخیره تنظیمات');
        }
    })
    .catch(() => {
        if (!window.notyf) {
            window.notyf = new Notyf({
                duration: 5000,
                position: { x: 'left', y: 'top' },
                dismissible: true
            });
        }
        window.notyf.error('خطا در ارتباط با سرور');
    });
}

</script>

<?php $content = ob_get_clean();
include __DIR__ . '/../../layouts/' . $layout . '.php'; ?>