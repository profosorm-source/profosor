<?php
$pageTitle = $pageTitle ?? 'تراکنش‌های مالی';
$transactions = $transactions ?? [];
$currentPage = $currentPage ?? 1;
$totalPages = $totalPages ?? 1;
$total = $total ?? 0;
$status = $status ?? '';
$type = $type ?? '';
$currency = $currency ?? '';
$layout = 'admin';
ob_start();
?>

<div class="main-content">
    <!-- Header -->
    <div class="content-header">
        <h1>مدیریت تراکنش‌های مالی</h1>
        <div class="header-stats">
            <div class="stat-badge info">
                <i class="material-icons">receipt_long</i>
                <span><?= to_jalali($total, '', true) ?> تراکنش</span>
            </div>
        </div>
    </div>

    <!-- فیلترها -->
    <div class="filters-card">
        <form method="GET" class="filters-form">
            <div class="filter-group">
                <label>نوع تراکنش:</label>
                <select name="type" class="form-control">
                    <option value="">همه</option>
                    <option value="deposit" <?= $type === 'deposit' ? 'selected' : '' ?>>واریز</option>
                    <option value="withdraw" <?= $type === 'withdraw' ? 'selected' : '' ?>>برداشت</option>
                    <option value="transfer" <?= $type === 'transfer' ? 'selected' : '' ?>>انتقال</option>
                    <option value="commission" <?= $type === 'commission' ? 'selected' : '' ?>>کمیسیون</option>
                    <option value="task_reward" <?= $type === 'task_reward' ? 'selected' : '' ?>>پاداش تسک</option>
                    <option value="penalty" <?= $type === 'penalty' ? 'selected' : '' ?>>جریمه</option>
                </select>
            </div>

            <div class="filter-group">
                <label>وضعیت:</label>
                <select name="status" class="form-control">
                    <option value="">همه</option>
                    <option value="pending" <?= $status === 'pending' ? 'selected' : '' ?>>در انتظار</option>
                    <option value="processing" <?= $status === 'processing' ? 'selected' : '' ?>>در حال پردازش</option>
                    <option value="completed" <?= $status === 'completed' ? 'selected' : '' ?>>تکمیل شده</option>
                    <option value="failed" <?= $status === 'failed' ? 'selected' : '' ?>>ناموفق</option>
                    <option value="cancelled" <?= $status === 'cancelled' ? 'selected' : '' ?>>لغو شده</option>
                </select>
            </div>

            <div class="filter-group">
                <label>ارز:</label>
                <select name="currency" class="form-control">
                    <option value="">همه</option>
                    <option value="irt" <?= $currency === 'irt' ? 'selected' : '' ?>>تومان</option>
                    <option value="usdt" <?= $currency === 'usdt' ? 'selected' : '' ?>>USDT</option>
                </select>
            </div>

            <button type="submit" class="btn btn-primary">
                <i class="material-icons">search</i>
                فیلتر
            </button>

            <?php if ($status || $type || $currency): ?>
            <a href="<?= url('/admin/transactions') ?>" class="btn btn-outline">
                <i class="material-icons">clear</i>
                حذف فیلتر
            </a>
            <?php endif; ?>
        </form>
    </div>

    <!-- جدول -->
    <div class="table-card">
        <?php if (empty($transactions)): ?>
        <div class="empty-state">
            <i class="material-icons">receipt_long</i>
            <h3>تراکنشی یافت نشد</h3>
            <p>هیچ تراکنش مالی ثبت نشده است</p>
        </div>
        <?php else: ?>
        <div class="table-responsive">
            <table class="data-table">
                <thead>
                    <tr>
                        <th>شناسه تراکنش</th>
                        <th>کاربر</th>
                        <th>نوع</th>
                        <th>مبلغ</th>
                        <th>ارز</th>
                        <th>موجودی قبل</th>
                        <th>موجودی بعد</th>
                        <th>وضعیت</th>
                        <th>درگاه</th>
                        <th>تاریخ</th>
                        <th>جزئیات</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($transactions as $tx): ?>
                    <tr>
                        <td>
                            <code class="tx-id" title="<?= e($tx->transaction_id) ?>">
                                <?= substr($tx->transaction_id, 0, 8) ?>...
                            </code>
                        </td>
                        <td>
                            <div class="user-info">
                                <strong><?= e($tx->full_name ?? 'نامشخص') ?></strong>
                                <small><?= e($tx->email ?? '') ?></small>
                            </div>
                        </td>
                        <td>
                            <?php
                            $typeLabels = [
                                'deposit' => 'واریز',
                                'withdraw' => 'برداشت',
                                'transfer' => 'انتقال',
                                'commission' => 'کمیسیون',
                                'investment' => 'سرمایه‌گذاری',
                                'task_reward' => 'پاداش تسک',
                                'penalty' => 'جریمه',
                                'refund' => 'بازگشت وجه',
                            ];
                            ?>
                            <span class="type-badge <?= e($tx->type) ?>">
                                <?= $typeLabels[$tx->type] ?? $tx->type ?>
                            </span>
                        </td>
                        <td>
                            <span class="amount-value <?= in_array($tx->type, ['withdraw', 'penalty']) ? 'negative' : 'positive' ?>">
                                <?php if (in_array($tx->type, ['withdraw', 'penalty'])): ?>-<?php else: ?>+<?php endif; ?>
                                <?= $tx->currency === 'usdt' 
                                    ? number_format($tx->amount, 4)
                                    : number_format($tx->amount) 
                                ?>
                            </span>
                        </td>
                        <td>
                            <span class="currency-badge <?= e($tx->currency) ?>">
                                <?= $tx->currency === 'usdt' ? 'USDT' : 'تومان' ?>
                            </span>
                        </td>
                        <td>
                            <span class="balance-value">
                                <?= $tx->currency === 'usdt' 
                                    ? number_format($tx->balance_before, 4)
                                    : number_format($tx->balance_before) 
                                ?>
                            </span>
                        </td>
                        <td>
                            <span class="balance-value">
                                <?= $tx->currency === 'usdt' 
                                    ? number_format($tx->balance_after, 4)
                                    : number_format($tx->balance_after) 
                                ?>
                            </span>
                        </td>
                        <td>
                            <?php
                            $statusLabels = [
                                'pending' => 'در انتظار',
                                'processing' => 'در حال پردازش',
                                'completed' => 'تکمیل شده',
                                'failed' => 'ناموفق',
                                'cancelled' => 'لغو شده',
                                'refunded' => 'بازگشت داده شده',
                            ];
                            ?>
                            <span class="status-badge <?= $tx->status ?>">
                                <?= $statusLabels[$tx->status] ?? $tx->status ?>
                            </span>
                        </td>
                        <td>
                            <?php if ($tx->gateway): ?>
                            <span class="gateway-badge"><?= e($tx->gateway) ?></span>
                            <?php else: ?>
                            <span class="text-muted">-</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <span class="date-badge"><?= to_jalali($tx->created_at) ?></span>
                        </td>
                        <td>
                            <a href="<?= url('/admin/transactions/show?id=' . $tx->id) ?>" 
                               class="btn-icon" 
                               title="جزئیات کامل">
                                <i class="material-icons">info</i>
                            </a>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>

        <!-- Pagination -->
        <?php if ($totalPages > 1): ?>
        <div class="pagination">
            <?php 
            $queryParams = [];
            if ($status) $queryParams[] = 'status=' . $status;
            if ($type) $queryParams[] = 'type=' . $type;
            if ($currency) $queryParams[] = 'currency=' . $currency;
            $queryString = !empty($queryParams) ? '&' . implode('&', $queryParams) : '';
            ?>
            
            <?php if ($currentPage > 1): ?>
            <a href="?page=<?= $currentPage - 1 ?><?= $queryString ?>" class="page-link">
                <i class="material-icons">chevron_right</i>
            </a>
            <?php endif; ?>

            <?php for ($i = max(1, $currentPage - 2); $i <= min($totalPages, $currentPage + 2); $i++): ?>
            <a href="?page=<?= $i ?><?= $queryString ?>" 
               class="page-link <?= $i === $currentPage ? 'active' : '' ?>">
                <?= to_jalali($i, '', true) ?>
            </a>
            <?php endfor; ?>

            <?php if ($currentPage < $totalPages): ?>
            <a href="?page=<?= $currentPage + 1 ?><?= $queryString ?>" class="page-link">
                <i class="material-icons">chevron_left</i>
            </a>
            <?php endif; ?>
        </div>
        <?php endif; ?>
        <?php endif; ?>
    </div>
</div>

<style>
.stat-badge.info {
    background: rgba(33, 150, 243, 0.1);
    color: #2196f3;
}

.tx-id {
    font-family: monospace;
    font-size: 11px;
    background: #f5f5f5;
    padding: 4px 8px;
    border-radius: 4px;
    direction: ltr;
}

.type-badge {
    display: inline-block;
    padding: 4px 10px;
    border-radius: 12px;
    font-size: 11px;
    font-weight: 500;
}

.type-badge.deposit {
    background: rgba(76, 175, 80, 0.1);
    color: #4caf50;
}

.type-badge.withdraw {
    background: rgba(244, 67, 54, 0.1);
    color: #f44336;
}

.type-badge.transfer {
    background: rgba(33, 150, 243, 0.1);
    color: #2196f3;
}

.type-badge.commission,
.type-badge.task_reward {
    background: rgba(79, 195, 247, 0.1);
    color: #4fc3f7;
}

.type-badge.penalty {
    background: rgba(255, 87, 34, 0.1);
    color: #ff5722;
}

.type-badge.refund {
    background: rgba(156, 39, 176, 0.1);
    color: #9c27b0;
}

.amount-value {
    font-weight: 600;
    font-size: 13px;
    direction: ltr;
    font-family: monospace;
}

.amount-value.positive {
    color: #4caf50;
}

.amount-value.negative {
    color: #f44336;
}

.balance-value {
    font-size: 12px;
    color: #666;
    direction: ltr;
    font-family: monospace;
}

.gateway-badge {
    display: inline-block;
    padding: 4px 10px;
    background: #f5f5f5;
    border-radius: 12px;
    font-size: 11px;
    color: #666;
}

.currency-badge {
    display: inline-block;
    padding: 4px 10px;
    border-radius: 12px;
    font-size: 11px;
    font-weight: 500;
}

.currency-badge.irt {
    background: rgba(76, 175, 80, 0.1);
    color: #4caf50;
}

.currency-badge.usdt {
    background: rgba(33, 150, 243, 0.1);
    color: #2196f3;
}
</style>

<?php
$content = ob_get_clean();
include __DIR__ . '/../../layouts/' . $layout . '.php';
?>