<?php
$title = 'تاریخچه تریدها';
$layout = 'admin';
ob_start();
$trades = $trades ?? [];
$stats = $stats ?? null;
$total = $total ?? 0;
$totalPages = $totalPages ?? 1;
$currentPage = $currentPage ?? 1;
$filters = $filters ?? [];
?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <h4 class="mb-0">تاریخچه تریدها</h4>
    <div class="d-flex gap-2">
        <a href="<?= url('/admin/investment/trade-create') ?>" class="btn btn-primary btn-sm">
            <i class="material-icons align-middle" style="font-size:16px">add</i> ثبت ترید جدید
        </a>
        <a href="<?= url('/admin/investment') ?>" class="btn btn-outline-secondary btn-sm">
            <i class="material-icons align-middle">arrow_forward</i> بازگشت
        </a>
    </div>
</div>

<!-- آمار کلی -->
<?php if ($stats): ?>
<div class="row g-3 mb-4">
    <div class="col-md-3"><div class="card text-center p-3">
        <div class="text-muted small">مجموع تریدها</div>
        <div class="fs-5 fw-bold"><?= number_format((int)($stats->total ?? 0)) ?></div>
    </div></div>
    <div class="col-md-3"><div class="card text-center p-3">
        <div class="text-muted small">سودها</div>
        <div class="fs-5 fw-bold text-success"><?= number_format((int)($stats->profit_count ?? 0)) ?></div>
    </div></div>
    <div class="col-md-3"><div class="card text-center p-3">
        <div class="text-muted small">ضررها</div>
        <div class="fs-5 fw-bold text-danger"><?= number_format((int)($stats->loss_count ?? 0)) ?></div>
    </div></div>
    <div class="col-md-3"><div class="card text-center p-3">
        <div class="text-muted small">میانگین درصد</div>
        <div class="fs-5 fw-bold"><?= number_format((float)($stats->avg_percent ?? 0), 2) ?>%</div>
    </div></div>
</div>
<?php endif; ?>

<!-- فیلتر -->
<div class="card mb-3">
    <div class="card-body py-2">
        <form method="GET" class="d-flex gap-2 align-items-center flex-wrap">
            <select name="status" class="form-select form-select-sm" style="width:160px">
                <option value="">همه وضعیت‌ها</option>
                <option value="profit" <?= ($filters['status'] ?? '') === 'profit' ? 'selected' : '' ?>>سود</option>
                <option value="loss"   <?= ($filters['status'] ?? '') === 'loss'   ? 'selected' : '' ?>>ضرر</option>
            </select>
            <button type="submit" class="btn btn-primary btn-sm">فیلتر</button>
            <?php if (!empty($filters['status'])): ?>
                <a href="<?= url('/admin/investment/trades') ?>" class="btn btn-outline-secondary btn-sm">حذف فیلتر</a>
            <?php endif; ?>
        </form>
    </div>
</div>

<!-- جدول -->
<div class="card">
    <div class="table-responsive">
        <table class="table table-hover mb-0">
            <thead class="table-light">
                <tr>
                    <th>#</th>
                    <th>نوع</th>
                    <th>درصد</th>
                    <th>مبلغ اعمال‌شده (USDT)</th>
                    <th>تاریخ</th>
                    <th>توضیح</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($trades as $t): ?>
                <?php $isProfit = strtolower($t->type ?? '') === 'profit' || (float)($t->percent ?? 0) >= 0; ?>
                <tr>
                    <td><?= (int)$t->id ?></td>
                    <td>
                        <span class="badge bg-<?= $isProfit ? 'success' : 'danger' ?>">
                            <?= $isProfit ? 'سود' : 'ضرر' ?>
                        </span>
                    </td>
                    <td class="<?= $isProfit ? 'text-success' : 'text-danger' ?> fw-bold">
                        <?= $isProfit ? '+' : '' ?><?= number_format((float)($t->percent ?? 0), 2) ?>%
                    </td>
                    <td class="font-monospace">
                        <?= $isProfit ? '+' : '' ?><?= number_format((float)($t->total_applied ?? 0), 4) ?>
                    </td>
                    <td><?= to_jalali($t->created_at) ?></td>
                    <td class="text-muted small"><?= e($t->note ?? $t->description ?? '—') ?></td>
                </tr>
                <?php endforeach; ?>
                <?php if (empty($trades)): ?>
                <tr><td colspan="6" class="text-center text-muted py-4">هیچ ترید‌ای ثبت نشده است</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <?php if ($totalPages > 1): ?>
    <div class="card-footer d-flex gap-1 justify-content-center">
        <?php for ($i = 1; $i <= $totalPages; $i++): ?>
            <a href="?page=<?= $i ?><?= !empty($filters['status']) ? '&status=' . e($filters['status']) : '' ?>"
               class="btn btn-sm <?= $i === $currentPage ? 'btn-primary' : 'btn-outline-secondary' ?>">
                <?= $i ?>
            </a>
        <?php endfor; ?>
    </div>
    <?php endif; ?>
</div>

<?php $content = ob_get_clean(); include __DIR__ . '/../../layouts/admin.php'; ?>
