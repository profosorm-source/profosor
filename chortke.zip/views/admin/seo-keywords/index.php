<?php
// views/admin/seo-keywords/index.php
$title = 'کلمات کلیدی SEO';
$layout = 'admin';
ob_start();
?>

<div class="page-header">
    <h4><i class="material-icons">search</i> کلمات کلیدی SEO</h4>
    <a href="<?= url('/admin/seo-keywords/create') ?>" class="btn btn-primary btn-sm"><i class="material-icons">add</i> کلمه جدید</a>
</div>

<div class="stats-row-4">
    <div class="mini-stat"><span class="ms-num"><?= number_format($stats->total ?? 0) ?></span><span class="ms-lbl">کل</span></div>
    <div class="mini-stat ms-green"><span class="ms-num"><?= number_format($stats->active ?? 0) ?></span><span class="ms-lbl">فعال</span></div>
    <div class="mini-stat ms-blue"><span class="ms-num"><?= number_format($stats->total_executions ?? 0) ?></span><span class="ms-lbl">کل اجرا</span></div>
    <div class="mini-stat ms-orange"><span class="ms-num"><?= number_format($stats->today_executions ?? 0) ?></span><span class="ms-lbl">امروز</span></div>
</div>

<div class="filter-card">
    <form method="GET" action="<?= url('/admin/seo-keywords') ?>" class="filter-form">
        <select name="is_active" class="form-control-sm">
            <option value="">همه</option>
            <option value="1" <?= ($filters['is_active'] ?? '') === '1' ? 'selected' : '' ?>>فعال</option>
            <option value="0" <?= ($filters['is_active'] ?? '') === '0' ? 'selected' : '' ?>>غیرفعال</option>
        </select>
        <input type="text" name="search" class="form-control-sm" placeholder="جستجو..." value="<?= e($filters['search'] ?? '') ?>">
        <button type="submit" class="btn btn-sm btn-primary"><i class="material-icons">search</i></button>
    </form>
    <span class="filter-count"><?= number_format($total) ?> مورد</span>
</div>

<div class="table-responsive">
    <table class="data-table">
        <thead><tr><th>#</th><th>کلمه</th><th>URL هدف</th><th>پاداش</th><th>اجرا امروز</th><th>اجرا کل</th><th>اولویت</th><th>وضعیت</th><th>عملیات</th></tr></thead>
        <tbody>
            <?php foreach ($keywords as $kw): ?>
                <tr>
                    <td><?= $kw->id ?></td>
                    <td><strong><?= e($kw->keyword) ?></strong></td>
                    <td><a href="<?= e($kw->target_url) ?>" target="_blank" class="ltr-text"><?= e(mb_substr($kw->target_url, 0, 40)) ?></a></td>
                    <td><?= number_format($kw->reward_amount) ?></td>
                    <td><?= $kw->today_executions ?>/<?= $kw->daily_budget ?></td>
                    <td><?= number_format($kw->total_executions) ?></td>
                    <td><?= $kw->priority ?></td>
                    <td>
                        <button class="btn btn-xs <?= $kw->is_active ? 'btn-success' : 'btn-secondary' ?> btn-toggle" data-id="<?= $kw->id ?>">
                            <?= $kw->is_active ? 'فعال' : 'غیرفعال' ?>
                        </button>
                    </td>
                    <td>
                        <a href="<?= url('/admin/seo-keywords/' . $kw->id . '/edit') ?>" class="btn btn-xs btn-outline-secondary"><i class="material-icons">edit</i></a>
                        <button class="btn btn-xs btn-danger btn-del-kw" data-id="<?= $kw->id ?>"><i class="material-icons">delete</i></button>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>

<?php if ($totalPages > 1): ?>
    <div class="pagination"><?php for($i=1;$i<=$totalPages;$i++){$qs=$_GET;$qs['page']=$i;?><a href="<?=url('/admin/seo-keywords?'.http_build_query($qs))?>" class="page-link <?=$i===$page?'active':''?>"><?=$i?></a><?php }?></div>
<?php endif; ?>

<style>
.stats-row-4{display:grid;grid-template-columns:repeat(4,1fr);gap:10px;margin-bottom:12px;}
.mini-stat{background:#fff;padding:10px;border-radius:8px;text-align:center;box-shadow:0 1px 4px rgba(0,0,0,0.05);}
.ms-num{display:block;font-size:18px;font-weight:700;}.ms-lbl{font-size:10px;color:#999;}
.ms-green .ms-num{color:#4caf50;}.ms-blue .ms-num{color:#2196f3;}.ms-orange .ms-num{color:#ff9800;}
.filter-card{background:#fff;padding:10px;border-radius:8px;margin-bottom:10px;display:flex;align-items:center;justify-content:space-between;gap:8px;box-shadow:0 1px 4px rgba(0,0,0,0.05);flex-wrap:wrap;}
.filter-form{display:flex;gap:6px;flex-wrap:wrap;}.form-control-sm{padding:5px 8px;border:1px solid #ddd;border-radius:5px;font-size:11px;}
.filter-count{font-size:11px;color:#999;}.ltr-text{direction:ltr;}
.data-table{width:100%;border-collapse:collapse;background:#fff;border-radius:8px;overflow:hidden;box-shadow:0 1px 4px rgba(0,0,0,0.05);}
.data-table thead th{background:#fafafa;padding:8px 10px;font-size:11px;font-weight:600;color:#666;text-align:right;white-space:nowrap;}
.data-table tbody td{padding:8px 10px;font-size:12px;border-bottom:1px solid #f5f5f5;}
.data-table tbody tr:hover{background:#fafafa;}
.btn-xs{padding:3px 8px;font-size:10px;border:none;border-radius:4px;cursor:pointer;color:#fff;}
.btn-success{background:#4caf50;}.btn-danger{background:#f44336;}.btn-secondary{background:#999;}
.btn-outline-secondary{background:transparent;border:1px solid #ccc;color:#555;}
.pagination{display:flex;gap:4px;justify-content:center;margin-top:12px;}
.page-link{padding:4px 10px;border:1px solid #ddd;border-radius:4px;text-decoration:none;color:#555;font-size:11px;}
.page-link.active{background:#4fc3f7;color:#fff;border-color:#4fc3f7;}
@media(max-width:768px){.stats-row-4{grid-template-columns:repeat(2,1fr);}}
</style>

<script>
document.querySelectorAll('.btn-toggle').forEach(btn=>{btn.addEventListener('click',function(){const id=this.dataset.id;fetch(`<?=url('/admin/seo-keywords')?>/${id}/toggle`,{method:'POST',headers:{'Content-Type':'application/json','X-CSRF-TOKEN':'<?=csrf_token()?>'},body:JSON.stringify({_csrf_token:'<?=csrf_token()?>'})}).then(r=>r.json()).then(d=>{if(d.success){notyf.success(d.message);setTimeout(()=>location.reload(),500);}else notyf.error(d.message);});});});

document.querySelectorAll('.btn-del-kw').forEach(btn=>{btn.addEventListener('click',function(){const id=this.dataset.id;Swal.fire({title:'حذف',text:'مطمئن هستید؟',icon:'warning',showCancelButton:true,confirmButtonText:'حذف',cancelButtonText:'انصراف',confirmButtonColor:'#f44336'}).then(r=>{if(r.isConfirmed){fetch(`<?=url('/admin/seo-keywords')?>/${id}/delete`,{method:'POST',headers:{'Content-Type':'application/json','X-CSRF-TOKEN':'<?=csrf_token()?>'},body:JSON.stringify({_csrf_token:'<?=csrf_token()?>'})}).then(r=>r.json()).then(d=>{if(d.success){notyf.success(d.message);setTimeout(()=>location.reload(),500);}else notyf.error(d.message);});}});});});
</script>

<?php $content = ob_get_clean(); include __DIR__ . '/../../layouts/' . $layout . '.php'; ?>