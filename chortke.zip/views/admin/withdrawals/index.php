<?php
$pageTitle = $pageTitle ?? 'درخواست‌های برداشت';
$withdrawals = $withdrawals ?? [];
$currentPage = $currentPage ?? 1;
$totalPages = $totalPages ?? 1;
$total = $total ?? 0;
$status = $status ?? '';
$currency = $currency ?? '';
?>

<div class="main-content">
    <!-- Header -->
    <div class="content-header">
        <h1>مدیریت درخواست‌های برداشت</h1>
        <div class="header-stats">
            <div class="stat-badge pending">
                <i class="material-icons">schedule</i>
                <span><?= to_jalali($total, '', true) ?> در انتظار</span>
            </div>
        </div>
    </div>

    <!-- فیلترها -->
    <div class="filters-card">
        <form method="GET" class="filters-form">
            <div class="filter-group">
                <label>وضعیت:</label>
                <select name="status" class="form-control">
                    <option value="">همه</option>
                    <option value="pending" <?= $status === 'pending' ? 'selected' : '' ?>>در انتظار</option>
                    <option value="processing" <?= $status === 'processing' ? 'selected' : '' ?>>در حال پردازش</option>
                    <option value="completed" <?= $status === 'completed' ? 'selected' : '' ?>>تکمیل شده</option>
                    <option value="rejected" <?= $status === 'rejected' ? 'selected' : '' ?>>رد شده</option>
                </select>
            </div>

            <div class="filter-group">
                <label>نوع ارز:</label>
                <select name="currency" class="form-control">
                    <option value="">همه</option>
                    <option value="irt" <?= $currency === 'irt' ? 'selected' : '' ?>>تومان</option>
                    <option value="usdt" <?= $currency === 'usdt' ? 'selected' : '' ?>>USDT</option>
                </select>
            </div>

            <button type="submit" class="btn btn-primary">
                <i class="material-icons">search</i>
                فیلتر
            </button>

            <?php if ($status || $currency): ?>
            <a href="<?= url('/admin/withdrawals') ?>" class="btn btn-outline">
                <i class="material-icons">clear</i>
                حذف فیلتر
            </a>
            <?php endif; ?>
        </form>
    </div>

    <!-- جدول -->
    <div class="table-card">
        <?php if (empty($withdrawals)): ?>
        <div class="empty-state">
            <i class="material-icons">payments</i>
            <h3>درخواستی یافت نشد</h3>
            <p>هیچ درخواست برداشتی وجود ندارد</p>
        </div>
        <?php else: ?>
        <div class="table-responsive">
            <table class="data-table">
                <thead>
                    <tr>
                        <th>کاربر</th>
                        <th>مبلغ</th>
                        <th>ارز</th>
                        <th>مقصد</th>
                        <th>تاریخ درخواست</th>
                        <th>وضعیت</th>
                        <th>عملیات</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($withdrawals as $withdrawal): ?>
                    <tr>
                        <td>
                            <div class="user-info">
                                <strong><?= e($withdrawal->full_name ?? 'نامشخص') ?></strong>
                                <small><?= e($withdrawal->email ?? '') ?></small>
                            </div>
                        </td>
                        <td>
                            <span class="amount-badge negative">
                                <?= $withdrawal->currency === 'usdt' 
                                    ? number_format($withdrawal->amount, 4) . ' USDT'
                                    : number_format($withdrawal->amount) . ' تومان' 
                                ?>
                            </span>
                        </td>
                        <td>
                            <span class="currency-badge <?= e($withdrawal->currency) ?>">
                                <?= $withdrawal->currency === 'usdt' ? 'USDT' : 'تومان' ?>
                            </span>
                        </td>
                        <td>
                            <?php if ($withdrawal->currency === 'irt'): ?>
                                <div class="destination-info">
                                    <code class="card-number">
                                        <?= substr($withdrawal->card_number ?? '', 0, 4) ?>-****-****-<?= substr($withdrawal->card_number ?? '', -4) ?>
                                    </code>
                                    <small class="bank-name"><?= e($withdrawal->bank_name ?? '') ?></small>
                                </div>
                            <?php else: ?>
                                <div class="wallet-info">
                                    <code class="wallet-address" title="<?= e($withdrawal->wallet_address ?? '') ?>">
                                        <?= substr($withdrawal->wallet_address ?? '', 0, 8) ?>...<?= substr($withdrawal->wallet_address ?? '', -6) ?>
                                    </code>
                                    <span class="network-badge <?= e($withdrawal->network ?? '') ?>">
                                        <?= strtoupper($withdrawal->network ?? '') ?>
                                    </span>
                                </div>
                            <?php endif; ?>
                        </td>
                        <td>
                            <span class="date-badge"><?= to_jalali($withdrawal->created_at) ?></span>
                        </td>
                        <td>
                            <?php
                            $statusLabels = [
                                'pending' => 'در انتظار',
                                'processing' => 'در حال پردازش',
                                'completed' => 'تکمیل شده',
                                'rejected' => 'رد شده',
                            ];
                            ?>
                            <span class="status-badge <?= $withdrawal->status ?>">
                                <?= $statusLabels[$withdrawal->status] ?? $withdrawal->status ?>
                            </span>
                        </td>
                        <td>
                            <div class="action-buttons">
                                <a href="<?= url('/admin/withdrawals/review?id=' . $withdrawal->id) ?>" 
                                   class="btn-icon" 
                                   title="بررسی جزئیات">
                                    <i class="material-icons">visibility</i>
                                </a>
                                <?php if ($withdrawal->status === 'pending'): ?>
                                <button class="btn-icon success" 
                                        onclick="processWithdrawal(<?= $withdrawal->id ?>)" 
                                        title="پردازش و تأیید">
                                    <i class="material-icons">done_all</i>
                                </button>
                                <button class="btn-icon danger" 
                                        onclick="showRejectModal(<?= $withdrawal->id ?>)" 
                                        title="رد">
                                    <i class="material-icons">cancel</i>
                                </button>
                                <?php endif; ?>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>

        <!-- Pagination -->
        <?php if ($totalPages > 1): ?>
        <div class="pagination">
            <?php 
            $queryParams = [];
            if ($status) $queryParams[] = 'status=' . $status;
            if ($currency) $queryParams[] = 'currency=' . $currency;
            $queryString = !empty($queryParams) ? '&' . implode('&', $queryParams) : '';
            ?>
            
            <?php if ($currentPage > 1): ?>
            <a href="?page=<?= $currentPage - 1 ?><?= $queryString ?>" class="page-link">
                <i class="material-icons">chevron_right</i>
            </a>
            <?php endif; ?>

            <?php for ($i = max(1, $currentPage - 2); $i <= min($totalPages, $currentPage + 2); $i++): ?>
            <a href="?page=<?= $i ?><?= $queryString ?>" 
               class="page-link <?= $i === $currentPage ? 'active' : '' ?>">
                <?= to_jalali($i, '', true) ?>
            </a>
            <?php endfor; ?>

            <?php if ($currentPage < $totalPages): ?>
            <a href="?page=<?= $currentPage + 1 ?><?= $queryString ?>" class="page-link">
                <i class="material-icons">chevron_left</i>
            </a>
            <?php endif; ?>
        </div>
        <?php endif; ?>
        <?php endif; ?>
    </div>
</div>

<!-- مودال رد برداشت -->
<div class="modal" id="rejectModal">
    <div class="modal-content">
        <div class="modal-header">
            <h3>رد درخواست برداشت</h3>
            <button class="modal-close" onclick="closeRejectModal()">
                <i class="material-icons">close</i>
            </button>
        </div>
        <form id="rejectForm">
            <?= csrf_field() ?>
            <input type="hidden" id="reject_withdrawal_id" name="withdrawal_id">
            
            <div class="modal-body">
                <div class="alert alert-warning">
                    <i class="material-icons">info</i>
                    <div>
                        با رد این درخواست، موجودی قفل‌شده به کیف پول کاربر بازگردانده می‌شود.
                    </div>
                </div>

                <div class="form-group">
                    <label for="rejection_reason">دلیل رد: <span class="required">*</span></label>
                    <textarea id="rejection_reason" 
                              name="rejection_reason" 
                              class="form-control" 
                              rows="4"
                              placeholder="لطفاً دلیل رد درخواست را به صورت واضح توضیح دهید..."
                              required></textarea>
                    <small class="form-text">این پیام به کاربر نمایش داده می‌شود</small>
                </div>

                <div class="common-reasons">
                    <strong>دلایل متداول:</strong>
                    <button type="button" class="reason-btn" onclick="setReason('اطلاعات کارت بانکی نادرست است')">
                        اطلاعات نادرست
                    </button>
                    <button type="button" class="reason-btn" onclick="setReason('احراز هویت تکمیل نشده است')">
                        عدم احراز هویت
                    </button>
                    <button type="button" class="reason-btn" onclick="setReason('مبلغ درخواستی کمتر از حداقل مجاز است')">
                        مبلغ نامعتبر
                    </button>
                    <button type="button" class="reason-btn" onclick="setReason('فعالیت مشکوک در حساب کاربری')">
                        فعالیت مشکوک
                    </button>
                </div>
            </div>

            <div class="modal-footer">
                <button type="button" class="btn btn-outline" onclick="closeRejectModal()">انصراف</button>
                <button type="submit" class="btn btn-danger">
                    <i class="material-icons">cancel</i>
                    رد درخواست
                </button>
            </div>
        </form>
    </div>
</div>

<style>
.amount-badge.negative {
    background: rgba(244, 67, 54, 0.1);
    color: #f44336;
}

.destination-info,
.wallet-info {
    display: flex;
    flex-direction: column;
    gap: 5px;
}

.wallet-address {
    font-family: monospace;
    font-size: 11px;
    background: #f5f5f5;
    padding: 4px 6px;
    border-radius: 4px;
    direction: ltr;
}

.status-badge.processing {
    background: rgba(33, 150, 243, 0.1);
    color: #2196f3;
}

.status-badge.completed {
    background: rgba(76, 175, 80, 0.1);
    color: #4caf50;
}
</style>

<script>
function processWithdrawal(withdrawalId) {
    Swal.fire({
        title: 'پردازش برداشت',
        html: `
            <p>آیا از پردازش این درخواست برداشت اطمینان دارید؟</p>
            <div style="margin-top: 15px; padding: 15px; background: #ffebee; border-radius: 8px; text-align: right;">
                <strong style="color: #d32f2f;">هشدار:</strong>
                <ul style="margin: 10px 0 0 20px; padding: 0; text-align: right;">
                    <li style="margin-bottom: 8px; font-size: 13px; color: #666;">
                        لطفاً قبل از تأیید، اطلاعات کاربر را دقیقاً بررسی کنید
                    </li>
                    <li style="margin-bottom: 8px; font-size: 13px; color: #666;">
                        پس از تأیید، موجودی قفل‌شده کسر و تراکنش تکمیل می‌شود
                    </li>
                    <li style="font-size: 13px; color: #666;">
                        برای تومان: به کارت کاربر واریز کنید<br>
                        برای USDT: به آدرس کیف پول ارسال کنید
                    </li>
                </ul>
            </div>
        `,
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#4caf50',
        cancelButtonColor: '#999',
        confirmButtonText: 'بله، پردازش شود',
        cancelButtonText: 'انصراف'
    }).then((result) => {
        if (result.isConfirmed) {
            const formData = new FormData();
            formData.append('withdrawal_id', withdrawalId);
            formData.append('<?= csrf_token() ?>', '<?= csrf_token() ?>');

            fetch('<?= url('/admin/withdrawals/process') ?>', {
                method: 'POST',
                body: formData
            })
            .then(res => res.json())
            .then(data => {
                if (data.success) {
                    notyf.success(data.message);
                    setTimeout(() => location.reload(), 1500);
                } else {
                    notyf.error(data.message);
                }
            })
            .catch(err => {
                notyf.error('خطا در ارتباط با سرور');
            });
        }
    });
}

function showRejectModal(withdrawalId) {
    document.getElementById('reject_withdrawal_id').value = withdrawalId;
    document.getElementById('rejection_reason').value = '';
    document.getElementById('rejectModal').classList.add('show');
}

function closeRejectModal() {
    document.getElementById('rejectModal').classList.remove('show');
}

function setReason(reason) {
    document.getElementById('rejection_reason').value = reason;
}

document.getElementById('rejectForm').addEventListener('submit', function(e) {
    e.preventDefault();
    
    const formData = new FormData(this);
    
    fetch('<?= url('/admin/withdrawals/reject') ?>', {
        method: 'POST',
        body: formData
    })
    .then(res => res.json())
    .then(data => {
        if (data.success) {
            closeRejectModal();
            notyf.success(data.message);
            setTimeout(() => location.reload(), 1000);
        } else {
            notyf.error(data.message);
        }
    })
    .catch(err => {
        notyf.error('خطا در ارتباط با سرور');
    });
});
</script>
<?php
$content = ob_get_clean();
include __DIR__ . '/../../layouts/' . $layout . '.php';
?>