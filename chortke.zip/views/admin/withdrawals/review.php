<?php
$title = 'بررسی درخواست برداشت';
$layout = 'admin';
ob_start();
$withdrawal = $withdrawal ?? null;
$user = $user ?? null;
$card = $card ?? null;
?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <h4 class="mb-0">بررسی درخواست برداشت #<?= (int)($withdrawal->id ?? 0) ?></h4>
    <a href="<?= url('/admin/withdrawals') ?>" class="btn btn-outline-secondary btn-sm">
        <i class="material-icons align-middle">arrow_forward</i> بازگشت
    </a>
</div>

<div class="row g-4">
    <!-- اطلاعات کاربر -->
    <div class="col-md-4">
        <div class="card">
            <div class="card-header"><h6 class="mb-0">اطلاعات کاربر</h6></div>
            <div class="card-body">
                <p class="mb-2"><strong>نام:</strong> <?= e($user->full_name ?? '—') ?></p>
                <p class="mb-2"><strong>ایمیل:</strong> <?= e($user->email ?? '—') ?></p>
                <p class="mb-2"><strong>موبایل:</strong> <?= e($user->mobile ?? '—') ?></p>
                <p class="mb-2"><strong>KYC:</strong>
                    <?php $kyc = $user->kyc_status ?? 'none'; ?>
                    <span class="badge bg-<?= $kyc === 'verified' ? 'success' : ($kyc === 'pending' ? 'warning' : 'danger') ?>">
                        <?= ['verified'=>'تأیید شده','pending'=>'در انتظار','rejected'=>'رد شده','none'=>'ندارد'][$kyc] ?? $kyc ?>
                    </span>
                </p>
                <a href="<?= url('/admin/users/' . (int)($user->id ?? 0)) ?>" class="btn btn-sm btn-outline-primary mt-2">
                    پروفایل کامل
                </a>
            </div>
        </div>
    </div>

    <!-- جزئیات برداشت -->
    <div class="col-md-8">
        <div class="card">
            <div class="card-header"><h6 class="mb-0">جزئیات درخواست</h6></div>
            <div class="card-body">
                <div class="row g-3">
                    <div class="col-6">
                        <label class="text-muted small">مبلغ:</label>
                        <p class="fs-5 fw-bold text-primary"><?= number_format((float)($withdrawal->amount ?? 0)) ?>
                            <small class="text-muted"><?= strtoupper($withdrawal->currency ?? 'IRT') ?></small>
                        </p>
                    </div>
                    <div class="col-6">
                        <label class="text-muted small">وضعیت:</label>
                        <p>
                            <?php
                            $stMap = ['pending'=>'badge-warning','processing'=>'badge-info','completed'=>'badge-success','rejected'=>'badge-danger'];
                            $stLbl = ['pending'=>'در انتظار','processing'=>'پردازش','completed'=>'تکمیل','rejected'=>'رد شده'];
                            $s = $withdrawal->status ?? 'pending';
                            ?>
                            <span class="badge <?= $stMap[$s] ?? 'badge-secondary' ?>"><?= $stLbl[$s] ?? $s ?></span>
                        </p>
                    </div>
                    <div class="col-6">
                        <label class="text-muted small">تاریخ درخواست:</label>
                        <p><?= to_jalali($withdrawal->created_at) ?></p>
                    </div>
                    <div class="col-6">
                        <label class="text-muted small">ارز:</label>
                        <p><?= strtoupper(e($withdrawal->currency ?? '—')) ?></p>
                    </div>
                    <?php if (!empty($card)): ?>
                    <div class="col-12">
                        <label class="text-muted small">کارت مقصد:</label>
                        <p class="font-monospace"><?= e($card->card_number ?? '—') ?>
                            <?php if (!empty($card->bank_name)): ?>
                                <small class="text-muted ms-2"><?= e($card->bank_name) ?></small>
                            <?php endif; ?>
                        </p>
                    </div>
                    <?php endif; ?>
                    <?php if (!empty($withdrawal->wallet_address)): ?>
                    <div class="col-12">
                        <label class="text-muted small">آدرس کیف پول:</label>
                        <p class="font-monospace small"><?= e($withdrawal->wallet_address) ?></p>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <?php if (($withdrawal->status ?? '') === 'pending'): ?>
        <div class="card mt-3">
            <div class="card-header"><h6 class="mb-0">عملیات</h6></div>
            <div class="card-body">
                <div class="mb-3">
                    <label class="form-label">شماره پیگیری پرداخت (برای تأیید):</label>
                    <input type="text" id="trackingCode" class="form-control" placeholder="شماره پیگیری...">
                </div>
                <div class="d-flex gap-2">
                    <button class="btn btn-success" onclick="doApprove()">
                        <i class="material-icons align-middle">check_circle</i> تأیید و پرداخت
                    </button>
                    <button class="btn btn-danger" onclick="doReject()">
                        <i class="material-icons align-middle">cancel</i> رد درخواست
                    </button>
                </div>
                <div id="rejectBox" style="display:none;" class="mt-3">
                    <textarea id="rejectReason" class="form-control" rows="3" placeholder="دلیل رد..."></textarea>
                    <button class="btn btn-danger mt-2" onclick="confirmReject()">تأیید رد</button>
                </div>
            </div>
        </div>
        <?php endif; ?>
    </div>
</div>

<script>
const wId = <?= (int)($withdrawal->id ?? 0) ?>;
const csrf = '<?= csrf_token() ?>';

function doApprove() {
    const tracking = document.getElementById('trackingCode').value.trim();
    if (!tracking) { alert('لطفاً شماره پیگیری را وارد کنید'); return; }
    if (!confirm('آیا از تأیید این برداشت مطمئنید؟')) return;

    fetch(`<?= url('/admin/withdrawals') ?>/${wId}/approve`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'X-CSRF-TOKEN': csrf },
        body: JSON.stringify({ tracking_code: tracking })
    }).then(r => r.json()).then(res => {
        if (res.success) { location.href = '<?= url('/admin/withdrawals') ?>'; }
        else { alert(res.message || 'خطا'); }
    });
}

function doReject() {
    document.getElementById('rejectBox').style.display = 'block';
}

function confirmReject() {
    const reason = document.getElementById('rejectReason').value.trim();
    if (!confirm('آیا از رد این درخواست مطمئنید؟')) return;

    fetch(`<?= url('/admin/withdrawals') ?>/${wId}/reject`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'X-CSRF-TOKEN': csrf },
        body: JSON.stringify({ reason })
    }).then(r => r.json()).then(res => {
        if (res.success) { location.href = '<?= url('/admin/withdrawals') ?>'; }
        else { alert(res.message || 'خطا'); }
    });
}
</script>

<?php $content = ob_get_clean(); include __DIR__ . '/../../layouts/admin.php'; ?>
