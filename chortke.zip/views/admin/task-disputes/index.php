<?php
// views/admin/task-disputes/index.php
$title = 'اختلافات تسک‌ها';
$layout = 'admin';
ob_start();
?>

<div class="page-header">
    <h4><i class="material-icons">gavel</i> اختلافات تسک‌ها</h4>
</div>

<div class="filter-card">
    <form method="GET" action="<?= url('/admin/task-disputes') ?>" class="filter-form">
        <select name="status" class="form-control-sm">
            <option value="">همه</option>
            <option value="open" <?= ($filters['status'] ?? '') === 'open' ? 'selected' : '' ?>>باز</option>
            <option value="under_review" <?= ($filters['status'] ?? '') === 'under_review' ? 'selected' : '' ?>>در حال بررسی</option>
            <option value="resolved_for_executor" <?= ($filters['status'] ?? '') === 'resolved_for_executor' ? 'selected' : '' ?>>به نفع انجام‌دهنده</option>
            <option value="resolved_for_advertiser" <?= ($filters['status'] ?? '') === 'resolved_for_advertiser' ? 'selected' : '' ?>>به نفع سفارش‌دهنده</option>
        </select>
        <button type="submit" class="btn btn-sm btn-primary"><i class="material-icons">search</i></button>
    </form>
    <span class="filter-count"><?= number_format($total) ?> مورد</span>
</div>

<div class="table-responsive">
    <table class="data-table">
        <thead>
            <tr>
                <th>#</th>
                <th>تسک</th>
                <th>باز‌شده توسط</th>
                <th>دلیل</th>
                <th>جریمه</th>
                <th>وضعیت</th>
                <th>تاریخ</th>
                <th>عملیات</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($disputes as $d): ?>
                <tr>
                    <td><?= $d->id ?></td>
                    <td><?= e($d->ad_title ?? '—') ?></td>
                    <td>
                        <?= e($d->opener_name ?? '') ?>
                        <small>(<?= $d->opened_by === 'executor' ? 'انجام‌دهنده' : 'سفارش‌دهنده' ?>)</small>
                    </td>
                    <td><?= e(mb_substr($d->reason, 0, 60)) ?><?= mb_strlen($d->reason) > 60 ? '...' : '' ?></td>
                    <td><?= $d->penalty_amount > 0 ? number_format($d->penalty_amount) : '—' ?></td>
                    <td><span class="badge badge-<?= task_dispute_status_badge($d->status) ?>"><?= e(task_dispute_status_label($d->status)) ?></span></td>
                    <td><?= to_jalali($d->created_at) ?></td>
                    <td>
                        <a href="<?= url('/admin/task-disputes/' . $d->id) ?>" class="btn btn-xs btn-outline-secondary">
                            <i class="material-icons">visibility</i>
                        </a>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>

<?php if ($totalPages > 1): ?>
    <div class="pagination">
        <?php for ($i = 1; $i <= $totalPages; $i++): $qs=$_GET;$qs['page']=$i; ?>
            <a href="<?= url('/admin/task-disputes?' . http_build_query($qs)) ?>" class="page-link <?= $i===$page?'active':'' ?>"><?= $i ?></a>
        <?php endfor; ?>
    </div>
<?php endif; ?>

<style>
.filter-card{background:#fff;padding:10px 12px;border-radius:8px;margin-bottom:12px;display:flex;align-items:center;justify-content:space-between;gap:8px;box-shadow:0 1px 4px rgba(0,0,0,0.05);flex-wrap:wrap;}
.filter-form{display:flex;gap:6px;flex-wrap:wrap;}
.form-control-sm{padding:5px 8px;border:1px solid #ddd;border-radius:5px;font-size:11px;}
.filter-count{font-size:11px;color:#999;}
.data-table{width:100%;border-collapse:collapse;background:#fff;border-radius:8px;overflow:hidden;box-shadow:0 1px 4px rgba(0,0,0,0.05);}
.data-table thead th{background:#fafafa;padding:8px 10px;font-size:11px;font-weight:600;color:#666;text-align:right;white-space:nowrap;}
.data-table tbody td{padding:8px 10px;font-size:12px;border-bottom:1px solid #f5f5f5;}
.data-table tbody tr:hover{background:#fafafa;}
.btn-xs{padding:3px 6px;font-size:10px;border:none;border-radius:4px;cursor:pointer;color:#fff;}
.btn-outline-secondary{background:transparent;border:1px solid #ccc;color:#555;}
.pagination{display:flex;gap:4px;justify-content:center;margin-top:12px;}
.page-link{padding:4px 10px;border:1px solid #ddd;border-radius:4px;text-decoration:none;color:#555;font-size:11px;}
.page-link.active{background:#4fc3f7;color:#fff;border-color:#4fc3f7;}
</style>

<?php
$content = ob_get_clean();
include __DIR__ . '/../../layouts/' . $layout . '.php';
?>