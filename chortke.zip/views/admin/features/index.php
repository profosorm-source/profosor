<?php
$pageTitle = 'مدیریت فیچرها';
require_once __DIR__ . '/../../layouts/admin-header.php';
?>

<div class="container-fluid">
    <h4 class="mb-4">مدیریت فیچرها (Feature Flags)</h4>

    <div class="alert alert-info">
        <i class="material-icons">info</i>
        <strong>توضیح:</strong> با استفاده از Feature Flags می‌توانید بخش‌های مختلف سایت را بدون نیاز به تغییر کد فعال یا غیرفعال کنید.
    </div>

    <div class="card">
        <div class="card-body">
            <div class="table-responsive">
                <table class="table">
                    <thead>
                        <tr>
                            <th>نام</th>
                            <th>توضیحات</th>
                            <th>درصد فعال</th>
                            <th>وضعیت</th>
                            <th>عملیات</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($features as $feature): ?>
                        <tr>
                            <td><code><?= e($feature->name) ?></code></td>
                            <td><?= e($feature->description) ?></td>
                            <td><?= $feature->enabled_percentage ?>%</td>
                            <td>
                                <span class="badge <?= $feature->enabled ? 'badge-success' : 'badge-secondary' ?>">
                                    <?= $feature->enabled ? 'فعال' : 'غیرفعال' ?>
                                </span>
                            </td>
                            <td>
                                <button class="btn btn-sm <?= $feature->enabled ? 'btn-danger' : 'btn-success' ?>" 
                                        onclick="toggleFeature('<?= e($feature->name) ?>')">
                                    <i class="material-icons"><?= $feature->enabled ? 'toggle_on' : 'toggle_off' ?></i>
                                    <?= $feature->enabled ? 'غیرفعال' : 'فعال' ?>
                                </button>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<script>
function toggleFeature(name) {
    Swal.fire({
        title: 'تغییر وضعیت فیچر',
        text: `آیا مطمئن هستید؟`,
        icon: 'question',
        showCancelButton: true,
        confirmButtonText: 'بله',
        cancelButtonText: 'خیر'
    }).then((result) => {
        if (result.isConfirmed) {
            fetch('<?= url('/admin/features/toggle') ?>', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': '<?= csrf_token() ?>'
                },
                body: JSON.stringify({ name: name })
            })
            .then(res => res.json())
            .then(data => {
                if (data.success) {
                    notyf.success(data.message);
                    setTimeout(() => location.reload(), 1000);
                } else {
                    notyf.error(data.message);
                }
            });
        }
    });
}
</script>

<?php require_once __DIR__ . '/../../layouts/admin-footer.php'; ?>