<?php
$pageTitle = 'مدیریت تیکت‌ها';
require_once __DIR__ . '/../../layouts/admin-header.php';

use App\Enums\TicketStatus;
use App\Enums\TicketPriority;
?>

<div class="container-fluid">
    <h4 class="mb-4">مدیریت تیکت‌های پشتیبانی</h4>

    <!-- آمار -->
    <div class="row mb-4">
        <div class="col-md-2">
            <div class="stats-card">
                <div class="stats-icon" style="background: rgba(76, 175, 80, 0.1);">
                    <i class="material-icons" style="color: #4caf50;">check_circle</i>
                </div>
                <div class="stats-content">
                    <h3><?= $stats['open'] ?></h3>
                    <span>باز</span>
                </div>
            </div>
        </div>
        <div class="col-md-2">
            <div class="stats-card">
                <div class="stats-icon" style="background: rgba(33, 150, 243, 0.1);">
                    <i class="material-icons" style="color: #2196f3;">reply</i>
                </div>
                <div class="stats-content">
                    <h3><?= $stats['answered'] ?></h3>
                    <span>پاسخ داده شده</span>
                </div>
            </div>
        </div>
        <div class="col-md-2">
            <div class="stats-card">
                <div class="stats-icon" style="background: rgba(255, 152, 0, 0.1);">
                    <i class="material-icons" style="color: #ff9800;">schedule</i>
                </div>
                <div class="stats-content">
                    <h3><?= $stats['in_progress'] ?></h3>
                    <span>در حال بررسی</span>
                </div>
            </div>
        </div>
        <div class="col-md-2">
            <div class="stats-card">
                <div class="stats-icon" style="background: rgba(244, 67, 54, 0.1);">
                    <i class="material-icons" style="color: #f44336;">priority_high</i>
                </div>
                <div class="stats-content">
                    <h3><?= $stats['urgent'] ?></h3>
                    <span>فوری</span>
                </div>
            </div>
        </div>
        <div class="col-md-2">
            <div class="stats-card">
                <div class="stats-icon" style="background: rgba(0, 0, 0, 0.1);">
                    <i class="material-icons">lock</i>
                </div>
                <div class="stats-content">
                    <h3><?= $stats['closed'] ?></h3>
                    <span>بسته شده</span>
                </div>
            </div>
        </div>
        <div class="col-md-2">
            <div class="stats-card">
                <div class="stats-icon" style="background: rgba(156, 39, 176, 0.1);">
                    <i class="material-icons" style="color: #9c27b0;">confirmation_number</i>
                </div>
                <div class="stats-content">
                    <h3><?= $stats['total'] ?></h3>
                    <span>کل</span>
                </div>
            </div>
        </div>
    </div>

    <!-- فیلترها -->
    <div class="card mb-4">
        <div class="card-body">
            <form method="GET" action="<?= url('/admin/tickets') ?>" class="row align-items-end">
                <div class="col-md-2">
                    <label>وضعیت</label>
                    <select name="status" class="form-control">
                        <option value="">همه</option>
                        <?php foreach (TicketStatus::all() as $s): ?>
                            <option value="<?= $s ?>" <?= $filters['status'] === $s ? 'selected' : '' ?>>
                                <?= TicketStatus::label($s) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-md-2">
                    <label>اولویت</label>
                    <select name="priority" class="form-control">
                        <option value="">همه</option>
                        <?php foreach (TicketPriority::all() as $p): ?>
                            <option value="<?= $p ?>" <?= $filters['priority'] === $p ? 'selected' : '' ?>>
                                <?= TicketPriority::label($p) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-md-2">
                    <label>دسته</label>
                    <select name="category_id" class="form-control">
                        <option value="">همه</option>
                        <?php foreach ($categories as $category): ?>
                            <option value="<?= $category->id ?>" <?= $filters['category_id'] == $category->id ? 'selected' : '' ?>>
                                <?= e($category->name) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-md-2">
                    <button type="submit" class="btn btn-primary btn-block">فیلتر</button>
                </div>
            </form>
        </div>
    </div>

    <!-- لیست -->
    <div class="card">
        <div class="card-body">
            <div class="table-responsive">
                <table class="table">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>کاربر</th>
                            <th>موضوع</th>
                            <th>دسته</th>
                            <th>اولویت</th>
                            <th>وضعیت</th>
                            <th>آخرین بروزرسانی</th>
                            <th>عملیات</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($tickets)): ?>
                        <tr>
                            <td colspan="8" class="text-center">موردی یافت نشد.</td>
                        </tr>
                        <?php else: ?>
                            <?php foreach ($tickets as $ticket): ?>
                            <tr>
                                <td><?= $ticket->id ?></td>
                                <td>
                                    <strong><?= e($ticket->full_name) ?></strong><br>
                                    <small class="text-muted"><?= e($ticket->email) ?></small>
                                </td>
                                <td>
                                    <?= e($ticket->subject) ?>
                                    <?php if ($ticket->last_reply_by === 'user'): ?>
                                        <span class="badge badge-danger badge-sm">جدید</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <i class="material-icons" style="font-size: 16px; vertical-align: middle;">
                                        <?= e($ticket->category_icon) ?>
                                    </i>
                                    <?= e($ticket->category_name) ?>
                                </td>
                                <td>
                                    <span class="badge <?= TicketPriority::badgeClass($ticket->priority) ?>">
                                        <?= TicketPriority::label($ticket->priority) ?>
                                    </span>
                                </td>
                                <td>
                                    <span class="badge <?= TicketStatus::badgeClass($ticket->status) ?>">
                                        <?= TicketStatus::label($ticket->status) ?>
                                    </span>
                                </td>
                                <td><?= to_jalali($ticket->updated_at) ?></td>
                                <td>
                                    <a href="<?= url('/admin/tickets/show/' . $ticket->id) ?>" class="btn btn-sm btn-info">
                                        <i class="material-icons">visibility</i>
                                    </a>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>

            <!-- Pagination -->
            <?php if ($totalPages > 1): ?>
            <nav>
                <ul class="pagination justify-content-center">
                    <?php for ($i = 1; $i <= $totalPages; $i++): ?>
                    <li class="page-item <?= $i == $page ? 'active' : '' ?>">
                        <a class="page-link" href="<?= url('/admin/tickets?page=' . $i) ?>">
                            <?= to_jalali($i, '', true) ?>
                        </a>
                    </li>
                    <?php endfor; ?>
                </ul>
            </nav>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../../layouts/admin-footer.php'; ?>