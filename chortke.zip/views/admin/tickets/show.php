<?php
$pageTitle = 'تیکت #' . $ticket->id;
require_once __DIR__ . '/../../layouts/admin-header.php';

use App\Enums\TicketStatus;
use App\Enums\TicketPriority;
?>

<div class="container-fluid">
    <div class="row">
        <!-- جزئیات تیکت -->
        <div class="col-lg-4 mb-4">
            <div class="card mb-4">
                <div class="card-header">
                    <h5 class="mb-0">جزئیات تیکت</h5>
                </div>
                <div class="card-body">
                    <table class="table table-sm table-borderless">
                        <tr>
                            <th>شماره:</th>
                            <td><strong>#<?= $ticket->id ?></strong></td>
                        </tr>
                        <tr>
                            <th>کاربر:</th>
                            <td>
                                <strong><?= e($ticket->user_name) ?></strong><br>
                                <small><?= e($ticket->user_email) ?></small>
                            </td>
                        </tr>
                        <tr>
                            <th>دسته:</th>
                            <td><?= e($ticket->category_name) ?></td>
                        </tr>
                        <tr>
                            <th>تاریخ ایجاد:</th>
                            <td><?= to_jalali($ticket->created_at) ?></td>
                        </tr>
                    </table>
                </div>
            </div>

            <!-- تغییر وضعیت -->
            <div class="card">
                <div class="card-header">
                    <h5 class="mb-0">مدیریت</h5>
                </div>
                <div class="card-body">
                    <div class="form-group">
                        <label>تغییر وضعیت</label>
                        <select class="form-control" id="statusSelect">
                            <?php foreach (TicketStatus::all() as $s): ?>
                                <option value="<?= $s ?>" <?= $ticket->status === $s ? 'selected' : '' ?>>
                                    <?= TicketStatus::label($s) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <button class="btn btn-primary btn-block" onclick="changeStatus(<?= $ticket->id ?>)">
                        ذخیره تغییرات
                    </button>
                </div>
            </div>
        </div>

        <!-- پیام‌ها -->
        <div class="col-lg-8">
            <div class="card">
                <div class="card-header">
                    <h5 class="mb-0"><?= e($ticket->subject) ?></h5>
                </div>
                <div class="card-body">
                    <!-- لیست پیام‌ها -->
                    <div class="messages-container" id="messagesContainer">
                        <?php foreach ($messages as $message): ?>
                        <div class="message-item <?= $message->is_admin ? 'admin-message' : 'user-message' ?>">
                            <div class="message-header">
                                <div class="d-flex align-items-center">
                                    <div class="avatar">
                                        <?= $message->is_admin ? '👨‍💼' : '👤' ?>
                                    </div>
                                    <div class="ml-2">
                                        <strong><?= $message->is_admin ? 'پشتیبانی' : e($message->full_name) ?></strong>
                                        <br>
                                        <small class="text-muted"><?= to_jalali($message->created_at) ?></small>
                                    </div>
                                </div>
                            </div>
                            <div class="message-body">
                                <?= nl2br(e($message->message)) ?>
                            </div>
                            
                            <!-- فایل‌های پیوست -->
                            <?php if ($message->attachments): ?>
                                <?php $attachments = json_decode($message->attachments, true); ?>
                                <?php if (!empty($attachments)): ?>
                                <div class="attachments mt-2">
                                    <?php foreach ($attachments as $file): ?>
                                        <a href="<?= url($file['path']) ?>" target="_blank" class="btn btn-sm btn-outline-primary">
                                            <i class="material-icons">attach_file</i>
                                            <?= e($file['name']) ?>
                                        </a>
                                    <?php endforeach; ?>
                                </div>
                                <?php endif; ?>
                            <?php endif; ?>
                        </div>
                        <?php endforeach; ?>
                    </div>

                    <!-- فرم پاسخ -->
                    <hr>
                    <form id="replyForm">
                        <input type="hidden" name="ticket_id" value="<?= $ticket->id ?>">
                        
                        <div class="form-group">
                            <label>پاسخ:</label>
                            <textarea name="message" class="form-control" rows="4" required></textarea>
                        </div>
                        
                        <button type="submit" class="btn btn-primary">
                            <i class="material-icons">send</i>
                            ارسال پاسخ
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
.messages-container {
    max-height: 500px;
    overflow-y: auto;
    padding: 15px;
    background: #f9f9f9;
    border-radius: 8px;
    margin-bottom: 20px;
}

.message-item {
    background: white;
    padding: 15px;
    border-radius: 8px;
    margin-bottom: 15px;
    box-shadow: 0 2px 5px rgba(0,0,0,0.05);
}

.message-item.admin-message {
    border-right: 4px solid #4fc3f7;
}

.message-item.user-message {
    border-right: 4px solid #4caf50;
}

.message-header {
    margin-bottom: 10px;
}

.avatar {
    font-size: 32px;
    width: 40px;
    height: 40px;
    display: flex;
    align-items: center;
    justify-content: center;
}

.message-body {
    font-size: 14px;
    line-height: 1.6;
}
</style>

<script>
// ارسال پاسخ
document.getElementById('replyForm').addEventListener('submit', function(e) {
    e.preventDefault();
    
    const formData = new FormData(this);
    const data = {
        ticket_id: formData.get('ticket_id'),
        message: formData.get('message')
    };
    
    fetch('<?= url('/admin/tickets/reply') ?>', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'X-CSRF-TOKEN': '<?= csrf_token() ?>'
        },
        body: JSON.stringify(data)
    })
    .then(res => res.json())
    .then(data => {
        if (data.success) {
            notyf.success(data.message);
            setTimeout(() => location.reload(), 1000);
        } else {
            notyf.error(data.message);
        }
    });
});

// تغییر وضعیت
function changeStatus(id) {
    const status = document.getElementById('statusSelect').value;
    
    fetch('<?= url('/admin/tickets/change-status') ?>', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'X-CSRF-TOKEN': '<?= csrf_token() ?>'
        },
        body: JSON.stringify({ id: id, status: status })
    })
    .then(res => res.json())
    .then(data => {
        if (data.success) {
            notyf.success(data.message);
            setTimeout(() => location.reload(), 1000);
        } else {
            notyf.error(data.message);
        }
    });
}
</script>

<?php require_once __DIR__ . '/../../layouts/admin-footer.php'; ?>