<?php
ob_start();
?>
<div class="row g-3 mb-4">
    <div class="col-md-3">
        <div class="card border-start border-success border-3">
            <div class="card-body d-flex justify-content-between align-items-center">
                <div>
                    <small class="text-muted">✅ فعال</small>
                    <h4 class="mb-0">
                        <?= e(fa_digits(\number_format((int)($userStats->active_count ?? 0)))) ?>
                    </h4>
                </div>
                <i class="material-icons text-success" style="font-size: 40px;">check_circle</i>
            </div>
        </div>
    </div>

    <div class="col-md-3">
        <div class="card border-start border-warning border-3">
            <div class="card-body d-flex justify-content-between align-items-center">
                <div>
                    <small class="text-muted">⏸ تعلیق شده</small>
                    <h4 class="mb-0">
                        <?= e(fa_digits(\number_format((int)($userStats->suspended_count ?? 0)))) ?>
                    </h4>
                </div>
                <i class="material-icons text-warning" style="font-size: 40px;">pause_circle</i>
            </div>
        </div>
    </div>

    <div class="col-md-3">
        <div class="card border-start border-danger border-3">
            <div class="card-body d-flex justify-content-between align-items-center">
                <div>
                    <small class="text-muted">🚫 بن شده</small>
                    <h4 class="mb-0">
                        <?= e(fa_number(\number_format((int)($userStats->banned_count ?? 0)))) ?>
                    </h4>
                </div>
                <i class="material-icons text-danger" style="font-size: 40px;">block</i>
            </div>
        </div>
    </div>

    <div class="col-md-3">
        <div class="card border-start border-primary border-3">
            <div class="card-body d-flex justify-content-between align-items-center">
                <div>
                    <small class="text-muted">👥 کل کاربران</small>
                    <h4 class="mb-0">
                        <?= e(fa_number(\number_format((int)($userStats->total_count ?? 0)))) ?>
                    </h4>
                </div>
                <i class="material-icons text-primary" style="font-size: 40px;">groups</i>
            </div>
        </div>
    </div>
</div>

<div class="card">
    <div class="card-header d-flex justify-content-between align-items-center">
        <span>لیست کاربران (<?= number_format($total ?? 0) ?> نفر)</span>
        <a href="<?= url('/admin/users/create') ?>" class="btn btn-primary">
            <span class="material-icons" style="vertical-align: middle; font-size: 18px;">add</span>
            افزودن کاربر
        </a>
    </div>
    
    <div class="card-body">
        <!-- فیلترها -->
        <form method="GET" class="row g-3 mb-4">
            <div class="col-md-4">
                <input type="text" name="search" class="form-control" placeholder="جستجو (نام، ایمیل، موبایل...)" value="<?= e($filters['search'] ?? '') ?>">
            </div>
            <div class="col-md-3">
                <select name="role" class="form-select">
                    <option value="">همه نقش‌ها</option>
                    <option value="user" <?= ($filters['role'] ?? '') == 'user' ? 'selected' : '' ?>>کاربر</option>
                    <option value="support" <?= ($filters['role'] ?? '') == 'support' ? 'selected' : '' ?>>پشتیبان</option>
                    <option value="admin" <?= ($filters['role'] ?? '') == 'admin' ? 'selected' : '' ?>>مدیر</option>
                </select>
            </div>
            <div class="col-md-3">
                <select name="status" class="form-select">
                    <option value="">همه وضعیت‌ها</option>
                    <option value="active" <?= ($filters['status'] ?? '') == 'active' ? 'selected' : '' ?>>فعال</option>
                    <option value="inactive" <?= ($filters['status'] ?? '') == 'inactive' ? 'selected' : '' ?>>غیرفعال</option>
                    <option value="suspended" <?= ($filters['status'] ?? '') == 'suspended' ? 'selected' : '' ?>>تعلیق</option>
                    <option value="banned" <?= ($filters['status'] ?? '') == 'banned' ? 'selected' : '' ?>>بن شده</option>
                </select>
            </div>
            <div class="col-md-2">
                <button type="submit" class="btn btn-secondary w-100">فیلتر</button>
            </div>
        </form>
        
        <!-- جدول -->
        <div class="table-responsive">
            <table class="table table-hover">
                <thead>
                    <tr>
                        <th>شناسه</th>
                        <th>نام و نام خانوادگی</th>
                        <th>ایمیل</th>
                        <th>موبایل</th>
                        <th>نقش</th>
                        <th>وضعیت</th>
                        <th>آخرین ورود</th>
                        <th>عملیات</th>
                    </tr>
                </thead>
                <tbody>
    <?php if (empty($users)): ?>
        <tr>
            <td colspan="8" class="text-center py-4 text-muted">
                هیچ کاربری یافت نشد
            </td>
        </tr>
    <?php else: ?>
        <?php foreach ($users as $userItem): ?>
            <tr>
                <td><?= e($userItem->id) ?></td>
                <td><?= e($userItem->full_name) ?></td>
                <td><?= e($userItem->email) ?></td>
                <td><?= e($userItem->mobile) ?></td>
                <td>
                    <?php
                    $roleColors = ['admin' => 'danger', 'support' => 'warning', 'user' => 'secondary'];
                    $roleNames = ['admin' => 'مدیر', 'support' => 'پشتیبان', 'user' => 'کاربر'];
                    ?>
                    <span class="badge bg-<?= $roleColors[$userItem->role] ?? 'secondary' ?>">
                        <?= $roleNames[$userItem->role] ?? 'کاربر' ?>
                    </span>
                </td>
                <td>
                    <?php
                    $statusColors = ['active' => 'success', 'inactive' => 'secondary', 'suspended' => 'warning', 'banned' => 'danger'];
                    $statusNames = ['active' => 'فعال', 'inactive' => 'غیرفعال', 'suspended' => 'تعلیق', 'banned' => 'بن شده'];
                    ?>
                    <span class="badge bg-<?= $statusColors[$userItem->status] ?? 'secondary' ?>">
                        <?= $statusNames[$userItem->status] ?? 'نامشخص' ?>
                    </span>
                </td>
                <td>
                    <small class="text-muted">
                        <?= $userItem->last_login ? jdate('Y/m/d', strtotime($userItem->last_login)) : 'هرگز' ?>
                    </small>
                </td>
               <td>
  <div class="btn-group btn-group-sm">

    <a href="<?= url('/admin/users/edit/' . $userItem->id) ?>" class="btn btn-outline-primary" title="ویرایش">
      <i class="material-icons" style="font-size:16px;">edit</i>
    </a>

    <!-- ✅ BAN/UNBAN -->
    <button type="button"
            class="btn btn-outline-danger js-user-ban"
            data-id="<?= (int)$userItem->id ?>"
            data-status="<?= e($userItem->status) ?>"
            data-url="<?= url('/admin/users/ban/' . $userItem->id) ?>"
            title="<?= $userItem->status === 'banned' ? 'خارج کردن از بن' : 'بن کردن' ?>">
      <i class="material-icons" style="font-size:16px;"><?= $userItem->status === 'banned' ? 'lock_open' : 'block' ?></i>
    </button>

    <!-- ✅ SUSPEND/UNSUSPEND -->
    <button type="button"
            class="btn btn-outline-warning js-user-suspend"
            data-id="<?= (int)$userItem->id ?>"
            data-status="<?= e($userItem->status) ?>"
            data-url="<?= url('/admin/users/suspend/' . $userItem->id) ?>"
            title="<?= $userItem->status === 'suspended' ? 'برداشتن تعلیق' : 'تعلیق' ?>">
      <i class="material-icons" style="font-size:16px;"><?= $userItem->status === 'suspended' ? 'play_circle' : 'pause_circle' ?></i>
    </button>

    <!-- ✅ DELETE (SOFT) -->
    <button type="button"
            class="btn btn-outline-secondary js-user-delete"
            data-id="<?= (int)$userItem->id ?>"
            data-url="<?= url('/admin/users/delete/' . $userItem->id) ?>"
            title="حذف نرم">
      <i class="material-icons" style="font-size:16px;">delete</i>
    </button>

  </div>
</td>
            </tr>
        <?php endforeach; ?>
    <?php endif; ?>
</tbody>
            </table>
        </div>
        
        <!-- Pagination -->
        <?php if (($totalPages ?? 0) > 1): ?>
            <nav class="mt-4">
                <ul class="pagination justify-content-center">
                    <?php for ($i = 1; $i <= $totalPages; $i++): ?>
                        <li class="page-item <?= $i == $page ? 'active' : '' ?>">
                            <a class="page-link" href="?page=<?= $i ?><?= isset($filters['search']) ? '&search=' . urlencode($filters['search']) : '' ?><?= isset($filters['role']) ? '&role=' . $filters['role'] : '' ?><?= isset($filters['status']) ? '&status=' . $filters['status'] : '' ?>">
                                <?= $i ?>
                            </a>
                        </li>
                    <?php endfor; ?>
                </ul>
            </nav>
        <?php endif; ?>
    </div>
</div>
<script>
console.log('USERS_ACTIONS_V2 LOADED ✅'); // اگر این را در Console ندیدی یعنی JS جدید اصلاً لود نشده

async function postJson(url, payload = {}) {
  const token = '<?= csrf_token() ?>';

  const res = await fetch(url, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'X-CSRF-TOKEN': token
    },
    body: JSON.stringify(Object.assign({_token: token}, payload))
  });

  const text = await res.text();
  let data = null;
  try { data = JSON.parse(text); } catch (e) { data = null; }

  if (!data) {
    console.log('Non-JSON response:', text);
    throw new Error('پاسخ سرور JSON نیست (احتمالاً Route اشتباه است).');
  }

  return data;
}

async function confirmAction(title, text, confirmText) {
  try {
    if (typeof swalConfirm === 'function') {
      const r = await swalConfirm({
        title,
        text,
        confirmButtonText: confirmText,
        cancelButtonText: 'انصراف'
      });
      return r || { isConfirmed: false };
    }
  } catch (e) {
    console.log('swalConfirm error:', e);
  }
  return { isConfirmed: confirm(title + "\n" + text) };
}

document.addEventListener('click', async function(e) {

  const banBtn = e.target.closest('.js-user-ban');
  if (banBtn) {
    e.preventDefault();
    const willBan = (banBtn.dataset.status !== 'banned');

    const c = await confirmAction(
      willBan ? 'بن کردن کاربر' : 'خارج کردن از بن',
      willBan ? 'کاربر مسدود خواهد شد.' : 'کاربر دوباره فعال می‌شود.',
      willBan ? 'بن شود' : 'آزاد شود'
    );
    if (!c.isConfirmed) return;

    try {
      const data = await postJson(banBtn.dataset.url);
      console.log('BAN RESPONSE:', data);

      if (data.success) {
        if (window.notyf) notyf.success(data.message || 'انجام شد');

        // ✅ ریدایرکت قطعی
        window.location.replace(data.redirect || '<?= url('/admin/users') ?>');
      } else {
        if (window.notyf) notyf.error(data.message || 'خطا');
      }
    } catch (err) {
      if (window.notyf) notyf.error(err.message || 'خطا');
    }
    return;
  }

  const susBtn = e.target.closest('.js-user-suspend');
  if (susBtn) {
    e.preventDefault();
    const willSuspend = (susBtn.dataset.status !== 'suspended');

    const c = await confirmAction(
      willSuspend ? 'تعلیق کاربر' : 'برداشتن تعلیق',
      willSuspend ? 'کاربر موقتاً محدود می‌شود.' : 'تعلیق برداشته می‌شود.',
      willSuspend ? 'تعلیق شود' : 'آزاد شود'
    );
    if (!c.isConfirmed) return;

    try {
      const data = await postJson(susBtn.dataset.url);
      console.log('SUSPEND RESPONSE:', data);

      if (data.success) {
        if (window.notyf) notyf.success(data.message || 'انجام شد');
        window.location.replace(data.redirect || '<?= url('/admin/users') ?>');
      } else {
        if (window.notyf) notyf.error(data.message || 'خطا');
      }
    } catch (err) {
      if (window.notyf) notyf.error(err.message || 'خطا');
    }
    return;
  }

  const delBtn = e.target.closest('.js-user-delete');
  if (delBtn) {
    e.preventDefault();

    const c = await confirmAction(
      'حذف کاربر',
      'این کاربر به صورت نرم حذف می‌شود.',
      'حذف شود'
    );
    if (!c.isConfirmed) return;

    try {
      const data = await postJson(delBtn.dataset.url);
      console.log('DELETE RESPONSE:', data);

      if (data.success) {
        if (window.notyf) notyf.success(data.message || 'حذف شد');
        window.location.replace(data.redirect || '<?= url('/admin/users') ?>');
      } else {
        if (window.notyf) notyf.error(data.message || 'خطا');
      }
    } catch (err) {
      if (window.notyf) notyf.error(err.message || 'خطا');
    }
    return;
  }

});
</script>
<?php
$content = ob_get_clean();
require_once __DIR__ . '/../../layouts/admin.php';
?>