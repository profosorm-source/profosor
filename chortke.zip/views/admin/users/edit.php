<?php
$title = 'ویرایش کاربر';
$layout = 'admin';
ob_start();
?>

<div class="card">
    <div class="card-header">
        <h5 class="mb-0">ویرایش کاربر: <?= e($user->full_name) ?></h5>
    </div>
    <div class="card-body">
        <form id="editUserForm">
            <?= csrf_field() ?>

            <div class="row g-3">
                <div class="col-md-6">
                    <label class="form-label">نام کامل <span class="text-danger">*</span></label>
                    <input type="text" name="full_name" class="form-control" 
                           value="<?= e($user->full_name) ?>" required>
                    <div class="invalid-feedback"></div>
                </div>

                <div class="col-md-6">
                    <label class="form-label">ایمیل <span class="text-danger">*</span></label>
                    <input type="email" name="email" class="form-control" 
                           value="<?= e($user->email) ?>" required>
                    <div class="invalid-feedback"></div>
                </div>

                <div class="col-md-6">
                    <label class="form-label">رمز عبور جدید (اختیاری)</label>
                    <input type="password" name="password" class="form-control">
                    <small class="text-muted">خالی بگذارید اگر نمی‌خواهید تغییر دهید</small>
                    <div class="invalid-feedback"></div>
                </div>

                <div class="col-md-6">
                    <label class="form-label">نقش <span class="text-danger">*</span></label>
                    <select name="role" class="form-select" required>
                        <option value="user" <?= $user->role === 'user' ? 'selected' : '' ?>>کاربر</option>
                        <option value="support" <?= $user->role === 'support' ? 'selected' : '' ?>>پشتیبان</option>
                        <option value="admin" <?= $user->role === 'admin' ? 'selected' : '' ?>>مدیر</option>
                    </select>
                    <div class="invalid-feedback"></div>
                </div>

                <div class="col-md-6">
                    <label class="form-label">وضعیت <span class="text-danger">*</span></label>
                    <select name="status" class="form-select" required>
                        <option value="active" <?= $user->status === 'active' ? 'selected' : '' ?>>فعال</option>
                        <option value="inactive" <?= $user->status === 'inactive' ? 'selected' : '' ?>>غیرفعال</option>
                        <option value="suspended" <?= $user->status === 'suspended' ? 'selected' : '' ?>>تعلیق</option>
                        <option value="banned" <?= $user->status === 'banned' ? 'selected' : '' ?>>مسدود</option>
                    </select>
                    <div class="invalid-feedback"></div>
                </div>
            </div>

            <div class="mt-4">
        <button type="submit" class="btn btn-primary">
            <i class="material-icons" style="font-size: 18px; vertical-align: middle;">save</i>
            به‌روزرسانی
        </button>
        <a href="<?= url('/admin/users') ?>" class="btn btn-secondary">انصراف</a>
    </div>
</form>

<script>
document.getElementById('editUserForm').addEventListener('submit', async function(e) {
    e.preventDefault();
    const formData = new FormData(this);
    const data = Object.fromEntries(formData.entries());

    // حذف کلاس‌های خطای قبلی
    document.querySelectorAll('.is-invalid').forEach(el => el.classList.remove('is-invalid'));

    try {
         const response = await fetch('<?= url("/admin/users/" . $user->id . "/update") ?>', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'X-CSRF-TOKEN': data._token
        },
        body: JSON.stringify(data)
    });

    console.log('HTTP status:', response.status); // اضافه شده
    const result = await response.json();
    console.log('Result:', result);

    if (result.success) {
        showToast(result.message, 'success');
        if (result.redirect) {
            setTimeout(() => window.location.href = result.redirect, 1000);
        }
    } else {
        if (result.errors) {
            Object.keys(result.errors).forEach(field => {
                const input = document.querySelector(`[name="${field}"]`);
                if (input) {
                    input.classList.add('is-invalid');
                    input.nextElementSibling.textContent = result.errors[field][0];
                }
            });
        }
        showToast(result.message || 'خطا در به‌روزرسانی', 'error');
    }
} catch (error) {
    console.error(error); // اضافه شده
    showToast('خطا در ارتباط با سرور', 'error');
}
});
</script>
<?php
$content = ob_get_clean();
include __DIR__ . '/../../layouts/' . $layout . '.php';
?>