<?php
$pageTitle = 'تنظیم مجدد رمز عبور';
require_once __DIR__ . '/../layouts/auth.php';
?>

<div class="auth-container">
    <div class="auth-card">
        <div class="auth-header">
            <img src="<?= asset('images/logo.png') ?>" alt="چرتکه" class="auth-logo">
            <h1 class="auth-title">تنظیم مجدد رمز عبور</h1>
            <p class="auth-subtitle">رمز عبور جدید خود را وارد کنید</p>
        </div>

        <?php if (flash('error')): ?>
            <div class="alert alert-danger">
                <i class="material-icons">error</i>
                <?= e(flash('error')) ?>
            </div>
        <?php endif; ?>

        <?php if (flash('success')): ?>
            <div class="alert alert-success">
                <i class="material-icons">check_circle</i>
                <?= e(flash('success')) ?>
            </div>
        <?php endif; ?>

        <form method="POST" action="<?= url('reset-password') ?>" class="auth-form">
            <?= csrf_field() ?>
            
            <input type="hidden" name="token" value="<?= e($token ?? '') ?>">

            <!-- Password -->
            <div class="form-group">
                <label for="password" class="form-label">
                    <i class="material-icons">lock</i>
                    رمز عبور جدید
                </label>
                <div class="password-wrapper">
                    <input type="password" 
                           id="password"
                           name="password" 
                           class="form-control <?= hasError('password') ? 'is-invalid' : '' ?>" 
                           placeholder="رمز عبور جدید (حداقل 8 کاراکتر)"
                           required>
                    <button type="button" class="password-toggle" onclick="togglePassword('password')">
                        <i class="material-icons">visibility</i>
                    </button>
                </div>
                <?php if (hasError('password')): ?>
                    <div class="invalid-feedback">
                        <?= e(error('password')) ?>
                    </div>
                <?php endif; ?>
            </div>

            <!-- Password Confirmation -->
            <div class="form-group">
                <label for="password_confirm" class="form-label">
                    <i class="material-icons">lock_outline</i>
                    تکرار رمز عبور
                </label>
                <div class="password-wrapper">
                    <input type="password" 
                           id="password_confirm"
                           name="password_confirm" 
                           class="form-control <?= hasError('password_confirm') ? 'is-invalid' : '' ?>" 
                           placeholder="رمز عبور را مجدداً وارد کنید"
                           required>
                    <button type="button" class="password-toggle" onclick="togglePassword('password_confirm')">
                        <i class="material-icons">visibility</i>
                    </button>
                </div>
                <?php if (hasError('password_confirm')): ?>
                    <div class="invalid-feedback">
                        <?= e(error('password_confirm')) ?>
                    </div>
                <?php endif; ?>
            </div>

            <!-- Submit Button -->
            <button type="submit" class="btn btn-primary btn-block btn-auth">
                <span class="btn-text">تنظیم رمز عبور</span>
                <i class="material-icons">check</i>
            </button>

            <!-- Back to Login -->
            <div class="auth-footer">
                <p>
                    <a href="<?= url('login') ?>" class="register-link">
                        بازگشت به صفحه ورود
                    </a>
                </p>
            </div>
        </form>
    </div>
</div>

<script>
function togglePassword(fieldId) {
    const field = document.getElementById(fieldId);
    const icon = event.currentTarget.querySelector('i');
    
    if (field.type === 'password') {
        field.type = 'text';
        icon.textContent = 'visibility_off';
    } else {
        field.type = 'password';
        icon.textContent = 'visibility';
    }
}
</script>

<style>
.password-wrapper {
    position: relative;
}

.password-toggle {
    position: absolute;
    left: 10px;
    top: 50%;
    transform: translateY(-50%);
    background: none;
    border: none;
    cursor: pointer;
    padding: 5px;
    color: #666;
    transition: color 0.3s;
}

.password-toggle:hover {
    color: #007bff;
}

.password-toggle i {
    font-size: 20px;
}

.btn-auth {
    display: flex;
    justify-content: center;
    align-items: center;
    gap: 0.5rem;
    padding: 0.75rem;
    font-size: 1rem;
    font-weight: 600;
}

.auth-footer {
    text-align: center;
    margin-top: 1.5rem;
    padding-top: 1.5rem;
    border-top: 1px solid #e0e0e0;
}

.register-link {
    color: #007bff;
    text-decoration: none;
    font-weight: 600;
    transition: color 0.3s;
}

.register-link:hover {
    color: #0056b3;
    text-decoration: underline;
}
</style>