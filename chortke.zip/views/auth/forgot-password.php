<?php
use Core\Session;
$session = Session::getInstance();
$errors = $session->getFlash('errors') ?? [];
$old = $session->getFlash('old') ?? [];

ob_start();
?>

<div class="auth-card">
    <div class="auth-header">
        <h3>🎯 چرتکه</h3>
        <p>بازیابی رمز عبور</p>
    </div>
    
    <div class="auth-body">
        <?php if ($session->hasFlash('error')): ?>
            <div class="alert alert-danger">
                <?= e($session->getFlash('error')) ?>
            </div>
        <?php endif; ?>
        
        <?php if ($session->hasFlash('success')): ?>
            <div class="alert alert-success">
                <?= e($session->getFlash('success')) ?>
            </div>
        <?php endif; ?>
        
        <div class="alert alert-info">
            لینک بازیابی رمز عبور به ایمیل شما ارسال خواهد شد.
        </div>
        
        <form method="POST" action="<?= url('/forgot-password') ?>">
            <?= csrf_field() ?>
            
            <div class="form-group">
                <label class="form-label">ایمیل</label>
                <input type="email" name="email" class="form-control <?= isset($errors['email']) ? 'is-invalid' : '' ?>" value="<?= e($old['email'] ?? '') ?>" required autofocus>
                <?php if (isset($errors['email'])): ?>
                    <div class="invalid-feedback"><?= e($errors['email'][0]) ?></div>
                <?php endif; ?>
            </div>
            
            <button type="submit" class="btn btn-primary">
                ارسال لینک بازیابی
            </button>
        </form>
    </div>
    
    <div class="auth-footer">
        <a href="<?= url('/login') ?>">بازگشت به صفحه ورود</a>
    </div>
</div>

<?php
$content = ob_get_clean();
require_once __DIR__ . '/../layouts/auth.php';
?>