<!DOCTYPE html>
<html dir="rtl" lang="fa">
<head>
    <meta charset="UTF-8">
    <style>
        body {
            font-family: Tahoma, Arial, sans-serif;
            direction: rtl;
            text-align: right;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }
        .container {
            max-width: 600px;
            margin: 20px auto;
            background: white;
            border-radius: 10px;
            overflow: hidden;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        .header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 40px 20px;
            text-align: center;
        }
        .header h1 {
            margin: 0;
            font-size: 28px;
        }
        .content {
            padding: 40px 30px;
            line-height: 1.8;
        }
        .button {
            display: inline-block;
            background: #667eea;
            color: white !important;
            padding: 15px 40px;
            text-decoration: none;
            border-radius: 8px;
            margin: 20px 0;
            font-weight: bold;
        }
        .button:hover {
            background: #5568d3;
        }
        .footer {
            background: #f9f9f9;
            padding: 20px;
            text-align: center;
            color: #999;
            font-size: 12px;
        }
        .warning {
            background: #fff3cd;
            border-right: 4px solid #ffc107;
            padding: 15px;
            margin: 20px 0;
            border-radius: 5px;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>چرتکه</h1>
            <p>تایید ایمیل</p>
        </div>
        
        <div class="content">
            <h2>سلام <?= e($username) ?>!</h2>
            
            <p>
                از اینکه به جمع چرتکه پیوستید خوشحالیم! 🎉
            </p>
            
            <p>
                برای تکمیل ثبت‌نام و فعالسازی حساب کاربری خود، 
                لطفاً روی دکمه زیر کلیک کنید:
            </p>
            
            <div style="text-align: center;">
                <a href="<?= e($verification_url) ?>" class="button">
                    تایید ایمیل
                </a>
            </div>
            
            <p style="color: #999; font-size: 12px;">
                اگر دکمه کار نکرد، لینک زیر را کپی کرده و در مرورگر باز کنید:
                <br>
                <a href="<?= e($verification_url) ?>"><?= e($verification_url) ?></a>
            </p>
            
            <div class="warning">
                <strong>⚠️ توجه:</strong>
                اگر شما درخواست ثبت‌نام نداده‌اید، این ایمیل را نادیده بگیرید.
            </div>
        </div>
        
        <div class="footer">
            <p>&copy; <?= date('Y') ?> چرتکه. تمامی حقوق محفوظ است.</p>
            <p>این ایمیل به صورت خودکار ارسال شده است، لطفاً پاسخ ندهید.</p>
        </div>
    </div>
</body>
</html>