<!DOCTYPE html>
<html dir="rtl" lang="fa">
<head>
    <meta charset="UTF-8">
    <style>
        body { font-family: Tahoma; direction: rtl; background: #f4f4f4; margin: 0; padding: 0; }
        .container { max-width: 600px; margin: 20px auto; background: white; border-radius: 10px; overflow: hidden; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
        .header { background: linear-gradient(135deg, #10b981 0%, #059669 100%); color: white; padding: 40px 20px; text-align: center; }
        .content { padding: 40px 30px; line-height: 1.8; }
        .footer { background: #f9f9f9; padding: 20px; text-align: center; color: #999; font-size: 12px; }
        .success-icon { font-size: 60px; }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <div class="success-icon">✅</div>
            <h1>احراز هویت تأیید شد</h1>
        </div>
        
        <div class="content">
            <h2>تبریک <?= e($username) ?>!</h2>
            
            <p>
                مدارک احراز هویت شما با موفقیت بررسی و تأیید شد.
            </p>
            
            <p>
                حالا می‌توانید از تمام امکانات سایت استفاده کنید:
            </p>
            
            <ul>
                <li>برداشت وجه بدون محدودیت</li>
                <li>افزایش سقف تراکنش‌ها</li>
                <li>دسترسی به سرمایه‌گذاری</li>
                <li>شرکت در قرعه‌کشی‌ها</li>
            </ul>
            
            <p><strong>تاریخ تأیید:</strong> <?= date('Y/m/d H:i') ?></p>
        </div>
        
        <div class="footer">
            <p>&copy; <?= date('Y') ?> چرتکه</p>
        </div>
    </div>
</body>
</html>