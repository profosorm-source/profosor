<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>404 - صفحه یافت نشد</title>
    <link href="https://fonts.googleapis.com/css2?family=Vazirmatn:wght@300;400;700&display=swap" rel="stylesheet">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Vazirmatn', sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
        }
        
        .container {
            text-align: center;
            padding: 40px;
        }
        
        .error-code {
            font-size: 150px;
            font-weight: 700;
            line-height: 1;
            margin-bottom: 20px;
            text-shadow: 4px 4px 10px rgba(0,0,0,0.2);
        }
        
        h1 {
            font-size: 36px;
            margin-bottom: 15px;
        }
        
        p {
            font-size: 18px;
            margin-bottom: 30px;
            opacity: 0.9;
        }
        
        .btn {
            display: inline-block;
            padding: 15px 40px;
            background: white;
            color: #667eea;
            text-decoration: none;
            border-radius: 50px;
            font-weight: 500;
            transition: all 0.3s;
            box-shadow: 0 4px 15px rgba(0,0,0,0.2);
        }
        
        .btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(0,0,0,0.3);
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="error-code">404</div>
        <h1>صفحه یافت نشد</h1>
        <p>متأسفانه صفحه‌ای که دنبال آن می‌گردید یافت نشد.</p>
        <a href="<?= url('/') ?>" class="btn">بازگشت به صفحه اصلی</a>
    </div>
</body>
</html>