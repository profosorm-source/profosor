<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>در حال تعمیر - <?= setting('site_name', 'چرتکه') ?></title>
    <link href="https://fonts.googleapis.com/css2?family=Vazirmatn:wght@300;400;500;700&display=swap" rel="stylesheet">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Vazirmatn', sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            color: #fff;
        }
        
        .container {
            text-align: center;
            padding: 40px;
            max-width: 600px;
        }
        
        .icon {
            font-size: 120px;
            margin-bottom: 30px;
            animation: bounce 2s infinite;
        }
        
        @keyframes bounce {
            0%, 100% { transform: translateY(0); }
            50% { transform: translateY(-20px); }
        }
        
        h1 {
            font-size: 48px;
            margin-bottom: 20px;
            font-weight: 700;
        }
        
        p {
            font-size: 20px;
            margin-bottom: 30px;
            opacity: 0.9;
        }
        
        .loader {
            display: inline-block;
            width: 50px;
            height: 50px;
            border: 4px solid rgba(255,255,255,0.3);
            border-top-color: #fff;
            border-radius: 50%;
            animation: spin 1s linear infinite;
        }
        
        @keyframes spin {
            to { transform: rotate(360deg); }
        }
        
        .contact {
            margin-top: 40px;
            padding: 20px;
            background: rgba(255,255,255,0.1);
            border-radius: 10px;
        }
        
        .contact p {
            font-size: 16px;
            margin: 5px 0;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="icon">🔧</div>
        <h1>در حال بروزرسانی</h1>
        <p><?= e($message ?? 'سایت در حال تعمیر و بهبود است...') ?></p>
        <div class="loader"></div>
        
        <div class="contact">
            <p><strong>در صورت نیاز با ما در تماس باشید:</strong></p>
            <?php if (setting('telegram_support')): ?>
                <p>📱 تلگرام: <?= e(setting('telegram_support')) ?></p>
            <?php endif; ?>
            <?php if (setting('contact_email')): ?>
                <p>✉️ ایمیل: <?= e(setting('contact_email')) ?></p>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>