<?php ob_start(); ?>

<div class="container">
    <div class="row min-vh-100 align-items-center justify-content-center">
        <div class="col-md-6 text-center">
            <div class="card border-0 shadow-lg">
                <div class="card-body p-5">
                    <i class="material-icons-outlined text-danger" style="font-size: 120px;">block</i>
                    <h1 class="display-1 fw-bold text-danger">403</h1>
                    <h3 class="mb-3">دسترسی غیرمجاز</h3>
                    <p class="text-muted mb-4">شما اجازه دسترسی به این صفحه را ندارید.</p>
                    
                    <a href="<?= url('/') ?>" class="btn btn-primary btn-lg">
                        <i class="material-icons-outlined">home</i>
                        بازگشت به صفحه اصلی
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>

<?php
$content = ob_get_clean();
$layout = __DIR__ . '/../layouts/app.php';
require $layout;
?>