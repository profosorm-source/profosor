<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>429 - درخواست‌های بیش از حد</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: 'Segoe UI', Tahoma, Arial, sans-serif;
            background: linear-gradient(135deg, #fa709a 0%, #fee140 100%);
            display: flex;
            align-items: center;
            justify-content: center;
            min-height: 100vh;
            color: #333;
        }
        .container {
            background: white;
            padding: 60px 50px;
            border-radius: 20px;
            box-shadow: 0 20px 60px rgba(0,0,0,0.3);
            text-align: center;
            max-width: 500px;
        }
        h1 {
            font-size: 96px;
            color: #fa709a;
            margin-bottom: 20px;
            font-weight: bold;
        }
        h2 {
            color: #555;
            margin-bottom: 15px;
            font-size: 24px;
        }
        p {
            color: #777;
            line-height: 1.6;
            margin-bottom: 30px;
        }
        #countdown {
            font-size: 48px;
            color: #fa709a;
            font-weight: bold;
            margin: 20px 0;
        }
        .btn {
            display: inline-block;
            padding: 12px 30px;
            background: #fa709a;
            color: white;
            text-decoration: none;
            border-radius: 25px;
            transition: all 0.3s;
            font-size: 16px;
        }
        .btn:hover {
            background: #fee140;
            color: #333;
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(250, 112, 154, 0.4);
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>429</h1>
        <h2>⏳ تعداد درخواست‌ها بیش از حد</h2>
        <p>
            شما درخواست‌های بسیار زیادی ارسال کرده‌اید.<br>
            لطفاً کمی صبر کنید.
        </p>
        <div id="countdown">60</div>
        <p>ثانیه تا امکان درخواست مجدد</p>
        <a href="/" class="btn">🏠 بازگشت به صفحه اصلی</a>
    </div>

    <script>
        let seconds = 60;
        const countdown = document.getElementById('countdown');
        
        setInterval(() => {
            seconds--;
            countdown.textContent = seconds;
            
            if (seconds <= 0) {
                location.reload();
            }
        }, 1000);
    </script>
</body>
</html>