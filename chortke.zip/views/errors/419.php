<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>419 - توکن امنیتی نامعتبر</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: 'Segoe UI', Tahoma, Arial, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            display: flex;
            align-items: center;
            justify-content: center;
            min-height: 100vh;
            color: #333;
        }
        .container {
            background: white;
            padding: 50px;
            border-radius: 20px;
            box-shadow: 0 20px 60px rgba(0,0,0,0.3);
            text-align: center;
            max-width: 500px;
        }
        h1 {
            font-size: 72px;
            color: #e74c3c;
            margin-bottom: 20px;
        }
        h2 {
            color: #555;
            margin-bottom: 15px;
        }
        p {
            color: #777;
            line-height: 1.6;
            margin-bottom: 30px;
        }
        .btn {
            display: inline-block;
            padding: 12px 30px;
            background: #667eea;
            color: white;
            text-decoration: none;
            border-radius: 25px;
            transition: all 0.3s;
        }
        .btn:hover {
            background: #764ba2;
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(102, 126, 234, 0.4);
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>419</h1>
        <h2>توکن امنیتی نامعتبر</h2>
        <p>
            نشست شما منقضی شده است یا توکن امنیتی نامعتبر است.<br>
            لطفاً صفحه را رفرش کنید و دوباره تلاش کنید.
        </p>
        <a href="javascript:location.reload()" class="btn">🔄 رفرش صفحه</a>
    </div>
</body>
</html>