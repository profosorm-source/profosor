<?php
$title = 'سفارش‌های پیج من (اینفلوئنسر)';
$layout = 'user';
ob_start();

$statusLabels = story_order_status_labels_map();
$statusClasses = story_order_status_classes_map();
$minPublish = (int) setting('story_min_publish_hours', 24);
?>

<div class="content-header">
    <div class="d-flex justify-content-between align-items-center">
        <div>
            <h4 class="page-title mb-1"><i class="material-icons text-primary">campaign</i> سفارش‌های پیج من</h4>
            <p class="text-muted mb-0" style="font-size:12px;">پذیرش/رد سفارش و ارسال مدرک انتشار</p>
        </div>
        <a href="<?= url('/user/stories/register') ?>" class="btn btn-outline-secondary btn-sm">
            <i class="material-icons" style="font-size:16px;vertical-align:middle;">badge</i> وضعیت پیج من
        </a>
    </div>
</div>

<div class="alert mt-3" style="background:linear-gradient(135deg,#fff3e0 0%,#ffe0b2 100%);border-right:4px solid #ffa726;">
    <div style="font-size:12px;color:#e65100;">
        <i class="material-icons" style="font-size:16px;vertical-align:middle;color:#f57c00;">warning</i>
        کد تأیید هر سفارش باید داخل استوری/پست درج شود. مدرک معتبر: اسکرین‌شات از آرشیو اینستاگرام که کد داخل آن مشخص باشد.
        حداقل مدت نمایش: <strong><?= $minPublish ?></strong> ساعت.
    </div>
</div>

<div class="card mt-3 mb-4">
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table table-hover mb-0" style="font-size:12px;">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>تبلیغ‌دهنده</th>
                        <th>نوع</th>
                        <th>مدت</th>
                        <th>کد</th>
                        <th>مبلغ</th>
                        <th>وضعیت</th>
                        <th>تاریخ</th>
                        <th>عملیات</th>
                    </tr>
                </thead>
                <tbody>
                <?php if (empty($orders)): ?>
                    <tr><td colspan="9" class="text-center text-muted py-4">سفارشی ندارید.</td></tr>
                <?php else: ?>
                    <?php foreach ($orders as $idx => $o): ?>
                    <tr>
                        <td class="text-muted"><?= $idx + 1 ?></td>
                        <td><?= e($o->customer_name ?? '—') ?></td>
                        <td><?= $o->order_type === 'story' ? 'استوری' : 'پست موقت' ?></td>
                        <td><?= (int)$o->duration_hours ?> ساعت</td>
                        <td><code dir="ltr"><?= e($o->verification_code) ?></code></td>
                        <td>
                            <strong class="text-success">
                                <?= $o->currency === 'usdt' ? number_format($o->price, 2) . ' USDT' : number_format($o->price) . ' تومان' ?>
                            </strong>
                        </td>
                        <td><span class="badge <?= $statusClasses[$o->status] ?? '' ?>"><?= e($statusLabels[$o->status] ?? $o->status) ?></span></td>
                        <td style="font-size:10px;"><?= to_jalali($o->created_at ?? '') ?></td>
                        <td>
                            <?php if ($o->status === 'paid'): ?>
                                <button class="btn btn-sm btn-success btn-respond" data-id="<?= $o->id ?>" data-action="accept">
                                    <i class="material-icons" style="font-size:14px;">check</i>
                                </button>
                                <button class="btn btn-sm btn-danger btn-respond" data-id="<?= $o->id ?>" data-action="reject">
                                    <i class="material-icons" style="font-size:14px;">close</i>
                                </button>
                            <?php elseif (\in_array($o->status, ['accepted','published'], true)): ?>
                                <button class="btn btn-sm btn-primary btn-proof" data-id="<?= $o->id ?>">
                                    <i class="material-icons" style="font-size:14px;">upload</i> ارسال مدرک
                                </button>
                            <?php elseif ($o->status === 'proof_submitted'): ?>
                                <span class="text-muted" style="font-size:11px;">مدرک ارسال شد</span>
                            <?php else: ?>
                                <span class="text-muted">—</span>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Modal Proof -->
<div class="modal fade" id="proofModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h6 class="modal-title">
                    <i class="material-icons text-primary" style="vertical-align:middle;">upload</i>
                    ارسال مدرک انتشار
                </h6>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form id="proofForm" enctype="multipart/form-data">
                <div class="modal-body">
                    <input type="hidden" id="order-id" value="">

                    <div class="mb-3">
                        <label class="form-label">اسکرین‌شات آرشیو (اجباری)</label>
                        <input type="file" name="proof_screenshot" id="proof_screenshot" class="form-control" accept="image/*" required>
                        <small class="text-muted">کد تأیید باید داخل استوری/پست دیده شود.</small>
                    </div>

                    <div class="mb-3">
                        <label class="form-label">زمان واقعی انتشار (اختیاری)</label>
                        <input type="datetime-local" name="actual_publish_time" id="actual_publish_time" class="form-control">
                    </div>

                    <div class="alert mb-0" style="background:#f5f5f5;border:none;font-size:12px;">
                        اگر مدرک ناقص باشد یا کد تأیید داخل آن نباشد، سفارش رد می‌شود.
                    </div>
                </div>

                <div class="modal-footer">
                    <button type="button" class="btn btn-outline-secondary btn-sm" data-bs-dismiss="modal">انصراف</button>
                    <button type="submit" class="btn btn-primary btn-sm" id="btn-send-proof">
                        <i class="material-icons" style="font-size:16px;vertical-align:middle;">send</i>
                        ارسال
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    var proofModal = new bootstrap.Modal(document.getElementById('proofModal'));

    document.querySelectorAll('.btn-respond').forEach(function(btn) {
        btn.addEventListener('click', function() {
            var orderId = this.dataset.id;
            var action = this.dataset.action;

            if (action === 'reject') {
                Swal.fire({
                    title: 'رد سفارش',
                    input: 'text',
                    inputLabel: 'دلیل رد:',
                    showCancelButton: true,
                    confirmButtonColor: '#f44336',
                    confirmButtonText: 'رد سفارش',
                    cancelButtonText: 'انصراف',
                    inputValidator: function(v){ if(!v) return 'دلیل را وارد کنید'; }
                }).then(function(result){
                    if(result.isConfirmed) sendRespond(orderId, 'reject', result.value);
                });
            } else {
                Swal.fire({
                    title: 'پذیرش سفارش',
                    text: 'با پذیرش سفارش، موظف به انتشار و ارسال مدرک معتبر خواهید بود.',
                    icon: 'question',
                    showCancelButton: true,
                    confirmButtonText: 'می‌پذیرم',
                    cancelButtonText: 'انصراف'
                }).then(function(result){
                    if(result.isConfirmed) sendRespond(orderId, 'accept', null);
                });
            }
        });
    });

    function sendRespond(orderId, decision, reason) {
        fetch('<?= url('/user/stories/respond-order') ?>', {
            method: 'POST',
            headers: {'X-Requested-With':'XMLHttpRequest','Content-Type':'application/json','X-CSRF-TOKEN':'<?= csrf_token() ?>'},
            body: JSON.stringify({csrf_token:'<?= csrf_token() ?>', order_id: orderId, decision: decision, reason: reason})
        })
        .then(r => r.json())
        .then(function(data){
            var notyf = new Notyf({duration: 3000, position: {x:'left',y:'top'}});
            if (data.success) { notyf.success(data.message); setTimeout(() => location.reload(), 1200); }
            else notyf.error(data.message);
        });
    }

    document.querySelectorAll('.btn-proof').forEach(function(btn) {
        btn.addEventListener('click', function() {
            document.getElementById('order-id').value = this.dataset.id;
            document.getElementById('proof_screenshot').value = '';
            document.getElementById('actual_publish_time').value = '';
            proofModal.show();
        });
    });

    document.getElementById('proofForm').addEventListener('submit', function(e) {
        e.preventDefault();

        var orderId = document.getElementById('order-id').value;
        var fileEl = document.getElementById('proof_screenshot');

        if (!fileEl.files.length) {
            var notyf = new Notyf({duration: 3000, position: {x:'left',y:'top'}});
            notyf.error('اسکرین‌شات اجباری است.');
            return;
        }

        var formData = new FormData(this);
        formData.append('csrf_token', '<?= csrf_token() ?>');

        var btn = document.getElementById('btn-send-proof');
        btn.disabled = true;
        btn.innerHTML = '<span class="spinner-border spinner-border-sm"></span>';

        fetch('<?= url('/user/stories/') ?>' + orderId + '/submit-proof', {
            method: 'POST',
            headers: {'X-Requested-With':'XMLHttpRequest','X-CSRF-TOKEN':'<?= csrf_token() ?>'},
            body: formData
        })
        .then(r => r.json())
        .then(function(data){
            var notyf = new Notyf({duration: 3500, position: {x:'left',y:'top'}});
            if (data.success) {
                notyf.success(data.message);
                proofModal.hide();
                setTimeout(() => location.reload(), 1200);
            } else {
                notyf.error(data.message);
                btn.disabled = false;
                btn.innerHTML = '<i class="material-icons" style="font-size:16px;vertical-align:middle;">send</i> ارسال';
            }
        })
        .catch(function(){
            var notyf = new Notyf({duration: 3500, position: {x:'left',y:'top'}});
            notyf.error('خطا در ارتباط');
            btn.disabled = false;
            btn.innerHTML = '<i class="material-icons" style="font-size:16px;vertical-align:middle;">send</i> ارسال';
        });
    });
});
</script>

<?php
$content = ob_get_clean();
include __DIR__ . '/../../layouts/' . $layout . '.php';
?>