<?php
$title = 'تبلیغات استوری و پست';
$layout = 'user';
ob_start();

$currencyMode = setting('currency_mode', 'irt');
$currencyLabel = $currencyMode === 'usdt' ? 'USDT' : 'تومان';
?>

<div class="content-header">
    <div class="d-flex justify-content-between align-items-center">
        <div>
            <h4 class="page-title mb-1">
                <i class="material-icons text-primary">camera_alt</i>
                تبلیغات استوری و پست
            </h4>
            <p class="text-muted mb-0" style="font-size:12px;">صفحات تأییدشده را انتخاب کنید و سفارش ثبت کنید</p>
        </div>
        <div class="d-flex gap-2">
            <a href="<?= url('/user/stories/my-orders') ?>" class="btn btn-outline-secondary btn-sm">
                <i class="material-icons" style="font-size:16px;vertical-align:middle;">receipt_long</i>
                سفارش‌های من
            </a>
            <a href="<?= url('/user/stories/register') ?>" class="btn btn-primary btn-sm">
                <i class="material-icons" style="font-size:16px;vertical-align:middle;">add</i>
                ثبت پیج برای درآمد
            </a>
        </div>
    </div>
</div>

<div class="card mt-3">
    <div class="card-body">
        <form method="GET" action="<?= url('/user/stories/influencers') ?>">
            <div class="row">
                <div class="col-md-3 mb-2">
                    <input type="text" name="search" class="form-control form-control-sm"
                           placeholder="جستجو (یوزرنیم/توضیحات)" value="<?= e($filters['search'] ?? '') ?>">
                </div>
                <div class="col-md-2 mb-2">
                    <select name="category" class="form-select form-select-sm">
                        <option value="">همه دسته‌ها</option>
                        <?php foreach ($categories as $cat): ?>
                            <?php $cat = trim($cat); ?>
                            <option value="<?= e($cat) ?>" <?= ($filters['category'] ?? '') === $cat ? 'selected' : '' ?>>
                                <?= e($cat) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-md-2 mb-2">
                    <input type="number" name="min_followers" class="form-control form-control-sm"
                           placeholder="حداقل فالوور" value="<?= e($filters['min_followers'] ?? '') ?>">
                </div>
                <div class="col-md-2 mb-2">
                    <input type="number" name="max_price" class="form-control form-control-sm"
                           placeholder="حداکثر قیمت استوری" value="<?= e($filters['max_price'] ?? '') ?>">
                </div>
                <div class="col-md-2 mb-2">
                    <select name="sort" class="form-select form-select-sm">
                        <option value="priority" <?= ($sort ?? 'priority') === 'priority' ? 'selected' : '' ?>>پیشنهادی</option>
                        <option value="followers" <?= ($sort ?? '') === 'followers' ? 'selected' : '' ?>>فالوور بیشتر</option>
                        <option value="price_low" <?= ($sort ?? '') === 'price_low' ? 'selected' : '' ?>>ارزان‌تر</option>
                        <option value="price_high" <?= ($sort ?? '') === 'price_high' ? 'selected' : '' ?>>گران‌تر</option>
                        <option value="orders" <?= ($sort ?? '') === 'orders' ? 'selected' : '' ?>>سفارش بیشتر</option>
                        <option value="rating" <?= ($sort ?? '') === 'rating' ? 'selected' : '' ?>>امتیاز بالاتر</option>
                    </select>
                </div>
                <div class="col-md-1 mb-2">
                    <button class="btn btn-primary btn-sm w-100">فیلتر</button>
                </div>
            </div>
        </form>
    </div>
</div>

<div class="alert mt-3" style="background:linear-gradient(135deg,#fff3e0 0%,#ffe0b2 100%);border-right:4px solid #ffa726;">
    <div style="font-size:12px;color:#e65100;">
        <i class="material-icons" style="font-size:16px;vertical-align:middle;color:#f57c00;">info</i>
        برای جلوگیری از تقلب، هنگام سفارش یک <strong>کد تأیید (CK-XXXXXX)</strong> تولید می‌شود و اینفلوئنسر موظف است آن را داخل استوری/پست قرار دهد.
    </div>
</div>

<div class="row mt-3">
    <?php if (empty($profiles)): ?>
        <div class="col-12">
            <div class="card">
                <div class="card-body text-center py-5">
                    <i class="material-icons" style="font-size:60px;opacity:0.2;">person_search</i>
                    <p class="text-muted mt-2 mb-0">صفحه‌ای یافت نشد.</p>
                </div>
            </div>
        </div>
    <?php else: ?>
        <?php foreach ($profiles as $p): ?>
            <?php
            $avatar = null;
            if (!empty($p->profile_image)) {
                $avatar = url('/file/view/influencer-profiles/' . \basename($p->profile_image));
            }
            ?>
            <div class="col-lg-3 col-md-4 col-sm-6 mb-3">
                <div class="card h-100" style="transition:all 0.3s ease;">
                    <div class="card-body text-center">
                        <div style="width:84px;height:84px;border-radius:50%;margin:0 auto 10px;overflow:hidden;border:2px solid #ffa726;background:#f5f5f5;">
                            <?php if ($avatar): ?>
                                <img src="<?= e($avatar) ?>" alt="avatar" style="width:100%;height:100%;object-fit:cover;">
                            <?php else: ?>
                                <div style="width:100%;height:100%;display:flex;align-items:center;justify-content:center;">
                                    <i class="material-icons" style="font-size:40px;opacity:0.35;">person</i>
                                </div>
                            <?php endif; ?>
                        </div>

                        <div style="font-weight:bold;font-size:14px;" dir="ltr">@<?= e($p->username) ?></div>
                        <div class="text-muted" style="font-size:11px;"><?= e($p->category ?? '—') ?></div>

                        <div class="mt-2" style="font-size:12px;">
                            <span class="badge bg-info"><?= number_format($p->follower_count) ?> فالوور</span>
                            <?php if (!empty($p->engagement_rate)): ?>
                                <span class="badge bg-secondary"><?= e($p->engagement_rate) ?>% تعامل</span>
                            <?php endif; ?>
                        </div>

                        <div class="mt-2 p-2 rounded" style="background:#f8f9fa;font-size:12px;">
                            استوری 24h:
                            <strong class="text-success">
                                <?= $currencyMode === 'usdt' ? number_format($p->story_price_24h, 2) . ' USDT' : number_format($p->story_price_24h) . ' تومان' ?>
                            </strong>
                        </div>

                        <div class="mt-2 d-grid gap-2">
                            <a href="<?= url('/user/stories/create-order?influencer=' . (int)$p->id) ?>" class="btn btn-primary btn-sm">
                                ثبت سفارش
                            </a>
                            <a href="<?= e($p->page_url) ?>" target="_blank" rel="noopener" class="btn btn-outline-secondary btn-sm">
                                مشاهده پیج
                            </a>
                        </div>

                        <?php if (!empty($p->bio)): ?>
                            <p class="text-muted mt-2 mb-0" style="font-size:11px;line-height:1.6;max-height:52px;overflow:hidden;">
                                <?= e(\mb_substr($p->bio, 0, 120)) ?><?= \mb_strlen($p->bio) > 120 ? '...' : '' ?>
                            </p>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
    <?php endif; ?>
</div>

<?php if (($pages ?? 1) > 1): ?>
<div class="d-flex justify-content-center mt-2 mb-4">
    <nav>
        <ul class="pagination pagination-sm mb-0">
            <?php for ($i = 1; $i <= \min((int)$pages, 20); $i++): ?>
            <li class="page-item <?= $i === (int)$page ? 'active' : '' ?>">
                <a class="page-link" href="<?= url('/user/stories/influencers?page=' . $i) ?>"><?= $i ?></a>
            </li>
            <?php endfor; ?>
        </ul>
    </nav>
</div>
<?php endif; ?>

<?php
$content = ob_get_clean();
include __DIR__ . '/../../layouts/' . $layout . '.php';
?>