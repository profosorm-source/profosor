<?php
$title = 'سفارش‌های من';
$layout = 'user';
ob_start();

$statusLabels = story_order_status_labels_map();
$statusClasses = story_order_status_classes_map();
?>

<div class="content-header">
    <div class="d-flex justify-content-between align-items-center">
        <div>
            <h4 class="page-title mb-1"><i class="material-icons text-primary">receipt_long</i> سفارش‌های من</h4>
            <p class="text-muted mb-0" style="font-size:12px;">وضعیت سفارش‌ها و کدهای تأیید</p>
        </div>
        <a href="<?= url('/user/stories/influencers') ?>" class="btn btn-primary btn-sm">
            <i class="material-icons" style="font-size:16px;vertical-align:middle;">add</i> سفارش جدید
        </a>
    </div>
</div>

<div class="card mt-3 mb-4">
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table table-hover mb-0" style="font-size:12px;">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>اینفلوئنسر</th>
                        <th>نوع</th>
                        <th>مدت</th>
                        <th>کد تأیید</th>
                        <th>مبلغ</th>
                        <th>وضعیت</th>
                        <th>تاریخ</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($orders)): ?>
                    <tr><td colspan="8" class="text-center text-muted py-4">سفارشی ثبت نشده است.</td></tr>
                    <?php else: ?>
                    <?php foreach ($orders as $idx => $o): ?>
                    <tr>
                        <td class="text-muted"><?= $idx + 1 ?></td>
                        <td dir="ltr">@<?= e($o->influencer_username ?? '—') ?></td>
                        <td><?= $o->order_type === 'story' ? 'استوری' : 'پست موقت' ?></td>
                        <td><?= (int)$o->duration_hours ?> ساعت</td>
                        <td><code dir="ltr"><?= e($o->verification_code ?? '—') ?></code></td>
                        <td>
                            <strong class="text-success">
                                <?= $o->currency === 'usdt' ? number_format($o->price, 2) . ' USDT' : number_format($o->price) . ' تومان' ?>
                            </strong>
                        </td>
                        <td><span class="badge <?= $statusClasses[$o->status] ?? '' ?>"><?= e($statusLabels[$o->status] ?? $o->status) ?></span></td>
                        <td style="font-size:10px;"><?= to_jalali($o->created_at ?? '') ?></td>
                    </tr>
                    <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php
$content = ob_get_clean();
include __DIR__ . '/../../layouts/' . $layout . '.php';
?>