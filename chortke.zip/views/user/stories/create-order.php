<?php
$title = 'ثبت سفارش تبلیغ';
$layout = 'user';
$session = \Core\Session::getInstance();
$currencyMode = setting('currency_mode', 'irt');
$currencyLabel = $currencyMode === 'usdt' ? 'USDT' : 'تومان';
$minPublish = (int) setting('story_min_publish_hours', 24);
ob_start();

$avatar = null;
if (!empty($profile->profile_image)) {
    $avatar = url('/file/view/influencer-profiles/' . \basename($profile->profile_image));
}
?>

<div class="content-header">
    <div class="d-flex justify-content-between align-items-center">
        <div>
            <h4 class="page-title mb-1">
                <i class="material-icons text-primary">add_photo_alternate</i>
                ثبت سفارش تبلیغ
            </h4>
            <p class="text-muted mb-0" style="font-size:12px;">برای پیج: <span dir="ltr"><strong>@<?= e($profile->username) ?></strong></span></p>
        </div>
        <a href="<?= url('/user/stories/influencers') ?>" class="btn btn-outline-secondary btn-sm">
            <i class="material-icons" style="font-size:16px;vertical-align:middle;">arrow_forward</i> بازگشت
        </a>
    </div>
</div>

<?php if ($flash = $session->getFlash('error')): ?>
<div class="alert alert-danger alert-dismissible fade show mt-3" role="alert">
    <?= e($flash) ?>
    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
</div>
<?php endif; ?>

<div class="alert mt-3" style="background:linear-gradient(135deg,#fff3e0 0%,#ffe0b2 100%);border-right:4px solid #ffa726;">
    <div style="font-size:12px;color:#e65100;">
        <i class="material-icons" style="font-size:16px;vertical-align:middle;color:#f57c00;">warning</i>
        کد تأیید (CK-XXXXXX) بعد از پرداخت تولید می‌شود و اینفلوئنسر باید آن را داخل استوری/پست قرار دهد.
        حداقل زمان نمایش باید <strong><?= $minPublish ?></strong> ساعت باشد.
    </div>
</div>

<div class="card mt-3">
    <div class="card-body">
        <div class="d-flex align-items-center gap-3">
            <div style="width:72px;height:72px;border-radius:50%;overflow:hidden;border:2px solid #ffa726;background:#f5f5f5;">
                <?php if ($avatar): ?>
                    <img src="<?= e($avatar) ?>" style="width:100%;height:100%;object-fit:cover;">
                <?php else: ?>
                    <div style="width:100%;height:100%;display:flex;align-items:center;justify-content:center;">
                        <i class="material-icons" style="font-size:36px;opacity:0.35;">person</i>
                    </div>
                <?php endif; ?>
            </div>
            <div>
                <div dir="ltr"><strong>@<?= e($profile->username) ?></strong></div>
                <div class="text-muted" style="font-size:12px;"><?= number_format($profile->follower_count) ?> فالوور</div>
                <a href="<?= e($profile->page_url) ?>" target="_blank" rel="noopener" style="font-size:12px;" dir="ltr"><?= e($profile->page_url) ?></a>
            </div>
            <div class="ms-auto text-muted" style="font-size:12px;">
                ارز سفارش: <strong><?= e($currencyLabel) ?></strong>
            </div>
        </div>
    </div>
</div>

<form action="<?= url('/user/stories/store-order') ?>" method="POST" enctype="multipart/form-data">
    <?= csrf_field() ?>
    <input type="hidden" name="influencer_id" value="<?= (int)$profile->id ?>">

    <div class="card mt-3">
        <div class="card-header"><h6 class="card-title mb-0">جزئیات سفارش</h6></div>
        <div class="card-body">
            <div class="row">
                <div class="col-md-4 mb-3">
                    <label class="form-label">نوع تبلیغ</label>
                    <select name="order_type" id="order_type" class="form-select">
                        <option value="story">استوری (24h)</option>
                        <option value="post">پست موقت</option>
                    </select>
                </div>
                <div class="col-md-4 mb-3">
                    <label class="form-label">مدت زمان</label>
                    <select name="duration_hours" id="duration_hours" class="form-select">
                        <option value="24">24 ساعت</option>
                        <option value="48">48 ساعت</option>
                        <option value="72">72 ساعت</option>
                    </select>
                    <small class="text-muted">برای استوری معمولاً 24 ساعت است.</small>
                </div>
                <div class="col-md-4 mb-3">
                    <label class="form-label">زمان پیشنهادی انتشار</label>
                    <input type="datetime-local" name="preferred_publish_time" class="form-control">
                </div>
            </div>

            <div class="mb-3">
                <label class="form-label">متن/کپشن</label>
                <textarea name="caption" class="form-control" rows="3" placeholder="متن تبلیغ..."></textarea>
            </div>

            <div class="mb-3">
                <label class="form-label">لینک (اختیاری)</label>
                <input type="url" name="link" class="form-control" dir="ltr" style="text-align:left;" placeholder="https://...">
            </div>

            <div class="mb-3">
                <label class="form-label">فایل تبلیغ (اختیاری)</label>
                <input type="file" name="media" class="form-control" accept="image/*,video/mp4,image/gif">
                <small class="text-muted">jpg/png/webp/mp4/gif</small>
            </div>

            <div class="p-3 rounded" style="background:#f8f9fa;font-size:13px;">
                مبلغ قابل پرداخت: <strong class="text-success" id="price_label">—</strong>
                <div class="text-muted" style="font-size:11px;margin-top:4px;">
                    مبلغ از کیف پول شما کسر می‌شود و پس از تأیید مدرک، سهم اینفلوئنسر پرداخت خواهد شد.
                </div>
            </div>
        </div>
    </div>

    <div class="d-flex justify-content-end gap-2 mt-3 mb-4">
        <a href="<?= url('/user/stories/influencers') ?>" class="btn btn-outline-secondary">انصراف</a>
        <button type="submit" class="btn btn-primary">
            <i class="material-icons" style="font-size:16px;vertical-align:middle;">payment</i>
            پرداخت و ثبت سفارش
        </button>
    </div>
</form>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const currencyMode = '<?= e($currencyMode) ?>';

    const prices = {
        story24: <?= (float)$profile->story_price_24h ?>,
        post24:  <?= (float)$profile->post_price_24h ?>,
        post48:  <?= (float)$profile->post_price_48h ?>,
        post72:  <?= (float)$profile->post_price_72h ?>
    };

    const orderTypeEl = document.getElementById('order_type');
    const durationEl = document.getElementById('duration_hours');
    const priceLabelEl = document.getElementById('price_label');

    function formatMoney(val) {
        if (currencyMode === 'usdt') return (val || 0).toFixed(2) + ' USDT';
        return Math.round(val || 0).toLocaleString('fa-IR') + ' تومان';
    }

    function recalc() {
        const t = orderTypeEl.value;
        const d = parseInt(durationEl.value, 10);

        let price = 0;
        if (t === 'story') {
            price = prices.story24;
            durationEl.value = '24';
            durationEl.disabled = true;
        } else {
            durationEl.disabled = false;
            price = (d === 48) ? prices.post48 : (d === 72) ? prices.post72 : prices.post24;
        }

        priceLabelEl.textContent = formatMoney(price);
    }

    orderTypeEl.addEventListener('change', recalc);
    durationEl.addEventListener('change', recalc);
    recalc();
});
</script>

<?php
$content = ob_get_clean();
include __DIR__ . '/../../layouts/' . $layout . '.php';
?>