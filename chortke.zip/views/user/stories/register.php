<?php
$title = 'ثبت پیج اینستاگرام برای تبلیغات';
$layout = 'user';
$session = \Core\Session::getInstance();
$old = $session->getFlash('old') ?? [];
$old = \is_array($old) ? (object) $old : $old;
$currencyMode = setting('currency_mode', 'irt');
$currencyLabel = $currencyMode === 'usdt' ? 'USDT' : 'تومان';
$minFollowers = (int) setting('story_min_followers', 1000);
ob_start();
?>

<div class="content-header">
    <div class="d-flex justify-content-between align-items-center">
        <div>
            <h4 class="page-title mb-1">
                <i class="material-icons text-primary">badge</i>
                ثبت پیج برای دریافت سفارش تبلیغ
            </h4>
            <p class="text-muted mb-0" style="font-size:12px;">پس از ثبت، پیج شما توسط مدیریت بررسی و تأیید می‌شود</p>
        </div>
        <a href="<?= url('/user/stories/influencers') ?>" class="btn btn-outline-secondary btn-sm">
            <i class="material-icons" style="font-size:16px;vertical-align:middle;">arrow_forward</i> بازگشت
        </a>
    </div>
</div>

<?php if ($flash = $session->getFlash('success')): ?>
<div class="alert alert-success alert-dismissible fade show mt-3" role="alert">
    <?= e($flash) ?>
    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
</div>
<?php endif; ?>

<?php if ($flash = $session->getFlash('error')): ?>
<div class="alert alert-danger alert-dismissible fade show mt-3" role="alert">
    <?= e($flash) ?>
    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
</div>
<?php endif; ?>

<div class="alert mt-3" style="background:linear-gradient(135deg,#e3f2fd 0%,#bbdefb 100%);border:none;font-size:13px;">
    <i class="material-icons" style="font-size:16px;vertical-align:middle;color:#1976d2;">info</i>
    حداقل فالوور برای ثبت پیج: <strong><?= number_format($minFollowers) ?></strong>
</div>

<?php if (!empty($existing)): ?>
    <div class="card mt-3">
        <div class="card-body">
            <h6 style="font-weight:bold;">پیج ثبت‌شده شما</h6>
            <p class="mb-1" dir="ltr"><strong>@<?= e($existing->username) ?></strong></p>
            <p class="mb-1"><strong>وضعیت:</strong>
                <?php
                $st = [
                    'pending' => 'در انتظار بررسی',
                    'verified' => 'تأیید شده',
                    'rejected' => 'رد شده',
                    'suspended' => 'تعلیق',
                ];
                ?>
                <span class="badge bg-info"><?= e($st[$existing->status] ?? $existing->status) ?></span>
            </p>
            <?php if (!empty($existing->rejection_reason)): ?>
                <p class="text-danger mb-0" style="font-size:12px;"><strong>دلیل رد:</strong> <?= e($existing->rejection_reason) ?></p>
            <?php endif; ?>

            <hr>
            <div class="text-muted" style="font-size:12px;">
                برای ویرایش پیج (نسخه بعدی)، از طریق تیکت با مدیریت در ارتباط باشید.
            </div>
        </div>
    </div>
<?php else: ?>
<form action="<?= url('/user/stories/register') ?>" method="POST" enctype="multipart/form-data">
    <?= csrf_field() ?>

    <div class="card mt-3">
        <div class="card-header"><h6 class="card-title mb-0">اطلاعات پیج</h6></div>
        <div class="card-body">
            <div class="row">
                <div class="col-md-4 mb-3">
                    <label class="form-label">یوزرنیم پیج <span class="text-danger">*</span></label>
                    <input type="text" name="username" class="form-control" dir="ltr" style="text-align:left;"
                           value="<?= e($old->username ?? '') ?>" placeholder="example_page" required>
                </div>
                <div class="col-md-8 mb-3">
                    <label class="form-label">آدرس پیج <span class="text-danger">*</span></label>
                    <input type="url" name="page_url" class="form-control" dir="ltr" style="text-align:left;"
                           value="<?= e($old->page_url ?? '') ?>" placeholder="https://instagram.com/..." required>
                </div>
            </div>

            <div class="row">
                <div class="col-md-4 mb-3">
                    <label class="form-label">تعداد فالوور <span class="text-danger">*</span></label>
                    <input type="number" name="follower_count" class="form-control"
                           value="<?= e($old->follower_count ?? '') ?>" min="0" required>
                </div>
                <div class="col-md-4 mb-3">
                    <label class="form-label">نرخ تعامل (درصد)</label>
                    <input type="number" name="engagement_rate" class="form-control"
                           value="<?= e($old->engagement_rate ?? '') ?>" step="0.1" min="0" max="100">
                </div>
                <div class="col-md-4 mb-3">
                    <label class="form-label">دسته‌بندی</label>
                    <select name="category" class="form-select">
                        <option value="">انتخاب کنید</option>
                        <?php foreach ($categories as $cat): ?>
                            <?php $cat = trim($cat); ?>
                            <option value="<?= e($cat) ?>" <?= ($old->category ?? '') === $cat ? 'selected' : '' ?>><?= e($cat) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
            </div>

            <div class="mb-3">
                <label class="form-label">بیو / توضیحات</label>
                <textarea name="bio" class="form-control" rows="3" placeholder="توضیح کوتاه درباره پیج..."><?= e($old->bio ?? '') ?></textarea>
            </div>

            <div class="mb-3">
                <label class="form-label">عکس پروفایل (اختیاری)</label>
                <input type="file" name="profile_image" class="form-control" accept="image/*">
                <small class="text-muted">حداکثر 2 مگابایت</small>
            </div>
        </div>
    </div>

    <div class="card mt-3">
        <div class="card-header"><h6 class="card-title mb-0">تعرفه‌ها (<?= e($currencyLabel) ?>)</h6></div>
        <div class="card-body">
            <div class="row">
                <div class="col-md-3 mb-3">
                    <label class="form-label">استوری 24h <span class="text-danger">*</span></label>
                    <input type="number" name="story_price_24h" class="form-control"
                           value="<?= e($old->story_price_24h ?? '') ?>" step="<?= $currencyMode === 'usdt' ? '0.01' : '1000' ?>" min="0" required>
                </div>
                <div class="col-md-3 mb-3">
                    <label class="form-label">پست موقت 24h</label>
                    <input type="number" name="post_price_24h" class="form-control"
                           value="<?= e($old->post_price_24h ?? '0') ?>" step="<?= $currencyMode === 'usdt' ? '0.01' : '1000' ?>" min="0">
                </div>
                <div class="col-md-3 mb-3">
                    <label class="form-label">پست موقت 48h</label>
                    <input type="number" name="post_price_48h" class="form-control"
                           value="<?= e($old->post_price_48h ?? '0') ?>" step="<?= $currencyMode === 'usdt' ? '0.01' : '1000' ?>" min="0">
                </div>
                <div class="col-md-3 mb-3">
                    <label class="form-label">پست موقت 72h</label>
                    <input type="number" name="post_price_72h" class="form-control"
                           value="<?= e($old->post_price_72h ?? '0') ?>" step="<?= $currencyMode === 'usdt' ? '0.01' : '1000' ?>" min="0">
                </div>
            </div>

            <div class="alert mb-0" style="background:#f5f5f5;border:none;font-size:12px;">
                نکته: قیمت‌ها توسط شما تعیین می‌شود. سایت فقط درصد کارمزد را هنگام تکمیل سفارش برمی‌دارد.
            </div>
        </div>
    </div>

    <div class="d-flex justify-content-end gap-2 mt-3 mb-4">
        <a href="<?= url('/user/stories/influencers') ?>" class="btn btn-outline-secondary">انصراف</a>
        <button type="submit" class="btn btn-primary">
            <i class="material-icons" style="font-size:16px;vertical-align:middle;">send</i>
            ثبت پیج
        </button>
    </div>
</form>
<?php endif; ?>

<?php
$content = ob_get_clean();
include __DIR__ . '/../../layouts/' . $layout . '.php';
?>