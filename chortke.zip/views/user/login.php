<?php
use Core\Session;
$session = Session::getInstance();
$errors = $session->getFlash('errors') ?? [];
$old = $session->getFlash('old') ?? [];

?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ورود | چرتکه</title>
    
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.rtl.min.css">
    <link rel="stylesheet" href="<?= asset('assets/css/auth.css') ?>">
</head>
<body>
    
    <div class="auth-container">
        <div class="auth-card">
            <div class="auth-header">
                <h3>🎯 چرتکه</h3>
                <p>ورود به حساب کاربری</p>
            </div>
            
            <div class="auth-body">
                <?php if ($session->hasFlash('success')): ?>
                    <div class="alert alert-success alert-dismissible fade show">
                        <span class="material-icons">check_circle</span>
                        <?= e($session->getFlash('success')) ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    </div>
                <?php endif; ?>
                
                <?php if ($session->hasFlash('error')): ?>
                    <div class="alert alert-danger alert-dismissible fade show">
                        <span class="material-icons">error</span>
                        <?= e($session->getFlash('error')) ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    </div>
                <?php endif; ?>
                
                <?php if ($session->hasFlash('warning')): ?>
                    <div class="alert alert-warning alert-dismissible fade show">
                        <span class="material-icons">warning</span>
                        <?= e($session->getFlash('warning')) ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    </div>
                <?php endif; ?>
                
                <form method="POST" action="<?= url('/login') ?>">
                    <?= csrf_field() ?>
                    
                    <div class="form-group">
                        <label class="form-label">ایمیل یا موبایل</label>
                        <input type="text" name="email" class="form-control <?= isset($errors['email']) ? 'is-invalid' : '' ?>" 
                            value="<?= e($old['email'] ?? '') ?>" required autofocus>
                        <?php if (isset($errors['email'])): ?>
                            <div class="invalid-feedback" style="display: block;">
                                <?= e($errors['email'][0]) ?>
                            </div>
                        <?php endif; ?>
                    </div>
                    
                    <div class="form-group">
                        <label class="form-label">رمز عبور</label>
                        <input type="password" name="password" class="form-control <?= isset($errors['password']) ? 'is-invalid' : '' ?>" required>
                        <?php if (isset($errors['password'])): ?>
                            <div class="invalid-feedback" style="display: block;">
                                <?= e($errors['password'][0]) ?>
                            </div>
                        <?php endif; ?>
                    </div>
                    <?= captcha_field('math') ?>

<?php if (!empty($errors['captcha'])): ?>
  <div class="text-danger" style="font-size:12px;margin-top:6px;">
    <?= e($errors['captcha']) ?>
  </div>
<?php endif; ?>
                    <div class="form-check mb-3">
                        <input class="form-check-input" type="checkbox" name="remember" id="remember">
                        <label class="form-check-label" for="remember">
                            مرا به خاطر بسپار
                        </label>
                    </div>
                    
                    <button type="submit" class="btn btn-primary">
                        ورود
                    </button>
                </form>
                
                <div class="divider">
                    <span>یا</span>
                </div>
                
                <div class="text-center">
                    <a href="<?= url('/forgot-password') ?>" style="color: var(--primary);">رمز عبور خود را فراموش کرده‌اید؟</a>
                </div>
            </div>
            
            <div class="auth-footer">
                حساب کاربری ندارید؟ <a href="<?= url('/register') ?>">ثبت‌نام کنید</a>
            </div>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="<?= asset('assets/js/app.js') ?>"></script>
</body>
</html>