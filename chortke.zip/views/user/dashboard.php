<?php
ob_start();
?>

<!-- Stats Grid -->
<div class="stats-grid">
    <div class="stat-card green">
        <div class="stat-icon">
            <span class="material-icons">account_balance_wallet</span>
        </div>
        <h3 class="stat-value">۰ تومان</h3>
        <p class="stat-label">موجودی کیف پول</p>
    </div>
    
    <div class="stat-card blue">
        <div class="stat-icon">
            <span class="material-icons">task_alt</span>
        </div>
        <h3 class="stat-value">۰</h3>
        <p class="stat-label">تسک‌های انجام شده</p>
    </div>
    
    <div class="stat-card red">
        <div class="stat-icon">
            <span class="material-icons">campaign</span>
        </div>
        <h3 class="stat-value">۰</h3>
        <p class="stat-label">تبلیغات فعال</p>
    </div>
    
    <div class="stat-card orange">
        <div class="stat-icon">
            <span class="material-icons">attach_money</span>
        </div>
        <h3 class="stat-value">۰ تومان</h3>
        <p class="stat-label">درآمد کل</p>
    </div>
</div>

<!-- Charts Row -->
<div class="row">
    <div class="col-lg-8">
        <div class="card">
            <div class="card-header">
                <h5>📊 نمودار درآمد (30 روز اخیر)</h5>
            </div>
            <div class="card-body">
                <canvas id="incomeChart" height="80"></canvas>
            </div>
        </div>
    </div>
    
    <div class="col-lg-4">
        <div class="card">
            <div class="card-header">
                <h5>📈 آمار تبلیغات</h5>
            </div>
            <div class="card-body">
                <canvas id="adsChart"></canvas>
            </div>
        </div>
    </div>
</div>

<!-- Transactions & Activities Row -->
<div class="row">
    <div class="col-lg-6">
        <div class="card">
            <div class="card-header">
                <h5>💳 آخرین تراکنش‌ها</h5>
            </div>
            <div class="card-body p-0">
                <table class="table">
                    <thead>
                        <tr>
                            <th>شناسه</th>
                            <th>نوع</th>
                            <th>مبلغ</th>
                            <th>وضعیت</th>
                            <th>تاریخ</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td colspan="5" class="text-center py-4 text-muted">
                                هیچ تراکنشی یافت نشد
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    
    <div class="col-lg-6">
        <div class="card">
            <div class="card-header">
                <h5>📋 آخرین فعالیت‌ها</h5>
            </div>
            <div class="card-body">
                <div class="activity-item mb-3">
                    <small class="text-muted">همین الان</small>
                    <p class="mb-0">شما وارد سیستم شدید</p>
                </div>
                <div class="text-center text-muted py-3">
                    <p class="mb-0">فعالیت دیگری وجود ندارد</p>
                </div>
            </div>
        </div>
    </div>
</div>


$scripts = '
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
<script>
// Income Chart
const incomeCtx = document.getElementById("incomeChart");
new Chart(incomeCtx, {
    type: "line",
    data: {
        labels: ["۱", "۵", "۱۰", "۱۵", "۲۰", "۲۵", "۳۰"],
        datasets: [{
            label: "درآمد (تومان)",
            data: [0, 0, 0, 0, 0, 0, 0],
            borderColor: "#4fc3f7",
            backgroundColor: "rgba(79, 195, 247, 0.1)",
            tension: 0.4,
            fill: true
        }]
    },
    options: {
        responsive: true,
        maintainAspectRatio: true,
        plugins: { legend: { display: false } },
        scales: { y: { beginAtZero: true } }
    }
});

// Ads Chart
const adsCtx = document.getElementById("adsChart");
new Chart(adsCtx, {
    type: "doughnut",
    data: {
        labels: ["اینستاگرام", "یوتیوب", "تلگرام", "تیک‌تاک"],
        datasets: [{
            data: [0, 0, 0, 0],
            backgroundColor: ["#e91e63", "#f44336", "#2196f3", "#000000"]
        }]
    },
    options: {
        responsive: true,
        maintainAspectRatio: true,
        plugins: { legend: { position: "bottom" } }
    }
});
</script>
<?php
$content = ob_get_clean();



require_once __DIR__ . '/../layouts/user.php';

?>
