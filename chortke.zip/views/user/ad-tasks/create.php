<?php
// views/user/ad-tasks/create.php
$title = 'ثبت تسک جدید';
$layout = 'user';
ob_start();
?>

<div class="page-header">
    <h4><i class="material-icons">add_circle</i> ثبت تسک جدید</h4>
    <a href="<?= url('/user/ad-tasks') ?>" class="btn btn-outline-sm">
        <i class="material-icons">arrow_forward</i> بازگشت
    </a>
</div>

<div class="card">
    <div class="card-header">
        <h5>اطلاعات تسک</h5>
    </div>
    <div class="card-body">
        <!-- موجودی -->
        <div class="balance-box">
            <i class="material-icons">account_balance_wallet</i>
            <span>موجودی شما:</span>
            <strong>
                <?php if ($currency === 'usdt'): ?>
                    <?= number_format($wallet->balance_usdt ?? 0, 2) ?> تتر
                <?php else: ?>
                    <?= number_format($wallet->balance_irt ?? 0) ?> تومان
                <?php endif; ?>
            </strong>
        </div>

        <form action="<?= url('/user/ad-tasks/store') ?>" method="POST" enctype="multipart/form-data" id="adTaskForm">
            <?= csrf_field() ?>

            <div class="form-row">
                <div class="form-group col-md-6">
                    <label>پلتفرم <span class="required">*</span></label>
                    <select name="platform" class="form-control" required>
                        <option value="">انتخاب کنید...</option>
                        <?php foreach ($platforms as $key => $label): ?>
                            <option value="<?= $key ?>"><?= e($label) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="form-group col-md-6">
                    <label>نوع تسک <span class="required">*</span></label>
                    <select name="task_type" class="form-control" required>
                        <option value="">انتخاب کنید...</option>
                        <?php foreach ($taskTypes as $key => $label): ?>
                            <option value="<?= $key ?>"><?= e($label) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
            </div>

            <div class="form-group">
                <label>عنوان تسک <span class="required">*</span></label>
                <input type="text" name="title" class="form-control"
                       placeholder="مثال: فالو صفحه اینستاگرام فروشگاه ما" required>
            </div>

            <div class="form-group">
                <label>لینک هدف <span class="required">*</span></label>
                <input type="url" name="target_url" class="form-control ltr-input"
                       placeholder="https://instagram.com/yourpage" required>
            </div>

            <div class="form-group">
                <label>نام کاربری هدف</label>
                <input type="text" name="target_username" class="form-control"
                       placeholder="yourpage">
            </div>

            <div class="form-group">
                <label>توضیحات</label>
                <textarea name="description" class="form-control" rows="3"
                          placeholder="توضیحات بیشتر درباره تسک..."></textarea>
            </div>

            <div class="form-group">
                <label>تصویر نمونه (اختیاری)</label>
                <input type="file" name="sample_image" class="form-control" accept="image/*">
                <small class="form-hint">JPG, PNG — حداکثر ۲ مگابایت</small>
            </div>

            <hr>

            <div class="form-row">
                <div class="form-group col-md-4">
                    <label>قیمت هر تسک (<?= e($currencyLabel) ?>) <span class="required">*</span></label>
                    <input type="number" name="price_per_task" id="pricePerTask" class="form-control"
                           min="1" step="0.01" required>
                </div>

                <div class="form-group col-md-4">
                    <label>تعداد <span class="required">*</span></label>
                    <input type="number" name="total_count" id="totalCount" class="form-control"
                           min="1" max="10000" required>
                </div>

                <div class="form-group col-md-4">
                    <label>بودجه کل</label>
                    <div class="budget-display" id="budgetDisplay">
                        <span id="totalBudget">0</span>
                        <small><?= e($currencyLabel) ?></small>
                    </div>
                </div>
            </div>

            <!-- نمایش هزینه‌ها -->
            <div class="cost-breakdown" id="costBreakdown" style="display:none">
                <div class="cost-row">
                    <span>هزینه پایه:</span>
                    <span id="baseCost">0</span>
                </div>
                <div class="cost-row">
                    <span>کمیسیون سایت (<?= $commission ?>%):</span>
                    <span id="commissionCost">0</span>
                </div>
                <?php if ($tax > 0): ?>
                    <div class="cost-row">
                        <span>مالیات (<?= $tax ?>%):</span>
                        <span id="taxCost">0</span>
                    </div>
                <?php endif; ?>
                <div class="cost-row cost-total">
                    <span>مبلغ کل:</span>
                    <strong id="grandTotal">0</strong> <?= e($currencyLabel) ?>
                </div>
            </div>

            <!-- کوپن -->
            <div class="form-group mt-15">
                <label>کد تخفیف (اختیاری)</label>
                <div class="coupon-input">
                    <input type="text" name="coupon_code" id="couponCode" class="form-control"
                           placeholder="کد کوپن تخفیف">
                    <button type="button" class="btn btn-sm btn-outline-primary" id="btnCheckCoupon">
                        بررسی
                    </button>
                </div>
                <div id="couponResult"></div>
            </div>

            <div class="form-actions">
                <button type="submit" class="btn btn-primary">
                    <i class="material-icons">send</i> ثبت و پرداخت
                </button>
            </div>
        </form>
    </div>
</div>

<style>
.balance-box { display:flex; align-items:center; gap:8px; background:#e8f5e9; padding:12px 15px; border-radius:8px; margin-bottom:20px; color:#2e7d32; font-size:14px; }
.balance-box i { font-size:22px; }
.form-row { display:grid; grid-template-columns:repeat(auto-fit,minmax(200px,1fr)); gap:15px; }
.form-group { margin-bottom:15px; }
.form-group label { display:block; margin-bottom:5px; font-size:13px; font-weight:600; color:#555; }
.form-control { width:100%; padding:10px 12px; border:1px solid #ddd; border-radius:8px; font-size:13px; box-sizing:border-box; }
.form-control:focus { border-color:#4fc3f7; outline:none; }
.required { color:#f44336; }
.ltr-input { direction:ltr; text-align:left; }
.form-hint { font-size:11px; color:#999; }
.form-actions { margin-top:20px; padding-top:15px; border-top:1px solid #eee; }

.budget-display { background:#f5f7fa; padding:10px 15px; border-radius:8px; text-align:center; font-size:20px; font-weight:700; color:#2196f3; margin-top:22px; }

.cost-breakdown { background:#fafafa; padding:15px; border-radius:8px; margin-top:15px; }
.cost-row { display:flex; justify-content:space-between; padding:5px 0; font-size:13px; color:#555; }
.cost-total { border-top:1px solid #ddd; padding-top:10px; margin-top:5px; font-size:15px; color:#333; }

.coupon-input { display:flex; gap:8px; }
.coupon-input .form-control { flex:1; }
.mt-15 { margin-top:15px; }
hr { border:none; border-top:1px solid #eee; margin:20px 0; }

@media(max-width:768px) { .form-row { grid-template-columns:1fr; } }
</style>

<script>
const priceInput = document.getElementById('pricePerTask');
const countInput = document.getElementById('totalCount');
const commissionPercent = <?= $commission ?>;
const taxPercent = <?= $tax ?>;

function calcBudget() {
    const price = parseFloat(priceInput.value) || 0;
    const count = parseInt(countInput.value) || 0;
    const base = price * count;
    const comm = base * (commissionPercent / 100);
    const tax = base * (taxPercent / 100);
    const total = base + comm + tax;

    document.getElementById('totalBudget').textContent = total.toLocaleString();
    document.getElementById('baseCost').textContent = base.toLocaleString();
    document.getElementById('commissionCost').textContent = comm.toLocaleString();
    if (document.getElementById('taxCost')) {
        document.getElementById('taxCost').textContent = tax.toLocaleString();
    }
    document.getElementById('grandTotal').textContent = total.toLocaleString();

    document.getElementById('costBreakdown').style.display = (base > 0) ? 'block' : 'none';
}

priceInput.addEventListener('input', calcBudget);
countInput.addEventListener('input', calcBudget);

// بررسی کوپن
document.getElementById('btnCheckCoupon').addEventListener('click', function() {
    const code = document.getElementById('couponCode').value;
    if (!code) return;

    fetch('<?= url('/user/coupons/validate') ?>', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'X-CSRF-TOKEN': '<?= csrf_token() ?>' },
        body: JSON.stringify({ code: code, amount: parseFloat(document.getElementById('grandTotal').textContent.replace(/,/g, '')), type: 'tasks', _csrf_token: '<?= csrf_token() ?>' })
    })
    .then(r => r.json())
    .then(data => {
        const el = document.getElementById('couponResult');
        if (data.success) {
            el.innerHTML = '<div class="alert-box alert-success mt-5"><i class="material-icons">check_circle</i> تخفیف: ' + data.discount.toLocaleString() + ' <?= e($currencyLabel) ?></div>';
        } else {
            el.innerHTML = '<div class="alert-box alert-danger mt-5"><i class="material-icons">error</i> ' + data.message + '</div>';
        }
    })
    .catch(() => notyf.error('خطا'));
});
</script>

<?php
$content = ob_get_clean();
include __DIR__ . '/../../layouts/' . $layout . '.php';
?>