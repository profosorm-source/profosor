<?php
$pageTitle = $pageTitle ?? 'بررسی مدرک تسک';
$execution = $execution ?? null;
$task = $task ?? null;
?>

<div class="main-content">
    <div class="content-header">
        <h1>بررسی مدرک تسک</h1>
        <a href="<?= url('/user/ad-tasks') ?>" class="btn btn-outline">
            <i class="material-icons">arrow_forward</i>
            بازگشت
        </a>
    </div>

    <?php if (!$execution || !$task): ?>
    <div class="alert alert-danger"><i class="material-icons">error</i> تسک یافت نشد.</div>
    <?php else: ?>

    <div class="review-grid">
        <!-- اطلاعات تسک -->
        <div class="info-card">
            <div class="info-card-header">
                <i class="material-icons">campaign</i>
                <h3>اطلاعات تسک</h3>
            </div>
            <div class="info-card-body">
                <div class="info-row">
                    <span class="info-label">عنوان:</span>
                    <span class="info-value"><?= e($task->title ?? '—') ?></span>
                </div>
                <div class="info-row">
                    <span class="info-label">نوع:</span>
                    <span class="info-value"><?= e($task->type ?? '—') ?></span>
                </div>
                <div class="info-row">
                    <span class="info-label">پاداش:</span>
                    <span class="info-value"><?= number_format((float)($task->reward ?? 0)) ?> تومان</span>
                </div>
                <div class="info-row">
                    <span class="info-label">وضعیت تسک:</span>
                    <span class="badge badge-info"><?= e($execution->status ?? '—') ?></span>
                </div>
                <div class="info-row">
                    <span class="info-label">تاریخ انجام:</span>
                    <span class="info-value"><?= to_jalali($execution->created_at) ?></span>
                </div>
            </div>
        </div>

        <!-- مدرک ارسال‌شده -->
        <div class="info-card">
            <div class="info-card-header">
                <i class="material-icons">attachment</i>
                <h3>مدرک ارسال‌شده</h3>
            </div>
            <div class="info-card-body">
                <?php if (!empty($execution->proof_url)): ?>
                    <?php $ext = strtolower(pathinfo($execution->proof_url, PATHINFO_EXTENSION)); ?>
                    <?php if (in_array($ext, ['jpg','jpeg','png','gif','webp'])): ?>
                        <div class="proof-image-wrapper">
                            <img src="<?= url('/file/view/' . ltrim($execution->proof_url, '/')) ?>"
                                 alt="مدرک" class="proof-image">
                        </div>
                    <?php else: ?>
                        <a href="<?= url('/file/view/' . ltrim($execution->proof_url, '/')) ?>"
                           class="btn btn-outline" target="_blank">
                            <i class="material-icons">download</i>
                            دانلود فایل مدرک
                        </a>
                    <?php endif; ?>
                <?php endif; ?>

                <?php if (!empty($execution->proof_text)): ?>
                    <div class="proof-text-box">
                        <strong>متن مدرک:</strong>
                        <p><?= nl2br(e($execution->proof_text)) ?></p>
                    </div>
                <?php endif; ?>

                <?php if (empty($execution->proof_url) && empty($execution->proof_text)): ?>
                    <p class="text-muted">مدرکی ارسال نشده است.</p>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <?php if ($execution->status === 'pending_review'): ?>
    <!-- دکمه‌های تأیید/رد -->
    <div class="action-card">
        <h3>تصمیم شما</h3>
        <p class="text-muted">آیا مدرک ارسال‌شده توسط انجام‌دهنده معتبر است؟</p>
        <div class="action-buttons">
            <button class="btn btn-success" onclick="doDecision('approve')">
                <i class="material-icons">check_circle</i>
                تأیید مدرک و پرداخت پاداش
            </button>
            <button class="btn btn-danger" onclick="doDecision('reject')">
                <i class="material-icons">cancel</i>
                رد مدرک
            </button>
        </div>
        <div id="rejectReasonBox" style="display:none; margin-top:15px;">
            <label>دلیل رد (اختیاری):</label>
            <textarea id="rejectReason" class="form-control" rows="3"
                      placeholder="دلیل رد مدرک را بنویسید..."></textarea>
        </div>
    </div>
    <?php else: ?>
    <div class="alert alert-info">
        <i class="material-icons">info</i>
        این تسک قبلاً بررسی شده و وضعیت آن: <strong><?= e($execution->status) ?></strong>
    </div>
    <?php endif; ?>

    <?php endif; ?>
</div>

<script>
function doDecision(action) {
    const executionId = <?= (int)($execution->id ?? 0) ?>;
    if (action === 'reject') {
        const box = document.getElementById('rejectReasonBox');
        if (box.style.display === 'none') {
            box.style.display = 'block';
            return;
        }
    }

    const reason = document.getElementById('rejectReason')?.value ?? '';
    const url = action === 'approve'
        ? '<?= url('/user/ad-tasks/executions') ?>/' + executionId + '/approve'
        : '<?= url('/user/ad-tasks/executions') ?>/' + executionId + '/reject';

    fetch(url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'X-CSRF-TOKEN': '<?= csrf_token() ?>' },
        body: JSON.stringify({ reason })
    })
    .then(r => r.json())
    .then(res => {
        if (res.success) {
            const n = new Notyf({ duration: 3000 });
            n.success(res.message || 'عملیات موفق');
            setTimeout(() => location.href = '<?= url('/user/ad-tasks') ?>', 1500);
        } else {
            alert(res.message || 'خطا');
        }
    });
}
</script>

<style>
.review-grid { display:grid; grid-template-columns:repeat(auto-fit,minmax(320px,1fr)); gap:20px; margin-bottom:20px; }
.info-card { background:white; border-radius:12px; box-shadow:0 2px 8px rgba(0,0,0,0.06); overflow:hidden; }
.info-card-header { display:flex; align-items:center; gap:10px; padding:15px 20px; background:#f8f9fa; border-bottom:1px solid #f0f0f0; }
.info-card-header i { color:#4fc3f7; }
.info-card-header h3 { margin:0; font-size:15px; font-weight:600; }
.info-card-body { padding:20px; }
.info-row { display:flex; justify-content:space-between; align-items:center; padding:10px 0; border-bottom:1px solid #f5f5f5; }
.info-row:last-child { border-bottom:none; }
.info-label { color:#666; font-size:14px; }
.info-value { font-weight:500; }
.action-card { background:white; border-radius:12px; padding:25px; box-shadow:0 2px 8px rgba(0,0,0,0.06); }
.action-card h3 { margin:0 0 8px; }
.action-buttons { display:flex; gap:12px; margin-top:20px; flex-wrap:wrap; }
.proof-image-wrapper { text-align:center; }
.proof-image { max-width:100%; max-height:400px; border-radius:8px; border:1px solid #eee; }
.proof-text-box { background:#f8f9fa; border-radius:8px; padding:15px; margin-top:10px; }
</style>
