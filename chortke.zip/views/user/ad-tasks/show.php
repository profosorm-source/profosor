<?php
// views/user/ad-tasks/show.php
$title = 'جزئیات تسک';
$layout = 'user';
ob_start();
?>

<div class="page-header">
    <h4><i class="material-icons">info</i> جزئیات تسک #<?= $task->id ?></h4>
    <a href="<?= url('/user/ad-tasks') ?>" class="btn btn-outline-sm">
        <i class="material-icons">arrow_forward</i> بازگشت
    </a>
</div>

<!-- اطلاعات تسک -->
<div class="card">
    <div class="card-header">
        <h5><?= e($task->title) ?></h5>
        <span class="badge badge-<?= ad_status_badge($task->status) ?>">
            <?= e(ad_status_label($task->status)) ?>
        </span>
    </div>
    <div class="card-body">
        <div class="info-grid">
            <div class="info-item">
                <label>پلتفرم</label>
                <span class="badge-sm platform-<?= e($task->platform) ?>">
                    <?= e(social_platform_label($task->platform)) ?>
                </span>
            </div>
            <div class="info-item">
                <label>نوع تسک</label>
                <span><?= e(ad_task_type_label($task->task_type)) ?></span>
            </div>
            <div class="info-item">
                <label>قیمت واحد</label>
                <span><?= number_format($task->price_per_task) ?> <?= $task->currency === 'usdt' ? 'تتر' : 'تومان' ?></span>
            </div>
            <div class="info-item">
                <label>بودجه کل</label>
                <span><?= number_format($task->total_budget) ?></span>
            </div>
            <div class="info-item">
                <label>بودجه باقیمانده</label>
                <span class="text-primary"><?= number_format($task->remaining_budget) ?></span>
            </div>
            <div class="info-item">
                <label>پیشرفت</label>
                <span><?= $task->completed_count ?> / <?= $task->total_count ?></span>
            </div>
            <div class="info-item">
                <label>لینک هدف</label>
                <a href="<?= e($task->target_url) ?>" target="_blank" class="ltr-text"><?= e($task->target_url) ?></a>
            </div>
            <div class="info-item">
                <label>تاریخ ثبت</label>
                <span><?= to_jalali($task->created_at) ?></span>
            </div>
        </div>

        <?php if ($task->description): ?>
            <div class="desc-box">
                <label>توضیحات:</label>
                <p><?= nl2br(e($task->description)) ?></p>
            </div>
        <?php endif; ?>

        <!-- نوار پیشرفت -->
        <div class="progress-box">
            <div class="progress-bar-lg">
                <?php $percent = $task->total_count > 0 ? round($task->completed_count / $task->total_count * 100) : 0; ?>
                <div class="progress-fill-lg" style="width:<?= $percent ?>%"></div>
            </div>
            <span class="progress-label"><?= $percent ?>% تکمیل شده</span>
        </div>
    </div>
</div>

<!-- مدارک در انتظار بررسی -->
<div class="card mt-20">
    <div class="card-header">
        <h5><i class="material-icons">fact_check</i> مدارک در انتظار بررسی</h5>
    </div>
    <div class="card-body">
        <?php
        $pendingExecs = array_filter($executions, fn($e) => $e->status === 'submitted');
        ?>
        <?php if (empty($pendingExecs)): ?>
            <div class="empty-state-sm">
                <i class="material-icons">check_circle</i>
                <p>مدرک جدیدی برای بررسی وجود ندارد.</p>
            </div>
        <?php else: ?>
            <div class="review-list">
                <?php foreach ($pendingExecs as $exec): ?>
                    <div class="review-item" data-id="<?= $exec->id ?>">
                        <div class="review-info">
                            <div class="review-user">
                                <i class="material-icons">person</i>
                                <span><?= e($exec->executor_name ?? 'کاربر #' . $exec->executor_id) ?></span>
                            </div>
                            <?php if ($exec->social_username): ?>
                                <small class="review-social">@<?= e($exec->social_username) ?></small>
                            <?php endif; ?>
                            <small class="review-date"><?= to_jalali($exec->submitted_at ?? $exec->created_at) ?></small>
                        </div>

                        <?php if ($exec->proof_image): ?>
                            <div class="review-proof">
                                <img src="<?= url('/file/view/task-proofs/' . basename($exec->proof_image)) ?>" 
                                     alt="مدرک" class="proof-thumb"
                                     onclick="showProofModal(this.src)">
                            </div>
                        <?php endif; ?>

                        <div class="review-actions">
                            <button class="btn btn-sm btn-success btn-approve-exec" data-id="<?= $exec->id ?>">
                                <i class="material-icons">check</i> تایید
                            </button>
                            <button class="btn btn-sm btn-danger btn-reject-exec" data-id="<?= $exec->id ?>">
                                <i class="material-icons">close</i> رد
                            </button>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>
</div>

<!-- مودال نمایش تصویر -->
<div class="modal-overlay" id="proofModal" style="display:none">
    <div class="modal-content">
        <button class="modal-close" onclick="document.getElementById('proofModal').style.display='none'">&times;</button>
        <img id="proofModalImg" src="" alt="مدرک">
    </div>
</div>

<style>
.info-grid { display:grid; grid-template-columns:repeat(auto-fill, minmax(250px, 1fr)); gap:15px; }
.info-item { padding:10px; background:#f9f9f9; border-radius:8px; }
.info-item label { display:block; font-size:11px; color:#999; margin-bottom:4px; }
.info-item span, .info-item a { font-size:14px; font-weight:500; color:#333; }
.info-item a { color:#1565c0; text-decoration:none; }
.ltr-text { direction:ltr; display:inline-block; }
.text-primary { color:#2196f3; font-weight:700; }

.desc-box { margin-top:15px; padding:12px; background:#f5f7fa; border-radius:8px; }
.desc-box label { font-size:12px; color:#999; display:block; margin-bottom:5px; }
.desc-box p { font-size:13px; line-height:1.8; margin:0; }

.progress-box { margin-top:15px; }
.progress-bar-lg { width:100%; height:10px; background:#eee; border-radius:5px; overflow:hidden; }
.progress-fill-lg { height:100%; background:linear-gradient(90deg, #4caf50, #81c784); border-radius:5px; transition:width 0.5s; }
.progress-label { font-size:12px; color:#888; margin-top:5px; display:block; }

.review-list { display:flex; flex-direction:column; gap:12px; }
.review-item { display:flex; align-items:center; gap:15px; padding:12px; background:#fafafa; border-radius:8px; flex-wrap:wrap; }
.review-info { flex:1; min-width:150px; }
.review-user { display:flex; align-items:center; gap:5px; font-size:14px; font-weight:500; }
.review-user i { font-size:18px; color:#999; }
.review-social { display:block; font-size:12px; color:#1565c0; margin-top:2px; }
.review-date { display:block; font-size:11px; color:#aaa; margin-top:2px; }
.review-proof { }
.proof-thumb { width:80px; height:60px; object-fit:cover; border-radius:6px; border:1px solid #eee; cursor:pointer; transition:transform 0.2s; }
.proof-thumb:hover { transform:scale(1.1); }
.review-actions { display:flex; gap:6px; }

.empty-state-sm { text-align:center; padding:30px; color:#999; }
.empty-state-sm i { font-size:40px; color:#ccc; }

.modal-overlay { position:fixed; inset:0; background:rgba(0,0,0,0.8); display:flex; align-items:center; justify-content:center; z-index:9999; }
.modal-content { position:relative; max-width:90vw; max-height:90vh; }
.modal-content img { max-width:100%; max-height:85vh; border-radius:10px; }
.modal-close { position:absolute; top:-10px; left:-10px; width:32px; height:32px; border-radius:50%; background:#fff; border:none; font-size:20px; cursor:pointer; box-shadow:0 2px 8px rgba(0,0,0,0.3); }

.mt-20 { margin-top:20px; }
.badge-sm { padding:3px 8px; border-radius:12px; font-size:10px; color:#fff; }

@media(max-width:768px) {
    .info-grid { grid-template-columns:1fr; }
    .review-item { flex-direction:column; align-items:flex-start; }
}
</style>

<script>
function showProofModal(src) {
    document.getElementById('proofModalImg').src = src;
    document.getElementById('proofModal').style.display = 'flex';
}

document.getElementById('proofModal').addEventListener('click', function(e) {
    if (e.target === this) this.style.display = 'none';
});

// تایید
document.querySelectorAll('.btn-approve-exec').forEach(btn => {
    btn.addEventListener('click', function() {
        const id = this.dataset.id;
        Swal.fire({
            title: 'تایید تسک',
            text: 'آیا از تایید این مدرک مطمئن هستید؟ پاداش به کاربر پرداخت خواهد شد.',
            icon: 'question',
            showCancelButton: true,
            confirmButtonText: 'بله، تایید',
            cancelButtonText: 'انصراف',
            confirmButtonColor: '#4caf50'
        }).then(result => {
            if (result.isConfirmed) {
                fetch(`<?= url('/user/ad-tasks/review') ?>/${id}/approve`, {
                    method: 'POST',
                    headers: { 'Content-Type':'application/json', 'X-CSRF-TOKEN':'<?= csrf_token() ?>' },
                    body: JSON.stringify({ _csrf_token: '<?= csrf_token() ?>' })
                })
                .then(r => r.json())
                .then(data => {
                    if (data.success) { notyf.success(data.message); setTimeout(() => location.reload(), 1000); }
                    else notyf.error(data.message);
                })
                .catch(() => notyf.error('خطا'));
            }
        });
    });
});

// رد
document.querySelectorAll('.btn-reject-exec').forEach(btn => {
    btn.addEventListener('click', function() {
        const id = this.dataset.id;
        Swal.fire({
            title: 'رد تسک',
            input: 'textarea',
            inputLabel: 'دلیل رد:',
            inputPlaceholder: 'توضیح دهید چرا این مدرک معتبر نیست...',
            showCancelButton: true,
            confirmButtonText: 'رد کن',
            cancelButtonText: 'انصراف',
            confirmButtonColor: '#f44336',
            inputValidator: v => { if (!v) return 'دلیل رد الزامی است.'; }
        }).then(result => {
            if (result.isConfirmed) {
                fetch(`<?= url('/user/ad-tasks/review') ?>/${id}/reject`, {
                    method: 'POST',
                    headers: { 'Content-Type':'application/json', 'X-CSRF-TOKEN':'<?= csrf_token() ?>' },
                    body: JSON.stringify({ reason: result.value, _csrf_token: '<?= csrf_token() ?>' })
                })
                .then(r => r.json())
                .then(data => {
                    if (data.success) { notyf.success(data.message); setTimeout(() => location.reload(), 1000); }
                    else notyf.error(data.message);
                })
                .catch(() => notyf.error('خطا'));
            }
        });
    });
});
</script>

<?php
$content = ob_get_clean();
include __DIR__ . '/../../layouts/' . $layout . '.php';
?>