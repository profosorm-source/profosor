<?php
// views/user/ad-tasks/my-tasks.php
$title = 'تسک‌های من';
$layout = 'user';
ob_start();
?>

<div class="page-header">
    <h4><i class="material-icons">campaign</i> تسک‌های من (سفارشات)</h4>
    <a href="<?= url('/user/ad-tasks/create') ?>" class="btn btn-primary btn-sm">
        <i class="material-icons">add</i> ثبت تسک جدید
    </a>
</div>

<?php if (empty($tasks)): ?>
    <div class="empty-state">
        <i class="material-icons">inbox</i>
        <h5>هنوز تسکی ثبت نکرده‌اید</h5>
        <a href="<?= url('/user/ad-tasks/create') ?>" class="btn btn-primary">ثبت تسک جدید</a>
    </div>
<?php else: ?>
    <div class="table-responsive">
        <table class="data-table">
            <thead>
                <tr>
                    <th>#</th>
                    <th>عنوان</th>
                    <th>پلتفرم</th>
                    <th>نوع</th>
                    <th>قیمت واحد</th>
                    <th>انجام‌شده / کل</th>
                    <th>بودجه باقیمانده</th>
                    <th>وضعیت</th>
                    <th>عملیات</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($tasks as $task): ?>
                    <tr>
                        <td><?= $task->id ?></td>
                        <td><a href="<?= url('/user/ad-tasks/' . $task->id) ?>"><?= e($task->title) ?></a></td>
                        <td>
                            <span class="badge-sm platform-<?= e($task->platform) ?>">
                                <?= e(social_platform_label($task->platform)) ?>
                            </span>
                        </td>
                        <td><?= e(ad_task_type_label($task->task_type)) ?></td>
                        <td><?= number_format($task->price_per_task) ?></td>
                        <td>
                            <span class="progress-text">
                                <?= $task->completed_count ?> / <?= $task->total_count ?>
                            </span>
                            <div class="progress-bar-mini">
                                <div class="progress-fill" style="width:<?= $task->total_count > 0 ? ($task->completed_count / $task->total_count * 100) : 0 ?>%"></div>
                            </div>
                        </td>
                        <td><?= number_format($task->remaining_budget) ?></td>
                        <td>
                            <span class="badge badge-<?= ad_status_badge($task->status) ?>">
                                <?= e(ad_status_label($task->status)) ?>
                            </span>
                        </td>
                        <td>
                            <?php if ($task->status === 'active'): ?>
                                <button class="btn btn-xs btn-warning btn-action" data-action="pause" data-id="<?= $task->id ?>">
                                    <i class="material-icons">pause</i>
                                </button>
                            <?php elseif ($task->status === 'paused'): ?>
                                <button class="btn btn-xs btn-success btn-action" data-action="resume" data-id="<?= $task->id ?>">
                                    <i class="material-icons">play_arrow</i>
                                </button>
                            <?php endif; ?>

                            <?php if (\in_array($task->status, ['active', 'paused', 'pending'])): ?>
                                <button class="btn btn-xs btn-danger btn-action" data-action="cancel" data-id="<?= $task->id ?>">
                                    <i class="material-icons">close</i>
                                </button>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>

    <?php if ($totalPages > 1): ?>
        <div class="pagination">
            <?php for ($i = 1; $i <= $totalPages; $i++): ?>
                <a href="<?= url('/user/ad-tasks?page=' . $i) ?>" class="page-link <?= $i === $page ? 'active' : '' ?>"><?= $i ?></a>
            <?php endfor; ?>
        </div>
    <?php endif; ?>
<?php endif; ?>

<style>
.progress-text { font-size:12px; color:#555; }
.progress-bar-mini { width:100%; height:4px; background:#eee; border-radius:2px; margin-top:4px; }
.progress-fill { height:100%; background:#4caf50; border-radius:2px; transition:width 0.3s; }
.data-table { width:100%; border-collapse:collapse; background:#fff; border-radius:10px; overflow:hidden; box-shadow:0 2px 8px rgba(0,0,0,0.06); }
.data-table thead th { background:#fafafa; padding:12px; font-size:12px; font-weight:600; color:#555; text-align:right; }
.data-table tbody td { padding:12px; font-size:13px; border-bottom:1px solid #f5f5f5; }
.data-table tbody tr:hover { background:#fafafa; }
.btn-xs { padding:4px 8px; font-size:11px; border:none; border-radius:4px; cursor:pointer; }
.badge-sm { padding:3px 8px; border-radius:12px; font-size:10px; color:#fff; }
.pagination { display:flex; gap:5px; justify-content:center; margin-top:20px; }
.page-link { padding:6px 12px; border:1px solid #ddd; border-radius:6px; text-decoration:none; color:#555; font-size:13px; }
.page-link.active { background:#4fc3f7; color:#fff; border-color:#4fc3f7; }
.empty-state { text-align:center; padding:60px 20px; background:#fff; border-radius:10px; }
.empty-state i { font-size:60px; color:#ccc; }
</style>

<script>
document.querySelectorAll('.btn-action').forEach(btn => {
    btn.addEventListener('click', function() {
        const action = this.dataset.action;
        const id = this.dataset.id;

        const messages = {
            pause: 'آیا می‌خواهید این تسک را متوقف کنید؟',
            resume: 'آیا می‌خواهید این تسک را دوباره فعال کنید؟',
            cancel: 'آیا از لغو این تسک مطمئن هستید؟ بودجه باقیمانده بازگشت داده می‌شود.'
        };

        Swal.fire({
            title: 'تایید عملیات',
            text: messages[action],
            icon: action === 'cancel' ? 'warning' : 'question',
            showCancelButton: true,
            confirmButtonText: 'بله',
            cancelButtonText: 'انصراف',
            confirmButtonColor: action === 'cancel' ? '#f44336' : '#4caf50'
        }).then(result => {
            if (result.isConfirmed) {
                fetch(`<?= url('/user/ad-tasks') ?>/${id}/${action}`, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json', 'X-CSRF-TOKEN': '<?= csrf_token() ?>' },
                    body: JSON.stringify({ _csrf_token: '<?= csrf_token() ?>' })
                })
                .then(r => r.json())
                .then(data => {
                    if (data.success) {
                        notyf.success(data.message);
                        setTimeout(() => location.reload(), 1000);
                    } else {
                        notyf.error(data.message);
                    }
                })
                .catch(() => notyf.error('خطا'));
            }
        });
    });
});
</script>

<?php
$content = ob_get_clean();
include __DIR__ . '/../../layouts/' . $layout . '.php';
?>