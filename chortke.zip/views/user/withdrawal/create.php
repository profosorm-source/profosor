<?php
$pageTitle = $pageTitle ?? 'برداشت وجه';
$summary = $summary ?? null;
$cards = $cards ?? [];
$siteCurrency = $siteCurrency ?? 'irt';
$minWithdrawal = $minWithdrawal ?? 50000;
$old = $_SESSION['old'] ?? [];
?>

<div class="main-content">
    <!-- Header -->
    <div class="content-header">
        <h1>برداشت وجه</h1>
        <a href="<?= url('/user/wallet') ?>" class="btn btn-outline">
            <i class="material-icons">arrow_forward</i>
            بازگشت
        </a>
    </div>

    <?php if ($summary): ?>
    
    <!-- اطلاعات موجودی -->
    <div class="balance-info-card">
        <div class="balance-item">
            <div class="balance-icon">
                <i class="material-icons">account_balance_wallet</i>
            </div>
            <div class="balance-details">
                <span class="label">موجودی قابل برداشت:</span>
                <span class="amount">
                    <?php if ($siteCurrency === 'irt'): ?>
                        <?= number_format($summary->balance_irt) ?> تومان
                    <?php else: ?>
                        <?= number_format($summary->balance_usdt, 4) ?> USDT
                    <?php endif; ?>
                </span>
            </div>
        </div>

        <!-- محدودیت‌های هوشمند بر اساس KYC و سطح -->
        <div id="withdrawalLimitsBox" class="alert alert-info d-none">
            <i class="material-icons float-end">info</i>
            <strong id="limitsProfileLabel"></strong>
            <div class="row mt-2 g-2 small" id="limitsDetail"></div>
        </div>

        <?php if (!$summary->can_withdraw_today): ?>
        <div class="alert alert-warning">
            <i class="material-icons">schedule</i>
            <div>
                <strong>محدودیت برداشت:</strong>
                به سقف برداشت روزانه رسیده‌اید.
                <?php if ($summary->last_withdrawal_at): ?>
                <br><small>آخرین برداشت: <?= to_jalali($summary->last_withdrawal_at) ?></small>
                <?php endif; ?>
            </div>
        </div>
        <?php endif; ?>

<script>
async function loadWithdrawalLimits(currency) {
    try {
        const r = await fetch(`<?= url('/user/withdrawal/limits') ?>?currency=${currency}`);
        const { limits } = await r.json();
        if (!limits) return;

        const box = document.getElementById('withdrawalLimitsBox');
        document.getElementById('limitsProfileLabel').textContent = `سطح شما: ${limits.profile_label}`;
        document.getElementById('limitsDetail').innerHTML = `
            <div class="col-6 col-md-3"><div class="bg-light rounded p-2 text-center">
                <div class="fw-bold">${limits.used_today}/${limits.daily_count === 999 ? '∞' : limits.daily_count}</div>
                <small class="text-muted">برداشت امروز</small>
            </div></div>
            <div class="col-6 col-md-3"><div class="bg-light rounded p-2 text-center">
                <div class="fw-bold">${limits.used_week}/${limits.weekly_count === 9999 ? '∞' : limits.weekly_count}</div>
                <small class="text-muted">این هفته</small>
            </div></div>
            <div class="col-6 col-md-3"><div class="bg-light rounded p-2 text-center">
                <div class="fw-bold">${Number(limits.min_amount).toLocaleString('fa')}</div>
                <small class="text-muted">حداقل برداشت</small>
            </div></div>
            <div class="col-6 col-md-3"><div class="bg-light rounded p-2 text-center">
                <div class="fw-bold">${Number(limits.max_amount).toLocaleString('fa')}</div>
                <small class="text-muted">حداکثر برداشت</small>
            </div></div>
        `;
        box.classList.remove('d-none');
    } catch(e) {}
}
document.addEventListener('DOMContentLoaded', () => loadWithdrawalLimits('IRT'));
document.querySelector('[name="currency"]')?.addEventListener('change', e => loadWithdrawalLimits(e.target.value));
</script>
    </div>

    <!-- هشدارها -->
    <div class="alert alert-danger">
        <i class="material-icons">warning</i>
        <div>
            <strong>توجه مهم:</strong>
            <ul style="margin: 10px 0 0 20px; padding: 0;">
                <li>روزانه فقط یکبار امکان برداشت وجود دارد</li>
                <li>حداقل مبلغ برداشت: <?= $siteCurrency === 'irt' ? number_format($minWithdrawal) . ' تومان' : to_jalali($minWithdrawal, '', true) . ' USDT' ?></li>
                <li>پس از ثبت درخواست، موجودی قفل می‌شود تا زمان تأیید یا رد</li>
                <li><?php if ($siteCurrency === 'irt'): ?>
                    برداشت فقط به کارت‌های تأییدشده امکان‌پذیر است
                    <?php else: ?>
                    برداشت به آدرس کیف پول شخصی شما انجام می‌شود
                    <?php endif; ?>
                </li>
            </ul>
        </div>
    </div>

    <!-- فرم برداشت -->
    <div class="form-card">
        <h3>اطلاعات برداشت</h3>

        <form method="POST" action="<?= url('/user/wallet/withdraw') ?>" id="withdrawalForm">
            <?= csrf_field() ?>

            <?php if ($siteCurrency === 'irt'): ?>
            <!-- برداشت تومانی -->
            <div class="form-row">
                <div class="form-group full-width">
                    <label for="card_id">کارت مقصد: <span class="required">*</span></label>
                    <select id="card_id" name="card_id" class="form-control" required>
                        <option value="">انتخاب کنید</option>
                        <?php foreach ($cards as $card): ?>
                        <option value="<?= $card->id ?>" 
                                data-bank="<?= e($card->bank_name) ?>"
                                <?= ($old['card_id'] ?? '') == $card->id ? 'selected' : '' ?>>
                            <?= substr($card->card_number, 0, 4) ?>-****-****-<?= substr($card->card_number, -4) ?> 
                            (<?= e($card->bank_name) ?>)
                            <?= $card->is_default ? '⭐ پیش‌فرض' : '' ?>
                        </option>
                        <?php endforeach; ?>
                    </select>
                    <small class="form-text">برداشت به این کارت واریز می‌شود</small>
                </div>
            </div>

            <div class="selected-card-info" id="card_info" style="display: none;">
                <i class="material-icons">credit_card</i>
                <div>
                    <strong>کارت انتخابی:</strong>
                    <p id="card_details"></p>
                </div>
            </div>

            <?php else: ?>
            <!-- برداشت تتری -->
            <div class="form-row">
                <div class="form-group full-width">
                    <label for="network">شبکه انتقال: <span class="required">*</span></label>
                    <select id="network" name="network" class="form-control" required>
                        <option value="">انتخاب کنید</option>
                        <option value="bnb20" <?= ($old['network'] ?? '') === 'bnb20' ? 'selected' : '' ?>>
                            BNB Smart Chain (BEP20) - سریع و ارزان
                        </option>
                        <option value="trc20" <?= ($old['network'] ?? '') === 'trc20' ? 'selected' : '' ?>>
                            TRON Network (TRC20) - بدون کارمزد
                        </option>
                    </select>
                </div>
            </div>

            <div class="form-row">
                <div class="form-group full-width">
                    <label for="wallet_address">آدرس کیف پول USDT: <span class="required">*</span></label>
                    <input type="text" 
                           id="wallet_address" 
                           name="wallet_address" 
                           class="form-control ltr" 
                           placeholder="0x... یا T..."
                           value="<?= e($old['wallet_address'] ?? '') ?>"
                           required>
                    <small class="form-text">آدرس کیف پول شخصی خود را وارد کنید (حتماً شبکه صحیح را انتخاب کنید)</small>
                </div>
            </div>

            <div class="alert alert-danger">
                <i class="material-icons">warning</i>
                <div>
                    <strong>هشدار:</strong>
                    اشتباه در آدرس یا شبکه منجر به از دست رفتن دارایی می‌شود. لطفاً با دقت وارد کنید.
                </div>
            </div>
            <?php endif; ?>

            <!-- مبلغ -->
            <div class="form-row">
                <div class="form-group">
                    <label for="amount">
                        مبلغ برداشت (<?= $siteCurrency === 'irt' ? 'تومان' : 'USDT' ?>): 
                        <span class="required">*</span>
                    </label>
                    <input type="number" 
                           id="amount" 
                           name="amount" 
                           class="form-control" 
                           placeholder="مثال: <?= $siteCurrency === 'irt' ? '100000' : '50' ?>"
                           min="<?= $minWithdrawal ?>"
                           max="<?= $siteCurrency === 'irt' ? $summary->balance_irt : $summary->balance_usdt ?>"
                           step="<?= $siteCurrency === 'irt' ? '1000' : '0.01' ?>"
                           value="<?= e($old['amount'] ?? '') ?>"
                           required>
                    <small class="form-text">
                        حداقل: <?= $siteCurrency === 'irt' ? number_format($minWithdrawal) : to_jalali($minWithdrawal, '', true) ?> 
                        - حداکثر: <?= $siteCurrency === 'irt' ? number_format($summary->balance_irt) : number_format($summary->balance_usdt, 4) ?>
                    </small>
                </div>

                <div class="form-group">
                    <label>مبلغ قابل دریافت:</label>
                    <div class="receive-amount-display">
                        <span id="receive_amount">0</span>
                        <small><?= $siteCurrency === 'irt' ? 'تومان' : 'USDT' ?></small>
                    </div>
                    <small class="form-text">پس از کسر کارمزد (در صورت وجود)</small>
                </div>
            </div>

            <!-- مبالغ سریع -->
            <div class="quick-amounts">
                <span class="quick-label">انتخاب سریع:</span>
                <?php if ($siteCurrency === 'irt'): ?>
                    <button type="button" class="quick-amount-btn" onclick="setAmount(<?= min(100000, $summary->balance_irt) ?>)">
                        100,000
                    </button>
                    <button type="button" class="quick-amount-btn" onclick="setAmount(<?= min(250000, $summary->balance_irt) ?>)">
                        250,000
                    </button>
                    <button type="button" class="quick-amount-btn" onclick="setAmount(<?= min(500000, $summary->balance_irt) ?>)">
                        500,000
                    </button>
                <?php else: ?>
                    <button type="button" class="quick-amount-btn" onclick="setAmount(<?= min(50, $summary->balance_usdt) ?>)">
                        50
                    </button>
                    <button type="button" class="quick-amount-btn" onclick="setAmount(<?= min(100, $summary->balance_usdt) ?>)">
                        100
                    </button>
                    <button type="button" class="quick-amount-btn" onclick="setAmount(<?= min(500, $summary->balance_usdt) ?>)">
                        500
                    </button>
                <?php endif; ?>
                <button type="button" class="quick-amount-btn all" onclick="setMaxAmount()">
                    <i class="material-icons">select_all</i>
                    همه موجودی
                </button>
            </div>

            <!-- تأیید و ارسال -->
            <div class="confirmation-box">
                <label class="checkbox-container">
                    <input type="checkbox" id="confirm_withdrawal" required>
                    <span class="checkmark"></span>
                    <span class="checkbox-label">
                        اطلاعات وارد شده را بررسی کردم و از صحت آن اطمینان دارم.
                        می‌دانم که پس از ثبت درخواست، موجودی قفل می‌شود.
                    </span>
                </label>
            </div>

            <div class="form-actions">
                <button type="submit" class="btn btn-danger btn-lg" id="submit_btn" disabled>
                    <i class="material-icons">send</i>
                    ثبت درخواست برداشت
                </button>
                <a href="<?= url('/user/wallet') ?>" class="btn btn-outline btn-lg">
                    انصراف
                </a>
            </div>
        </form>
    </div>

    <?php else: ?>
    <div class="alert alert-danger">
        <i class="material-icons">error</i>
        خطا در دریافت اطلاعات کیف پول
    </div>
    <?php endif; ?>
</div>

<style>
.balance-info-card {
    background: linear-gradient(135deg, #e3f2fd 0%, white 50%);
    border-radius: 15px;
    padding: 25px;
    box-shadow: 0 2px 8px rgba(0,0,0,0.06);
    margin-bottom: 25px;
    border: 2px solid #4fc3f7;
}

.balance-item {
    display: flex;
    align-items: center;
    gap: 20px;
}

.balance-icon {
    width: 60px;
    height: 60px;
    border-radius: 15px;
    background: linear-gradient(135deg, #4fc3f7 0%, #29b6f6 100%);
    display: flex;
    align-items: center;
    justify-content: center;
}

.balance-icon i {
    font-size: 32px;
    color: white;
}

.balance-details {
    flex: 1;
}

.balance-details .label {
    display: block;
    font-size: 14px;
    color: #666;
    margin-bottom: 5px;
}

.balance-details .amount {
    display: block;
    font-size: 28px;
    font-weight: 700;
    color: #4fc3f7;
}

.selected-card-info {
    display: flex;
    gap: 15px;
    padding: 15px;
    background: rgba(79, 195, 247, 0.05);
    border-radius: 10px;
    border-right: 4px solid #4fc3f7;
    margin: 20px 0;
}

.selected-card-info i {
    font-size: 32px;
    color: #4fc3f7;
}

.selected-card-info strong {
    display: block;
    font-size: 14px;
    color: #333;
    margin-bottom: 5px;
}

.selected-card-info p {
    margin: 0;
    font-size: 13px;
    color: #666;
}

.receive-amount-display {
    padding: 15px;
    background: #f5f5f5;
    border: 2px solid #4caf50;
    border-radius: 10px;
    text-align: center;
}

.receive-amount-display span {
    font-size: 24px;
    font-weight: 700;
    color: #4caf50;
}

.receive-amount-display small {
    display: block;
    font-size: 12px;
    color: #666;
    margin-top: 5px;
}

.quick-amounts {
    display: flex;
    flex-wrap: wrap;
    gap: 10px;
    align-items: center;
    padding: 20px;
    background: #fafafa;
    border-radius: 10px;
    margin: 25px 0;
}

.quick-label {
    font-size: 13px;
    font-weight: 500;
    color: #666;
}

.quick-amount-btn {
    padding: 10px 20px;
    background: white;
    border: 2px solid #e0e0e0;
    border-radius: 8px;
    cursor: pointer;
    font-size: 14px;
    font-weight: 500;
    transition: all 0.3s ease;
}

.quick-amount-btn:hover {
    border-color: #4fc3f7;
    color: #4fc3f7;
}

.quick-amount-btn.all {
    display: flex;
    align-items: center;
    gap: 5px;
    background: #4fc3f7;
    color: white;
    border-color: #4fc3f7;
}

.quick-amount-btn.all:hover {
    background: #29b6f6;
}

.quick-amount-btn.all i {
    font-size: 18px;
}

.confirmation-box {
    padding: 20px;
    background: rgba(255, 167, 38, 0.05);
    border-radius: 10px;
    border: 2px solid #ffa726;
    margin: 25px 0;
}

.checkbox-container {
    display: flex;
    align-items: flex-start;
    gap: 12px;
    cursor: pointer;
}

.checkbox-container input[type="checkbox"] {
    display: none;
}

.checkmark {
    width: 24px;
    height: 24px;
    border: 2px solid #e0e0e0;
    border-radius: 6px;
    flex-shrink: 0;
    position: relative;
    transition: all 0.3s ease;
}

.checkbox-container input:checked + .checkmark {
    background: #4fc3f7;
    border-color: #4fc3f7;
}

.checkbox-container input:checked + .checkmark::after {
    content: '✓';
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    color: white;
    font-size: 16px;
    font-weight: bold;
}

.checkbox-label {
    flex: 1;
    font-size: 14px;
    color: #666;
    line-height: 1.6;
}

@media (max-width: 768px) {
    .balance-item {
        flex-direction: column;
        text-align: center;
    }
    
    .quick-amounts {
        flex-direction: column;
        align-items: stretch;
    }
    
    .quick-amount-btn {
        width: 100%;
        justify-content: center;
    }
}
</style>

<script>
const maxBalance = <?= $siteCurrency === 'irt' ? $summary->balance_irt : $summary->balance_usdt ?>;
const minAmount = <?= $minWithdrawal ?>;
const withdrawalFee = <?= (float)config('withdrawal_fee_' . $siteCurrency, 0) ?>;

// نمایش اطلاعات کارت انتخابی
document.getElementById('card_id')?.addEventListener('change', function() {
    const selectedOption = this.options[this.selectedIndex];
    const cardInfo = document.getElementById('card_info');
    const cardDetails = document.getElementById('card_details');
    
    if (this.value) {
        const bankName = selectedOption.dataset.bank;
        const cardNumber = selectedOption.text.split('(')[0].trim();
        
        cardDetails.innerHTML = `${cardNumber}<br>بانک ${bankName}`;
        cardInfo.style.display = 'flex';
    } else {
        cardInfo.style.display = 'none';
    }
});

// محاسبه مبلغ دریافتی
document.getElementById('amount').addEventListener('input', function() {
    const amount = parseFloat(this.value) || 0;
    const fee = (amount * withdrawalFee) / 100;
    const receiveAmount = amount - fee;
    
    document.getElementById('receive_amount').textContent = 
        <?= $siteCurrency === 'irt' ? 'receiveAmount.toLocaleString()' : 'receiveAmount.toFixed(4)' ?>;
});

function setAmount(amount) {
    document.getElementById('amount').value = amount;
    document.getElementById('amount').dispatchEvent(new Event('input'));
}

function setMaxAmount() {
    setAmount(maxBalance);
}

// فعال کردن دکمه ارسال
document.getElementById('confirm_withdrawal').addEventListener('change', function() {
    document.getElementById('submit_btn').disabled = !this.checked;
});

// اعتبارسنجی فرم
document.getElementById('withdrawalForm').addEventListener('submit', function(e) {
    const amount = parseFloat(document.getElementById('amount').value);
    
    if (amount < minAmount) {
        e.preventDefault();
        notyf.error('مبلغ برداشت کمتر از حداقل مجاز است');
        return false;
    }
    
    if (amount > maxBalance) {
        e.preventDefault();
        notyf.error('موجودی کافی نیست');
        return false;
    }
    
    <?php if ($siteCurrency === 'usdt'): ?>
    const walletAddress = document.getElementById('wallet_address').value;
    const network = document.getElementById('network').value;
    
    if (network === 'bnb20' && !walletAddress.startsWith('0x')) {
        e.preventDefault();
        notyf.error('آدرس BNB20 باید با 0x شروع شود');
        return false;
    }
    
    if (network === 'trc20' && !walletAddress.startsWith('T')) {
        e.preventDefault();
        notyf.error('آدرس TRC20 باید با T شروع شود');
        return false;
    }
    <?php endif; ?>
    
    if (!confirm('آیا از ثبت درخواست برداشت اطمینان دارید؟')) {
        e.preventDefault();
        return false;
    }
});
</script>