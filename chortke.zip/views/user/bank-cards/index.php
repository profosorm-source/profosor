<?php
$pageTitle = $pageTitle ?? 'کارت‌های بانکی من';
$cards = $cards ?? [];
$cardCount = $cardCount ?? 0;
$maxCards = $maxCards ?? 4;
?>

<div class="main-content">
    <!-- Header -->
    <div class="content-header">
        <h1>کارت‌های بانکی من</h1>
        <div class="header-actions">
            <?php if ($cardCount < $maxCards): ?>
            <a href="<?= url('/user/bank-cards/create') ?>" class="btn btn-primary">
                <i class="material-icons">add</i>
                افزودن کارت جدید
            </a>
            <?php endif; ?>
        </div>
    </div>

    <!-- راهنما -->
    <div class="alert alert-info">
        <i class="material-icons">info</i>
        <div>
            <strong>توجه:</strong>
            برای برداشت وجه و واریز دستی، ابتدا باید کارت بانکی خود را ثبت و تأیید کنید.
            حداکثر <?= to_jalali($maxCards, '', true) ?> کارت می‌توانید ثبت کنید.
            <br>
            <small>⚠️ کارت باید به نام خودتان باشد و پس از تأیید مدیریت قابل استفاده خواهد بود.</small>
        </div>
    </div>

    <!-- محدودیت تعداد -->
    <?php if ($cardCount >= $maxCards): ?>
    <div class="alert alert-warning">
        <i class="material-icons">warning</i>
        <div>
            شما به حداکثر تعداد کارت مجاز رسیده‌اید. برای افزودن کارت جدید، ابتدا یکی از کارت‌های موجود را حذف کنید.
        </div>
    </div>
    <?php endif; ?>

    <!-- لیست کارت‌ها -->
    <div class="cards-grid">
        <?php if (empty($cards)): ?>
        <div class="empty-state">
            <i class="material-icons">credit_card</i>
            <h3>کارت بانکی ثبت نشده</h3>
            <p>هنوز کارت بانکی ثبت نکرده‌اید</p>
            <a href="<?= url('/user/bank-cards/create') ?>" class="btn btn-primary">
                <i class="material-icons">add</i>
                افزودن کارت اول
            </a>
        </div>
        <?php else: ?>
            <?php foreach ($cards as $card): ?>
            <div class="bank-card <?= $card->is_default ? 'default-card' : '' ?> <?= $card->status ?>">
                <!-- نشان پیش‌فرض -->
                <?php if ($card->is_default): ?>
                <div class="default-badge">
                    <i class="material-icons">star</i>
                    <span>پیش‌فرض</span>
                </div>
                <?php endif; ?>

                <!-- وضعیت -->
                <div class="card-status-badge">
                    <?php
                    $statusLabels = [
                        'pending' => 'در انتظار تأیید',
                        'verified' => 'تأیید شده',
                        'rejected' => 'رد شده',
                    ];
                    $statusIcons = [
                        'pending' => 'schedule',
                        'verified' => 'check_circle',
                        'rejected' => 'cancel',
                    ];
                    ?>
                    <i class="material-icons"><?= $statusIcons[$card->status] ?></i>
                    <span><?= $statusLabels[$card->status] ?></span>
                </div>

                <!-- اطلاعات کارت -->
                <div class="card-body">
                    <div class="card-info-row">
                        <span class="label">شماره کارت:</span>
                        <span class="value card-number">
                            <?= substr($card->card_number, 0, 4) ?>-****-****-<?= substr($card->card_number, -4) ?>
                        </span>
                    </div>

                    <div class="card-info-row">
                        <span class="label">نام بانک:</span>
                        <span class="value"><?= e($card->bank_name) ?></span>
                    </div>

                    <div class="card-info-row">
                        <span class="label">صاحب کارت:</span>
                        <span class="value"><?= e($card->cardholder_name) ?></span>
                    </div>

                    <?php if ($card->sheba): ?>
                    <div class="card-info-row">
                        <span class="label">شماره شبا:</span>
                        <span class="value sheba-number" dir="ltr">IR<?= e($card->sheba) ?></span>
                    </div>
                    <?php endif; ?>

                    <?php if ($card->status === 'rejected' && $card->rejection_reason): ?>
                    <div class="rejection-reason">
                        <i class="material-icons">info</i>
                        <div>
                            <strong>دلیل رد:</strong>
                            <p><?= e($card->rejection_reason) ?></p>
                        </div>
                    </div>
                    <?php endif; ?>

                    <div class="card-date">
                        <i class="material-icons">access_time</i>
                        ثبت شده در <?= to_jalali($card->created_at) ?>
                    </div>
                </div>

                <!-- اکشن‌ها -->
                <div class="card-actions">
                    <?php if ($card->status === 'verified' && !$card->is_default): ?>
                    <button class="action-btn primary" onclick="setDefaultCard(<?= $card->id ?>)">
                        <i class="material-icons">star</i>
                        تنظیم به عنوان پیش‌فرض
                    </button>
                    <?php endif; ?>

                    <?php if ($card->status !== 'verified'): ?>
                    <button class="action-btn danger" onclick="confirmDeleteCard(<?= $card->id ?>)">
                        <i class="material-icons">delete</i>
                        حذف
                    </button>
                    <?php endif; ?>
                </div>
            </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>
</div>

<style>
.cards-grid {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(350px, 1fr));
    gap: 25px;
    margin-top: 25px;
}

.bank-card {
    position: relative;
    background: white;
    border-radius: 15px;
    box-shadow: 0 2px 8px rgba(0,0,0,0.06);
    overflow: hidden;
    border: 2px solid transparent;
    transition: all 0.3s ease;
}

.bank-card:hover {
    box-shadow: 0 4px 15px rgba(0,0,0,0.12);
    transform: translateY(-3px);
}

.bank-card.verified {
    border-color: #4caf50;
}

.bank-card.pending {
    border-color: #ffa726;
}

.bank-card.rejected {
    border-color: #f44336;
}

.bank-card.default-card {
    background: linear-gradient(135deg, #fff9e6 0%, white 50%);
}

.default-badge {
    position: absolute;
    top: 15px;
    left: 15px;
    display: flex;
    align-items: center;
    gap: 5px;
    background: linear-gradient(135deg, #ffa726 0%, #fb8c00 100%);
    color: white;
    padding: 5px 12px;
    border-radius: 20px;
    font-size: 11px;
    font-weight: 600;
    z-index: 2;
}

.default-badge i {
    font-size: 14px;
}

.card-status-badge {
    display: flex;
    align-items: center;
    gap: 8px;
    padding: 15px 20px;
    background: #fafafa;
    border-bottom: 1px solid #f5f5f5;
}

.bank-card.verified .card-status-badge {
    background: rgba(76, 175, 80, 0.1);
    color: #4caf50;
}

.bank-card.pending .card-status-badge {
    background: rgba(255, 167, 38, 0.1);
    color: #ffa726;
}

.bank-card.rejected .card-status-badge {
    background: rgba(244, 67, 54, 0.1);
    color: #f44336;
}

.card-status-badge i {
    font-size: 20px;
}

.card-status-badge span {
    font-size: 13px;
    font-weight: 600;
}

.card-body {
    padding: 20px;
}

.card-info-row {
    display: flex;
    justify-content: space-between;
    padding: 12px 0;
    border-bottom: 1px solid #f5f5f5;
}

.card-info-row:last-of-type {
    border-bottom: none;
}

.card-info-row .label {
    font-size: 13px;
    color: #666;
}

.card-info-row .value {
    font-size: 14px;
    font-weight: 600;
    color: #333;
}

.card-number {
    direction: ltr;
    font-family: monospace;
}

.sheba-number {
    font-family: monospace;
    font-size: 12px;
}

.rejection-reason {
    display: flex;
    gap: 10px;
    margin-top: 15px;
    padding: 12px;
    background: rgba(244, 67, 54, 0.05);
    border-radius: 8px;
    border-right: 3px solid #f44336;
}

.rejection-reason i {
    color: #f44336;
    font-size: 20px;
}

.rejection-reason strong {
    display: block;
    font-size: 13px;
    color: #f44336;
    margin-bottom: 5px;
}

.rejection-reason p {
    margin: 0;
    font-size: 12px;
    color: #666;
    line-height: 1.6;
}

.card-date {
    display: flex;
    align-items: center;
    gap: 5px;
    margin-top: 15px;
    font-size: 11px;
    color: #999;
}

.card-date i {
    font-size: 14px;
}

.card-actions {
    display: flex;
    gap: 10px;
    padding: 15px 20px;
    border-top: 1px solid #f5f5f5;
}

.action-btn {
    flex: 1;
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 5px;
    padding: 10px;
    border: none;
    border-radius: 8px;
    font-size: 13px;
    font-weight: 500;
    cursor: pointer;
    transition: all 0.3s ease;
}

.action-btn.primary {
    background: #4fc3f7;
    color: white;
}

.action-btn.primary:hover {
    background: #29b6f6;
}

.action-btn.danger {
    background: #ffebee;
    color: #f44336;
}

.action-btn.danger:hover {
    background: #f44336;
    color: white;
}

.action-btn i {
    font-size: 18px;
}

.empty-state {
    grid-column: 1 / -1;
    text-align: center;
    padding: 60px 20px;
}

.empty-state i {
    font-size: 80px;
    color: #e0e0e0;
    margin-bottom: 20px;
}

.empty-state h3 {
    margin: 0 0 10px 0;
    font-size: 18px;
    color: #666;
}

.empty-state p {
    margin: 0 0 25px 0;
    color: #999;
}

@media (max-width: 768px) {
    .cards-grid {
        grid-template-columns: 1fr;
    }
}
</style>

<script>
function setDefaultCard(cardId) {
    if (!confirm('آیا می‌خواهید این کارت را به عنوان پیش‌فرض تنظیم کنید؟')) {
        return;
    }

    const formData = new FormData();
    formData.append('card_id', cardId);
    formData.append('<?= csrf_token() ?>', '<?= csrf_token() ?>');

    fetch('<?= url('/user/bank-cards/set-default') ?>', {
        method: 'POST',
        body: formData
    })
    .then(res => res.json())
    .then(data => {
        if (data.success) {
            notyf.success(data.message);
            setTimeout(() => location.reload(), 1000);
        } else {
            notyf.error(data.message);
        }
    })
    .catch(err => {
        notyf.error('خطا در ارتباط با سرور');
    });
}

function confirmDeleteCard(cardId) {
    Swal.fire({
        title: 'حذف کارت بانکی',
        text: 'آیا از حذف این کارت اطمینان دارید؟',
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#f44336',
        cancelButtonColor: '#999',
        confirmButtonText: 'بله، حذف شود',
        cancelButtonText: 'انصراف'
    }).then((result) => {
        if (result.isConfirmed) {
            deleteCard(cardId);
        }
    });
}

function deleteCard(cardId) {
    const formData = new FormData();
    formData.append('card_id', cardId);
    formData.append('<?= csrf_token() ?>', '<?= csrf_token() ?>');

    fetch('<?= url('/user/bank-cards/delete') ?>', {
        method: 'POST',
        body: formData
    })
    .then(res => res.json())
    .then(data => {
        if (data.success) {
            notyf.success(data.message);
            setTimeout(() => location.reload(), 1000);
        } else {
            notyf.error(data.message);
        }
    })
    .catch(err => {
        notyf.error('خطا در ارتباط با سرور');
    });
}
</script>
<?php
$content = ob_get_clean();
include __DIR__ . '/../../layouts/' . $layout . '.php';
?>
