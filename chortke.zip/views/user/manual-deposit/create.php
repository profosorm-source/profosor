<?php
$pageTitle = $pageTitle ?? 'واریز دستی';
$cards = $cards ?? [];
$siteCardNumber = $siteCardNumber ?? '';
$siteSheba = $siteSheba ?? '';
$siteBankName = $siteBankName ?? '';
$old = $_SESSION['old'] ?? [];
?>

<div class="main-content">
    <!-- Header -->
    <div class="content-header">
        <h1>واریز دستی</h1>
        <a href="<?= url('/user/wallet/deposit') ?>" class="btn btn-outline">
            <i class="material-icons">arrow_forward</i>
            بازگشت
        </a>
    </div>

    <!-- مراحل واریز -->
    <div class="steps-container">
        <div class="step active">
            <div class="step-number">1</div>
            <div class="step-title">واریز به حساب سایت</div>
        </div>
        <div class="step-line"></div>
        <div class="step">
            <div class="step-number">2</div>
            <div class="step-title">ثبت اطلاعات واریز</div>
        </div>
        <div class="step-line"></div>
        <div class="step">
            <div class="step-number">3</div>
            <div class="step-title">بررسی و تأیید</div>
        </div>
    </div>

    <!-- اطلاعات حساب سایت -->
    <div class="account-info-card">
        <h3>
            <i class="material-icons">account_balance</i>
            اطلاعات حساب سایت برای واریز
        </h3>
        
        <div class="info-grid">
            <div class="info-item">
                <span class="label">شماره کارت:</span>
                <div class="value-with-copy">
                    <span class="value card-number"><?= $siteCardNumber ?></span>
                    <button class="copy-btn" onclick="copyToClipboard('<?= $siteCardNumber ?>')">
                        <i class="material-icons">content_copy</i>
                    </button>
                </div>
            </div>

            <?php if ($siteSheba): ?>
            <div class="info-item">
                <span class="label">شماره شبا:</span>
                <div class="value-with-copy">
                    <span class="value sheba-number" dir="ltr">IR<?= $siteSheba ?></span>
                    <button class="copy-btn" onclick="copyToClipboard('IR<?= $siteSheba ?>')">
                        <i class="material-icons">content_copy</i>
                    </button>
                </div>
            </div>
            <?php endif; ?>

            <div class="info-item">
                <span class="label">نام بانک:</span>
                <span class="value"><?= e($siteBankName) ?></span>
            </div>

            <div class="info-item">
                <span class="label">به نام:</span>
                <span class="value">سایت چرتکه</span>
            </div>
        </div>

        <div class="alert alert-warning">
            <i class="material-icons">warning</i>
            <div>
                <strong>توجه:</strong>
                حتماً از یکی از کارت‌های تأییدشده خود واریز کنید. واریز از کارت دیگران رد خواهد شد.
            </div>
        </div>
    </div>

    <!-- فرم ثبت واریز -->
    <div class="form-card">
        <h3>ثبت اطلاعات واریز</h3>
        
        <form method="POST" action="<?= url('/user/wallet/deposit/manual') ?>" enctype="multipart/form-data" id="depositForm">
            <?= csrf_field() ?>

            <div class="form-row">
                <div class="form-group">
                    <label for="card_id">کارت بانکی شما: <span class="required">*</span></label>
                    <select id="card_id" name="card_id" class="form-control" required>
                        <option value="">انتخاب کنید</option>
                        <?php foreach ($cards as $card): ?>
                        <option value="<?= $card->id ?>" <?= ($old['card_id'] ?? '') == $card->id ? 'selected' : '' ?>>
                            <?= substr($card->card_number, 0, 4) ?>-****-****-<?= substr($card->card_number, -4) ?> 
                            (<?= e($card->bank_name) ?>)
                            <?= $card->is_default ? '⭐' : '' ?>
                        </option>
                        <?php endforeach; ?>
                    </select>
                    <small class="form-text">کارتی که از آن واریز کرده‌اید را انتخاب کنید</small>
                </div>

                <div class="form-group">
                    <label for="amount">مبلغ واریزی (تومان): <span class="required">*</span></label>
                    <input type="number" 
                           id="amount" 
                           name="amount" 
                           class="form-control" 
                           placeholder="مثال: 100000"
                           min="10000"
                           step="1000"
                           value="<?= e($old['amount'] ?? '') ?>"
                           required>
                    <small class="form-text">حداقل مبلغ: 10,000 تومان</small>
                </div>
            </div>

            <div class="form-row">
                <div class="form-group">
                    <label for="tracking_code">شماره پیگیری: <span class="required">*</span></label>
                    <input type="text" 
                           id="tracking_code" 
                           name="tracking_code" 
                           class="form-control ltr" 
                           placeholder="مثال: 123456789"
                           value="<?= e($old['tracking_code'] ?? '') ?>"
                           required>
                    <small class="form-text">شماره پیگیری تراکنش بانکی</small>
                </div>

                <div class="form-group">
                    <label for="deposit_date">تاریخ واریز: <span class="required">*</span></label>
                    <input type="date" 
                           id="deposit_date" 
                           name="deposit_date" 
                           class="form-control" 
                           max="<?= date('Y-m-d') ?>"
                           value="<?= e($old['deposit_date'] ?? date('Y-m-d')) ?>"
                           required>
                </div>
            </div>

            <div class="form-row">
                <div class="form-group">
                    <label for="deposit_time">ساعت واریز: <span class="required">*</span></label>
                    <input type="time" 
                           id="deposit_time" 
                           name="deposit_time" 
                           class="form-control" 
                           value="<?= e($old['deposit_time'] ?? date('H:i')) ?>"
                           required>
                </div>

                <div class="form-group">
                    <label for="receipt_image">تصویر فیش واریز:</label>
                    <input type="file" 
                           id="receipt_image" 
                           name="receipt_image" 
                           class="form-control" 
                           accept="image/*">
                    <small class="form-text">اختیاری - حداکثر 2MB - فرمت: JPG, PNG</small>
                </div>
            </div>

            <div class="form-actions">
                <button type="submit" class="btn btn-primary btn-lg">
                    <i class="material-icons">check</i>
                    ثبت درخواست واریز
                </button>
                <a href="<?= url('/user/wallet/deposit') ?>" class="btn btn-outline btn-lg">
                    انصراف
                </a>
            </div>
        </form>
    </div>

    <!-- راهنما -->
    <div class="help-card">
        <h4>
            <i class="material-icons">help</i>
            راهنمای واریز دستی
        </h4>
        <ol>
            <li>ابتدا از یکی از کارت‌های تأییدشده خود به حساب سایت واریز کنید</li>
            <li>اطلاعات دقیق واریز (شماره پیگیری، تاریخ و ساعت) را در فرم بالا وارد کنید</li>
            <li>در صورت امکان، تصویر فیش واریز را آپلود کنید (سرعت تأیید بیشتر می‌شود)</li>
            <li>درخواست شما حداکثر ظرف 2 تا 24 ساعت بررسی و تأیید می‌شود</li>
            <li>پس از تأیید، مبلغ به کیف پول شما افزوده می‌شود</li>
        </ol>
    </div>
</div>

<style>
.steps-container {
    display: flex;
    align-items: center;
    justify-content: center;
    background: white;
    border-radius: 10px;
    padding: 30px;
    box-shadow: 0 2px 8px rgba(0,0,0,0.06);
    margin: 25px 0;
}

.step {
    display: flex;
    flex-direction: column;
    align-items: center;
    gap: 10px;
}

.step-number {
    width: 50px;
    height: 50px;
    border-radius: 50%;
    background: #e0e0e0;
    color: #999;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 20px;
    font-weight: 700;
    transition: all 0.3s ease;
}

.step.active .step-number {
    background: #4fc3f7;
    color: white;
    box-shadow: 0 4px 15px rgba(79, 195, 247, 0.4);
}

.step-title {
    font-size: 13px;
    color: #666;
    font-weight: 500;
    text-align: center;
}

.step.active .step-title {
    color: #4fc3f7;
    font-weight: 600;
}

.step-line {
    width: 80px;
    height: 2px;
    background: #e0e0e0;
    margin: 0 10px;
}

.account-info-card {
    background: linear-gradient(135deg, #e3f2fd 0%, white 50%);
    border-radius: 15px;
    padding: 30px;
    box-shadow: 0 2px 8px rgba(0,0,0,0.06);
    border: 2px solid #4fc3f7;
    margin-bottom: 25px;
}

.account-info-card h3 {
    display: flex;
    align-items: center;
    gap: 10px;
    margin: 0 0 25px 0;
    font-size: 18px;
    color: #333;
}

.account-info-card h3 i {
    color: #4fc3f7;
    font-size: 28px;
}

.info-grid {
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    gap: 20px;
    margin-bottom: 20px;
}

.info-item {
    display: flex;
    flex-direction: column;
    gap: 8px;
}

.info-item .label {
    font-size: 13px;
    color: #666;
    font-weight: 500;
}

.info-item .value {
    font-size: 16px;
    font-weight: 700;
    color: #333;
}

.value-with-copy {
    display: flex;
    align-items: center;
    gap: 10px;
}

.card-number,
.sheba-number {
    direction: ltr;
    font-family: monospace;
}

.copy-btn {
    padding: 8px;
    background: #4fc3f7;
    border: none;
    border-radius: 8px;
    color: white;
    cursor: pointer;
    transition: all 0.3s ease;
    display: flex;
    align-items: center;
    justify-content: center;
}

.copy-btn:hover {
    background: #29b6f6;
    transform: scale(1.1);
}

.copy-btn i {
    font-size: 18px;
}

.help-card {
    background: white;
    border-radius: 10px;
    padding: 25px;
    box-shadow: 0 2px 8px rgba(0,0,0,0.06);
    margin-top: 25px;
}

.help-card h4 {
    display: flex;
    align-items: center;
    gap: 10px;
    margin: 0 0 20px 0;
    font-size: 16px;
    color: #333;
}

.help-card h4 i {
    color: #4fc3f7;
    font-size: 24px;
}

.help-card ol {
    margin: 0;
    padding-right: 20px;
}

.help-card ol li {
    margin-bottom: 12px;
    line-height: 1.8;
    color: #666;
    font-size: 14px;
}

@media (max-width: 768px) {
    .steps-container {
        padding: 20px;
    }
    
    .step-line {
        width: 40px;
    }
    
    .step-title {
        font-size: 11px;
    }
    
    .info-grid {
        grid-template-columns: 1fr;
    }
}
</style>

<script>
function copyToClipboard(text) {
    navigator.clipboard.writeText(text).then(() => {
        notyf.success('کپی شد!');
    }).catch(err => {
        notyf.error('خطا در کپی کردن');
    });
}

// اعتبارسنجی فایل
document.getElementById('receipt_image')?.addEventListener('change', function(e) {
    const file = e.target.files[0];
    if (file) {
        // بررسی حجم (2MB)
        if (file.size > 2 * 1024 * 1024) {
            notyf.error('حجم فایل نباید بیشتر از 2 مگابایت باشد');
            e.target.value = '';
            return;
        }
        
        // بررسی فرمت
        const allowedTypes = ['image/jpeg', 'image/jpg', 'image/png'];
        if (!allowedTypes.includes(file.type)) {
            notyf.error('فقط فرمت JPG و PNG مجاز است');
            e.target.value = '';
            return;
        }
    }
});
</script>