<?php
// views/user/advertiser/campaigns.php
$title = 'کمپین‌های من';
include BASE_PATH . '/views/partials/user/sidebar.php';
?>

<div class="main-content">
<div class="container-fluid py-4">

    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h4 class="mb-1">📋 کمپین‌های من</h4>
            <p class="text-muted mb-0">مجموع <?= number_format($total) ?> کمپین</p>
        </div>
        <div class="d-flex gap-2">
            <a href="<?= url('/advertiser/analytics') ?>" class="btn btn-outline-secondary btn-sm">
                <span class="material-icons align-middle" style="font-size:18px">analytics</span>
                آنالیتیک
            </a>
            <a href="<?= url('/user/ad-tasks/create') ?>" class="btn btn-primary btn-sm">
                <span class="material-icons align-middle" style="font-size:18px">add</span>
                کمپین جدید
            </a>
        </div>
    </div>

    <div class="card border-0 shadow-sm">
        <div class="card-body p-0">
            <?php if (empty($campaigns)): ?>
                <div class="text-center py-5">
                    <span class="material-icons fs-1 text-muted">campaign</span>
                    <h5 class="mt-2 text-muted">هنوز کمپینی ندارید</h5>
                    <a href="<?= url('/user/ad-tasks/create') ?>" class="btn btn-primary mt-2">
                        اولین کمپین را بسازید
                    </a>
                </div>
            <?php else: ?>
            <div class="table-responsive">
                <table class="table table-hover mb-0 small">
                    <thead class="table-light">
                        <tr>
                            <th>#</th>
                            <th>کمپین</th>
                            <th>پلتفرم</th>
                            <th>نوع</th>
                            <th>اجرا / کل</th>
                            <th>نرخ تأیید</th>
                            <th>بودجه مصرفی</th>
                            <th>تکمیل</th>
                            <th>وضعیت</th>
                            <th>عملیات</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($campaigns as $c):
                            $c   = (object)$c;
                            $p   = $perfById[$c->id] ?? [];
                        ?>
                        <tr>
                            <td class="text-muted"><?= (int)$c->id ?></td>
                            <td>
                                <a href="<?= url('/user/ad-tasks/' . (int)$c->id) ?>" class="fw-semibold text-decoration-none">
                                    <?= e(mb_substr($c->title, 0, 35)) ?>
                                </a>
                                <div class="text-muted" style="font-size:11px">
                                    <?= to_jalali($c->created_at) ?>
                                </div>
                            </td>
                            <td><span class="badge bg-primary"><?= e($c->platform) ?></span></td>
                            <td class="text-muted"><?= e($c->task_type) ?></td>
                            <td>
                                <?php $done = (int)($c->total_count) - (int)($c->remaining_count); ?>
                                <span class="fw-semibold"><?= number_format($done) ?></span>
                                <span class="text-muted">/ <?= number_format((int)$c->total_count) ?></span>
                            </td>
                            <td>
                                <?php $ar = (float)($p['approval_rate'] ?? 0); ?>
                                <div class="d-flex align-items-center gap-1">
                                    <div class="progress" style="height:5px;width:50px">
                                        <div class="progress-bar bg-<?= $ar>=70?'success':($ar>=40?'warning':'danger') ?>"
                                             style="width:<?= min(100,$ar) ?>%"></div>
                                    </div>
                                    <small><?= $ar ?>%</small>
                                </div>
                            </td>
                            <td>
                                <?php $spent = (float)$c->total_budget - (float)$c->remaining_budget; ?>
                                <span title="از <?= number_format((float)$c->total_budget) ?>">
                                    <?= number_format($spent) ?>
                                </span>
                            </td>
                            <td>
                                <?php $pct = (float)($p['completion_pct'] ?? 0); ?>
                                <div class="progress" style="height:5px;width:60px">
                                    <div class="progress-bar bg-info" style="width:<?= min(100,$pct) ?>%"></div>
                                </div>
                                <small class="text-muted"><?= $pct ?>%</small>
                            </td>
                            <td>
                                <?php
                                $sc = ['active'=>'success','paused'=>'warning','completed'=>'secondary','pending'=>'info','cancelled'=>'danger','rejected'=>'danger'];
                                $sl = ['active'=>'فعال','paused'=>'متوقف','completed'=>'تمام','pending'=>'انتظار','cancelled'=>'لغو','rejected'=>'رد'];
                                ?>
                                <span class="badge bg-<?= $sc[$c->status]??'secondary' ?>">
                                    <?= $sl[$c->status]??$c->status ?>
                                </span>
                            </td>
                            <td>
                                <div class="d-flex gap-1">
                                    <a href="<?= url('/user/ad-tasks/'.(int)$c->id) ?>"
                                       class="btn btn-xs btn-outline-secondary" title="جزئیات">
                                        <span class="material-icons" style="font-size:14px">visibility</span>
                                    </a>
                                    <?php if ($c->status === 'active'): ?>
                                    <button onclick="pauseCampaign(<?= (int)$c->id ?>)"
                                            class="btn btn-xs btn-outline-warning" title="توقف">
                                        <span class="material-icons" style="font-size:14px">pause</span>
                                    </button>
                                    <?php elseif ($c->status === 'paused'): ?>
                                    <button onclick="resumeCampaign(<?= (int)$c->id ?>)"
                                            class="btn btn-xs btn-outline-success" title="ادامه">
                                        <span class="material-icons" style="font-size:14px">play_arrow</span>
                                    </button>
                                    <?php endif; ?>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>

            <!-- Pagination -->
            <?php
            $totalPages = (int)ceil($total / $perPage);
            if ($totalPages > 1):
            ?>
            <div class="card-footer bg-white text-center">
                <nav>
                    <ul class="pagination justify-content-center mb-0">
                        <?php for ($i = 1; $i <= $totalPages; $i++): ?>
                        <li class="page-item <?= $i === $page ? 'active' : '' ?>">
                            <a class="page-link" href="?page=<?= $i ?>"><?= $i ?></a>
                        </li>
                        <?php endfor; ?>
                    </ul>
                </nav>
            </div>
            <?php endif; ?>
            <?php endif; ?>
        </div>
    </div>

</div>
</div>

<script>
const csrf = '<?= csrf_token() ?>';

async function pauseCampaign(id) {
    if (!confirm('این کمپین متوقف شود؟')) return;
    const r = await fetch(`<?= url('/user/ad-tasks') ?>/${id}/pause`, {
        method: 'POST', headers: {'X-CSRF-TOKEN': csrf}
    }).then(r => r.json());
    notyf[r.success ? 'success' : 'error'](r.message);
    if (r.success) setTimeout(() => location.reload(), 800);
}

async function resumeCampaign(id) {
    if (!confirm('ادامه کمپین شروع شود؟')) return;
    const r = await fetch(`<?= url('/user/ad-tasks') ?>/${id}/resume`, {
        method: 'POST', headers: {'X-CSRF-TOKEN': csrf}
    }).then(r => r.json());
    notyf[r.success ? 'success' : 'error'](r.message);
    if (r.success) setTimeout(() => location.reload(), 800);
}
</script>
