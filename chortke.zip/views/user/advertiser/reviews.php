<?php
// views/user/advertiser/reviews.php
$title = 'بررسی اجراها';
include BASE_PATH . '/views/partials/user/sidebar.php';
?>

<div class="main-content">
<div class="container-fluid py-4">

    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h4 class="mb-1">⏳ بررسی اجراها</h4>
            <p class="text-muted mb-0">مجموع <?= number_format($total) ?> اجرا در انتظار تأیید شما</p>
        </div>
        <?php if ($total > 0): ?>
        <button class="btn btn-success btn-sm" onclick="approveAll()">
            <span class="material-icons align-middle" style="font-size:18px">done_all</span>
            تأیید همه (<?= $total ?>)
        </button>
        <?php endif; ?>
    </div>

    <?php if (empty($reviews)): ?>
    <div class="card border-0 shadow-sm">
        <div class="card-body text-center py-5">
            <span class="material-icons fs-1 text-success">check_circle</span>
            <h5 class="mt-2">همه اجراها بررسی شده‌اند!</h5>
            <p class="text-muted">در حال حاضر اجرایی در انتظار بررسی شما نیست.</p>
            <a href="<?= url('/advertiser') ?>" class="btn btn-primary">بازگشت به داشبورد</a>
        </div>
    </div>
    <?php else: ?>

    <div class="row g-3" id="reviewsContainer">
        <?php foreach ($reviews as $r): $r = (object)$r; ?>
        <div class="col-md-6 col-xl-4" id="card-<?= (int)$r->id ?>">
            <div class="card border-0 shadow-sm h-100">
                <div class="card-header bg-light d-flex justify-content-between align-items-center py-2">
                    <div>
                        <strong class="small"><?= e($r->executor_name ?? 'کاربر') ?></strong>
                        <?php if (!empty($r->social_username)): ?>
                        <span class="text-muted small"> · @<?= e($r->social_username) ?></span>
                        <?php endif; ?>
                    </div>
                    <span class="badge bg-secondary small"><?= e($r->platform ?? '') ?></span>
                </div>
                <div class="card-body">
                    <p class="small text-muted mb-2">
                        <strong>کمپین:</strong> <?= e(mb_substr($r->ad_title ?? '', 0, 40)) ?><br>
                        <strong>نوع:</strong> <?= e($r->task_type ?? '') ?><br>
                        <strong>ارسال:</strong> <?= $r->submitted_at ? to_jalali($r->submitted_at) : '-' ?>
                    </p>

                    <!-- مدرک -->
                    <?php if (!empty($r->proof_image)): ?>
                    <div class="mb-2 text-center">
                        <img src="<?= asset('uploads/task-proofs/' . e($r->proof_image)) ?>"
                             class="img-fluid rounded"
                             style="max-height:200px;cursor:zoom-in"
                             onclick="showFullImage(this.src)"
                             alt="مدرک اجرا"
                             onerror="this.style.display='none'">
                    </div>
                    <?php else: ?>
                    <div class="text-center text-muted small py-2 bg-light rounded mb-2">
                        <span class="material-icons">image_not_supported</span>
                        <div>مدرکی ارسال نشده</div>
                    </div>
                    <?php endif; ?>
                </div>
                <div class="card-footer bg-white border-top-0 d-flex gap-2">
                    <button class="btn btn-success flex-fill btn-sm"
                            onclick="approve(<?= (int)$r->id ?>)">
                        <span class="material-icons align-middle" style="font-size:16px">check</span>
                        تأیید
                    </button>
                    <button class="btn btn-outline-danger flex-fill btn-sm"
                            data-bs-toggle="modal"
                            data-bs-target="#rejectModal"
                            data-id="<?= (int)$r->id ?>">
                        <span class="material-icons align-middle" style="font-size:16px">close</span>
                        رد
                    </button>
                </div>
            </div>
        </div>
        <?php endforeach; ?>
    </div>

    <!-- Pagination -->
    <?php if (($totalPages ?? 1) > 1): ?>
    <nav class="mt-4">
        <ul class="pagination justify-content-center">
            <?php for ($p = 1; $p <= $totalPages; $p++): ?>
            <li class="page-item <?= $p === $page ? 'active' : '' ?>">
                <a class="page-link" href="?page=<?= $p ?>"><?= $p ?></a>
            </li>
            <?php endfor; ?>
        </ul>
    </nav>
    <?php endif; ?>
    <?php endif; ?>

</div>
</div>

<!-- Modal رد کردن -->
<div class="modal fade" id="rejectModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">دلیل رد</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <p class="small text-muted">دلیل رد کردن را برای کاربر توضیح دهید:</p>
                <textarea id="rejectReason" class="form-control" rows="3"
                          placeholder="مثلاً: مدرک تصویر کاملاً واضح نیست..."></textarea>
            </div>
            <div class="modal-footer">
                <button class="btn btn-secondary" data-bs-dismiss="modal">انصراف</button>
                <button class="btn btn-danger" onclick="submitReject()">رد کردن</button>
            </div>
        </div>
    </div>
</div>

<!-- Modal تصویر بزرگ -->
<div class="modal fade" id="imageModal" tabindex="-1">
    <div class="modal-dialog modal-lg modal-dialog-centered">
        <div class="modal-content bg-dark">
            <div class="modal-body p-1 text-center">
                <img id="fullImg" src="" class="img-fluid rounded" alt="">
            </div>
        </div>
    </div>
</div>

<script>
const csrf = '<?= csrf_token() ?>';
let rejectId = null;

document.getElementById('rejectModal').addEventListener('show.bs.modal', e => {
    rejectId = e.relatedTarget?.dataset?.id ?? rejectId;
});

function approve(id) {
    if (!confirm('این اجرا تأیید شود؟')) return;
    doAction(id, 'approve', null);
}

function submitReject() {
    const reason = document.getElementById('rejectReason').value.trim();
    if (!reason) { notyf.error('دلیل الزامی است'); return; }

    const fd = new FormData();
    fd.append('reason', reason);
    doAction(rejectId, 'reject', fd, () => {
        bootstrap.Modal.getInstance(document.getElementById('rejectModal')).hide();
        document.getElementById('rejectReason').value = '';
    });
}

function doAction(id, action, formData, cb) {
    const body = formData || null;
    const headers = { 'X-CSRF-TOKEN': csrf };
    if (!formData) headers['Content-Type'] = 'application/json';

    fetch(`<?= url('/advertiser/reviews') ?>/${id}/${action}`, {
        method: 'POST',
        headers,
        body
    }).then(r => r.json()).then(d => {
        notyf[d.success ? 'success' : 'error'](d.message);
        if (d.success) {
            document.getElementById(`card-${id}`)?.remove();
            if (cb) cb();
        }
    });
}

function approveAll() {
    if (!confirm('همه اجراهای این صفحه تأیید شوند؟')) return;
    const cards = document.querySelectorAll('[id^="card-"]');
    let count = 0;
    cards.forEach(card => {
        const id = card.id.replace('card-', '');
        setTimeout(() => doAction(id, 'approve', null), count * 200);
        count++;
    });
}

function showFullImage(src) {
    document.getElementById('fullImg').src = src;
    new bootstrap.Modal(document.getElementById('imageModal')).show();
}
</script>
