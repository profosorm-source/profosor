<?php
// views/user/advertiser/analytics.php
$title = 'آنالیتیک تبلیغات';
include BASE_PATH . '/views/partials/user/sidebar.php';
?>

<div class="main-content">
<div class="container-fluid py-4">

    <!-- Header + فیلتر بازه زمانی -->
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h4 class="mb-1">📈 آنالیتیک تبلیغات</h4>
            <p class="text-muted mb-0">بررسی دقیق عملکرد کمپین‌های شما</p>
        </div>
        <div class="btn-group" role="group">
            <?php foreach ([7 => '۷ روز', 14 => '۱۴ روز', 30 => '۳۰ روز', 90 => '۹۰ روز'] as $d => $lbl): ?>
            <a href="?days=<?= $d ?>"
               class="btn btn-<?= $days === $d ? 'primary' : 'outline-secondary' ?> btn-sm">
                <?= $lbl ?>
            </a>
            <?php endforeach; ?>
        </div>
    </div>

    <!-- KPI Row -->
    <div class="row g-3 mb-4">
        <?php
        $kpis = [
            ['بودجه کل',      number_format($summary['total_budget']),   'attach_money','primary'],
            ['مصرف شده',      number_format($summary['spent_budget']),   'payments',    'danger'],
            ['کل اجرا',       number_format($summary['total_executions']),'task_alt',   'info'],
            ['تأیید شده',     number_format($summary['approved']),        'check_circle','success'],
            ['نرخ تأیید',     $summary['approval_rate'] . '%',           'verified',    'success'],
            ['استفاده بودجه', $summary['budget_utilization'] . '%',      'pie_chart',   'warning'],
        ];
        foreach ($kpis as [$label, $value, $icon, $color]):
        ?>
        <div class="col-md-2 col-6">
            <div class="card border-0 shadow-sm">
                <div class="card-body text-center py-3">
                    <span class="material-icons text-<?= $color ?> fs-3"><?= $icon ?></span>
                    <h5 class="mb-0 mt-1"><?= $value ?></h5>
                    <small class="text-muted"><?= $label ?></small>
                </div>
            </div>
        </div>
        <?php endforeach; ?>
    </div>

    <!-- نمودار اجراهای روزانه -->
    <div class="card border-0 shadow-sm mb-4">
        <div class="card-header bg-white">
            <h6 class="mb-0">📊 اجراهای روزانه (<?= $days ?> روز اخیر)</h6>
        </div>
        <div class="card-body">
            <canvas id="dailyChart" height="100"></canvas>
        </div>
    </div>

    <div class="row g-3">
        <!-- پلتفرم‌ها -->
        <div class="col-md-6">
            <div class="card border-0 shadow-sm h-100">
                <div class="card-header bg-white">
                    <h6 class="mb-0">🌐 مقایسه پلتفرم</h6>
                </div>
                <div class="card-body">
                    <canvas id="platformChart" height="250"></canvas>
                    <div class="mt-3">
                        <div class="table-responsive">
                            <table class="table table-sm small mb-0">
                                <thead class="table-light">
                                    <tr>
                                        <th>پلتفرم</th>
                                        <th>اجرا</th>
                                        <th>تأیید</th>
                                        <th>نرخ تأیید</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($platforms as $p): $p = (array)$p; ?>
                                    <tr>
                                        <td><?= e($p['platform']) ?></td>
                                        <td><?= number_format((int)$p['executions']) ?></td>
                                        <td><?= number_format((int)$p['approved']) ?></td>
                                        <td>
                                            <span class="badge bg-<?= (float)$p['approval_rate'] >= 70 ? 'success' : ((float)$p['approval_rate'] >= 40 ? 'warning' : 'danger') ?>">
                                                <?= (float)$p['approval_rate'] ?>%
                                            </span>
                                        </td>
                                    </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- نوع تسک -->
        <div class="col-md-6">
            <div class="card border-0 shadow-sm h-100">
                <div class="card-header bg-white">
                    <h6 class="mb-0">📋 مقایسه نوع تسک</h6>
                </div>
                <div class="card-body">
                    <canvas id="taskTypeChart" height="250"></canvas>
                    <div class="mt-3">
                        <div class="table-responsive">
                            <table class="table table-sm small mb-0">
                                <thead class="table-light">
                                    <tr>
                                        <th>نوع</th>
                                        <th>اجرا</th>
                                        <th>نرخ تأیید</th>
                                        <th>قیمت میانگین</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($taskTypes as $t): $t = (array)$t; ?>
                                    <tr>
                                        <td><?= e($t['task_type']) ?></td>
                                        <td><?= number_format((int)$t['executions']) ?></td>
                                        <td>
                                            <span class="badge bg-<?= (float)$t['approval_rate'] >= 70 ? 'success' : 'warning' ?>">
                                                <?= (float)$t['approval_rate'] ?>%
                                            </span>
                                        </td>
                                        <td><?= number_format((float)$t['avg_price']) ?></td>
                                    </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- بهترین کمپین‌ها -->
    <div class="card border-0 shadow-sm mt-4">
        <div class="card-header bg-white d-flex justify-content-between">
            <h6 class="mb-0">🏆 عملکرد کمپین‌ها</h6>
            <a href="<?= url('/advertiser/campaigns') ?>" class="btn btn-outline-secondary btn-sm">مشاهده همه</a>
        </div>
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover small mb-0">
                    <thead class="table-light">
                        <tr>
                            <th>کمپین</th>
                            <th>پلتفرم</th>
                            <th>اجراها</th>
                            <th>تأیید</th>
                            <th>نرخ تأیید</th>
                            <th>تکمیل</th>
                            <th>هزینه</th>
                            <th>وضعیت</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($topCampaigns as $c): $c = (array)$c; ?>
                        <tr>
                            <td>
                                <a href="<?= url('/user/ad-tasks/' . (int)$c['id']) ?>">
                                    <?= e(mb_substr($c['title'] ?? '', 0, 30)) ?>
                                </a>
                            </td>
                            <td><span class="badge bg-secondary"><?= e($c['platform']) ?></span></td>
                            <td><?= number_format((int)$c['total_executions']) ?></td>
                            <td><?= number_format((int)$c['approved']) ?></td>
                            <td>
                                <div class="d-flex align-items-center gap-1">
                                    <div class="progress flex-grow-1" style="height:6px;width:60px">
                                        <div class="progress-bar bg-success"
                                             style="width:<?= min(100, (float)$c['approval_rate']) ?>%"></div>
                                    </div>
                                    <small><?= (float)$c['approval_rate'] ?>%</small>
                                </div>
                            </td>
                            <td>
                                <div class="progress" style="height:6px;width:60px">
                                    <div class="progress-bar bg-primary"
                                         style="width:<?= min(100, (float)$c['completion_pct']) ?>%"></div>
                                </div>
                                <small class="text-muted"><?= (float)$c['completion_pct'] ?>%</small>
                            </td>
                            <td><?= number_format((float)$c['paid_out']) ?></td>
                            <td>
                                <?php
                                $sc = ['active'=>'success','paused'=>'warning','completed'=>'secondary','pending'=>'info','cancelled'=>'danger'];
                                $sl = ['active'=>'فعال','paused'=>'متوقف','completed'=>'تمام','pending'=>'انتظار','cancelled'=>'لغو'];
                                ?>
                                <span class="badge bg-<?= $sc[$c['status']] ?? 'secondary' ?>">
                                    <?= $sl[$c['status']] ?? $c['status'] ?>
                                </span>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

</div>
</div>

<script src="https://cdn.jsdelivr.net/npm/chart.js@4/dist/chart.umd.min.js"></script>
<script>
// داده‌های PHP → JS
const dailyData = <?= json_encode($dailyChart, JSON_UNESCAPED_UNICODE) ?>;
const platformData = <?= json_encode($platforms, JSON_UNESCAPED_UNICODE) ?>;
const taskTypeData = <?= json_encode($taskTypes, JSON_UNESCAPED_UNICODE) ?>;

const palette = ['#0d6efd','#198754','#dc3545','#ffc107','#0dcaf0','#6f42c1','#fd7e14','#20c997'];

// نمودار روزانه
new Chart(document.getElementById('dailyChart'), {
    type: 'line',
    data: {
        labels: dailyData.map(d => d.label),
        datasets: [
            {
                label: 'کل اجراها',
                data: dailyData.map(d => d.total),
                borderColor: '#0d6efd',
                backgroundColor: 'rgba(13,110,253,0.08)',
                fill: true,
                tension: 0.3,
            },
            {
                label: 'تأیید شده',
                data: dailyData.map(d => d.approved),
                borderColor: '#198754',
                backgroundColor: 'rgba(25,135,84,0.08)',
                fill: true,
                tension: 0.3,
            },
            {
                label: 'رد شده',
                data: dailyData.map(d => d.rejected),
                borderColor: '#dc3545',
                tension: 0.3,
            },
        ]
    },
    options: {
        responsive: true,
        plugins: { legend: { position: 'bottom' } },
        scales: { y: { beginAtZero: true } }
    }
});

// نمودار پلتفرم
new Chart(document.getElementById('platformChart'), {
    type: 'doughnut',
    data: {
        labels: platformData.map(p => p.platform),
        datasets: [{
            data: platformData.map(p => p.executions),
            backgroundColor: palette.slice(0, platformData.length),
        }]
    },
    options: {
        responsive: true,
        plugins: { legend: { position: 'bottom' } }
    }
});

// نمودار نوع تسک
new Chart(document.getElementById('taskTypeChart'), {
    type: 'bar',
    data: {
        labels: taskTypeData.map(t => t.task_type),
        datasets: [{
            label: 'اجراها',
            data: taskTypeData.map(t => t.executions),
            backgroundColor: palette,
        }]
    },
    options: {
        responsive: true,
        plugins: { legend: { display: false } },
        scales: { y: { beginAtZero: true } }
    }
});
</script>
