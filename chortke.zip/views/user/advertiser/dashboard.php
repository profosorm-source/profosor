<?php
// views/user/advertiser/dashboard.php
$title = 'داشبورد تبلیغ‌دهنده';
include BASE_PATH . '/views/partials/user/sidebar.php';
?>

<div class="main-content">
<div class="container-fluid py-4">

    <!-- Header -->
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h4 class="mb-1">📢 داشبورد تبلیغ‌دهنده</h4>
            <p class="text-muted mb-0">مدیریت و پایش کمپین‌های تبلیغاتی</p>
        </div>
        <div class="d-flex gap-2">
            <?php if (($pendingCount ?? 0) > 0): ?>
            <a href="<?= url('/advertiser/reviews') ?>" class="btn btn-warning btn-sm">
                <span class="material-icons align-middle" style="font-size:18px">rate_review</span>
                بررسی اجراها
                <span class="badge bg-danger ms-1"><?= (int)$pendingCount ?></span>
            </a>
            <?php endif; ?>
            <a href="<?= url('/user/ad-tasks/create') ?>" class="btn btn-primary btn-sm">
                <span class="material-icons align-middle" style="font-size:18px">add</span>
                کمپین جدید
            </a>
        </div>
    </div>

    <!-- KPI Cards -->
    <div class="row g-3 mb-4">
        <?php
        $cards = [
            ['کمپین فعال',     $summary['active_campaigns'],    'campaign',            'success'],
            ['کل اجراها',      $summary['total_executions'],    'task_alt',            'primary'],
            ['در انتظار بررسی',$summary['pending_review'],      'pending_actions',     'warning'],
            ['نرخ تأیید',      $summary['approval_rate'] . '%', 'verified',            'info'],
            ['بودجه مصرفی',   number_format($summary['spent_budget']), 'payments',     'danger'],
            ['بودجه باقی',    number_format($summary['remaining_budget']),'savings',   'secondary'],
        ];
        foreach ($cards as [$label, $value, $icon, $color]):
        ?>
        <div class="col-md-2 col-6">
            <div class="card border-0 shadow-sm h-100">
                <div class="card-body text-center py-3 px-2">
                    <span class="material-icons text-<?= $color ?> fs-3"><?= $icon ?></span>
                    <h5 class="mb-0 mt-1 fw-bold" style="font-size:1.1rem"><?= $value ?></h5>
                    <small class="text-muted"><?= $label ?></small>
                </div>
            </div>
        </div>
        <?php endforeach; ?>
    </div>

    <div class="row g-3">
        <!-- نمودار ۷ روزه -->
        <div class="col-lg-8">
            <div class="card border-0 shadow-sm h-100">
                <div class="card-header bg-white d-flex justify-content-between align-items-center">
                    <h6 class="mb-0">📊 اجراها - ۷ روز اخیر</h6>
                    <a href="<?= url('/advertiser/analytics') ?>" class="btn btn-outline-secondary btn-sm">
                        آنالیتیک کامل
                    </a>
                </div>
                <div class="card-body">
                    <canvas id="execChart" height="200"></canvas>
                </div>
            </div>
        </div>

        <!-- پلتفرم‌ها -->
        <div class="col-lg-4">
            <div class="card border-0 shadow-sm h-100">
                <div class="card-header bg-white">
                    <h6 class="mb-0">🌐 عملکرد پلتفرم</h6>
                </div>
                <div class="card-body p-0">
                    <?php if (empty($platformData)): ?>
                        <div class="text-center py-4 text-muted small">هنوز اطلاعاتی ندارد</div>
                    <?php else: ?>
                    <div class="list-group list-group-flush small">
                        <?php foreach ($platformData as $p): $p = (array)$p; ?>
                        <div class="list-group-item border-0 py-2">
                            <div class="d-flex justify-content-between align-items-center">
                                <span class="badge bg-primary me-2"><?= e($p['platform']) ?></span>
                                <span><?= number_format((int)$p['executions']) ?> اجرا</span>
                                <span class="text-success"><?= (float)$p['approval_rate'] ?>%</span>
                            </div>
                            <div class="progress mt-1" style="height:4px">
                                <div class="progress-bar bg-success"
                                     style="width:<?= min(100, (float)$p['approval_rate']) ?>%"></div>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <div class="row g-3 mt-1">
        <!-- اجراهای معلق -->
        <?php if (!empty($pendingReviews)): ?>
        <div class="col-lg-6">
            <div class="card border-0 shadow-sm">
                <div class="card-header bg-white d-flex justify-content-between">
                    <h6 class="mb-0">⏳ در انتظار بررسی شما</h6>
                    <a href="<?= url('/advertiser/reviews') ?>" class="btn btn-warning btn-sm">
                        مشاهده همه (<?= (int)$pendingCount ?>)
                    </a>
                </div>
                <div class="card-body p-0">
                    <div class="list-group list-group-flush small">
                        <?php foreach ($pendingReviews as $r): $r = (object)$r; ?>
                        <div class="list-group-item border-0 py-2">
                            <div class="d-flex justify-content-between align-items-start">
                                <div>
                                    <div class="fw-semibold"><?= e($r->executor_name ?? 'کاربر') ?></div>
                                    <div class="text-muted"><?= e($r->ad_title ?? '') ?></div>
                                </div>
                                <div class="d-flex gap-1">
                                    <button class="btn btn-xs btn-success"
                                            onclick="quickApprove(<?= (int)$r->id ?>)">✓</button>
                                    <button class="btn btn-xs btn-outline-danger"
                                            data-bs-toggle="modal"
                                            data-bs-target="#rejectModal"
                                            data-id="<?= (int)$r->id ?>">✗</button>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>
        </div>
        <?php endif; ?>

        <!-- اجراهای اخیر -->
        <div class="col-lg-<?= empty($pendingReviews) ? '12' : '6' ?>">
            <div class="card border-0 shadow-sm">
                <div class="card-header bg-white">
                    <h6 class="mb-0">🕐 آخرین فعالیت‌ها</h6>
                </div>
                <div class="card-body p-0">
                    <div class="list-group list-group-flush small">
                        <?php if (empty($recentExecs)): ?>
                            <div class="list-group-item text-center text-muted">هنوز فعالیتی نیست</div>
                        <?php else: ?>
                        <?php foreach ($recentExecs as $e): $e = (object)$e; ?>
                        <div class="list-group-item border-0 py-2">
                            <div class="d-flex justify-content-between align-items-center">
                                <div>
                                    <div><?= htmlspecialchars($e->executor_name ?? 'کاربر') ?> ←
                                        <span class="text-muted"><?= htmlspecialchars($e->ad_title ?? '') ?></span>
                                    </div>
                                </div>
                                <div>
                                    <?php
                                    $badges = [
                                        'approved' => 'success',
                                        'rejected' => 'danger',
                                        'submitted'=> 'warning',
                                        'expired'  => 'secondary',
                                    ];
                                    $labels = [
                                        'approved' => 'تأیید',
                                        'rejected' => 'رد',
                                        'submitted'=> 'در انتظار',
                                        'expired'  => 'منقضی',
                                    ];
                                    ?>
                                    <span class="badge bg-<?= $badges[$e->status] ?? 'secondary' ?>">
                                        <?= $labels[$e->status] ?? $e->status ?>
                                    </span>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; ?>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

</div>
</div>

<!-- Modal: رد کردن -->
<div class="modal fade" id="rejectModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">دلیل رد</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <textarea id="rejectReason" class="form-control" rows="3"
                          placeholder="دلیل رد کردن این اجرا را بنویسید..."></textarea>
            </div>
            <div class="modal-footer">
                <button class="btn btn-secondary" data-bs-dismiss="modal">انصراف</button>
                <button class="btn btn-danger" onclick="submitReject()">رد کردن</button>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/chart.js@4/dist/chart.umd.min.js"></script>
<script>
const csrf = '<?= csrf_token() ?>';
let rejectId = null;

// نمودار
async function loadChart() {
    const res = await fetch('<?= url('/advertiser/chart-data?days=7') ?>');
    const { data } = await res.json();

    new Chart(document.getElementById('execChart'), {
        type: 'bar',
        data: {
            labels: data.map(d => d.label),
            datasets: [
                {
                    label: 'تأیید شده',
                    data: data.map(d => d.approved),
                    backgroundColor: 'rgba(25,135,84,0.7)',
                },
                {
                    label: 'رد شده',
                    data: data.map(d => d.rejected),
                    backgroundColor: 'rgba(220,53,69,0.5)',
                }
            ]
        },
        options: {
            responsive: true,
            plugins: { legend: { position: 'bottom' } },
            scales: { x: { stacked: true }, y: { stacked: true, beginAtZero: true } }
        }
    });
}
loadChart();

function quickApprove(id) {
    if (!confirm('این اجرا تأیید شود؟')) return;
    fetch(`<?= url('/advertiser/reviews') ?>/${id}/approve`, {
        method: 'POST',
        headers: { 'X-CSRF-TOKEN': csrf }
    }).then(r => r.json()).then(d => {
        notyf[d.success ? 'success' : 'error'](d.message);
        if (d.success) setTimeout(() => location.reload(), 800);
    });
}

document.getElementById('rejectModal').addEventListener('show.bs.modal', e => {
    rejectId = e.relatedTarget.dataset.id;
});

function submitReject() {
    const reason = document.getElementById('rejectReason').value.trim();
    if (!reason) { notyf.error('دلیل الزامی است'); return; }

    const fd = new FormData();
    fd.append('reason', reason);
    fd.append('_token', csrf);

    fetch(`<?= url('/advertiser/reviews') ?>/${rejectId}/reject`, {
        method: 'POST',
        body: fd
    }).then(r => r.json()).then(d => {
        notyf[d.success ? 'success' : 'error'](d.message);
        if (d.success) { bootstrap.Modal.getInstance(document.getElementById('rejectModal')).hide(); setTimeout(() => location.reload(), 800); }
    });
}
</script>
