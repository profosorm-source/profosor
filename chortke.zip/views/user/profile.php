<?php
/**
 * صفحه پروفایل کاربر
 * شامل: اطلاعات شخصی + آواتار + تغییر رمز عبور
 */

$title = 'پروفایل من';
$currentPage = 'profile';
ob_start();
?>

<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/notyf@3/notyf.min.css">
<link rel="stylesheet" href="<?= asset('assets/vendor/sweetalert2/sweetalert2.min.css') ?>">


<div class="profile-grid">
<!-- کارت آواتار -->
<div class="profile-card">
    <div class="profile-card-header">
        <h5>
            <i class="material-icons">account_circle</i>
            تصویر پروفایل
        </h5>
    </div>
    <div class="profile-card-body">
        <div class="avatar-section">
            <div class="avatar-wrapper">
                <img id="avatarPreview" 
                     src="<?= asset('uploads/avatars/' . ($user->avatar ?: 'default-avatar.png')) ?>" 
                     alt="<?= e($user->full_name) ?>" 
                     class="avatar-image">
                
                <!-- دکمه تغییر تصویر (روی عکس) -->
                <label for="avatarInput" class="avatar-overlay" title="تغییر تصویر">
                    <i class="material-icons">camera_alt</i>
                </label>
                
                <!-- Input مخفی برای انتخاب فایل -->
                <input type="file" 
                       id="avatarInput" 
                       name="avatar"
                       accept="image/jpeg,image/png,image/jpg,image/gif,image/webp" 
                       style="display: none;">
                
                <!-- لودر -->
                <div class="avatar-preview-loader" id="avatarLoader">
                    <i class="material-icons">hourglass_empty</i>
                </div>
            </div>
            
            <p class="avatar-info">
                <i class="material-icons" style="font-size: 14px; vertical-align: middle;">info</i>
                فرمت‌های مجاز: JPG, PNG, GIF, WEBP | حداکثر حجم: 2 مگابایت
            </p>
            
            <div class="avatar-actions">
                <!-- دکمه انتخاب تصویر -->
                <button type="button" class="btn btn-upload" onclick="document.getElementById('avatarInput').click()">
                    <i class="material-icons" style="font-size: 14px; vertical-align: middle;">upload</i>
                    انتخاب تصویر جدید
                </button>
                
                <!-- دکمه حذف (فقط اگر آواتار سفارشی دارد) -->
                <?php if ($user->avatar && $user->avatar !== 'default-avatar.png'): ?>
                <button type="button" class="btn btn-delete-avatar" onclick="deleteAvatar()">
                    <i class="material-icons" style="font-size: 14px; vertical-align: middle;">delete</i>
                    حذف تصویر فعلی
                </button>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<!-- کارت اطلاعات شخصی -->
<div class="profile-card">
    <div class="profile-card-header">
        <h5>
            <i class="material-icons">person</i>
            اطلاعات شخصی
        </h5>
    </div>
    <div class="profile-card-body">
        <form method="POST" action="<?= url('user/profile/update') ?>">
            <?= csrf_field() ?>
            
            <!-- اطلاعات پایه -->
            <div class="form-section">
                <div class="form-section-title">
                    <i class="material-icons">badge</i>
                    اطلاعات پایه
                </div>
                
                <div class="row">
                    <div class="col-md-6">
                        <div class="mb-3">
                            <label class="form-label">
                                <span class="required">*</span>
                                نام کامل
                            </label>
                            <input type="text" 
                                   name="full_name" 
                                   class="form-control" 
                                   value="<?= e($user->full_name) ?>" 
                                   placeholder="نام و نام خانوادگی خود را وارد کنید"
                                   required>
                        </div>
                    </div>
                    
                    <div class="col-md-6">
                        <div class="mb-3">
                            <label class="form-label">ایمیل</label>
                            <input type="email" 
                                   value="<?= e($user->email) ?>" 
                                   class="form-control" 
                                   readonly>
                            <small class="form-text">
                                <i class="material-icons" style="font-size: 12px; vertical-align: middle;">lock</i>
                                ایمیل قابل تغییر نیست
                            </small>
                        </div>
                    </div>
                </div>
                
                <div class="row">
                    <div class="col-md-6">
                        <div class="mb-3">
                            <label class="form-label">شماره موبایل</label>
                            <input type="text" 
                                   name="mobile" 
                                   class="form-control" 
                                   value="<?= e($user->mobile ?? '') ?>" 
                                   pattern="09[0-9]{9}" 
                                   placeholder="09123456789"
                                   maxlength="11">
                            <small class="form-text">مثال: 09123456789</small>
                        </div>
                    </div>
                    
                    <div class="col-md-6">
                        <div class="mb-3">
                            <label class="form-label">کد ملی</label>
                            <input type="text" 
                                   name="national_id" 
                                   class="form-control" 
                                   value="<?= e($user->national_id ?? '') ?>" 
                                   pattern="[0-9]{10}" 
                                   placeholder="1234567890"
                                   maxlength="10">
                            <small class="form-text">10 رقم بدون فاصله</small>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- اطلاعات تکمیلی -->
            <div class="form-section">
                <div class="form-section-title">
                    <i class="material-icons">description</i>
                    اطلاعات تکمیلی
                </div>
                
                <div class="row">
                    <div class="col-md-6">
                        <div class="mb-3">
                            <label class="form-label">تاریخ تولد</label>
                            <input type="date" 
                                   name="birth_date" 
                                   class="form-control" 
                                   value="<?= e($user->birth_date ?? '') ?>">
                        </div>
                    </div>
                    
                    <div class="col-md-6">
                        <div class="mb-3">
                            <label class="form-label">جنسیت</label>
                            <select name="gender" class="form-select">
                                <option value="">انتخاب کنید</option>
                                <option value="male" <?= ($user->gender ?? '') === 'male' ? 'selected' : '' ?>>مرد</option>
                                <option value="female" <?= ($user->gender ?? '') === 'female' ? 'selected' : '' ?>>زن</option>
                                <option value="other" <?= ($user->gender ?? '') === 'other' ? 'selected' : '' ?>>سایر</option>
                            </select>
                        </div>
                    </div>
                </div>
                
                <div class="row">
                    <div class="col-md-12">
                        <div class="mb-3">
                            <label class="form-label">آدرس</label>
                            <textarea name="address" 
                                      class="form-control" 
                                      rows="3" 
                                      placeholder="آدرس کامل پستی خود را وارد کنید"><?= e($user->address ?? '') ?></textarea>
                            <small class="form-text">این اطلاعات برای ارسال پستی استفاده می‌شود</small>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- اطلاعات سیستمی -->
            <div class="info-box">
                <div class="info-box-title">
                    <i class="material-icons">info</i>
                    اطلاعات حساب کاربری
                </div>
                <div class="row">
                    <div class="col-md-6">
                        <p><strong>تاریخ عضویت:</strong> <?= e($user->created_at ? date('Y/m/d H:i', strtotime($user->created_at)) : '-') ?></p>
                        <p><strong>آخرین ورود:</strong> <?= e($user->last_login ? date('Y/m/d H:i', strtotime($user->last_login)) : 'هرگز') ?></p>
                    </div>
                    <div class="col-md-6">
                        <p><strong>نقش:</strong> 
                            <span style="background: #e8f5e9; color: #4caf50; padding: 2px 8px; border-radius: 4px; font-size: 11px;">
                                <?= e($user->role) ?>
                            </span>
                        </p>
                        <p><strong>وضعیت:</strong> 
                            <span style="background: <?= $user->status === 'active' ? '#e8f5e9' : '#ffebee' ?>; color: <?= $user->status === 'active' ? '#4caf50' : '#f44336' ?>; padding: 2px 8px; border-radius: 4px; font-size: 11px;">
                                <?= e($user->status) ?>
                            </span>
                        </p>
                    </div>
                </div>
            </div>
            
            <div style="margin-top: 20px;">
                <button type="submit" class="btn-save">
                    <i class="material-icons">save</i>
                    ذخیره تغییرات
                </button>
            </div>
        </form>
    </div>
</div>

<!-- کارت تغییر رمز عبور -->
<div class="profile-card card-password">
<div class="profile-card">
    <div class="profile-card-header">
        <h5>
            <i class="material-icons">lock</i>
            تغییر رمز عبور
        </h5>
    </div>
    <div class="profile-card-body">
        <form method="POST" action="<?= url('user/profile/change-password') ?>" id="changePasswordForm">
            <?= csrf_field() ?>
            
            <div class="form-section">
                <div class="row">
                    <div class="col-md-12">
                        <div class="mb-3">
                            <label class="form-label">
                                <span class="required">*</span>
                                رمز عبور فعلی
                            </label>
                            <input type="password" 
                                   name="current_password" 
                                   class="form-control" 
                                   placeholder="رمز عبور فعلی خود را وارد کنید"
                                   required>
                        </div>
                    </div>
                </div>
                
                <div class="row">
                    <div class="col-md-6">
                        <div class="mb-3">
                            <label class="form-label">
                                <span class="required">*</span>
                                رمز عبور جدید
                            </label>
                            <input type="password" 
                                   name="new_password" 
                                   id="newPassword"
                                   class="form-control" 
                                   placeholder="رمز عبور جدید (حداقل 8 کاراکتر)"
                                   minlength="8"
                                   required>
                            <small class="form-text">حداقل 8 کاراکتر، ترکیبی از حروف و اعداد</small>
                        </div>
                    </div>
                    
                    <div class="col-md-6">
                        <div class="mb-3">
                            <label class="form-label">
                                <span class="required">*</span>
                                تکرار رمز عبور جدید
                            </label>
                            <input type="password" 
                                   name="new_password_confirmation" 
                                   id="confirmPassword"
                                   class="form-control" 
                                   placeholder="رمز عبور جدید را دوباره وارد کنید"
                                   minlength="8"
                                   required>
                        </div>
                    </div>
                </div>
            </div>
            
            <button type="submit" class="btn-save">
                <i class="material-icons">vpn_key</i>
                تغییر رمز عبور
            </button>
        </form>
    </div>
</div>
</div>
</div>
<style>
/* ===== کارت‌های اصلی ===== */
.profile-card {
    background: #fff;
    border-radius: 10px;
    box-shadow: 0 2px 8px rgba(0,0,0,0.06);
    overflow: hidden;
    margin-bottom: 20px;
    animation: fadeIn 0.5s ease;
}

.profile-card:nth-child(2) {
    animation-delay: 0.1s;
}

.profile-card-header {
    background: linear-gradient(135deg, #4fc3f7 0%, #29b6f6 100%);
    border: none;
    padding: 15px 20px;
    border-top: 3px solid #0288d1;
}

.profile-card-header h5 {
    color: #fff;
    margin: 0;
    font-size: 15px;
    font-weight: 700;
    display: flex;
    align-items: center;
}

.profile-card-header h5 i {
    margin-left: 10px;
    font-size: 20px;
}

.profile-card-body {
    padding: 25px;
}

/* ===== بخش آواتار ===== */
.avatar-section {
    text-align: center;
    padding: 30px 0;
    border-bottom: 1px solid #f0f0f0;
    margin-bottom: 25px;
}

.avatar-wrapper {
    position: relative;
    display: inline-block;
}

.avatar-image {
    width: 150px;
    height: 150px;
    border-radius: 50%;
    border: 4px solid #ffa726;
    object-fit: cover;
    box-shadow: 0 4px 12px rgba(0,0,0,0.15);
    transition: transform 0.3s ease;
}

.avatar-image:hover {
    transform: scale(1.05);
}

.avatar-overlay {
    position: absolute;
    bottom: 5px;
    right: 5px;
    background: linear-gradient(135deg, #4fc3f7 0%, #29b6f6 100%);
    width: 45px;
    height: 45px;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    cursor: pointer;
    box-shadow: 0 2px 8px rgba(0,0,0,0.2);
    transition: all 0.3s ease;
}

.avatar-overlay:hover {
    transform: scale(1.1);
    box-shadow: 0 4px 12px rgba(0,0,0,0.3);
}

.avatar-overlay i {
    color: #fff;
    font-size: 20px;
}

.avatar-info {
    margin-top: 15px;
    color: #666;
    font-size: 12px;
}

.avatar-actions {
    margin-top: 15px;
    display: flex;
    gap: 10px;
    justify-content: center;
    flex-wrap: wrap;
}

/* ===== فرم‌ها ===== */
.form-section {
    margin-bottom: 25px;
    padding-bottom: 25px;
    border-bottom: 1px solid #f0f0f0;
}

.form-section:last-of-type {
    border-bottom: none;
    margin-bottom: 0;
    padding-bottom: 0;
}

.form-section-title {
    font-size: 14px;
    font-weight: 700;
    color: #333;
    margin-bottom: 15px;
    padding-bottom: 10px;
    border-bottom: 2px solid #4fc3f7;
    display: flex;
    align-items: center;
}

.form-section-title i {
    margin-left: 8px;
    color: #4fc3f7;
}

.form-label {
    font-size: 12px;
    font-weight: 600;
    color: #555;
    margin-bottom: 5px;
    display: block;
}

.form-label .required {
    color: #f44336;
    margin-right: 3px;
}

.form-control,
.form-select {
    border-radius: 8px;
    border: 1px solid #e0e0e0;
    padding: 10px 12px;
    font-size: 13px;
    transition: all 0.3s ease;
}

.form-control:focus,
.form-select:focus {
    border-color: #4fc3f7;
    box-shadow: 0 0 0 3px rgba(79, 195, 247, 0.1);
    outline: none;
}

.form-control[readonly] {
    background: #f5f5f5;
    cursor: not-allowed;
    color: #999;
}

.form-text {
    font-size: 11px;
    color: #999;
    margin-top: 5px;
    display: block;
}

/* ===== دکمه‌ها ===== */
.btn-save {
    background: linear-gradient(135deg, #4caf50 0%, #388e3c 100%);
    border: none;
    color: #fff;
    padding: 10px 30px;
    border-radius: 8px;
    font-size: 13px;
    font-weight: 600;
    transition: all 0.3s ease;
    display: inline-flex;
    align-items: center;
    gap: 8px;
}

.btn-save:hover {
    transform: translateY(-2px);
    box-shadow: 0 4px 12px rgba(76, 175, 80, 0.3);
}

.btn-save i {
    font-size: 16px;
}

.btn-upload {
    background: linear-gradient(135deg, #4fc3f7 0%, #29b6f6 100%);
    border: none;
    color: #fff;
    padding: 8px 20px;
    border-radius: 8px;
    font-size: 12px;
    font-weight: 600;
    transition: all 0.3s ease;
}

.btn-upload:hover {
    transform: translateY(-2px);
    box-shadow: 0 4px 12px rgba(79, 195, 247, 0.3);
}

.btn-delete-avatar {
    background: linear-gradient(135deg, #f44336 0%, #d32f2f 100%);
    border: none;
    color: #fff;
    padding: 8px 20px;
    border-radius: 8px;
    font-size: 12px;
    font-weight: 600;
    transition: all 0.3s ease;
}

.btn-delete-avatar:hover {
    transform: translateY(-2px);
    box-shadow: 0 4px 12px rgba(244, 67, 54, 0.3);
}

/* ===== باکس اطلاعاتی ===== */
.info-box {
    background: linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%);
    border-radius: 8px;
    padding: 15px;
    margin-top: 20px;
    border-right: 4px solid #4fc3f7;
}

.info-box-title {
    font-size: 13px;
    font-weight: 700;
    color: #333;
    margin-bottom: 10px;
    display: flex;
    align-items: center;
}

.info-box-title i {
    margin-left: 8px;
    color: #4fc3f7;
}

.info-box p {
    margin: 5px 0;
    font-size: 12px;
    color: #555;
}

.info-box strong {
    color: #333;
}

/* ===== Grid سیستم داخلی فرم ===== */
.row {
    display: flex;
    flex-wrap: wrap;
    margin: 0 -10px;
}

.col-md-6 {
    flex: 0 0 50%;
    max-width: 50%;
    padding: 0 10px;
}

.col-md-12 {
    flex: 0 0 100%;
    max-width: 100%;
    padding: 0 10px;
}

.mb-3 {
    margin-bottom: 15px;
}

/* ===== Grid کلی صفحه پروفایل ===== */
.profile-grid {
    display: grid;
    grid-template-columns: 1fr;
    gap: 20px;
}

/* دسکتاپ */
/* ===== Grid حرفه‌ای صفحه پروفایل ===== */

.profile-grid {
    display: grid;
    grid-template-columns: 1fr;
    gap: 20px;
}

/* دسکتاپ */
@media (min-width: 1200px) {

    .profile-grid {
        grid-template-columns: 1fr 420px; /* راست | چپ */
        align-items: stretch;
    }

    /* کارت 1 = آواتار (چپ بالا) */
    .profile-grid > .profile-card:nth-of-type(1) {
        grid-column: 2;
        grid-row: 1;
    }

    /* کارت 3 = رمز عبور (چپ پایین) */
    .profile-grid > .profile-card:nth-of-type(3) {
        grid-column: 2;
        grid-row: 2;
    }

    /* کارت 2 = اطلاعات (راست، کل ارتفاع) */
    .profile-grid > .profile-card:nth-of-type(2) {
        grid-column: 1;
        grid-row: 1 / span 2;
        display: flex;
        flex-direction: column;
    }

    .profile-grid > .profile-card:nth-of-type(2) .profile-card-body {
        flex: 1;
    }

    .profile-grid > .profile-card {
        margin-bottom: 0;
        height: 100%;
    }

    .card-password > .profile-card {
        box-shadow: none;
        margin: 0;
        border-radius: 0;
    }
}



/* تبلت */
@media (min-width: 768px) and (max-width: 1199px) {
    .profile-grid {
        grid-template-columns: 1fr;
    }
}

/* موبایل */
@media (max-width: 768px) {
    .col-md-6 {
        flex: 0 0 100%;
        max-width: 100%;
    }

    .avatar-image {
        width: 120px;
        height: 120px;
    }

    .profile-card-body {
        padding: 20px 15px;
    }

    .avatar-actions {
        flex-direction: column;
    }

    .avatar-actions .btn {
        width: 100%;
    }
}

/* ===== انیمیشن‌ها ===== */
@keyframes fadeIn {
    from { opacity: 0; transform: translateY(10px); }
    to { opacity: 1; transform: translateY(0); }
}

@keyframes spin {
    0% { transform: rotate(0deg); }
    100% { transform: rotate(360deg); }
}

/* ===== پیش‌نمایش آواتار ===== */
.avatar-preview-loader {
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    background: rgba(0,0,0,0.7);
    width: 150px;
    height: 150px;
    border-radius: 50%;
    display: none;
    align-items: center;
    justify-content: center;
}

.avatar-preview-loader.active {
    display: flex;
}

.avatar-preview-loader i {
    color: #fff;
    font-size: 30px;
    animation: spin 1s linear infinite;
}


</style>
<script src="https://cdn.jsdelivr.net/npm/notyf@3/notyf.min.js"></script>
<script src="<?= asset('assets/vendor/sweetalert2/sweetalert2.all.min.js') ?>"></script>


<script>
(function () {
    // اگر قبلاً تعریف شده، دوباره نساز
    if (typeof window.showNotification === 'function') return;

    const notyf = new Notyf({
      duration: 4000,
      position: { x: 'left', y: 'top' }
    });

    window.showNotification = function (type, message) {
      // type: success | error | warning | info
      notyf.open({ type: type, message: message });
    };
  })();
(function () {
	  const input = document.getElementById('avatarInput');
  const loader = document.getElementById('avatarLoader');
  const preview = document.getElementById('avatarPreview');

  if (!input) return;

  const MAX_BYTES = 2 * 1024 * 1024; // 2MB
  const ALLOWED = ['image/jpeg','image/png','image/jpg','image/gif','image/webp'];

  function stopLoader(){ if (loader) loader.classList.remove('active'); }
  function startLoader(){ if (loader) loader.classList.add('active'); }

  input.addEventListener('change', async function (e) {
    const file = e.target.files && e.target.files[0] ? e.target.files[0] : null;

    if (!file) return;

    // اعتبارسنجی سمت کلاینت (قبل از ارسال)
    if (!ALLOWED.includes(file.type)) {
      showNotification('error', 'فرمت فایل مجاز نیست. فقط JPG/PNG/GIF/WEBP');
      e.target.value = '';
      return;
    }

    if (file.size > MAX_BYTES) {
      showNotification('error', 'حجم تصویر نباید بیشتر از ۲ مگابایت باشد');
      e.target.value = '';
      return;
    }

    // پیش‌نمایش
    try {
      const reader = new FileReader();
      reader.onload = (ev) => { if (preview) preview.src = ev.target.result; };
      reader.readAsDataURL(file);
    } catch (_) {}

    startLoader();

    const fd = new FormData();
    fd.append('avatar', file);

    let res;
    try {
      res = await fetch('<?= url('user/profile/upload-avatar') ?>', {
        method: 'POST',
        body: fd,
        headers: {
          'X-Requested-With': 'XMLHttpRequest',
          'X-CSRF-TOKEN': '<?= csrf_token() ?>'
        }
      });
    } catch (err) {
      stopLoader();
      showNotification('error', 'خطا در ارتباط با سرور');
      e.target.value = '';
      return;
    }

    const contentType = (res.headers.get('content-type') || '').toLowerCase();
    const raw = await res.text();

    stopLoader();

    if (!contentType.includes('application/json')) {
      showNotification('error', 'پاسخ سرور نامعتبر است');
      console.log('Non-JSON response:', raw);
      e.target.value = '';
      return;
    }

    let data;
    try {
      data = JSON.parse(raw);
    } catch (err) {
      showNotification('error', 'خطا در پردازش پاسخ سرور');
      console.log('JSON parse error:', err, raw);
      e.target.value = '';
      return;
    }

    if (!data.success) {
      showNotification('error', data.message || 'آپلود ناموفق بود');
      e.target.value = '';
      return;
    }

    // موفق
    showNotification('success', data.message || 'آواتار بروزرسانی شد');

    if (data.avatar_url) {
      const t = Date.now();
      document.querySelectorAll('.user-avatar').forEach(img => img.src = data.avatar_url + '?t=' + t);
      if (preview) preview.src = data.avatar_url + '?t=' + t;
    }

    e.target.value = '';
  });
 window.deleteAvatar = async function () {
  const result = await Swal.fire({
    title: 'حذف تصویر پروفایل؟',
    text: 'این عملیات قابل بازگشت است و تصویر پیش‌فرض جایگزین می‌شود.',
    icon: 'warning',
    showCancelButton: true,
    confirmButtonText: 'بله، حذف شود',
    cancelButtonText: 'انصراف',
    reverseButtons: true
  });

  if (!result.isConfirmed) return;

  try {
    const res = await fetch('<?= url('user/profile/delete-avatar') ?>', {
      method: 'POST',
      headers: {
        'X-Requested-With': 'XMLHttpRequest',
        'X-CSRF-TOKEN': '<?= csrf_token() ?>'
      }
    });

    const data = await res.json();

    if (data.success) {
      showNotification('success', data.message || 'حذف شد');

      if (data.avatar_url) {
        const t = Date.now();
        document.querySelectorAll('.user-avatar').forEach(img => img.src = data.avatar_url + '?t=' + t);
        const prev = document.getElementById('avatarPreview');
        if (prev) prev.src = data.avatar_url + '?t=' + t;
      }

      setTimeout(() => location.reload(), 700);
      return;
    }

    showNotification('error', data.message || 'خطا در حذف آواتار');
  } catch (e) {
    console.error(e);
    showNotification('error', 'خطا در ارتباط با سرور');
  }
}
})();
</script>

<?php
$content = ob_get_clean();
include __DIR__ . '/../layouts/user.php';
?>