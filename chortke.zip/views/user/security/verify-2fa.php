<?php ob_start(); ?>

<div class="container">
    <div class="row justify-content-center align-items-center min-vh-100">
        <div class="col-md-5 col-lg-4">
            
            <div class="text-center mb-4">
                <i class="material-icons-outlined text-white" style="font-size: 80px;">security</i>
                <h2 class="text-white mt-3">تایید احراز هویت</h2>
            </div>
            
            <div class="card shadow-lg border-0">
                <div class="card-body p-4">
                    
                    <p class="text-center text-muted mb-4">
                        لطفاً کد 6 رقمی از Google Authenticator را وارد کنید.
                    </p>
                    
                    <form method="POST" action="<?= url('security/2fa/verify') ?>" id="verify-form">
                        <?= csrf_field() ?>
                        
                        <div class="mb-4">
                            <label class="form-label">کد احراز هویت</label>
                            <input type="text" 
                                   name="code" 
                                   class="form-control form-control-lg text-center" 
                                   placeholder="123456"
                                   maxlength="6"
                                   pattern="[0-9]{6}"
                                   autocomplete="off"
                                   autofocus
                                   required>
                        </div>
                        
                        <button type="submit" class="btn btn-primary btn-lg w-100 mb-3">
                            <i class="material-icons-outlined">check</i>
                            تایید
                        </button>
                        
                        <div class="text-center">
                            <a href="<?= url('logout') ?>" class="text-decoration-none text-muted">
                                <i class="material-icons-outlined" style="font-size: 16px;">logout</i>
                                انصراف و خروج
                            </a>
                        </div>
                        
                    </form>
                    
                </div>
            </div>
            
        </div>
    </div>
</div>

<script>
$('#verify-form').on('submit', function(e) {
    e.preventDefault();
    
    const form = $(this);
    const btn = form.find('button[type="submit"]');
    const btnText = btn.html();
    
    btn.prop('disabled', true).html('<span class="spinner-border spinner-border-sm"></span> در حال تایید...');
    
    $.ajax({
        url: form.attr('action'),
        method: 'POST',
        data: form.serialize(),
        success: function(response) {
            if (response.success) {
                showToast(response.message, 'success');
                setTimeout(() => {
                    window.location.href = response.data.redirect;
                }, 1000);
            } else {
                showToast(response.message, 'danger');
                form[0].reset();
                btn.prop('disabled', false).html(btnText);
            }
        },
        error: function(xhr) {
            const response = xhr.responseJSON;
            showToast(response.message || 'کد نامعتبر است', 'danger');
            form[0].reset();
            btn.prop('disabled', false).html(btnText);
        }
    });
});
</script>

<?php
$content = ob_get_clean();
$layout = __DIR__ . '/../layouts/app.php';
require $layout;
?>