<?php ob_start(); ?>

<div class="row mb-4">
    <div class="col-12">
        <h3>
            <i class="material-icons-outlined">security</i>
            احراز هویت دو مرحله‌ای (2FA)
        </h3>
        <p class="text-muted">افزایش امنیت حساب با استفاده از Google Authenticator</p>
    </div>
</div>

<div class="row justify-content-center">
    <div class="col-md-8">
        
        <?php if ($is_enabled): ?>
            
            <!-- 2FA فعال است -->
            <div class="card border-0 shadow-sm">
                <div class="card-body text-center p-5">
                    <i class="material-icons-outlined text-success" style="font-size: 80px;">verified_user</i>
                    <h4 class="mt-3 text-success">احراز هویت دو مرحله‌ای فعال است</h4>
                    <p class="text-muted">حساب شما با لایه امنیتی اضافی محافظت می‌شود.</p>
                    
                    <hr class="my-4">
                    
                    <h5 class="mb-3">غیرفعال کردن</h5>
                    <p class="text-muted small mb-3">
                        برای غیرفعال کردن، رمز عبور خود را وارد کنید.
                    </p>
                    
                    <form id="disable-2fa-form" class="mx-auto" style="max-width: 400px;">
                        <?= csrf_field() ?>
                        
                        <div class="mb-3">
                            <input type="password" 
                                   name="password" 
                                   class="form-control" 
                                   placeholder="رمز عبور"
                                   required>
                        </div>
                        
                        <button type="submit" class="btn btn-danger">
                            <i class="material-icons-outlined">lock_open</i>
                            غیرفعال کردن
                        </button>
                    </form>
                </div>
            </div>
            
        <?php else: ?>
            
            <!-- 2FA غیرفعال است -->
            <div class="card border-0 shadow-sm">
                <div class="card-body p-4">
                    
                    <div class="text-center mb-4">
                        <i class="material-icons-outlined text-warning" style="font-size: 80px;">shield</i>
                        <h4 class="mt-3">احراز هویت دو مرحله‌ای غیرفعال است</h4>
                    </div>
                    
                    <div class="alert alert-info">
                        <strong>چگونه فعال کنیم؟</strong>
                        <ol class="mb-0 mt-2">
                            <li>اپلیکیشن Google Authenticator را نصب کنید</li>
                            <li>QR Code زیر را اسکن کنید</li>
                            <li>کد 6 رقمی نمایش داده شده را وارد کنید</li>
                        </ol>
                    </div>
                    
                    <hr>
                    
                    <!-- QR Code -->
                    <div class="text-center mb-4">
                        <h5 class="mb-3">QR Code</h5>
                        <img src="<?= $qr_code_url ?>" alt="QR Code" class="img-fluid border p-2" style="max-width: 250px;">
                        
                        <div class="mt-3">
                            <small class="text-muted">یا این کد را به صورت دستی وارد کنید:</small>
                            <div class="input-group mt-2">
                                <input type="text" 
                                       class="form-control text-center" 
                                       id="secret-key" 
                                       value="<?= e($secret) ?>" 
                                       readonly>
                                <button class="btn btn-outline-secondary" 
                                        type="button" 
                                        onclick="copyToClipboard('<?= e($secret) ?>')">
                                    <i class="material-icons-outlined">content_copy</i>
                                </button>
                            </div>
                        </div>
                    </div>
                    
                    <hr>
                    
                    <!-- فعالسازی -->
                    <form id="enable-2fa-form">
                        <?= csrf_field() ?>
                        
                        <h5 class="mb-3 text-center">فعالسازی</h5>
                        
                        <div class="mb-3">
                            <label class="form-label">کد 6 رقمی از Google Authenticator</label>
                            <input type="text" 
                                   name="code" 
                                   class="form-control text-center" 
                                   placeholder="123456"
                                   maxlength="6"
                                   pattern="[0-9]{6}"
                                   autocomplete="off"
                                   required>
                        </div>
                        
                        <button type="submit" class="btn btn-success w-100">
                            <i class="material-icons-outlined">check_circle</i>
                            فعالسازی
                        </button>
                    </form>
                    
                </div>
            </div>
            
        <?php endif; ?>
        
    </div>
</div>

<!-- Modal برای نمایش کدهای بازیابی -->
<div class="modal fade" id="recovery-codes-modal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">
                    <i class="material-icons-outlined">vpn_key</i>
                    کدهای بازیابی
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <div class="alert alert-warning">
                    <strong>⚠️ مهم:</strong> این کدها را در جای امنی ذخیره کنید. 
                    در صورت از دست دادن دسترسی به Google Authenticator، 
                    می‌توانید با این کدها وارد شوید.
                </div>
                
                <div class="row g-2" id="recovery-codes-list"></div>
                
                <div class="text-center mt-3">
                    <button type="button" class="btn btn-primary" onclick="downloadRecoveryCodes()">
                        <i class="material-icons-outlined">download</i>
                        دانلود کدها
                    </button>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
let recoveryCodes = [];

// فعالسازی 2FA
$('#enable-2fa-form').on('submit', function(e) {
    e.preventDefault();
    
    const form = $(this);
    const btn = form.find('button[type="submit"]');
    const btnText = btn.html();
    
    btn.prop('disabled', true).html('<span class="spinner-border spinner-border-sm"></span> در حال فعالسازی...');
    
    $.ajax({
        url: '<?= url('security/2fa/enable') ?>',
        method: 'POST',
        data: form.serialize(),
        success: function(response) {
            if (response.success) {
                // نمایش کدهای بازیابی
                recoveryCodes = response.data.recovery_codes;
                showRecoveryCodes(recoveryCodes);
                
                showToast(response.message, 'success');
                
                setTimeout(() => {
                    window.location.reload();
                }, 3000);
            } else {
                showToast(response.message, 'danger');
                btn.prop('disabled', false).html(btnText);
            }
        },
        error: function(xhr) {
            const response = xhr.responseJSON;
            showToast(response.message || 'خطایی رخ داد', 'danger');
            btn.prop('disabled', false).html(btnText);
        }
    });
});

// غیرفعالسازی 2FA
$('#disable-2fa-form').on('submit', function(e) {
    e.preventDefault();
    
    if (!confirm('آیا مطمئن هستید که می‌خواهید احراز هویت دو مرحله‌ای را غیرفعال کنید؟')) {
        return;
    }
    
    const form = $(this);
    const btn = form.find('button[type="submit"]');
    const btnText = btn.html();
    
    btn.prop('disabled', true).html('<span class="spinner-border spinner-border-sm"></span> در حال غیرفعالسازی...');
    
    $.ajax({
        url: '<?= url('security/2fa/disable') ?>',
        method: 'POST',
        data: form.serialize(),
        success: function(response) {
            if (response.success) {
                showToast(response.message, 'success');
                setTimeout(() => {
                    window.location.reload();
                }, 1500);
            } else {
                showToast(response.message, 'danger');
                btn.prop('disabled', false).html(btnText);
            }
        },
        error: function(xhr) {
            const response = xhr.responseJSON;
            showToast(response.message || 'خطایی رخ داد', 'danger');
            btn.prop('disabled', false).html(btnText);
        }
    });
});

// نمایش کدهای بازیابی
function showRecoveryCodes(codes) {
    let html = '';
    codes.forEach((code, index) => {
        html += `
            <div class="col-6 mb-2">
                <div class="p-2 bg-light text-center border rounded">
                    <code class="text-dark">${code}</code>
                </div>
            </div>
        `;
    });
    
    $('#recovery-codes-list').html(html);
    
    const modal = new bootstrap.Modal(document.getElementById('recovery-codes-modal'));
    modal.show();
}

// دانلود کدهای بازیابی
function downloadRecoveryCodes() {
    const text = 'کدهای بازیابی چرتکه\n\n' + recoveryCodes.join('\n');
    const blob = new Blob([text], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'chortke-recovery-codes.txt';
    a.click();
}
</script>

<?php
$content = ob_get_clean();
$layout = __DIR__ . '/../../layouts/user.php';
require $layout;
?>