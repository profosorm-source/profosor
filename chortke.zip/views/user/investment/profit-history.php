<?php
$pageTitle = $pageTitle ?? 'تاریخچه سود و زیان';
$profits = $profits ?? [];
$total = $total ?? 0;
$totalPages = $totalPages ?? 1;
$currentPage = $currentPage ?? 1;
?>

<div class="main-content">
    <div class="content-header">
        <h1>تاریخچه سود و زیان</h1>
        <a href="<?= url('/user/investment') ?>" class="btn btn-outline">
            <i class="material-icons">arrow_forward</i>
            بازگشت
        </a>
    </div>

    <?php if (empty($profits)): ?>
    <div class="empty-state-card">
        <i class="material-icons">show_chart</i>
        <h3>تاریخچه‌ای وجود ندارد</h3>
        <p>پس از فعال‌سازی سرمایه‌گذاری، سود و زیان روزانه اینجا نمایش داده می‌شود.</p>
    </div>
    <?php else: ?>
    <div class="table-card">
        <div class="table-header-info">
            <span>مجموع <strong><?= number_format($total) ?></strong> رکورد</span>
        </div>
        <div class="table-responsive">
            <table class="data-table">
                <thead>
                    <tr>
                        <th>تاریخ</th>
                        <th>نوع</th>
                        <th>مقدار (USDT)</th>
                        <th>درصد</th>
                        <th>موجودی بعد از اعمال</th>
                        <th>توضیح</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($profits as $p): ?>
                    <?php $isProfit = (float)($p->amount ?? 0) >= 0; ?>
                    <tr>
                        <td><?= to_jalali($p->profit_date ?? $p->created_at) ?></td>
                        <td>
                            <?php if ($isProfit): ?>
                                <span class="badge badge-success">سود</span>
                            <?php else: ?>
                                <span class="badge badge-danger">ضرر</span>
                            <?php endif; ?>
                        </td>
                        <td class="<?= $isProfit ? 'text-success' : 'text-danger' ?> ltr-text">
                            <?= $isProfit ? '+' : '' ?><?= number_format((float)($p->amount ?? 0), 4) ?>
                        </td>
                        <td class="<?= $isProfit ? 'text-success' : 'text-danger' ?>">
                            <?php if (!empty($p->percent)): ?>
                                <?= $isProfit ? '+' : '' ?><?= number_format((float)$p->percent, 2) ?>%
                            <?php else: ?>—<?php endif; ?>
                        </td>
                        <td><?= !empty($p->balance_after) ? number_format((float)$p->balance_after, 4) : '—' ?></td>
                        <td class="text-muted"><?= e($p->note ?? $p->description ?? '—') ?></td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>

        <?php if ($totalPages > 1): ?>
        <div class="pagination-wrapper">
            <?php for ($i = 1; $i <= $totalPages; $i++): ?>
            <a href="?page=<?= $i ?>" class="pagination-btn <?= $i === $currentPage ? 'active' : '' ?>">
                <?= $i ?>
            </a>
            <?php endfor; ?>
        </div>
        <?php endif; ?>
    </div>
    <?php endif; ?>
</div>

<style>
.empty-state-card { background:white; border-radius:12px; padding:60px 30px; text-align:center; box-shadow:0 2px 8px rgba(0,0,0,0.06); }
.empty-state-card .material-icons { font-size:64px; color:#ccc; }
.empty-state-card h3 { margin:15px 0 8px; color:#555; }
.empty-state-card p { color:#999; }
.text-success { color:#22c55e !important; font-weight:600; }
.text-danger { color:#ef4444 !important; font-weight:600; }
.ltr-text { direction:ltr; text-align:right; font-family:monospace; }
.table-header-info { padding:12px 20px; border-bottom:1px solid #f0f0f0; color:#666; font-size:13px; }
.pagination-wrapper { display:flex; gap:6px; padding:16px 20px; justify-content:center; }
.pagination-btn { padding:6px 12px; border-radius:6px; background:#f5f5f5; color:#333; text-decoration:none; font-size:13px; }
.pagination-btn.active { background:#4fc3f7; color:white; }
</style>
