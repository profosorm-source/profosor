<?php
// views/user/seo-tasks/history.php
$title = 'تاریخچه جستجو';
$layout = 'user';
ob_start();
?>

<div class="page-header"><h4><i class="material-icons">history</i> تاریخچه جستجوی کلمات کلیدی</h4></div>

<div class="stats-row">
    <div class="stat-card stat-green"><span class="stat-num"><?= number_format($stats->completed ?? 0) ?></span><span class="stat-lbl">تکمیل</span></div>
    <div class="stat-card stat-blue"><span class="stat-num"><?= number_format($stats->total_earned ?? 0) ?></span><span class="stat-lbl">کل درآمد</span></div>
</div>

<?php if (empty($executions)): ?>
    <div class="empty-state"><i class="material-icons">inbox</i><h5>تاریخچه‌ای وجود ندارد</h5></div>
<?php else: ?>
    <div class="table-responsive">
        <table class="data-table">
            <thead><tr><th>#</th><th>کلمه</th><th>مدت</th><th>پاداش</th><th>وضعیت</th><th>تاریخ</th></tr></thead>
            <tbody>
                <?php foreach ($executions as $ex): ?>
                    <tr>
                        <td><?= $ex->id ?></td>
                        <td><?= e($ex->keyword_text ?? $ex->search_query) ?></td>
                        <td><?= $ex->total_duration ?>ثانیه</td>
                        <td><?= number_format($ex->reward_amount) ?></td>
                        <td><span class="badge badge-<?= seo_execution_status_badge($ex->status) ?>"><?= e(seo_execution_status_label($ex->status)) ?></span></td>
                        <td><?= to_jalali($ex->started_at) ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <?php if ($totalPages > 1): ?>
        <div class="pagination"><?php for($i=1;$i<=$totalPages;$i++): ?><a href="<?=url('/user/seo-tasks/history?page='.$i)?>" class="page-link <?=$i===$page?'active':''?>"><?=$i?></a><?php endfor; ?></div>
    <?php endif; ?>
<?php endif; ?>

<style>
.stats-row{display:grid;grid-template-columns:repeat(2,1fr);gap:12px;margin-bottom:15px;}
.stat-card{background:#fff;padding:12px;border-radius:8px;text-align:center;box-shadow:0 1px 4px rgba(0,0,0,0.05);}
.stat-num{display:block;font-size:20px;font-weight:700;}.stat-lbl{font-size:11px;color:#999;}
.stat-green .stat-num{color:#4caf50;}.stat-blue .stat-num{color:#2196f3;}
.data-table{width:100%;border-collapse:collapse;background:#fff;border-radius:8px;overflow:hidden;box-shadow:0 1px 4px rgba(0,0,0,0.05);}
.data-table thead th{background:#fafafa;padding:10px;font-size:11px;font-weight:600;color:#666;text-align:right;}
.data-table tbody td{padding:10px;font-size:12px;border-bottom:1px solid #f5f5f5;}
.data-table tbody tr:hover{background:#fafafa;}
.pagination{display:flex;gap:4px;justify-content:center;margin-top:12px;}
.page-link{padding:4px 10px;border:1px solid #ddd;border-radius:4px;text-decoration:none;color:#555;font-size:11px;}
.page-link.active{background:#4fc3f7;color:#fff;border-color:#4fc3f7;}
.empty-state{text-align:center;padding:50px;background:#fff;border-radius:10px;}.empty-state i{font-size:50px;color:#ccc;}
</style>

<?php $content = ob_get_clean(); include __DIR__ . '/../../layouts/' . $layout . '.php'; ?>