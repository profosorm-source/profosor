<?php
// views/user/seo-tasks/execute.php
$title = 'مرور صفحه';
$layout = 'user';
ob_start();
$googleUrl = 'https://www.google.com/search?q=' . urlencode($keyword->keyword);
?>

<div class="page-header">
    <h4><i class="material-icons">search</i> مرور صفحه — <?= e($keyword->keyword) ?></h4>
</div>

<div class="alert-box alert-warning mb-15">
    <i class="material-icons">warning</i>
    <div>
        <strong>توجه:</strong> از صفحه خارج نشوید. سیستم به‌صورت خودکار صفحه را مرور می‌کند. پس از تکمیل، پاداش به حساب شما واریز می‌شود.
    </div>
</div>

<!-- پیشرفت -->
<div class="seo-progress-card">
    <div class="seo-progress-bar"><div class="seo-progress-fill" id="seoProgressFill" style="width:0%"></div></div>
    <div class="seo-progress-info">
        <span id="seoElapsed">00:00</span>
        <span id="seoStatus">▶ در حال مرور...</span>
        <span id="seoPercent">0%</span>
    </div>
</div>

<!-- اطلاعات -->
<div class="card mt-15">
    <div class="card-body">
        <div class="info-row"><label>کلمه کلیدی:</label><span><strong><?= e($keyword->keyword) ?></strong></span></div>
        <div class="info-row"><label>صفحه هدف:</label><a href="<?= e($keyword->target_url) ?>" target="_blank" class="ltr-text"><?= e($keyword->target_url) ?></a></div>
        <div class="info-row"><label>پاداش:</label><span class="text-success"><?= number_format($execution->reward_amount) ?> <?= $execution->reward_currency === 'usdt' ? 'تتر' : 'تومان' ?></span></div>
    </div>
</div>

<!-- محتوای صفحه هدف (iframe) -->
<div class="card mt-15">
    <div class="card-header"><h5><i class="material-icons">web</i> صفحه هدف</h5></div>
    <div class="card-body p-0">
        <iframe id="targetFrame" src="<?= e($keyword->target_url) ?>" class="target-iframe" sandbox="allow-same-origin allow-scripts"></iframe>
    </div>
</div>

<style>
.seo-progress-card{background:#fff;padding:15px;border-radius:10px;box-shadow:0 2px 8px rgba(0,0,0,0.06);}
.seo-progress-bar{width:100%;height:10px;background:#eee;border-radius:5px;overflow:hidden;}
.seo-progress-fill{height:100%;background:linear-gradient(90deg,#4caf50,#81c784);border-radius:5px;transition:width 1s linear;}
.seo-progress-info{display:flex;justify-content:space-between;margin-top:8px;font-size:13px;color:#666;}
.info-row{display:flex;padding:8px 0;border-bottom:1px solid #f5f5f5;font-size:13px;}
.info-row label{min-width:120px;color:#999;font-weight:500;}
.ltr-text{direction:ltr;}.text-success{color:#4caf50;font-weight:700;}
.target-iframe{width:100%;height:600px;border:none;}
.p-0{padding:0!important;}
.mt-15{margin-top:15px;}.mb-15{margin-bottom:15px;}
.alert-box{display:flex;align-items:flex-start;gap:10px;padding:12px 15px;border-radius:8px;font-size:13px;}
.alert-warning{background:#fff8e1;color:#e65100;border-right:4px solid #ffa726;}
@media(max-width:768px){.target-iframe{height:400px;}}
</style>

<script src="<?= asset('assets/js/seo-scroll.js') ?>"></script>
<script>
const seoEngine = new SEOScrollEngine({
    executionId: <?= $execution->id ?>,
    csrfToken: '<?= csrf_token() ?>',
    completeUrl: '<?= url('/user/seo-tasks/' . $execution->id . '/complete') ?>',
    targetUrl: '<?= e($keyword->target_url) ?>',
    scrollMin: <?= $keyword->scroll_min_seconds ?>,
    scrollMax: <?= $keyword->scroll_max_seconds ?>,
    pauseMin: <?= $keyword->pause_min_seconds ?>,
    pauseMax: <?= $keyword->pause_max_seconds ?>,
    totalBrowse: <?= $keyword->total_browse_seconds ?>,
});

window.addEventListener('unload', () => seoEngine.destroy());
</script>

<?php $content = ob_get_clean(); include __DIR__ . '/../../layouts/' . $layout . '.php'; ?>