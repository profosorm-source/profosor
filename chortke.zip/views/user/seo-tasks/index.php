<?php
// views/user/seo-tasks/index.php
$title = 'جستجوی کلمات کلیدی';
$layout = 'user';
ob_start();
?>

<div class="page-header">
    <h4><i class="material-icons">search</i> جستجوی کلمات کلیدی</h4>
</div>

<div class="stats-row">
    <div class="stat-card stat-green"><span class="stat-num"><?= number_format($stats->completed ?? 0) ?></span><span class="stat-lbl">تکمیل شده</span></div>
    <div class="stat-card stat-blue"><span class="stat-num"><?= number_format($stats->total_earned ?? 0) ?></span><span class="stat-lbl">کل درآمد</span></div>
    <div class="stat-card stat-orange"><span class="stat-num"><?= $todayCount ?></span><span class="stat-lbl">امروز</span></div>
</div>

<div class="alert-box alert-info mb-15">
    <i class="material-icons">info</i>
    <div>
        <strong>راهنما:</strong> کلمه کلیدی را انتخاب کنید. سیستم آن را در گوگل جستجو کرده و صفحه هدف را برای شما باز می‌کند.
        سپس به‌صورت خودکار صفحه را مرور می‌کنید. <strong>از صفحه خارج نشوید</strong> تا پاداش دریافت کنید.
    </div>
</div>

<?php if (empty($keywords)): ?>
    <div class="empty-state"><i class="material-icons">inbox</i><h5>کلمه‌ای برای جستجو وجود ندارد</h5><p>لطفاً بعداً مراجعه کنید.</p></div>
<?php else: ?>
    <div class="seo-grid">
        <?php foreach ($keywords as $kw): ?>
            <div class="seo-card" data-id="<?= $kw->id ?>">
                <div class="seo-keyword">
                    <i class="material-icons">search</i>
                    <span><?= e($kw->keyword) ?></span>
                </div>
                <div class="seo-meta">
                    <span><i class="material-icons">link</i> <?= e(parse_url($kw->target_url, PHP_URL_HOST) ?? $kw->target_url) ?></span>
                    <span><i class="material-icons">timer</i> ~<?= $kw->total_browse_seconds ?>ثانیه</span>
                </div>
                <?php if ($kw->target_position > 0): ?>
                    <div class="seo-position">رتبه فعلی: <strong><?= $kw->target_position ?></strong></div>
                <?php endif; ?>
                <div class="seo-reward">
                    <i class="material-icons">paid</i>
                    <span><?= number_format($kw->reward_amount) ?></span>
                    <small><?= $kw->currency === 'usdt' ? 'تتر' : 'تومان' ?></small>
                </div>
                <button class="btn btn-primary btn-block btn-start-seo" data-id="<?= $kw->id ?>" data-keyword="<?= e($kw->keyword) ?>">
                    <i class="material-icons">play_arrow</i> شروع جستجو
                </button>
            </div>
        <?php endforeach; ?>
    </div>
<?php endif; ?>

<style>
.stats-row{display:grid;grid-template-columns:repeat(3,1fr);gap:12px;margin-bottom:15px;}
.stat-card{background:#fff;padding:12px;border-radius:8px;text-align:center;box-shadow:0 1px 4px rgba(0,0,0,0.05);}
.stat-num{display:block;font-size:20px;font-weight:700;}.stat-lbl{font-size:11px;color:#999;}
.stat-green .stat-num{color:#4caf50;}.stat-blue .stat-num{color:#2196f3;}.stat-orange .stat-num{color:#ff9800;}
.seo-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(300px,1fr));gap:15px;}
.seo-card{background:#fff;border-radius:10px;padding:18px;box-shadow:0 2px 8px rgba(0,0,0,0.06);transition:transform 0.2s;}
.seo-card:hover{transform:translateY(-2px);box-shadow:0 4px 15px rgba(0,0,0,0.1);}
.seo-keyword{display:flex;align-items:center;gap:8px;font-size:16px;font-weight:600;color:#333;margin-bottom:10px;}
.seo-keyword i{color:#4fc3f7;font-size:22px;}
.seo-meta{display:flex;gap:15px;font-size:12px;color:#888;margin-bottom:8px;}
.seo-meta i{font-size:14px;vertical-align:middle;}
.seo-position{font-size:12px;color:#999;margin-bottom:10px;}
.seo-reward{display:flex;align-items:center;gap:5px;font-size:18px;font-weight:700;color:#4caf50;margin-bottom:12px;}
.seo-reward i{font-size:22px;}.seo-reward small{font-size:11px;color:#888;font-weight:400;}
.btn-block{width:100%;}.mb-15{margin-bottom:15px;}
.alert-box{display:flex;align-items:flex-start;gap:10px;padding:12px 15px;border-radius:8px;font-size:13px;}
.alert-info{background:#e3f2fd;color:#1565c0;}
.empty-state{text-align:center;padding:50px;background:#fff;border-radius:10px;}
.empty-state i{font-size:50px;color:#ccc;}
@media(max-width:768px){.stats-row{grid-template-columns:1fr;}.seo-grid{grid-template-columns:1fr;}}
</style>

<script>
document.querySelectorAll('.btn-start-seo').forEach(btn=>{
    btn.addEventListener('click',function(){
        const id=this.dataset.id, kw=this.dataset.keyword;
        Swal.fire({title:'شروع جستجو',html:`<p>کلمه: <strong>"${kw}"</strong></p><p style="font-size:12px;color:#666;">صفحه هدف در تب جدید باز شده و به‌صورت خودکار مرور می‌شود. لطفاً تب را نبندید.</p>`,icon:'question',showCancelButton:true,confirmButtonText:'شروع',cancelButtonText:'انصراف',confirmButtonColor:'#4caf50'})
        .then(r=>{if(r.isConfirmed){
            fetch('<?=url('/user/seo-tasks/start')?>',{method:'POST',headers:{'Content-Type':'application/json','X-CSRF-TOKEN':'<?=csrf_token()?>'},body:JSON.stringify({keyword_id:id,_csrf_token:'<?=csrf_token()?>'})})
            .then(r=>r.json()).then(d=>{
                if(d.success){
                    notyf.success(d.message);
                    if(d.execution&&d.execution.id){
                        setTimeout(()=>{window.location.href='<?=url('/user/seo-tasks')?>/' + d.execution.id + '/execute';},800);
                    }
                }else notyf.error(d.message);
            }).catch(()=>notyf.error('خطا'));
        }});
    });
});
</script>

<?php $content = ob_get_clean(); include __DIR__ . '/../../layouts/' . $layout . '.php'; ?>