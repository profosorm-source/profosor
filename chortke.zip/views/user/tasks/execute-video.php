<?php
// views/user/tasks/execute-video.php
$title = 'تماشای ویدیو';
$layout = 'user';
ob_start();

$deadlineTimestamp = strtotime($execution->deadline_at);
$remainingSeconds = max(0, $deadlineTimestamp - time());

// استخراج video ID از URL
$videoId = '';
if (preg_match('/(?:youtube\.com\/watch\?v=|youtu\.be\/)([a-zA-Z0-9_-]{11})/', $task->target_url, $matches)) {
    $videoId = $matches[1];
}

// مدت ویدیو (ثانیه) — تنظیم از ادمین یا پیش‌فرض 180 ثانیه
$videoDuration = (int) ($task->restrictions ? (json_decode($task->restrictions)->video_duration ?? 180) : 180);
?>

<div class="page-header">
    <h4><i class="material-icons">play_circle</i> تماشای ویدیو</h4>
    <a href="<?= url('/user/tasks') ?>" class="btn btn-outline-sm">
        <i class="material-icons">arrow_forward</i> بازگشت
    </a>
</div>

<!-- هشدار قوانین -->
<div class="alert-box alert-warning">
    <i class="material-icons">warning</i>
    <div>
        <strong>قوانین تماشای ویدیو:</strong>
        <ul class="rules-list">
            <li>ویدیو را تا انتها و بدون رد کردن (Skip) تماشا کنید</li>
            <li>سرعت پخش را تغییر ندهید (1x)</li>
            <li>از صفحه خارج نشوید و تب دیگری باز نکنید</li>
            <li>پنجره مرورگر را کوچک (Minimize) نکنید</li>
            <li>رفتار رباتیک باعث رد تسک و جریمه می‌شود</li>
        </ul>
    </div>
</div>

<!-- تایمر -->
<div class="timer-box" id="timerBox">
    <i class="material-icons">timer</i>
    <span id="countdown"><?= gmdate('i:s', $remainingSeconds) ?></span>
    <small>زمان باقیمانده تسک</small>
</div>

<!-- ویدیو -->
<div class="video-container">
    <?php if ($videoId): ?>
        <div class="video-wrapper">
            <iframe id="ytVideoFrame"
                    src="https://www.youtube.com/embed/<?= e($videoId) ?>?autoplay=1&modestbranding=1&rel=0&disablekb=1"
                    frameborder="0"
                    allow="autoplay; encrypted-media"
                    allowfullscreen>
            </iframe>
        </div>
    <?php else: ?>
        <div class="alert-box alert-danger">
            <i class="material-icons">error</i>
            <span>لینک ویدیو نامعتبر است.</span>
        </div>
    <?php endif; ?>
</div>

<!-- UI پیشرفت -->
<div id="videoTaskUI" class="mt-15"></div>

<!-- اطلاعات تسک -->
<div class="card mt-15">
    <div class="card-body">
        <div class="task-info-row">
            <span><i class="material-icons">info</i> <?= e($task->title) ?></span>
            <span class="reward-badge">
                <i class="material-icons">paid</i>
                <?= number_format($execution->reward_amount) ?>
                <?= $execution->reward_currency === 'usdt' ? 'تتر' : 'تومان' ?>
            </span>
        </div>
    </div>
</div>

<!-- فرم ارسال مدرک -->
<div class="card mt-15" id="submitSection" style="opacity:0.5;pointer-events:none;">
    <div class="card-header">
        <h5><i class="material-icons">camera_alt</i> ارسال مدرک</h5>
    </div>
    <div class="card-body">
        <div class="alert-box alert-info mb-15">
            <i class="material-icons">info</i>
            <span>پس از تکمیل تماشا، اسکرین‌شات از صفحه ویدیو بگیرید و ارسال کنید.</span>
        </div>

        <div class="form-group">
            <label>اسکرین‌شات <span class="required">*</span></label>
            <div class="upload-area">
                <input type="file" id="proofImageVideo" accept="image/*" required>
                <div class="upload-placeholder">
                    <i class="material-icons">cloud_upload</i>
                    <p>تصویر را انتخاب کنید</p>
                </div>
                <img id="previewImageVideo" class="preview-img" style="display:none">
            </div>
        </div>

        <button id="btnSubmitVideo" class="btn btn-primary btn-block" disabled>
            <i class="material-icons">send</i> ارسال مدرک
        </button>
    </div>
</div>

<style>
.video-container { margin:15px 0; }
.video-wrapper { position:relative; padding-bottom:56.25%; height:0; overflow:hidden; border-radius:10px; box-shadow:0 4px 15px rgba(0,0,0,0.15); }
.video-wrapper iframe { position:absolute; top:0; left:0; width:100%; height:100%; }

.timer-box { background:linear-gradient(135deg, #4fc3f7, #29b6f6); color:#fff; padding:12px 20px; border-radius:10px; display:flex; align-items:center; gap:10px; margin-bottom:15px; }
.timer-box i { font-size:24px; }
.timer-box #countdown { font-size:24px; font-weight:700; font-family:monospace; }
.timer-box small { margin-right:auto; font-size:12px; opacity:0.8; }

/* YouTube Task UI */
.vt-progress-bar { width:100%; height:8px; background:#eee; border-radius:4px; overflow:hidden; }
.vt-progress-fill { height:100%; background:linear-gradient(90deg, #4caf50, #81c784); border-radius:4px; transition:width 1s linear; }
.vt-info { display:flex; justify-content:space-between; align-items:center; margin-top:8px; font-size:13px; }
.vt-status { color:#666; }
.vt-warnings { margin-top:8px; }
.vt-warning { background:#fff3e0; color:#e65100; padding:8px 12px; border-radius:6px; font-size:12px; margin-bottom:5px; display:flex; align-items:center; gap:6px; animation:fadeIn 0.3s; }
.vt-warning i { font-size:18px; }

.task-info-row { display:flex; justify-content:space-between; align-items:center; }
.reward-badge { display:flex; align-items:center; gap:4px; font-size:16px; font-weight:700; color:#4caf50; }
.reward-badge i { font-size:20px; }

.upload-area { border:2px dashed #ddd; border-radius:10px; padding:20px; text-align:center; cursor:pointer; position:relative; }
.upload-area input[type=file] { position:absolute; inset:0; opacity:0; cursor:pointer; }
.upload-placeholder i { font-size:40px; color:#ccc; }
.preview-img { max-width:100%; max-height:200px; border-radius:8px; margin-top:10px; }

.btn-pulse { animation:pulse 1.5s infinite; }
@keyframes pulse { 0%,100% { box-shadow:0 0 0 0 rgba(76,175,80,0.4); } 50% { box-shadow:0 0 0 10px rgba(76,175,80,0); } }
@keyframes fadeIn { from { opacity:0; transform:translateY(-5px); } to { opacity:1; transform:translateY(0); } }

.rules-list { margin:8px 0 0 20px; padding:0; font-size:12px; }
.rules-list li { margin-bottom:3px; }
.alert-box { display:flex; align-items:flex-start; gap:10px; padding:12px 15px; border-radius:8px; font-size:13px; }
.alert-warning { background:#fff8e1; color:#e65100; border-right:4px solid #ffa726; }
.alert-info { background:#e3f2fd; color:#1565c0; }
.alert-danger { background:#ffebee; color:#c62828; }
.required { color:#f44336; }
.mt-15 { margin-top:15px; }
.mb-15 { margin-bottom:15px; }
.btn-block { width:100%; }

@media(max-width:768px) {
    .task-info-row { flex-direction:column; gap:8px; }
}
</style>

<script src="<?= asset('assets/js/youtube-task.js') ?>"></script>
<script>
// تایمر Deadline
let remaining = <?= $remainingSeconds ?>;
const countdownEl = document.getElementById('countdown');
const deadlineInterval = setInterval(() => {
    remaining--;
    if (remaining <= 0) {
        clearInterval(deadlineInterval);
        countdownEl.textContent = '00:00';
        document.getElementById('timerBox').style.background = 'linear-gradient(135deg, #ef5350, #e53935)';
        if (typeof notyf !== 'undefined') notyf.error('زمان تسک به پایان رسید!');
        return;
    }
    const m = Math.floor(remaining / 60).toString().padStart(2, '0');
    const s = (remaining % 60).toString().padStart(2, '0');
    countdownEl.textContent = m + ':' + s;
}, 1000);

// YouTube Task Controller
const ytTask = new YouTubeTaskController({
    executionId: <?= $execution->id ?>,
    csrfToken: '<?= csrf_token() ?>',
    submitUrl: '<?= url('/user/tasks/' . $execution->id . '/submit') ?>',
    videoUrl: '<?= e($task->target_url) ?>',
    videoDuration: <?= $videoDuration ?>,
    minWatchPercent: 90
});

// فعال کردن بخش ارسال پس از تکمیل
const checkComplete = setInterval(() => {
    if (ytTask.completed) {
        document.getElementById('submitSection').style.opacity = '1';
        document.getElementById('submitSection').style.pointerEvents = 'auto';
        clearInterval(checkComplete);
    }
}, 1000);

// پیش‌نمایش تصویر
document.getElementById('proofImageVideo').addEventListener('change', function() {
    if (this.files && this.files[0]) {
        const reader = new FileReader();
        reader.onload = function(e) {
            const img = document.getElementById('previewImageVideo');
            img.src = e.target.result;
            img.style.display = 'block';
        };
        reader.readAsDataURL(this.files[0]);
    }
});

// ارسال
document.getElementById('btnSubmitVideo').addEventListener('click', function() {
    if (!document.getElementById('proofImageVideo').files[0]) {
        notyf.error('لطفاً اسکرین‌شات ارسال کنید.');
        return;
    }
    ytTask.submit();
});

// پاکسازی هنگام خروج
window.addEventListener('unload', () => ytTask.destroy());
</script>

<?php
$content = ob_get_clean();
include __DIR__ . '/../../layouts/' . $layout . '.php';
?>