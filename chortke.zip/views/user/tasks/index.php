<?php
// views/user/tasks/index.php
$title = 'انجام تسک';
$layout = 'user';
ob_start();
?>

<div class="page-header">
    <h4><i class="material-icons">assignment</i> تسک‌های فعال</h4>
</div>

<!-- آمار کاربر -->
<div class="stats-row">
    <div class="stat-card stat-green">
        <i class="material-icons">check_circle</i>
        <div>
            <span class="stat-num"><?= number_format($stats->approved ?? 0) ?></span>
            <span class="stat-lbl">تایید شده</span>
        </div>
    </div>
    <div class="stat-card stat-orange">
        <i class="material-icons">hourglass_empty</i>
        <div>
            <span class="stat-num"><?= number_format(($stats->total ?? 0) - ($stats->approved ?? 0) - ($stats->rejected ?? 0) - ($stats->expired ?? 0)) ?></span>
            <span class="stat-lbl">در انتظار</span>
        </div>
    </div>
    <div class="stat-card stat-blue">
        <i class="material-icons">account_balance_wallet</i>
        <div>
            <span class="stat-num"><?= number_format($stats->total_earned ?? 0) ?></span>
            <span class="stat-lbl">کل درآمد</span>
        </div>
    </div>
</div>

<!-- هشدار حساب اجتماعی -->
<?php if (empty($socialAccounts)): ?>
    <div class="alert-box alert-warning">
        <i class="material-icons">warning</i>
        <div>
            <strong>توجه:</strong> برای انجام تسک‌هایی مثل فالو، لایک و سابسکرایب باید ابتدا
            <a href="<?= url('/user/social-accounts/create') ?>">حساب اجتماعی</a> خود را ثبت و تایید کنید.
        </div>
    </div>
<?php endif; ?>

<!-- لیست تسک‌ها -->
<?php if (empty($tasks)): ?>
    <div class="empty-state">
        <i class="material-icons">inbox</i>
        <h5>در حال حاضر تسک فعالی وجود ندارد</h5>
        <p>لطفاً بعداً مراجعه کنید.</p>
    </div>
<?php else: ?>
    <div class="tasks-grid">
        <?php foreach ($tasks as $task): ?>
            <div class="task-card" data-id="<?= $task->id ?>">
                <div class="task-card-top">
                    <div class="task-platform platform-<?= e($task->platform) ?>">
                        <?= e(social_platform_label($task->platform)) ?>
                    </div>
                    <span class="task-type-badge">
                        <?= e(ad_task_type_label($task->task_type)) ?>
                    </span>
                </div>

                <h5 class="task-title"><?= e($task->title) ?></h5>

                <?php if ($task->description): ?>
                    <p class="task-desc"><?= e(mb_substr($task->description, 0, 100)) ?><?= mb_strlen($task->description) > 100 ? '...' : '' ?></p>
                <?php endif; ?>

                <?php if ($task->target_username): ?>
                    <div class="task-target">
                        <i class="material-icons">person</i>
                        <span>@<?= e($task->target_username) ?></span>
                    </div>
                <?php endif; ?>

                <div class="task-card-bottom">
                    <div class="task-reward">
                        <i class="material-icons">paid</i>
                        <span><?= number_format($task->price_per_task) ?></span>
                        <small><?= $task->currency === 'usdt' ? 'تتر' : 'تومان' ?></small>
                    </div>

                    <div class="task-remaining">
                        <small><?= number_format($task->remaining_count) ?> باقیمانده</small>
                    </div>
                </div>

                <button class="btn btn-primary btn-block btn-start-task"
                        data-id="<?= $task->id ?>"
                        data-title="<?= e($task->title) ?>"
                        data-url="<?= e($task->target_url) ?>"
                        data-type="<?= e($task->task_type) ?>">
                    <i class="material-icons">play_arrow</i> شروع تسک
                </button>
            </div>
        <?php endforeach; ?>
    </div>
<?php endif; ?>

<style>
.stats-row { display:grid; grid-template-columns:repeat(3, 1fr); gap:15px; margin-bottom:20px; }
.stat-card { display:flex; align-items:center; gap:12px; background:#fff; padding:15px; border-radius:10px; box-shadow:0 2px 8px rgba(0,0,0,0.06); }
.stat-card i { font-size:36px; }
.stat-green i { color:#4caf50; }
.stat-orange i { color:#ff9800; }
.stat-blue i { color:#2196f3; }
.stat-num { display:block; font-size:20px; font-weight:700; }
.stat-lbl { font-size:12px; color:#999; }

.tasks-grid { display:grid; grid-template-columns:repeat(auto-fill, minmax(300px, 1fr)); gap:20px; }
.task-card { background:#fff; border-radius:10px; padding:20px; box-shadow:0 2px 8px rgba(0,0,0,0.06); transition:transform 0.2s, box-shadow 0.2s; }
.task-card:hover { transform:translateY(-2px); box-shadow:0 4px 15px rgba(0,0,0,0.1); }
.task-card-top { display:flex; justify-content:space-between; align-items:center; margin-bottom:12px; }
.task-platform { font-size:12px; font-weight:600; padding:4px 10px; border-radius:20px; color:#fff; }
.platform-instagram { background:linear-gradient(135deg, #833ab4, #fd1d1d, #fcb045); }
.platform-youtube { background:#ff0000; }
.platform-telegram { background:#0088cc; }
.platform-tiktok { background:#000; }
.platform-twitter { background:#1da1f2; }
.task-type-badge { background:#e3f2fd; color:#1565c0; padding:4px 10px; border-radius:20px; font-size:11px; font-weight:600; }
.task-title { margin:0 0 8px; font-size:15px; color:#333; }
.task-desc { font-size:12px; color:#777; margin:0 0 10px; line-height:1.6; }
.task-target { display:flex; align-items:center; gap:4px; font-size:12px; color:#555; margin-bottom:12px; }
.task-target i { font-size:16px; color:#999; }
.task-card-bottom { display:flex; justify-content:space-between; align-items:center; padding:10px 0; border-top:1px solid #f0f0f0; margin-bottom:12px; }
.task-reward { display:flex; align-items:center; gap:4px; font-size:16px; font-weight:700; color:#4caf50; }
.task-reward small { font-size:11px; color:#888; font-weight:400; }
.task-reward i { font-size:20px; }
.task-remaining small { color:#999; font-size:11px; }
.btn-block { width:100%; text-align:center; }
.btn-start-task { padding:10px; font-size:14px; }

.empty-state { text-align:center; padding:60px 20px; background:#fff; border-radius:10px; }
.empty-state i { font-size:60px; color:#ccc; }

@media(max-width:768px) {
    .stats-row { grid-template-columns:1fr; }
    .tasks-grid { grid-template-columns:1fr; }
}
</style>

<script>
document.querySelectorAll('.btn-start-task').forEach(btn => {
    btn.addEventListener('click', function() {
        const adId = this.dataset.id;
        const title = this.dataset.title;
        const targetUrl = this.dataset.url;

        Swal.fire({
            title: 'شروع تسک',
            html: `
                <p>آیا می‌خواهید تسک <strong>"${title}"</strong> را شروع کنید؟</p>
                <div style="text-align:right;font-size:12px;color:#666;margin-top:10px;">
                    <p>⏱ بعد از شروع، زمان محدودی برای انجام و ارسال مدرک دارید.</p>
                    <p>📸 باید اسکرین‌شات از انجام کار ارسال کنید.</p>
                    <p>⚠️ رفتار رباتیک باعث رد تسک می‌شود.</p>
                </div>
            `,
            icon: 'question',
            showCancelButton: true,
            confirmButtonText: 'بله، شروع',
            cancelButtonText: 'انصراف',
            confirmButtonColor: '#4caf50'
        }).then(result => {
            if (result.isConfirmed) {
                // شروع تسک
                fetch('<?= url('/user/tasks/start') ?>', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-CSRF-TOKEN': '<?= csrf_token() ?>'
                    },
                    body: JSON.stringify({
                        ad_id: adId,
                        _csrf_token: '<?= csrf_token() ?>'
                    })
                })
                .then(r => r.json())
                .then(data => {
                    if (data.success) {
                        notyf.success(data.message);
                        // باز کردن لینک هدف
                        if (data.target_url) {
                            window.open(data.target_url, '_blank');
                        }
                        // ریدایرکت به صفحه انجام
                        if (data.execution && data.execution.id) {
                            setTimeout(() => {
                                window.location.href = '<?= url('/user/tasks') ?>/' + data.execution.id + '/execute';
                            }, 1500);
                        }
                    } else {
                        notyf.error(data.message);
                    }
                })
                .catch(() => notyf.error('خطا در ارتباط'));
            }
        });
    });
});
</script>

<?php
$content = ob_get_clean();
include __DIR__ . '/../../layouts/' . $layout . '.php';
?>