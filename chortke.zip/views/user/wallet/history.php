<?php
$pageTitle = $pageTitle ?? 'تاریخچه تراکنش‌ها';
$transactions = $transactions ?? [];
$currentPage = $currentPage ?? 1;
$totalPages = $totalPages ?? 1;
$type = $type ?? '';
$currency = $currency ?? '';
?>

<div class="main-content">
    <!-- Header -->
    <div class="content-header">
        <h1>تاریخچه تراکنش‌ها</h1>
        <a href="<?= url('/user/wallet') ?>" class="btn btn-outline">
            <i class="material-icons">arrow_forward</i>
            بازگشت
        </a>
    </div>

    <!-- فیلترها -->
    <div class="filters-card">
        <form method="GET" action="<?= url('/user/wallet/history') ?>" class="filters-form">
            <div class="filter-group">
                <label>نوع تراکنش:</label>
                <select name="type" class="form-control">
                    <option value="">همه</option>
                    <option value="deposit" <?= $type === 'deposit' ? 'selected' : '' ?>>واریز</option>
                    <option value="withdraw" <?= $type === 'withdraw' ? 'selected' : '' ?>>برداشت</option>
                    <option value="commission" <?= $type === 'commission' ? 'selected' : '' ?>>کمیسیون</option>
                    <option value="task_reward" <?= $type === 'task_reward' ? 'selected' : '' ?>>پاداش تسک</option>
                </select>
            </div>

            <div class="filter-group">
                <label>نوع ارز:</label>
                <select name="currency" class="form-control">
                    <option value="">همه</option>
                    <option value="irt" <?= $currency === 'irt' ? 'selected' : '' ?>>تومان</option>
                    <option value="usdt" <?= $currency === 'usdt' ? 'selected' : '' ?>>USDT</option>
                </select>
            </div>

            <button type="submit" class="btn btn-primary">
                <i class="material-icons">search</i>
                فیلتر
            </button>

            <?php if ($type || $currency): ?>
            <a href="<?= url('/user/wallet/history') ?>" class="btn btn-outline">
                <i class="material-icons">clear</i>
                حذف فیلتر
            </a>
            <?php endif; ?>
        </form>
    </div>

    <!-- جدول تراکنش‌ها -->
    <div class="table-card">
        <?php if (empty($transactions)): ?>
        <div class="empty-state">
            <i class="material-icons">receipt_long</i>
            <h3>تراکنشی یافت نشد</h3>
            <p>هنوز هیچ تراکنشی ثبت نشده است</p>
            <a href="<?= url('/user/wallet/deposit') ?>" class="btn btn-primary">
                افزایش موجودی
            </a>
        </div>
        <?php else: ?>
        <div class="table-responsive">
            <table class="data-table">
                <thead>
                    <tr>
                        <th>شناسه تراکنش</th>
                        <th>نوع</th>
                        <th>مبلغ</th>
                        <th>ارز</th>
                        <th>وضعیت</th>
                        <th>درگاه</th>
                        <th>تاریخ</th>
                        <th>جزئیات</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($transactions as $tx): ?>
                    <tr>
                        <td>
                            <code class="tx-id"><?= e(substr($tx->transaction_id, 0, 8)) ?>...</code>
                        </td>
                        <td>
                            <span class="tx-type <?= e($tx->type) ?>">
                                <?php
                                $typeLabels = [
                                    'deposit' => 'واریز',
                                    'withdraw' => 'برداشت',
                                    'transfer' => 'انتقال',
                                    'commission' => 'کمیسیون',
                                    'investment' => 'سرمایه‌گذاری',
                                    'task_reward' => 'پاداش تسک',
                                    'penalty' => 'جریمه',
                                    'refund' => 'بازگشت وجه',
                                ];
                                echo $typeLabels[$tx->type] ?? $tx->type;
                                ?>
                            </span>
                        </td>
                        <td>
                            <span class="tx-amount <?= $tx->type === 'withdraw' || $tx->type === 'penalty' ? 'negative' : 'positive' ?>">
                                <?php if ($tx->type === 'withdraw' || $tx->type === 'penalty'): ?>
                                -
                                <?php else: ?>
                                +
                                <?php endif; ?>
                                <?= $tx->currency === 'usdt' ? number_format($tx->amount, 4) : number_format($tx->amount) ?>
                            </span>
                        </td>
                        <td>
                            <span class="currency-badge <?= e($tx->currency) ?>">
                                <?= $tx->currency === 'usdt' ? 'USDT' : 'تومان' ?>
                            </span>
                        </td>
                        <td>
                            <?php
                            $statusLabels = [
                                'pending' => 'در انتظار',
                                'processing' => 'در حال پردازش',
                                'completed' => 'تکمیل شده',
                                'failed' => 'ناموفق',
                                'cancelled' => 'لغو شده',
                                'refunded' => 'بازگشت داده شده',
                            ];
                            ?>
                            <span class="status-badge <?= e($tx->status) ?>">
                                <?= $statusLabels[$tx->status] ?? $tx->status ?>
                            </span>
                        </td>
                        <td>
                            <?php if ($tx->gateway): ?>
                            <span class="gateway-name"><?= e($tx->gateway) ?></span>
                            <?php else: ?>
                            <span class="text-muted">-</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <span class="tx-date"><?= to_jalali($tx->created_at) ?></span>
                        </td>
                        <td>
                            <button class="btn-icon" onclick="showTransactionDetails(<?= $tx->id ?>)" title="جزئیات">
                                <i class="material-icons">visibility</i>
                            </button>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>

        <!-- صفحه‌بندی -->
        <?php if ($totalPages > 1): ?>
        <div class="pagination">
            <?php if ($currentPage > 1): ?>
            <a href="?page=<?= $currentPage - 1 ?><?= $type ? '&type=' . $type : '' ?><?= $currency ? '&currency=' . $currency : '' ?>" class="page-link">
                <i class="material-icons">chevron_right</i>
            </a>
            <?php endif; ?>

            <?php for ($i = max(1, $currentPage - 2); $i <= min($totalPages, $currentPage + 2); $i++): ?>
            <a href="?page=<?= $i ?><?= $type ? '&type=' . $type : '' ?><?= $currency ? '&currency=' . $currency : '' ?>" 
               class="page-link <?= $i === $currentPage ? 'active' : '' ?>">
                <?= to_jalali($i, '', true) ?>
            </a>
            <?php endfor; ?>

            <?php if ($currentPage < $totalPages): ?>
            <a href="?page=<?= $currentPage + 1 ?><?= $type ? '&type=' . $type : '' ?><?= $currency ? '&currency=' . $currency : '' ?>" class="page-link">
                <i class="material-icons">chevron_left</i>
            </a>
            <?php endif; ?>
        </div>
        <?php endif; ?>
        <?php endif; ?>
    </div>
</div>

<style>
.filters-card {
    background: white;
    border-radius: 10px;
    padding: 20px;
    box-shadow: 0 2px 8px rgba(0,0,0,0.06);
    margin-bottom: 25px;
}

.filters-form {
    display: flex;
    gap: 15px;
    align-items: flex-end;
    flex-wrap: wrap;
}

.filter-group {
    flex: 1;
    min-width: 200px;
}

.filter-group label {
    display: block;
    margin-bottom: 8px;
    font-size: 13px;
    font-weight: 500;
    color: #666;
}

.table-card {
    background: white;
    border-radius: 10px;
    box-shadow: 0 2px 8px rgba(0,0,0,0.06);
    overflow: hidden;
}

.table-responsive {
    overflow-x: auto;
}

.data-table {
    width: 100%;
    border-collapse: collapse;
}

.data-table thead {
    background: #fafafa;
}

.data-table th {
    padding: 15px;
    text-align: right;
    font-size: 12px;
    font-weight: 600;
    color: #666;
    border-bottom: 2px solid #f5f5f5;
}

.data-table td {
    padding: 15px;
    border-bottom: 1px solid #f5f5f5;
    font-size: 13px;
}

.data-table tbody tr:hover {
    background: #fafafa;
}

.tx-id {
    font-family: monospace;
    background: #f5f5f5;
    padding: 4px 8px;
    border-radius: 4px;
    font-size: 11px;
}

.tx-type {
    display: inline-block;
    padding: 4px 10px;
    border-radius: 12px;
    font-size: 11px;
    font-weight: 500;
}

.tx-type.deposit {
    background: rgba(76, 175, 80, 0.1);
    color: #4caf50;
}

.tx-type.withdraw {
    background: rgba(244, 67, 54, 0.1);
    color: #f44336;
}

.tx-type.commission,
.tx-type.task_reward {
    background: rgba(79, 195, 247, 0.1);
    color: #4fc3f7;
}

.tx-amount {
    font-weight: 600;
    font-size: 14px;
}

.tx-amount.positive {
    color: #4caf50;
}

.tx-amount.negative {
    color: #f44336;
}

.currency-badge {
    display: inline-block;
    padding: 4px 10px;
    border-radius: 12px;
    font-size: 11px;
    font-weight: 500;
}

.currency-badge.irt {
    background: rgba(76, 175, 80, 0.1);
    color: #4caf50;
}

.currency-badge.usdt {
    background: rgba(33, 150, 243, 0.1);
    color: #2196f3;
}

.status-badge {
    display: inline-block;
    padding: 4px 10px;
    border-radius: 12px;
    font-size: 11px;
    font-weight: 500;
}

.status-badge.pending {
    background: rgba(255, 167, 38, 0.1);
    color: #ffa726;
}

.status-badge.processing {
    background: rgba(33, 150, 243, 0.1);
    color: #2196f3;
}

.status-badge.completed {
    background: rgba(76, 175, 80, 0.1);
    color: #4caf50;
}

.status-badge.failed,
.status-badge.cancelled {
    background: rgba(244, 67, 54, 0.1);
    color: #f44336;
}

.status-badge.refunded {
    background: rgba(156, 39, 176, 0.1);
    color: #9c27b0;
}

.gateway-name {
    font-size: 12px;
    color: #666;
}

.tx-date {
    font-size: 12px;
    color: #999;
    direction: ltr;
    display: inline-block;
}

.btn-icon {
    background: none;
    border: none;
    cursor: pointer;
    padding: 5px;
    color: #4fc3f7;
    transition: all 0.3s;
}

.btn-icon:hover {
    color: #29b6f6;
    transform: scale(1.1);
}

.empty-state {
    text-align: center;
    padding: 60px 20px;
}

.empty-state i {
    font-size: 80px;
    color: #e0e0e0;
    margin-bottom: 20px;
}

.empty-state h3 {
    margin: 0 0 10px 0;
    font-size: 18px;
    color: #666;
}

.empty-state p {
    margin: 0 0 25px 0;
    color: #999;
}

.pagination {
    display: flex;
    justify-content: center;
    align-items: center;
    gap: 5px;
    padding: 20px;
    border-top: 1px solid #f5f5f5;
}

.page-link {
    display: flex;
    align-items: center;
    justify-content: center;
    min-width: 36px;
    height: 36px;
    padding: 0 12px;
    background: white;
    border: 1px solid #e0e0e0;
    border-radius: 8px;
    color: #666;
    text-decoration: none;
    font-size: 13px;
    transition: all 0.3s;
}

.page-link:hover {
    background: #4fc3f7;
    color: white;
    border-color: #4fc3f7;
}

.page-link.active {
    background: #4fc3f7;
    color: white;
    border-color: #4fc3f7;
}

@media (max-width: 768px) {
    .filters-form {
        flex-direction: column;
    }
    
    .filter-group {
        width: 100%;
    }
    
    .table-responsive {
        font-size: 12px;
    }
    
    .data-table th,
    .data-table td {
        padding: 10px;
    }
}
</style>

<script>
function showTransactionDetails(id) {
    // TODO: نمایش جزئیات تراکنش در مودال
    alert('جزئیات تراکنش ' + id);
}
</script>