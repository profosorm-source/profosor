<?php
$pageTitle = $pageTitle ?? 'کیف پول من';
$summary = $summary ?? null;
$siteCurrency = $siteCurrency ?? 'irt';
?>

<div class="main-content">
    <!-- Header -->
    <div class="content-header">
        <h1>کیف پول من</h1>
        <div class="header-actions">
            <a href="<?= url('/user/wallet/deposit') ?>" class="btn btn-primary">
                <i class="material-icons">add_circle</i>
                افزایش موجودی
            </a>
            <a href="<?= url('/user/wallet/withdraw') ?>" class="btn btn-success">
                <i class="material-icons">remove_circle</i>
                برداشت وجه
            </a>
        </div>
    </div>

    <?php if ($summary): ?>
    
    <!-- Wallet Cards -->
    <div class="wallet-cards">
        <!-- کارت تومانی -->
        <div class="wallet-card irt">
            <div class="card-header">
                <div class="card-icon">
                    <i class="material-icons">account_balance_wallet</i>
                </div>
                <h3>کیف پول تومانی (IRT)</h3>
            </div>
            <div class="card-body">
                <div class="balance-info">
                    <span class="label">موجودی آزاد:</span>
                    <span class="amount"><?= number_format($summary->balance_irt) ?> <small>تومان</small></span>
                </div>
                <?php if ($summary->locked_irt > 0): ?>
                <div class="balance-info locked">
                    <span class="label">موجودی قفل‌شده:</span>
                    <span class="amount"><?= number_format($summary->locked_irt) ?> <small>تومان</small></span>
                </div>
                <?php endif; ?>
                <div class="balance-info total">
                    <span class="label">مجموع:</span>
                    <span class="amount"><?= number_format($summary->total_irt) ?> <small>تومان</small></span>
                </div>
            </div>
            <div class="card-footer">
                <a href="<?= url('/user/wallet/history?currency=irt') ?>" class="card-link">
                    <i class="material-icons">history</i>
                    تاریخچه تراکنش‌ها
                </a>
            </div>
        </div>

        <!-- کارت تتری -->
        <div class="wallet-card usdt">
            <div class="card-header">
                <div class="card-icon">
                    <i class="material-icons">currency_bitcoin</i>
                </div>
                <h3>کیف پول تتری (USDT)</h3>
            </div>
            <div class="card-body">
                <div class="balance-info">
                    <span class="label">موجودی آزاد:</span>
                    <span class="amount"><?= number_format($summary->balance_usdt, 4) ?> <small>USDT</small></span>
                </div>
                <?php if ($summary->locked_usdt > 0): ?>
                <div class="balance-info locked">
                    <span class="label">موجودی قفل‌شده:</span>
                    <span class="amount"><?= number_format($summary->locked_usdt, 4) ?> <small>USDT</small></span>
                </div>
                <?php endif; ?>
                <div class="balance-info total">
                    <span class="label">مجموع:</span>
                    <span class="amount"><?= number_format($summary->total_usdt, 4) ?> <small>USDT</small></span>
                </div>
            </div>
            <div class="card-footer">
                <a href="<?= url('/user/wallet/history?currency=usdt') ?>" class="card-link">
                    <i class="material-icons">history</i>
                    تاریخچه تراکنش‌ها
                </a>
            </div>
        </div>
    </div>

    <!-- آمار تراکنش‌ها -->
    <div class="stats-section">
        <h2>آمار تراکنش‌ها</h2>
        <div class="stats-grid">
            <!-- آمار تومانی -->
            <div class="stat-card">
                <div class="stat-icon green">
                    <i class="material-icons">trending_up</i>
                </div>
                <div class="stat-info">
                    <h4>واریزهای تومانی</h4>
                    <p class="stat-value"><?= number_format($summary->stats->irt->total_deposits) ?> تومان</p>
                    <p class="stat-count"><?= to_jalali($summary->stats->irt->deposit_count, '', true) ?> تراکنش</p>
                </div>
            </div>

            <div class="stat-card">
                <div class="stat-icon red">
                    <i class="material-icons">trending_down</i>
                </div>
                <div class="stat-info">
                    <h4>برداشت‌های تومانی</h4>
                    <p class="stat-value"><?= number_format($summary->stats->irt->total_withdrawals) ?> تومان</p>
                    <p class="stat-count"><?= to_jalali($summary->stats->irt->withdrawal_count, '', true) ?> تراکنش</p>
                </div>
            </div>

            <!-- آمار تتری -->
            <div class="stat-card">
                <div class="stat-icon green">
                    <i class="material-icons">trending_up</i>
                </div>
                <div class="stat-info">
                    <h4>واریزهای تتری</h4>
                    <p class="stat-value"><?= number_format($summary->stats->usdt->total_deposits, 2) ?> USDT</p>
                    <p class="stat-count"><?= to_jalali($summary->stats->usdt->deposit_count, '', true) ?> تراکنش</p>
                </div>
            </div>

            <div class="stat-card">
                <div class="stat-icon red">
                    <i class="material-icons">trending_down</i>
                </div>
                <div class="stat-info">
                    <h4>برداشت‌های تتری</h4>
                    <p class="stat-value"><?= number_format($summary->stats->usdt->total_withdrawals, 2) ?> USDT</p>
                    <p class="stat-count"><?= to_jalali($summary->stats->usdt->withdrawal_count, '', true) ?> تراکنش</p>
                </div>
            </div>
        </div>
    </div>

    <!-- وضعیت برداشت -->
    <?php if (!$summary->can_withdraw_today): ?>
    <div class="alert alert-warning">
        <i class="material-icons">info</i>
        <div>
            <strong>توجه:</strong>
            شما امروز یکبار برداشت انجام داده‌اید. برداشت بعدی از فردا امکان‌پذیر است.
            <?php if ($summary->last_withdrawal_at): ?>
            <br>
            <small>آخرین برداشت: <?= to_jalali($summary->last_withdrawal_at) ?></small>
            <?php endif; ?>
        </div>
    </div>
    <?php endif; ?>

    <?php else: ?>
    <div class="alert alert-danger">
        <i class="material-icons">error</i>
        خطا در دریافت اطلاعات کیف پول
    </div>
    <?php endif; ?>
</div>

<style>
.wallet-cards {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(400px, 1fr));
    gap: 25px;
    margin-bottom: 30px;
}

.wallet-card {
    background: white;
    border-radius: 15px;
    overflow: hidden;
    box-shadow: 0 2px 8px rgba(0,0,0,0.06);
    transition: all 0.3s ease;
}

.wallet-card:hover {
    transform: translateY(-5px);
    box-shadow: 0 8px 20px rgba(0,0,0,0.12);
}

.wallet-card.irt {
    border-top: 4px solid #4caf50;
}

.wallet-card.usdt {
    border-top: 4px solid #2196f3;
}

.wallet-card .card-header {
    display: flex;
    align-items: center;
    gap: 15px;
    padding: 20px;
    background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
}

.wallet-card.irt .card-header {
    background: linear-gradient(135deg, #e8f5e9 0%, #c8e6c9 100%);
}

.wallet-card.usdt .card-header {
    background: linear-gradient(135deg, #e3f2fd 0%, #bbdefb 100%);
}

.card-icon {
    width: 50px;
    height: 50px;
    background: white;
    border-radius: 12px;
    display: flex;
    align-items: center;
    justify-content: center;
    box-shadow: 0 2px 8px rgba(0,0,0,0.1);
}

.card-icon i {
    font-size: 28px;
    color: #4fc3f7;
}

.wallet-card.irt .card-icon i {
    color: #4caf50;
}

.wallet-card.usdt .card-icon i {
    color: #2196f3;
}

.card-header h3 {
    margin: 0;
    font-size: 16px;
    font-weight: 600;
    color: #333;
}

.card-body {
    padding: 25px 20px;
}

.balance-info {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 12px 0;
    border-bottom: 1px solid #f5f5f5;
}

.balance-info:last-child {
    border-bottom: none;
}

.balance-info.total {
    padding-top: 15px;
    margin-top: 10px;
    border-top: 2px solid #f5f5f5;
    border-bottom: none;
}

.balance-info .label {
    font-size: 14px;
    color: #666;
}

.balance-info .amount {
    font-size: 20px;
    font-weight: 700;
    color: #333;
}

.balance-info.total .amount {
    font-size: 24px;
    color: #4fc3f7;
}

.balance-info.locked .amount {
    color: #ffa726;
}

.balance-info .amount small {
    font-size: 12px;
    font-weight: 400;
    color: #999;
}

.card-footer {
    padding: 15px 20px;
    background: #fafafa;
    border-top: 1px solid #f5f5f5;
}

.card-link {
    display: flex;
    align-items: center;
    gap: 8px;
    color: #4fc3f7;
    text-decoration: none;
    font-size: 14px;
    transition: all 0.3s ease;
}

.card-link:hover {
    color: #29b6f6;
}

.card-link i {
    font-size: 18px;
}

.stats-section {
    background: white;
    border-radius: 10px;
    padding: 25px;
    box-shadow: 0 2px 8px rgba(0,0,0,0.06);
    margin-bottom: 25px;
}

.stats-section h2 {
    margin: 0 0 20px 0;
    font-size: 18px;
    font-weight: 600;
    color: #333;
}

.stats-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
    gap: 20px;
}

.stat-card {
    display: flex;
    align-items: center;
    gap: 15px;
    padding: 20px;
    background: #fafafa;
    border-radius: 10px;
    transition: all 0.3s ease;
}

.stat-card:hover {
    background: #f5f5f5;
    transform: translateY(-2px);
}

.stat-icon {
    width: 50px;
    height: 50px;
    border-radius: 10px;
    display: flex;
    align-items: center;
    justify-content: center;
}

.stat-icon.green {
    background: rgba(76, 175, 80, 0.1);
}

.stat-icon.green i {
    color: #4caf50;
}

.stat-icon.red {
    background: rgba(244, 67, 54, 0.1);
}

.stat-icon.red i {
    color: #f44336;
}

.stat-icon i {
    font-size: 26px;
}

.stat-info h4 {
    margin: 0 0 8px 0;
    font-size: 13px;
    font-weight: 500;
    color: #666;
}

.stat-value {
    margin: 0 0 5px 0;
    font-size: 18px;
    font-weight: 700;
    color: #333;
}

.stat-count {
    margin: 0;
    font-size: 12px;
    color: #999;
}

.header-actions {
    display: flex;
    gap: 10px;
}

@media (max-width: 768px) {
    .wallet-cards {
        grid-template-columns: 1fr;
    }
    
    .stats-grid {
        grid-template-columns: 1fr;
    }
    
    .header-actions {
        flex-direction: column;
        width: 100%;
    }
    
    .header-actions .btn {
        width: 100%;
    }
}
</style>