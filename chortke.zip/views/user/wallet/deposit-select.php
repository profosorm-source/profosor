<?php
$pageTitle = $pageTitle ?? 'افزایش موجودی';
$siteCurrency = $siteCurrency ?? 'irt';
?>

<div class="main-content">
    <!-- Header -->
    <div class="content-header">
        <h1>افزایش موجودی</h1>
        <a href="<?= url('/user/wallet') ?>" class="btn btn-outline">
            <i class="material-icons">arrow_forward</i>
            بازگشت
        </a>
    </div>

    <!-- راهنما -->
    <div class="alert alert-info">
        <i class="material-icons">info</i>
        <div>
            <strong>راهنما:</strong>
            یکی از روش‌های زیر را برای افزایش موجودی کیف پول خود انتخاب کنید.
        </div>
    </div>

    <!-- روش‌های افزایش موجودی -->
    <div class="deposit-methods">
        
        <?php if ($siteCurrency === 'irt' || $siteCurrency === 'both'): ?>
        <!-- درگاه‌های آنلاین -->
        <div class="method-card">
            <div class="method-icon online">
                <i class="material-icons">credit_card</i>
            </div>
            <div class="method-info">
                <h3>پرداخت آنلاین</h3>
                <p>واریز سریع و آنی از طریق درگاه‌های بانکی</p>
                <ul class="features">
                    <li><i class="material-icons">check_circle</i> تأیید خودکار</li>
                    <li><i class="material-icons">check_circle</i> واریز آنی</li>
                    <li><i class="material-icons">check_circle</i> امن و مطمئن</li>
                </ul>
                <div class="gateway-logos">
                    <img src="<?= asset('images/gateways/zarinpal.png') ?>" alt="زرین‌پال" title="زرین‌پال">
                    <img src="<?= asset('images/gateways/nextpay.png') ?>" alt="نکست‌پی" title="نکست‌پی">
                    <img src="<?= asset('images/gateways/idpay.png') ?>" alt="آیدی‌پی" title="آیدی‌پی">
                    <img src="<?= asset('images/gateways/dgpay.png') ?>" alt="دی‌جی‌پی" title="دی‌جی‌پی">
                </div>
            </div>
            <a href="#" class="method-btn" onclick="showOnlinePaymentModal(); return false;">
                انتخاب درگاه
                <i class="material-icons">arrow_back</i>
            </a>
        </div>

        <!-- واریز دستی -->
        <div class="method-card">
            <div class="method-icon manual">
                <i class="material-icons">account_balance</i>
            </div>
            <div class="method-info">
                <h3>واریز دستی</h3>
                <p>واریز از طریق کارت به کارت یا شبا</p>
                <ul class="features">
                    <li><i class="material-icons">check_circle</i> بدون کارمزد اضافی</li>
                    <li><i class="material-icons">schedule</i> بررسی در 2-24 ساعت</li>
                    <li><i class="material-icons">check_circle</i> واریز از کارت شخصی</li>
                </ul>
            </div>
            <a href="<?= url('/user/wallet/deposit/manual') ?>" class="method-btn">
                شروع واریز دستی
                <i class="material-icons">arrow_back</i>
            </a>
        </div>
        <?php endif; ?>

        <?php if ($siteCurrency === 'usdt' || $siteCurrency === 'both'): ?>
        <!-- واریز USDT -->
        <div class="method-card crypto">
            <div class="method-icon crypto">
                <i class="material-icons">currency_bitcoin</i>
            </div>
            <div class="method-info">
                <h3>واریز USDT</h3>
                <p>واریز تتر از طریق شبکه‌های BNB20 و TRC20</p>
                <ul class="features">
                    <li><i class="material-icons">check_circle</i> بررسی خودکار</li>
                    <li><i class="material-icons">check_circle</i> پشتیبانی 2 شبکه</li>
                    <li><i class="material-icons">schedule</i> تأیید در 5-30 دقیقه</li>
                </ul>
                <div class="network-badges">
                    <span class="badge badge-success">BNB20</span>
                    <span class="badge badge-info">TRC20</span>
                </div>
            </div>
            <a href="<?= url('/user/wallet/deposit/crypto') ?>" class="method-btn">
                واریز USDT
                <i class="material-icons">arrow_back</i>
            </a>
        </div>
        <?php endif; ?>

    </div>
</div>

<!-- مودال پرداخت آنلاین -->
<div class="modal" id="onlinePaymentModal">
    <div class="modal-content">
        <div class="modal-header">
            <h3>پرداخت آنلاین</h3>
            <button class="modal-close" onclick="closeOnlinePaymentModal()">
                <i class="material-icons">close</i>
            </button>
        </div>
        <form method="POST" action="<?= url('/payment/request') ?>" id="paymentForm">
            <?= csrf_field() ?>
            
            <div class="modal-body">
                <!-- انتخاب درگاه -->
                <div class="form-group">
                    <label>انتخاب درگاه پرداخت:</label>
                    <div class="gateway-select">
                        <label class="gateway-option">
                            <input type="radio" name="gateway" value="zarinpal" required>
                            <div class="gateway-card">
                                <img src="<?= asset('images/gateways/zarinpal.png') ?>" alt="زرین‌پال">
                                <span>زرین‌پال</span>
                            </div>
                        </label>
                        
                        <label class="gateway-option">
                            <input type="radio" name="gateway" value="nextpay" required>
                            <div class="gateway-card">
                                <img src="<?= asset('images/gateways/nextpay.png') ?>" alt="نکست‌پی">
                                <span>نکست‌پی</span>
                            </div>
                        </label>
                        
                        <label class="gateway-option">
                            <input type="radio" name="gateway" value="idpay" required>
                            <div class="gateway-card">
                                <img src="<?= asset('images/gateways/idpay.png') ?>" alt="آیدی‌پی">
                                <span>آیدی‌پی</span>
                            </div>
                        </label>
                        
                        <label class="gateway-option">
                            <input type="radio" name="gateway" value="dgpay" required>
                            <div class="gateway-card">
                                <img src="<?= asset('images/gateways/dgpay.png') ?>" alt="دی‌جی‌پی">
                                <span>دی‌جی‌پی</span>
                            </div>
                        </label>
                    </div>
                </div>

                <!-- مبلغ -->
                <div class="form-group">
                    <label for="amount">مبلغ (تومان):</label>
                    <input type="number" 
                           id="amount" 
                           name="amount" 
                           class="form-control" 
                           placeholder="مثال: 100000"
                           min="10000"
                           step="1000"
                           required>
                    <small class="form-text">حداقل مبلغ: 10,000 تومان</small>
                </div>

                <!-- مبالغ پیشنهادی -->
                <div class="quick-amounts">
                    <button type="button" class="quick-amount-btn" onclick="setAmount(50000)">50,000</button>
                    <button type="button" class="quick-amount-btn" onclick="setAmount(100000)">100,000</button>
                    <button type="button" class="quick-amount-btn" onclick="setAmount(250000)">250,000</button>
                    <button type="button" class="quick-amount-btn" onclick="setAmount(500000)">500,000</button>
                    <button type="button" class="quick-amount-btn" onclick="setAmount(1000000)">1,000,000</button>
                </div>
            </div>

            <div class="modal-footer">
                <button type="button" class="btn btn-outline" onclick="closeOnlinePaymentModal()">انصراف</button>
                <button type="submit" class="btn btn-primary">
                    <i class="material-icons">payment</i>
                    انتقال به درگاه
                </button>
            </div>
        </form>
    </div>
</div>

<style>
.deposit-methods {
    display: grid;
    gap: 25px;
    margin-top: 25px;
}

.method-card {
    display: flex;
    align-items: flex-start;
    gap: 20px;
    background: white;
    border-radius: 15px;
    padding: 25px;
    box-shadow: 0 2px 8px rgba(0,0,0,0.06);
    transition: all 0.3s ease;
    border: 2px solid transparent;
}

.method-card:hover {
    border-color: #4fc3f7;
    box-shadow: 0 4px 15px rgba(79, 195, 247, 0.2);
    transform: translateY(-3px);
}

.method-card.crypto {
    background: linear-gradient(135deg, #e3f2fd 0%, #bbdefb 30%, white 100%);
}

.method-icon {
    width: 70px;
    height: 70px;
    border-radius: 15px;
    display: flex;
    align-items: center;
    justify-content: center;
    flex-shrink: 0;
}

.method-icon.online {
    background: linear-gradient(135deg, #4caf50 0%, #81c784 100%);
}

.method-icon.manual {
    background: linear-gradient(135deg, #2196f3 0%, #64b5f6 100%);
}

.method-icon.crypto {
    background: linear-gradient(135deg, #ffa726 0%, #ffb74d 100%);
}

.method-icon i {
    font-size: 36px;
    color: white;
}

.method-info {
    flex: 1;
}

.method-info h3 {
    margin: 0 0 8px 0;
    font-size: 18px;
    font-weight: 600;
    color: #333;
}

.method-info p {
    margin: 0 0 15px 0;
    font-size: 14px;
    color: #666;
}

.features {
    list-style: none;
    padding: 0;
    margin: 0 0 15px 0;
}

.features li {
    display: flex;
    align-items: center;
    gap: 8px;
    font-size: 13px;
    color: #666;
    margin-bottom: 8px;
}

.features li i {
    font-size: 16px;
    color: #4caf50;
}

.features li i.material-icons-outlined {
    color: #ffa726;
}

.gateway-logos {
    display: flex;
    gap: 10px;
    flex-wrap: wrap;
}

.gateway-logos img {
    height: 30px;
    width: auto;
    padding: 5px;
    background: white;
    border: 1px solid #e0e0e0;
    border-radius: 5px;
}

.network-badges {
    display: flex;
    gap: 8px;
}

.method-btn {
    display: flex;
    align-items: center;
    gap: 8px;
    padding: 12px 25px;
    background: #4fc3f7;
    color: white;
    text-decoration: none;
    border-radius: 10px;
    font-weight: 500;
    transition: all 0.3s ease;
    white-space: nowrap;
}

.method-btn:hover {
    background: #29b6f6;
    transform: translateX(-5px);
}

.method-btn i {
    font-size: 18px;
}

/* Modal Styles */
.modal {
    display: none;
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: rgba(0,0,0,0.6);
    z-index: 9999;
    align-items: center;
    justify-content: center;
}

.modal.show {
    display: flex;
}

.modal-content {
    background: white;
    border-radius: 15px;
    max-width: 600px;
    width: 90%;
    max-height: 90vh;
    overflow-y: auto;
}

.modal-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 20px 25px;
    border-bottom: 1px solid #f5f5f5;
}

.modal-header h3 {
    margin: 0;
    font-size: 18px;
}

.modal-close {
    background: none;
    border: none;
    cursor: pointer;
    padding: 5px;
    color: #999;
    transition: color 0.3s;
}

.modal-close:hover {
    color: #f44336;
}

.modal-body {
    padding: 25px;
}

.modal-footer {
    display: flex;
    justify-content: flex-end;
    gap: 10px;
    padding: 20px 25px;
    border-top: 1px solid #f5f5f5;
}

.gateway-select {
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    gap: 15px;
}

.gateway-option {
    cursor: pointer;
}

.gateway-option input[type="radio"] {
    display: none;
}

.gateway-card {
    padding: 20px;
    border: 2px solid #e0e0e0;
    border-radius: 10px;
    text-align: center;
    transition: all 0.3s ease;
}

.gateway-option input:checked + .gateway-card {
    border-color: #4fc3f7;
    background: rgba(79, 195, 247, 0.05);
}

.gateway-card:hover {
    border-color: #4fc3f7;
}

.gateway-card img {
    height: 40px;
    margin-bottom: 10px;
}

.gateway-card span {
    display: block;
    font-size: 13px;
    font-weight: 500;
    color: #333;
}

.quick-amounts {
    display: flex;
    flex-wrap: wrap;
    gap: 10px;
    margin-top: 15px;
}

.quick-amount-btn {
    padding: 8px 15px;
    background: #f5f5f5;
    border: 1px solid #e0e0e0;
    border-radius: 8px;
    cursor: pointer;
    font-size: 13px;
    transition: all 0.3s ease;
}

.quick-amount-btn:hover {
    background: #4fc3f7;
    color: white;
    border-color: #4fc3f7;
}

@media (max-width: 768px) {
    .method-card {
        flex-direction: column;
        text-align: center;
    }
    
    .method-btn {
        width: 100%;
        justify-content: center;
    }
    
    .gateway-select {
        grid-template-columns: 1fr;
    }
    
    .gateway-logos {
        justify-content: center;
    }
}
</style>

<script>
function showOnlinePaymentModal() {
    document.getElementById('onlinePaymentModal').classList.add('show');
}

function closeOnlinePaymentModal() {
    document.getElementById('onlinePaymentModal').classList.remove('show');
}

function setAmount(amount) {
    document.getElementById('amount').value = amount;
}

// بستن مودال با کلیک خارج از آن
document.getElementById('onlinePaymentModal')?.addEventListener('click', function(e) {
    if (e.target === this) {
        closeOnlinePaymentModal();
    }
});
</script>