<?php
// views/user/social-accounts/create.php
$title = 'ثبت حساب اجتماعی';
$layout = 'user';
ob_start();
?>

<div class="page-header">
    <h4><i class="material-icons">person_add</i> ثبت حساب اجتماعی جدید</h4>
    <a href="<?= url('/user/social-accounts') ?>" class="btn btn-outline-sm">
        <i class="material-icons">arrow_forward</i> بازگشت
    </a>
</div>

<div class="card">
    <div class="card-header">
        <h5>اطلاعات حساب</h5>
    </div>
    <div class="card-body">
        <form action="<?= url('/user/social-accounts/store') ?>" method="POST" id="socialForm">
            <?= csrf_field() ?>

            <div class="form-row">
                <div class="form-group col-md-6">
                    <label>پلتفرم <span class="required">*</span></label>
                    <select name="platform" id="platform" class="form-control" required>
                        <option value="">انتخاب کنید...</option>
                        <?php foreach ($platforms as $key => $label): ?>
                            <option value="<?= $key ?>" <?= old('platform') === $key ? 'selected' : '' ?>>
                                <?= e($label) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="form-group col-md-6">
                    <label>نام کاربری <span class="required">*</span></label>
                    <input type="text" name="username" class="form-control" 
                           value="<?= e(old('username') ?? '') ?>"
                           placeholder="مثال: mypage123" required>
                    <small class="form-hint">بدون @ وارد کنید</small>
                </div>
            </div>

            <div class="form-group">
                <label>لینک پروفایل <span class="required">*</span></label>
                <input type="url" name="profile_url" class="form-control ltr-input"
                       value="<?= e(old('profile_url') ?? '') ?>"
                       placeholder="https://instagram.com/mypage123" required>
            </div>

            <div class="form-row">
                <div class="form-group col-md-3">
                    <label>تعداد فالوور <span class="required">*</span></label>
                    <input type="number" name="follower_count" class="form-control"
                           value="<?= e(old('follower_count') ?? '0') ?>" min="0" required>
                </div>

                <div class="form-group col-md-3">
                    <label>تعداد فالووینگ</label>
                    <input type="number" name="following_count" class="form-control"
                           value="<?= e(old('following_count') ?? '0') ?>" min="0">
                </div>

                <div class="form-group col-md-3">
                    <label>تعداد پست <span class="required">*</span></label>
                    <input type="number" name="post_count" class="form-control"
                           value="<?= e(old('post_count') ?? '0') ?>" min="0" required>
                </div>

                <div class="form-group col-md-3">
                    <label>قدمت حساب (ماه) <span class="required">*</span></label>
                    <input type="number" name="account_age_months" class="form-control"
                           value="<?= e(old('account_age_months') ?? '0') ?>" min="0" required>
                </div>
            </div>

            <!-- قوانین -->
            <div class="alert-box alert-warning mt-15">
                <i class="material-icons">warning</i>
                <div>
                    <strong>شرایط تایید حساب:</strong>
                    <ul class="rules-list">
                        <li>حساب باید حداقل <strong>۳ ماه</strong> قدمت داشته باشد</li>
                        <li>حداقل <strong>۱۰ پست</strong> در اینستاگرام/توییتر و <strong>۵ ویدیو</strong> در یوتیوب</li>
                        <li>حساب نباید فیک باشد و باید تعامل واقعی با فالوورها داشته باشد</li>
                        <li>اطلاعات وارد‌شده توسط مدیریت بررسی و تایید می‌شود</li>
                    </ul>
                </div>
            </div>

            <div class="form-actions">
                <button type="submit" class="btn btn-primary">
                    <i class="material-icons">send</i> ثبت و ارسال برای بررسی
                </button>
            </div>
        </form>
    </div>
</div>

<style>
.form-row { display:grid; grid-template-columns:repeat(auto-fit, minmax(200px, 1fr)); gap:15px; }
.form-group { margin-bottom:15px; }
.form-group label { display:block; margin-bottom:5px; font-size:13px; font-weight:600; color:#555; }
.form-control { width:100%; padding:10px 12px; border:1px solid #ddd; border-radius:8px; font-size:13px; transition:border-color 0.2s; box-sizing:border-box; }
.form-control:focus { border-color:#4fc3f7; outline:none; box-shadow:0 0 0 3px rgba(79,195,247,0.1); }
.form-hint { font-size:11px; color:#999; margin-top:4px; display:block; }
.required { color:#f44336; }
.ltr-input { direction:ltr; text-align:left; }
.form-actions { margin-top:20px; padding-top:15px; border-top:1px solid #eee; }
.alert-warning { background:#fff8e1; color:#e65100; border-right:4px solid #ffa726; }
.rules-list { margin:8px 0 0 20px; padding:0; font-size:12px; }
.rules-list li { margin-bottom:4px; }
.mt-15 { margin-top:15px; }

@media(max-width:768px) {
    .form-row { grid-template-columns:1fr; }
}
</style>

<?php
$content = ob_get_clean();
include __DIR__ . '/../../layouts/' . $layout . '.php';
?>