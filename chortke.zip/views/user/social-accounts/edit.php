<?php
// views/user/social-accounts/edit.php
$title = 'ویرایش حساب اجتماعی';
$layout = 'user';
ob_start();
?>

<div class="page-header">
    <h4><i class="material-icons">edit</i> ویرایش حساب — <?= e(social_platform_label($account->platform)) ?></h4>
    <a href="<?= url('/user/social-accounts') ?>" class="btn btn-outline-sm">
        <i class="material-icons">arrow_forward</i> بازگشت
    </a>
</div>

<?php if ($account->status === 'rejected' && $account->rejection_reason): ?>
    <div class="alert-box alert-danger">
        <i class="material-icons">error</i>
        <div>
            <strong>دلیل رد قبلی:</strong> <?= e($account->rejection_reason) ?>
            <br><small>لطفاً اطلاعات را اصلاح و مجدداً ارسال کنید.</small>
        </div>
    </div>
<?php endif; ?>

<div class="card">
    <div class="card-body">
        <form action="<?= url('/user/social-accounts/' . $account->id . '/update') ?>" method="POST">
            <?= csrf_field() ?>

            <div class="form-group">
                <label>پلتفرم</label>
                <input type="text" class="form-control" 
                       value="<?= e(social_platform_label($account->platform)) ?>" disabled>
            </div>

            <div class="form-row">
                <div class="form-group col-md-6">
                    <label>نام کاربری <span class="required">*</span></label>
                    <input type="text" name="username" class="form-control" 
                           value="<?= e($account->username) ?>" required>
                </div>
                <div class="form-group col-md-6">
                    <label>لینک پروفایل <span class="required">*</span></label>
                    <input type="url" name="profile_url" class="form-control ltr-input"
                           value="<?= e($account->profile_url) ?>" required>
                </div>
            </div>

            <div class="form-row">
                <div class="form-group col-md-3">
                    <label>تعداد فالوور</label>
                    <input type="number" name="follower_count" class="form-control"
                           value="<?= $account->follower_count ?>" min="0" required>
                </div>
                <div class="form-group col-md-3">
                    <label>تعداد فالووینگ</label>
                    <input type="number" name="following_count" class="form-control"
                           value="<?= $account->following_count ?>" min="0">
                </div>
                <div class="form-group col-md-3">
                    <label>تعداد پست</label>
                    <input type="number" name="post_count" class="form-control"
                           value="<?= $account->post_count ?>" min="0" required>
                </div>
                <div class="form-group col-md-3">
                    <label>قدمت (ماه)</label>
                    <input type="number" name="account_age_months" class="form-control"
                           value="<?= $account->account_age_months ?>" min="0" required>
                </div>
            </div>

            <div class="form-actions">
                <button type="submit" class="btn btn-primary">
                    <i class="material-icons">save</i> ذخیره و ارسال مجدد
                </button>
            </div>
        </form>
    </div>
</div>

<style>
.form-row { display:grid; grid-template-columns:repeat(auto-fit,minmax(200px,1fr)); gap:15px; }
.form-group { margin-bottom:15px; }
.form-group label { display:block; margin-bottom:5px; font-size:13px; font-weight:600; color:#555; }
.form-control { width:100%; padding:10px 12px; border:1px solid #ddd; border-radius:8px; font-size:13px; box-sizing:border-box; }
.form-control:focus { border-color:#4fc3f7; outline:none; }
.form-control:disabled { background:#f5f5f5; color:#999; }
.required { color:#f44336; }
.ltr-input { direction:ltr; text-align:left; }
.form-actions { margin-top:20px; padding-top:15px; border-top:1px solid #eee; }
.alert-box { display:flex; align-items:flex-start; gap:10px; padding:12px 15px; border-radius:8px; font-size:13px; margin-bottom:15px; }
.alert-danger { background:#ffebee; color:#c62828; }
</style>

<?php
$content = ob_get_clean();
include __DIR__ . '/../../layouts/' . $layout . '.php';
?>