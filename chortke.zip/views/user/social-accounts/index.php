<?php
// views/user/social-accounts/index.php
$title = 'حساب‌های اجتماعی';
$layout = 'user';
ob_start();
?>

<div class="page-header">
    <h4><i class="material-icons">share</i> حساب‌های اجتماعی من</h4>
    <a href="<?= url('/user/social-accounts/create') ?>" class="btn btn-primary btn-sm">
        <i class="material-icons">add</i> ثبت حساب جدید
    </a>
</div>

<!-- راهنما -->
<div class="alert-box alert-info">
    <i class="material-icons">info</i>
    <div>
        <strong>توجه:</strong> برای انجام تسک‌های شبکه‌های اجتماعی، ابتدا باید حساب خود را ثبت و توسط مدیریت تایید شود.
        حساب باید حداقل ۳ ماه قدمت و تعداد پست کافی داشته باشد.
    </div>
</div>

<?php if (empty($accounts)): ?>
    <div class="empty-state">
        <i class="material-icons">person_add</i>
        <h5>هنوز حسابی ثبت نکرده‌اید</h5>
        <p>برای شروع انجام تسک‌ها، حساب اجتماعی خود را ثبت کنید.</p>
        <a href="<?= url('/user/social-accounts/create') ?>" class="btn btn-primary">ثبت حساب جدید</a>
    </div>
<?php else: ?>
    <div class="cards-grid">
        <?php foreach ($accounts as $account): ?>
            <div class="social-card" data-id="<?= $account->id ?>">
                <div class="social-card-header">
                    <div class="platform-icon platform-<?= e($account->platform) ?>">
                        <?= getPlatformIcon($account->platform) ?>
                    </div>
                    <div class="platform-info">
                        <h5><?= e(social_platform_label($account->platform)) ?></h5>
                        <span class="username">@<?= e($account->username) ?></span>
                    </div>
                    <span class="badge badge-<?= social_status_badge($account->status) ?>">
                        <?= e(social_status_label($account->status)) ?>
                    </span>
                </div>

                <div class="social-card-body">
                    <div class="stat-row">
                        <div class="stat-item">
                            <span class="stat-value"><?= number_format($account->follower_count) ?></span>
                            <span class="stat-label">فالوور</span>
                        </div>
                        <div class="stat-item">
                            <span class="stat-value"><?= number_format($account->following_count) ?></span>
                            <span class="stat-label">فالووینگ</span>
                        </div>
                        <div class="stat-item">
                            <span class="stat-value"><?= number_format($account->post_count) ?></span>
                            <span class="stat-label">پست</span>
                        </div>
                        <div class="stat-item">
                            <span class="stat-value"><?= $account->account_age_months ?> ماه</span>
                            <span class="stat-label">قدمت</span>
                        </div>
                    </div>

                    <?php if ($account->status === 'rejected' && $account->rejection_reason): ?>
                        <div class="alert-box alert-danger mt-10">
                            <i class="material-icons">error</i>
                            <span>دلیل رد: <?= e($account->rejection_reason) ?></span>
                        </div>
                    <?php endif; ?>
                </div>

                <div class="social-card-footer">
                    <a href="<?= e($account->profile_url) ?>" target="_blank" class="btn btn-outline-sm">
                        <i class="material-icons">open_in_new</i> مشاهده پروفایل
                    </a>

                    <?php if ($account->status !== 'verified'): ?>
                        <a href="<?= url('/user/social-accounts/' . $account->id . '/edit') ?>" class="btn btn-outline-sm btn-warning-outline">
                            <i class="material-icons">edit</i> ویرایش
                        </a>
                    <?php endif; ?>

                    <button class="btn btn-outline-sm btn-danger-outline btn-delete-social"
                            data-id="<?= $account->id ?>"
                            data-name="<?= e($account->username) ?>">
                        <i class="material-icons">delete</i> حذف
                    </button>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
<?php endif; ?>

<style>
.page-header { display:flex; justify-content:space-between; align-items:center; margin-bottom:20px; }
.cards-grid { display:grid; grid-template-columns:repeat(auto-fill, minmax(340px, 1fr)); gap:20px; }
.social-card { background:#fff; border-radius:10px; box-shadow:0 2px 8px rgba(0,0,0,0.06); overflow:hidden; }
.social-card-header { display:flex; align-items:center; gap:12px; padding:15px 20px; border-bottom:1px solid #f0f0f0; }
.platform-icon { width:45px; height:45px; border-radius:10px; display:flex; align-items:center; justify-content:center; color:#fff; font-size:22px; }
.platform-instagram { background:linear-gradient(135deg, #833ab4, #fd1d1d, #fcb045); }
.platform-youtube { background:#ff0000; }
.platform-telegram { background:#0088cc; }
.platform-tiktok { background:#000; }
.platform-twitter { background:#1da1f2; }
.platform-info h5 { margin:0; font-size:14px; }
.platform-info .username { font-size:12px; color:#888; }
.social-card-body { padding:15px 20px; }
.stat-row { display:grid; grid-template-columns:repeat(4, 1fr); gap:10px; text-align:center; }
.stat-item { }
.stat-value { display:block; font-weight:700; font-size:15px; color:#333; }
.stat-label { font-size:11px; color:#999; }
.social-card-footer { padding:12px 20px; border-top:1px solid #f0f0f0; display:flex; gap:8px; flex-wrap:wrap; }
.btn-outline-sm { padding:5px 12px; font-size:12px; border:1px solid #ddd; border-radius:6px; background:transparent; cursor:pointer; display:inline-flex; align-items:center; gap:4px; text-decoration:none; color:#555; transition:all 0.2s; }
.btn-outline-sm:hover { background:#f5f5f5; }
.btn-warning-outline { border-color:#ffa726; color:#f57c00; }
.btn-danger-outline { border-color:#ef5350; color:#e53935; }
.empty-state { text-align:center; padding:60px 20px; background:#fff; border-radius:10px; }
.empty-state i { font-size:60px; color:#ccc; }
.empty-state h5 { margin:15px 0 8px; color:#555; }
.empty-state p { color:#999; margin-bottom:20px; }
.mt-10 { margin-top:10px; }
.alert-box { display:flex; align-items:flex-start; gap:10px; padding:12px 15px; border-radius:8px; font-size:13px; margin-bottom:15px; }
.alert-info { background:#e3f2fd; color:#1565c0; }
.alert-danger { background:#ffebee; color:#c62828; }
.alert-box i { font-size:20px; margin-top:2px; }

@media(max-width:768px) {
    .cards-grid { grid-template-columns:1fr; }
    .stat-row { grid-template-columns:repeat(2, 1fr); }
    .page-header { flex-direction:column; gap:10px; }
}
</style>

<script>
document.querySelectorAll('.btn-delete-social').forEach(btn => {
    btn.addEventListener('click', function() {
        const id = this.dataset.id;
        const name = this.dataset.name;

        Swal.fire({
            title: 'حذف حساب',
            text: `آیا از حذف حساب @${name} مطمئن هستید؟`,
            icon: 'warning',
            showCancelButton: true,
            confirmButtonText: 'بله، حذف شود',
            cancelButtonText: 'انصراف',
            confirmButtonColor: '#f44336'
        }).then(result => {
            if (result.isConfirmed) {
                fetch(`<?= url('/user/social-accounts') ?>/${id}/delete`, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-CSRF-TOKEN': '<?= csrf_token() ?>'
                    },
                    body: JSON.stringify({ _csrf_token: '<?= csrf_token() ?>' })
                })
                .then(r => r.json())
                .then(data => {
                    if (data.success) {
                        notyf.success(data.message);
                        document.querySelector(`.social-card[data-id="${id}"]`).remove();
                    } else {
                        notyf.error(data.message);
                    }
                })
                .catch(() => notyf.error('خطا در ارتباط'));
            }
        });
    });
});
</script>

<?php
$content = ob_get_clean();
include __DIR__ . '/../../layouts/' . $layout . '.php';

function getPlatformIcon($platform) {
    $icons = [
        'instagram' => '<i class="material-icons">camera_alt</i>',
        'youtube'   => '<i class="material-icons">play_circle</i>',
        'telegram'  => '<i class="material-icons">send</i>',
        'tiktok'    => '<i class="material-icons">music_note</i>',
        'twitter'   => '<i class="material-icons">tag</i>',
    ];
    return $icons[$platform] ?? '<i class="material-icons">share</i>';
}
?>