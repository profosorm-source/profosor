<?php
$title = 'وظایف من (تبلیغ‌دهنده)';
$layout = 'user';
$session = \Core\Session::getInstance();
ob_start();
$statusLabelsMap  = $statusLabelsMap ?? [];
$statusClassesMap = $statusClassesMap ?? [];
?>

<div class="content-header">
    <div class="d-flex justify-content-between align-items-center">
        <div>
            <h4 class="page-title mb-1">
                <i class="material-icons text-primary">campaign</i>
                وظایف من (تبلیغ‌دهنده)
            </h4>
            <p class="text-muted mb-0" style="font-size:12px;">وظایفی که ایجاد کرده‌اید و وضعیت آن‌ها</p>
        </div>
        <div class="d-flex gap-2">
            <a href="<?= url('/user/custom-tasks/available') ?>" class="btn btn-outline-primary btn-sm">
                <i class="material-icons" style="font-size:16px;vertical-align:middle;">search</i>
                انجام وظیفه
            </a>
            <a href="<?= url('/user/custom-tasks/create') ?>" class="btn btn-primary btn-sm">
                <i class="material-icons" style="font-size:16px;vertical-align:middle;">add</i>
                ثبت وظیفه جدید
            </a>
        </div>
    </div>
</div>

<?php if ($flash = $session->getFlash('success')): ?>
<div class="alert alert-success alert-dismissible fade show mt-3" role="alert">
    <i class="material-icons" style="font-size:18px;vertical-align:middle;">check_circle</i>
    <?= e($flash) ?>
    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
</div>
<?php endif; ?>
<?php if ($flash = $session->getFlash('error')): ?>
<div class="alert alert-danger alert-dismissible fade show mt-3" role="alert">
    <i class="material-icons" style="font-size:18px;vertical-align:middle;">error</i>
    <?= e($flash) ?>
    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
</div>
<?php endif; ?>

<div class="card mt-3 mb-4">
    <div class="card-header d-flex justify-content-between align-items-center">
        <h6 class="card-title mb-0">وظایف ثبت‌شده</h6>
        <span class="badge bg-info"><?= \count($myTasks) ?> مورد</span>
    </div>
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table table-hover mb-0" style="font-size:12px;">
                <thead>
                    <tr>
                        <th>#</th><th>عنوان</th><th>نوع</th><th>قیمت واحد</th>
                        <th>تعداد</th><th>انجام‌شده</th><th>بودجه</th><th>وضعیت</th><th>تاریخ</th><th>عملیات</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($myTasks)): ?>
                    <tr><td colspan="10" class="text-center text-muted py-4">
                        <i class="material-icons" style="font-size:40px;opacity:0.2;">inbox</i>
                        <p class="mt-2 mb-0">هنوز وظیفه‌ای ثبت نکرده‌اید.</p>
                    </td></tr>
                    <?php else: ?>
                    <?php $typeLabels = custom_task_types(); ?>
                    <?php foreach ($myTasks as $idx => $t): ?>
                    <tr>
                        <td class="text-muted"><?= $idx + 1 ?></td>
                        <td style="max-width:200px;">
                            <a href="<?= url('/user/custom-tasks/' . $t->id) ?>" style="font-size:12px;font-weight:bold;">
                                <?= e(\mb_substr($t->title, 0, 40)) ?><?= \mb_strlen($t->title) > 40 ? '...' : '' ?>
                            </a>
                        </td>
                        <td><span class="badge" style="background:#e3f2fd;color:#1976d2;font-size:9px;"><?= e($typeLabels[$t->task_type] ?? $t->task_type) ?></span></td>
                        <td><?= $t->currency === 'usdt' ? number_format($t->price_per_task, 2) : number_format($t->price_per_task) ?></td>
                        <td><?= number_format($t->total_quantity) ?></td>
                        <td><strong class="text-success"><?= number_format($t->completed_count) ?></strong> / <?= number_format($t->total_quantity) ?></td>
                        <td style="font-size:11px;">
                            <?= $t->currency === 'usdt' ? number_format($t->spent_budget, 2) : number_format($t->spent_budget) ?>
                            / <?= $t->currency === 'usdt' ? number_format($t->total_budget, 2) : number_format($t->total_budget) ?>
                        </td>
                        <td><span class="badge <?= $statusClasses[$t->status] ?? '' ?>"><?= $statusLabels[$t->status] ?? $t->status ?></span></td>
                        <td style="font-size:10px;"><?= to_jalali($t->created_at ?? '') ?></td>
                        <td>
                            <a href="<?= url('/user/custom-tasks/' . $t->id) ?>" class="btn btn-sm btn-outline-primary" title="جزئیات">
                                <i class="material-icons" style="font-size:14px;">visibility</i>
                            </a>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php
$content = ob_get_clean();
include __DIR__ . '/../../layouts/' . $layout . '.php';
?>