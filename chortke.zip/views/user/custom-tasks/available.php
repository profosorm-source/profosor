<?php
$title = 'وظایف موجود';
$layout = 'user';
ob_start();
?>

<div class="content-header">
    <div class="d-flex justify-content-between align-items-center">
        <div>
            <h4 class="page-title mb-1">
                <i class="material-icons text-primary">assignment</i>
                وظایف موجود
            </h4>
            <p class="text-muted mb-0" style="font-size:12px;">وظیفه‌ای انتخاب کنید، انجام دهید و پاداش بگیرید</p>
        </div>
        <div class="d-flex gap-2">
            <a href="<?= url('/user/custom-tasks') ?>" class="btn btn-outline-info btn-sm">
                <i class="material-icons" style="font-size:16px;vertical-align:middle;">campaign</i>
                وظایف من (تبلیغ‌دهنده)
            </a>
            <a href="<?= url('/user/custom-tasks/my-submissions') ?>" class="btn btn-outline-secondary btn-sm">
                <i class="material-icons" style="font-size:16px;vertical-align:middle;">history</i>
                تاریخچه انجام‌ها
            </a>
        </div>
    </div>
</div>

<!-- فیلتر -->
<div class="card mt-3">
    <div class="card-body py-2">
        <form method="GET" action="<?= url('/user/custom-tasks/available') ?>" class="d-flex gap-2 align-items-center flex-wrap">
            <select name="type" class="form-select form-select-sm" style="width:auto;">
                <option value="">همه انواع</option>
                <?php
                $types = custom_task_types();
                foreach ($types as $k => $v):
                ?>
                <option value="<?= e($k) ?>" <?= ($filters['task_type'] ?? '') === $k ? 'selected' : '' ?>><?= e($v) ?></option>
                <?php endforeach; ?>
            </select>
            <button type="submit" class="btn btn-primary btn-sm">فیلتر</button>
            <a href="<?= url('/user/custom-tasks/available') ?>" class="btn btn-outline-secondary btn-sm">همه</a>
            <span class="text-muted ms-auto" style="font-size:12px;"><?= number_format($total) ?> وظیفه فعال</span>
        </form>
    </div>
</div>

<!-- لیست وظایف -->
<div class="row mt-3">
    <?php if (empty($tasks)): ?>
    <div class="col-12">
        <div class="card">
            <div class="card-body text-center py-5">
                <i class="material-icons" style="font-size:60px;opacity:0.2;">inbox</i>
                <p class="text-muted mt-2">در حال حاضر وظیفه‌ای موجود نیست.</p>
            </div>
        </div>
    </div>
    <?php else: ?>
    <?php
    $typeLabels = custom_task_types();
    $proofLabels = custom_task_proof_types();
    ?>
    <?php foreach ($tasks as $task): ?>
    <div class="col-lg-4 col-md-6 mb-3">
        <div class="card h-100 task-card" style="transition:all 0.3s ease;">
            <?php if ($task->is_featured): ?>
            <div style="position:absolute;top:10px;left:10px;z-index:2;">
                <span class="badge" style="background:#ff9800;color:#fff;font-size:10px;">
                    <i class="material-icons" style="font-size:12px;vertical-align:middle;">star</i> ویژه
                </span>
            </div>
            <?php endif; ?>

            <div class="card-body">
                <div class="d-flex align-items-center mb-2">
                    <span class="badge" style="background:#e3f2fd;color:#1976d2;font-size:10px;">
                        <?= e($typeLabels[$task->task_type] ?? $task->task_type) ?>
                    </span>
                    <span class="badge ms-1" style="background:#f3e5f5;color:#7b1fa2;font-size:10px;">
                        <?= e($proofLabels[$task->proof_type] ?? $task->proof_type) ?>
                    </span>
                </div>

                <h6 class="card-title mb-2" style="font-weight:bold;font-size:14px;line-height:1.5;">
                    <?= e($task->title) ?>
                </h6>

                <p class="text-muted mb-2" style="font-size:12px;line-height:1.6;max-height:48px;overflow:hidden;">
                    <?= e(\mb_substr($task->description, 0, 100)) ?><?= \mb_strlen($task->description) > 100 ? '...' : '' ?>
                </p>

                <div class="d-flex justify-content-between align-items-center mb-2" style="font-size:12px;">
                    <span class="text-muted">
                        <i class="material-icons" style="font-size:14px;vertical-align:middle;">schedule</i>
                        مهلت: <?= $task->deadline_hours ?> ساعت
                    </span>
                    <span class="text-muted">
                        <i class="material-icons" style="font-size:14px;vertical-align:middle;">people</i>
                        باقی: <?= number_format($task->remaining_count) ?>
                    </span>
                </div>

                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <strong class="text-success" style="font-size:16px;">
                            <?= $task->currency === 'usdt' ? number_format($task->price_per_task, 2) . ' USDT' : number_format($task->price_per_task) . ' تومان' ?>
                        </strong>
                    </div>
                    <button class="btn btn-primary btn-sm btn-start-task" data-id="<?= $task->id ?>" data-title="<?= e($task->title) ?>">
                        <i class="material-icons" style="font-size:16px;vertical-align:middle;">play_arrow</i>
                        شروع
                    </button>
                </div>
            </div>
        </div>
    </div>
    <?php endforeach; ?>
    <?php endif; ?>
</div>

<!-- صفحه‌بندی -->
<?php if ($pages > 1): ?>
<div class="d-flex justify-content-center mt-3 mb-4">
    <nav><ul class="pagination pagination-sm mb-0">
        <?php for ($i = 1; $i <= \min($pages, 20); $i++): ?>
        <li class="page-item <?= $i === $page ? 'active' : '' ?>">
            <a class="page-link" href="<?= url('/user/custom-tasks/available?page=' . $i . '&type=' . e($filters['task_type'] ?? '')) ?>"><?= $i ?></a>
        </li>
        <?php endfor; ?>
    </ul></nav>
</div>
<?php endif; ?>

<style>
.task-card:hover { transform: translateY(-3px); box-shadow: 0 4px 15px rgba(0,0,0,0.1) !important; }
</style>

<script>
document.addEventListener('DOMContentLoaded', function() {
    document.querySelectorAll('.btn-start-task').forEach(function(btn) {
        btn.addEventListener('click', function() {
            var taskId = this.dataset.id;
            var title = this.dataset.title;
            var btnEl = this;

            Swal.fire({
                title: 'شروع وظیفه',
                html: '<strong>' + title + '</strong><br><small class="text-muted">بعد از شروع، مهلت محدودی برای انجام و ارسال مدرک دارید.</small>',
                icon: 'question',
                showCancelButton: true,
                confirmButtonColor: '#4caf50',
                confirmButtonText: 'شروع می‌کنم',
                cancelButtonText: 'بعداً'
            }).then(function(result) {
                if (result.isConfirmed) {
                    btnEl.disabled = true;
                    btnEl.innerHTML = '<span class="spinner-border spinner-border-sm"></span>';

                    fetch('<?= url('/user/custom-tasks/start') ?>', {
                        method: 'POST',
                        headers: {
                            'X-Requested-With': 'XMLHttpRequest',
                            'Content-Type': 'application/json',
                            'X-CSRF-TOKEN': '<?= csrf_token() ?>'
                        },
                        body: JSON.stringify({ csrf_token: '<?= csrf_token() ?>', task_id: taskId })
                    })
                    .then(function(r) { return r.json(); })
                    .then(function(data) {
                        var notyf = new Notyf({duration: 4000, position: {x:'left',y:'top'}});
                        if (data.success) {
                            notyf.success(data.message);
                            setTimeout(function() {
                                window.location.href = '<?= url('/user/custom-tasks/my-submissions') ?>';
                            }, 1500);
                        } else {
                            notyf.error(data.message);
                            btnEl.disabled = false;
                            btnEl.innerHTML = '<i class="material-icons" style="font-size:16px;vertical-align:middle;">play_arrow</i> شروع';
                        }
                    })
                    .catch(function() {
                        var notyf = new Notyf({duration: 4000, position: {x:'left',y:'top'}});
                        notyf.error('خطا در ارتباط با سرور');
                        btnEl.disabled = false;
                        btnEl.innerHTML = '<i class="material-icons" style="font-size:16px;vertical-align:middle;">play_arrow</i> شروع';
                    });
                }
            });
        });
    });
});
</script>

<?php
$content = ob_get_clean();
include __DIR__ . '/../../layouts/' . $layout . '.php';
?>