<?php
$title = 'ثبت وظیفه جدید';
$layout = 'user';
$session = \Core\Session::getInstance();
$old = $session->getFlash('old') ?? [];
$old = \is_array($old) ? (object) $old : $old;
$currencyMode = setting('currency_mode', 'irt');
$currencyLabel = $currencyMode === 'usdt' ? 'USDT' : 'تومان';
$feePercent = setting('custom_task_site_fee_percent', 10);
ob_start();
?>

<div class="content-header">
    <div class="d-flex justify-content-between align-items-center">
        <div>
            <h4 class="page-title mb-1"><i class="material-icons text-primary">add_circle</i> ثبت وظیفه جدید</h4>
            <p class="text-muted mb-0" style="font-size:12px;">وظیفه‌ای تعریف کنید تا کاربران برای شما انجام دهند</p>
        </div>
        <a href="<?= url('/user/custom-tasks') ?>" class="btn btn-outline-secondary btn-sm">
            <i class="material-icons" style="font-size:16px;vertical-align:middle;">arrow_forward</i> بازگشت
        </a>
    </div>
</div>

<?php if ($flash = $session->getFlash('error')): ?>
<div class="alert alert-danger alert-dismissible fade show mt-3" role="alert">
    <?= e($flash) ?>
    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
</div>
<?php endif; ?>

<!-- هشدار کارمزد -->
<div class="alert mt-3" style="background:linear-gradient(135deg,#e3f2fd 0%,#bbdefb 100%);border:none;font-size:13px;">
    <i class="material-icons" style="font-size:16px;vertical-align:middle;color:#1976d2;">info</i>
    کارمزد سایت: <strong><?= $feePercent ?>%</strong> از بودجه کل. مبلغ کارمزد + بودجه از کیف پول شما کسر می‌شود.
</div>

<form action="<?= url('/user/custom-tasks/store') ?>" method="POST" enctype="multipart/form-data">
    <?= csrf_field() ?>

    <div class="card mt-3">
        <div class="card-header"><h6 class="card-title mb-0">اطلاعات وظیفه</h6></div>
        <div class="card-body">
            <div class="row">
                <div class="col-md-8 mb-3">
                    <label class="form-label">عنوان وظیفه <span class="text-danger">*</span></label>
                    <input type="text" name="title" class="form-control" value="<?= e($old->title ?? '') ?>" placeholder="مثال: ثبت‌نام در سایت ..." required minlength="5" maxlength="200">
                </div>
                <div class="col-md-4 mb-3">
                    <label class="form-label">نوع وظیفه</label>
                    <select name="task_type" class="form-select">
                        <?php foreach ($taskTypes as $k => $v): ?>
                        <option value="<?= e($k) ?>" <?= ($old->task_type ?? 'custom') === $k ? 'selected' : '' ?>><?= e($v) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
            </div>
            <div class="mb-3">
                <label class="form-label">توضیحات کامل <span class="text-danger">*</span></label>
                <textarea name="description" class="form-control" rows="5" required minlength="20" placeholder="توضیح دقیق کاری که باید انجام شود..."><?= e($old->description ?? '') ?></textarea>
            </div>
            <div class="row">
                <div class="col-md-6 mb-3">
                    <label class="form-label">لینک کار</label>
                    <input type="url" name="link" class="form-control" dir="ltr" style="text-align:left;" value="<?= e($old->link ?? '') ?>" placeholder="https://...">
                </div>
                <div class="col-md-6 mb-3">
                    <label class="form-label">تصویر نمونه (اختیاری)</label>
                    <input type="file" name="sample_image" class="form-control" accept="image/*">
                    <small class="text-muted">حداکثر 2 مگابایت — jpg, png, webp</small>
                </div>
            </div>
        </div>
    </div>

    <div class="card mt-3">
        <div class="card-header"><h6 class="card-title mb-0">مدرک و تأیید</h6></div>
        <div class="card-body">
            <div class="row">
                <div class="col-md-6 mb-3">
                    <label class="form-label">نوع مدرک مورد نیاز</label>
                    <select name="proof_type" class="form-select">
                        <?php foreach ($proofTypes as $k => $v): ?>
                        <option value="<?= e($k) ?>" <?= ($old->proof_type ?? 'screenshot') === $k ? 'selected' : '' ?>><?= e($v) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-md-6 mb-3">
                    <label class="form-label">توضیح مدرک</label>
                    <input type="text" name="proof_description" class="form-control" value="<?= e($old->proof_description ?? '') ?>" placeholder="مثال: اسکرین‌شات از صفحه پروفایل">
                </div>
            </div>
        </div>
    </div>

    <div class="card mt-3">
        <div class="card-header"><h6 class="card-title mb-0">قیمت و تعداد</h6></div>
        <div class="card-body">
            <div class="row">
                <div class="col-md-3 mb-3">
                    <label class="form-label">قیمت هر انجام (<?= $currencyLabel ?>) <span class="text-danger">*</span></label>
                    <input type="number" name="price_per_task" id="price_per_task" class="form-control" step="<?= $currencyMode === 'usdt' ? '0.01' : '100' ?>" min="0" value="<?= e($old->price_per_task ?? '') ?>" required>
                </div>
                <div class="col-md-3 mb-3">
                    <label class="form-label">تعداد کل <span class="text-danger">*</span></label>
                    <input type="number" name="total_quantity" id="total_quantity" class="form-control" min="1" value="<?= e($old->total_quantity ?? '10') ?>" required>
                </div>
                <div class="col-md-3 mb-3">
                    <label class="form-label">مهلت انجام (ساعت)</label>
                    <input type="number" name="deadline_hours" class="form-control" min="1" max="168" value="<?= e($old->deadline_hours ?? '24') ?>">
                </div>
                <div class="col-md-3 mb-3">
                    <label class="form-label">سقف روزانه هر کاربر</label>
                    <input type="number" name="daily_limit_per_user" class="form-control" min="1" value="<?= e($old->daily_limit_per_user ?? '1') ?>">
                </div>
            </div>

            <!-- محاسبه زنده بودجه -->
            <div class="p-3 rounded" style="background:#f8f9fa;" id="budget-calc">
                <div class="row" style="font-size:13px;">
                    <div class="col-md-4 mb-1">
                        بودجه کل: <strong id="calc-budget">0</strong> <?= $currencyLabel ?>
                    </div>
                    <div class="col-md-4 mb-1">
                        کارمزد سایت (<?= $feePercent ?>%): <strong id="calc-fee">0</strong> <?= $currencyLabel ?>
                    </div>
                    <div class="col-md-4 mb-1">
                        مبلغ کسر از کیف پول: <strong class="text-danger" id="calc-total">0</strong> <?= $currencyLabel ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="card mt-3">
        <div class="card-header"><h6 class="card-title mb-0">محدودیت‌ها (اختیاری)</h6></div>
        <div class="card-body">
            <div class="row">
                <div class="col-md-4 mb-3">
                    <label class="form-label">محدودیت دستگاه</label>
                    <select name="device_restriction" class="form-select">
                        <option value="all" <?= ($old->device_restriction ?? 'all') === 'all' ? 'selected' : '' ?>>همه</option>
                        <option value="mobile" <?= ($old->device_restriction ?? '') === 'mobile' ? 'selected' : '' ?>>فقط موبایل</option>
                        <option value="desktop" <?= ($old->device_restriction ?? '') === 'desktop' ? 'selected' : '' ?>>فقط دسکتاپ</option>
                    </select>
                </div>
            </div>
        </div>
    </div>

    <div class="d-flex justify-content-end gap-2 mt-3 mb-4">
        <a href="<?= url('/user/custom-tasks') ?>" class="btn btn-outline-secondary">انصراف</a>
        <button type="submit" class="btn btn-primary">
            <i class="material-icons" style="font-size:16px;vertical-align:middle;">send</i>
            ثبت و پرداخت
        </button>
    </div>
</form>

<script>
document.addEventListener('DOMContentLoaded', function() {
    var feePercent = <?= $feePercent ?>;
    var isUsdt = <?= $currencyMode === 'usdt' ? 'true' : 'false' ?>;

    function calc() {
        var price = parseFloat(document.getElementById('price_per_task').value) || 0;
        var qty = parseInt(document.getElementById('total_quantity').value) || 0;
        var budget = price * qty;
        var fee = Math.round(budget * (feePercent / 100) * 100) / 100;
        var total = budget + fee;

        document.getElementById('calc-budget').textContent = isUsdt ? total.toFixed(2) : Math.round(budget).toLocaleString('fa-IR');
        document.getElementById('calc-fee').textContent = isUsdt ? fee.toFixed(2) : Math.round(fee).toLocaleString('fa-IR');
        document.getElementById('calc-total').textContent = isUsdt ? total.toFixed(2) : Math.round(total).toLocaleString('fa-IR');
    }

    document.getElementById('price_per_task').addEventListener('input', calc);
    document.getElementById('total_quantity').addEventListener('input', calc);
    calc();
});
</script>

<?php
$content = ob_get_clean();
include __DIR__ . '/../../layouts/' . $layout . '.php';
?>