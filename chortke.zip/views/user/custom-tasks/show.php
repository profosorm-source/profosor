<?php
$title = 'جزئیات وظیفه: ' . e(\mb_substr($task->title, 0, 30));
$layout = 'user';
ob_start();
$subStatusLabels = custom_submission_status_labels_map();
$subStatusClasses = custom_submission_status_classes_map();
$taskStatusLabels = custom_task_status_labels_map();
$taskStatusClasses = custom_task_status_classes_map();
?>

<div class="content-header">
    <div class="d-flex justify-content-between align-items-center">
        <div>
            <h4 class="page-title mb-1"><i class="material-icons text-primary">assignment</i> <?= e($task->title) ?></h4>
            <p class="text-muted mb-0" style="font-size:12px;">
                <span class="badge <?= $taskStatusClasses[$task->status] ?? '' ?>"><?= $taskStatusLabels[$task->status] ?? $task->status ?></span>
                | ایجاد: <?= to_jalali($task->created_at ?? '') ?>
            </p>
        </div>
        <a href="<?= $isOwner ? url('/user/custom-tasks') : url('/user/custom-tasks/available') ?>" class="btn btn-outline-secondary btn-sm">
            <i class="material-icons" style="font-size:16px;vertical-align:middle;">arrow_forward</i> بازگشت
        </a>
    </div>
</div>

<!-- اطلاعات وظیفه -->
<div class="card mt-3">
    <div class="card-body">
        <div class="row">
            <div class="col-md-8">
                <h6 style="font-weight:bold;">توضیحات:</h6>
                <p style="font-size:13px;line-height:1.8;white-space:pre-wrap;"><?= e($task->description) ?></p>
                <?php if ($task->link): ?>
                <p><strong>لینک:</strong> <a href="<?= e($task->link) ?>" target="_blank" rel="noopener" dir="ltr"><?= e($task->link) ?></a></p>
                <?php endif; ?>
                <?php if ($task->proof_description): ?>
                <p><strong>مدرک مورد نیاز:</strong> <?= e($task->proof_description) ?></p>
                <?php endif; ?>
            </div>
            <div class="col-md-4">
                <div class="p-3 rounded" style="background:#f8f9fa;font-size:13px;">
                    <div class="mb-2"><strong>قیمت واحد:</strong> <span class="text-success"><?= $task->currency === 'usdt' ? number_format($task->price_per_task, 2) . ' USDT' : number_format($task->price_per_task) . ' تومان' ?></span></div>
                    <div class="mb-2"><strong>تعداد:</strong> <?= number_format($task->completed_count) ?> / <?= number_format($task->total_quantity) ?></div>
                    <div class="mb-2"><strong>مهلت:</strong> <?= $task->deadline_hours ?> ساعت</div>
                    <div class="mb-2"><strong>نوع:</strong> <?= e(custom_task_types()[$task->task_type] ?? $task->task_type) ?></div>
                    <div><strong>مدرک:</strong> <?= e(custom_task_proof_types()[$task->proof_type] ?? $task->proof_type) ?></div>
                </div>
                <?php if ($task->sample_image): ?>
                <div class="mt-2">
                    <img src="<?= url('/file/view/task-samples/' . \basename($task->sample_image)) ?>" alt="نمونه" class="img-fluid rounded" style="max-height:200px;">
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<!-- submission‌ها (فقط برای تبلیغ‌دهنده) -->
<?php if ($isOwner): ?>
<div class="card mt-3 mb-4">
    <div class="card-header d-flex justify-content-between align-items-center">
        <h6 class="card-title mb-0"><i class="material-icons text-primary" style="font-size:18px;vertical-align:middle;">people</i> انجام‌دهندگان</h6>
        <span class="badge bg-info"><?= \count($submissions) ?> مورد</span>
    </div>
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table table-hover mb-0" style="font-size:12px;">
                <thead>
                    <tr><th>#</th><th>کاربر</th><th>مدرک</th><th>وضعیت</th><th>تاریخ ارسال</th><th>عملیات</th></tr>
                </thead>
                <tbody>
                    <?php if (empty($submissions)): ?>
                    <tr><td colspan="6" class="text-center text-muted py-3">هنوز کسی شروع نکرده.</td></tr>
                    <?php else: ?>
                    <?php foreach ($submissions as $idx => $s): ?>
                    <tr id="sub-row-<?= $s->id ?>">
                        <td class="text-muted"><?= $idx + 1 ?></td>
                        <td><?= e($s->worker_name ?? '—') ?></td>
                        <td>
                            <?php if ($s->proof_file): ?>
                            <a href="<?= url('/file/view/task-proofs/' . \basename($s->proof_file)) ?>" target="_blank" class="btn btn-sm btn-outline-info">
                                <i class="material-icons" style="font-size:14px;">image</i> مشاهده
                            </a>
                            <?php endif; ?>
                            <?php if ($s->proof_text): ?>
                            <button class="btn btn-sm btn-outline-secondary" onclick="Swal.fire({title:'مدرک متنی',html:'<pre style=text-align:right;direction:rtl;white-space:pre-wrap><?= e($s->proof_text) ?></pre>',width:600})">
                                <i class="material-icons" style="font-size:14px;">description</i> متن
                            </button>
                            <?php endif; ?>
                            <?php if (!$s->proof_file && !$s->proof_text): ?>
                            <span class="text-muted">هنوز ارسال نشده</span>
                            <?php endif; ?>
                        </td>
                        <td><span class="badge <?= $subStatusClasses[$s->status] ?? '' ?>"><?= $subStatusLabels[$s->status] ?? $s->status ?></span></td>
                        <td style="font-size:10px;"><?= $s->submitted_at ? to_jalali($s->submitted_at) : '—' ?></td>
                        <td>
                            <?php if ($s->status === 'submitted'): ?>
                            <div class="d-flex gap-1">
                                <button class="btn btn-sm btn-success btn-review-sub" data-id="<?= $s->id ?>" data-decision="approve" title="تأیید">
                                    <i class="material-icons" style="font-size:14px;">check</i>
                                </button>
                                <button class="btn btn-sm btn-danger btn-review-sub" data-id="<?= $s->id ?>" data-decision="reject" title="رد">
                                    <i class="material-icons" style="font-size:14px;">close</i>
                                </button>
                            </div>
                            <?php elseif ($s->status === 'approved'): ?>
                            <span class="text-success" style="font-size:11px;">✅ تأیید شده</span>
                            <?php elseif ($s->status === 'rejected'): ?>
                            <span class="text-danger" style="font-size:11px;">❌ رد شده</span>
                            <button class="btn btn-sm btn-outline-warning btn-dispute" data-id="<?= $s->id ?>" title="اعتراض کاربر">
                                <i class="material-icons" style="font-size:14px;">gavel</i>
                            </button>
                            <?php else: ?>
                            <span class="text-muted">—</span>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php endif; ?>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // تأیید/رد
    document.querySelectorAll('.btn-review-sub').forEach(function(btn) {
        btn.addEventListener('click', function() {
            var subId = this.dataset.id;
            var decision = this.dataset.decision;

            if (decision === 'reject') {
                Swal.fire({
                    title: 'رد مدرک',
                    input: 'text',
                    inputLabel: 'دلیل رد:',
                    inputPlaceholder: 'مثال: مدرک ناقص است',
                    showCancelButton: true,
                    confirmButtonColor: '#f44336',
                    confirmButtonText: 'رد کن',
                    cancelButtonText: 'انصراف',
                    inputValidator: function(v) { if (!v) return 'دلیل را وارد کنید'; }
                }).then(function(result) {
                    if (result.isConfirmed) sendReview(subId, 'reject', result.value);
                });
            } else {
                sendReview(subId, 'approve', null);
            }
        });
    });

    function sendReview(subId, decision, reason) {
        fetch('<?= url('/user/custom-tasks/review') ?>', {
            method: 'POST',
            headers: { 'X-Requested-With': 'XMLHttpRequest', 'Content-Type': 'application/json', 'X-CSRF-TOKEN': '<?= csrf_token() ?>' },
            body: JSON.stringify({ csrf_token: '<?= csrf_token() ?>', submission_id: subId, decision: decision, reason: reason })
        })
        .then(function(r) { return r.json(); })
        .then(function(data) {
            var notyf = new Notyf({duration: 3000, position: {x:'left',y:'top'}});
            if (data.success) { notyf.success(data.message); setTimeout(function() { location.reload(); }, 1500); }
            else { notyf.error(data.message); }
        });
    }

    // ثبت اختلاف
    document.querySelectorAll('.btn-dispute').forEach(function(btn) {
        btn.addEventListener('click', function() {
            var subId = this.dataset.id;
            Swal.fire({
                title: 'ثبت اختلاف',
                input: 'textarea',
                inputLabel: 'دلیل اعتراض شما:',
                showCancelButton: true,
                confirmButtonText: 'ارسال به مدیریت',
                cancelButtonText: 'انصراف',
                inputValidator: function(v) { if (!v) return 'دلیل را وارد کنید'; }
            }).then(function(result) {
                if (result.isConfirmed) {
                    fetch('<?= url('/user/custom-tasks/dispute') ?>', {
                        method: 'POST',
                        headers: { 'X-Requested-With': 'XMLHttpRequest', 'Content-Type': 'application/json', 'X-CSRF-TOKEN': '<?= csrf_token() ?>' },
                        body: JSON.stringify({ csrf_token: '<?= csrf_token() ?>', submission_id: subId, reason: result.value })
                    })
                    .then(function(r) { return r.json(); })
                    .then(function(data) {
                        var notyf = new Notyf({duration: 3000, position: {x:'left',y:'top'}});
                        if (data.success) { notyf.success(data.message); } else { notyf.error(data.message); }
                    });
                }
            });
        });
    });
});
</script>

<?php
$content = ob_get_clean();
include __DIR__ . '/../../layouts/' . $layout . '.php';
?>