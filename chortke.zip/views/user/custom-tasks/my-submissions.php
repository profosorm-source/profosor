<?php
$title = 'تاریخچه انجام وظایف';
$layout = 'user';
ob_start();
$subStatusLabels = custom_submission_status_labels_map();
$subStatusClasses = custom_submission_status_classes_map();
?>

<div class="content-header">
    <div class="d-flex justify-content-between align-items-center">
        <div>
            <h4 class="page-title mb-1"><i class="material-icons text-primary">history</i> تاریخچه انجام وظایف</h4>
        </div>
        <a href="<?= url('/user/custom-tasks/available') ?>" class="btn btn-outline-primary btn-sm">
            <i class="material-icons" style="font-size:16px;vertical-align:middle;">search</i> وظایف موجود
        </a>
    </div>
</div>

<!-- فیلتر -->
<div class="card mt-3">
    <div class="card-body py-2">
        <form method="GET" class="d-flex gap-2 align-items-center">
            <select name="status" class="form-select form-select-sm" style="width:auto;" onchange="this.form.submit()">
                <option value="">همه وضعیت‌ها</option>
                <?php foreach ($subStatusLabels as $k => $v): ?>
                <option value="<?= e($k) ?>" <?= ($statusFilter ?? '') === $k ? 'selected' : '' ?>><?= e($v) ?></option>
                <?php endforeach; ?>
            </select>
        </form>
    </div>
</div>

<div class="card mt-3 mb-4">
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table table-hover mb-0" style="font-size:12px;">
                <thead>
                    <tr><th>#</th><th>عنوان وظیفه</th><th>پاداش</th><th>وضعیت</th><th>شروع</th><th>مهلت</th><th>ارسال مدرک</th><th>عملیات</th></tr>
                </thead>
                <tbody>
                    <?php if (empty($submissions)): ?>
                    <tr><td colspan="8" class="text-center text-muted py-4">
                        <i class="material-icons" style="font-size:40px;opacity:0.2;">inbox</i>
                        <p class="mt-2 mb-0">هنوز وظیفه‌ای انجام نداده‌اید.</p>
                    </td></tr>
                    <?php else: ?>
                    <?php foreach ($submissions as $idx => $s): ?>
                    <tr>
                        <td class="text-muted"><?= $idx + 1 ?></td>
                        <td style="max-width:200px;">
                            <a href="<?= url('/user/custom-tasks/' . $s->task_id) ?>"><?= e(\mb_substr($s->task_title ?? '—', 0, 35)) ?></a>
                        </td>
                        <td>
                            <strong class="text-success">
                                <?= ($s->currency ?? 'irt') === 'usdt' ? number_format($s->reward_amount ?? 0, 2) . ' USDT' : number_format($s->reward_amount ?? 0) . ' ت' ?>
                            </strong>
                            <?php if ($s->reward_paid): ?><i class="material-icons text-success" style="font-size:12px;" title="پرداخت شده">check_circle</i><?php endif; ?>
                        </td>
                        <td><span class="badge <?= $subStatusClasses[$s->status] ?? '' ?>"><?= $subStatusLabels[$s->status] ?? $s->status ?></span></td>
                        <td style="font-size:10px;"><?= to_jalali($s->started_at ?? '') ?></td>
                        <td style="font-size:10px;">
                            <?= to_jalali($s->deadline_at ?? '') ?>
                            <?php if ($s->status === 'in_progress' && \strtotime($s->deadline_at) > \time()): ?>
                            <br><small class="text-danger">⏱ باقی: <?= \round((\strtotime($s->deadline_at) - \time()) / 3600, 1) ?> ساعت</small>
                            <?php endif; ?>
                        </td>
                        <td style="font-size:10px;"><?= $s->submitted_at ? to_jalali($s->submitted_at) : '—' ?></td>
                        <td>
                            <?php if ($s->status === 'in_progress'): ?>
                            <button class="btn btn-sm btn-primary btn-submit-proof" data-id="<?= $s->id ?>" data-title="<?= e($s->task_title ?? '') ?>">
                                <i class="material-icons" style="font-size:14px;">upload</i> ارسال مدرک
                            </button>
                            <?php elseif ($s->status === 'rejected' && $s->rejection_reason): ?>
                            <button class="btn btn-sm btn-outline-danger" onclick="Swal.fire({title:'دلیل رد',text:'<?= e($s->rejection_reason) ?>',icon:'error'})">
                                <i class="material-icons" style="font-size:14px;">info</i>
                            </button>
                            <button class="btn btn-sm btn-outline-warning btn-dispute-worker" data-id="<?= $s->id ?>">
                                <i class="material-icons" style="font-size:14px;">gavel</i> اعتراض
                            </button>
                            <?php else: ?>
                            <span class="text-muted">—</span>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- مودال ارسال مدرک -->
<div class="modal fade" id="proofModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h6 class="modal-title"><i class="material-icons text-primary" style="vertical-align:middle;">upload</i> ارسال مدرک</h6>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form id="proofForm" enctype="multipart/form-data">
                <div class="modal-body">
                    <input type="hidden" id="proof-sub-id" value="">
                    <div class="mb-3">
                        <label class="form-label">فایل مدرک (اسکرین‌شات / عکس)</label>
                        <input type="file" name="proof_file" id="proof-file" class="form-control" accept="image/*,.pdf">
                        <small class="text-muted">حداکثر 5 مگابایت</small>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">توضیحات متنی (اختیاری)</label>
                        <textarea name="proof_text" id="proof-text" class="form-control" rows="3" placeholder="توضیحات تکمیلی..."></textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-outline-secondary btn-sm" data-bs-dismiss="modal">انصراف</button>
                    <button type="submit" class="btn btn-primary btn-sm" id="btn-send-proof">
                        <i class="material-icons" style="font-size:16px;vertical-align:middle;">send</i> ارسال
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    var proofModal = new bootstrap.Modal(document.getElementById('proofModal'));

    // باز کردن مودال مدرک
    document.querySelectorAll('.btn-submit-proof').forEach(function(btn) {
        btn.addEventListener('click', function() {
            document.getElementById('proof-sub-id').value = this.dataset.id;
            document.getElementById('proof-file').value = '';
            document.getElementById('proof-text').value = '';
            proofModal.show();
        });
    });

    // ارسال مدرک
    document.getElementById('proofForm').addEventListener('submit', function(e) {
        e.preventDefault();
        var subId = document.getElementById('proof-sub-id').value;
        var formData = new FormData();
        formData.append('csrf_token', '<?= csrf_token() ?>');

        var fileInput = document.getElementById('proof-file');
        if (fileInput.files.length > 0) formData.append('proof_file', fileInput.files[0]);

        var proofText = document.getElementById('proof-text').value;
        if (proofText) formData.append('proof_text', proofText);

        if (!fileInput.files.length && !proofText) {
            var notyf = new Notyf({duration: 3000, position: {x:'left',y:'top'}});
            notyf.error('لطفاً حداقل یک مدرک ارسال کنید.');
            return;
        }

        var btn = document.getElementById('btn-send-proof');
        btn.disabled = true;
        btn.innerHTML = '<span class="spinner-border spinner-border-sm"></span>';

        fetch('<?= url('/user/custom-tasks/') ?>' + subId + '/submit-proof', {
            method: 'POST',
            headers: { 'X-Requested-With': 'XMLHttpRequest', 'X-CSRF-TOKEN': '<?= csrf_token() ?>' },
            body: formData
        })
        .then(function(r) { return r.json(); })
        .then(function(data) {
            var notyf = new Notyf({duration: 3000, position: {x:'left',y:'top'}});
            if (data.success) {
                notyf.success(data.message);
                proofModal.hide();
                setTimeout(function() { location.reload(); }, 1500);
            } else {
                notyf.error(data.message);
                btn.disabled = false;
                btn.innerHTML = '<i class="material-icons" style="font-size:16px;vertical-align:middle;">send</i> ارسال';
            }
        })
        .catch(function() {
            var notyf = new Notyf({duration: 3000, position: {x:'left',y:'top'}});
            notyf.error('خطا در ارتباط');
            btn.disabled = false;
            btn.innerHTML = '<i class="material-icons" style="font-size:16px;vertical-align:middle;">send</i> ارسال';
        });
    });

    // اعتراض کارمند
    document.querySelectorAll('.btn-dispute-worker').forEach(function(btn) {
        btn.addEventListener('click', function() {
            var subId = this.dataset.id;
            Swal.fire({
                title: 'ثبت اعتراض',
                input: 'textarea',
                inputLabel: 'دلیل اعتراض شما:',
                inputPlaceholder: 'توضیح دهید چرا فکر می‌کنید کارتان درست بوده...',
                showCancelButton: true,
                confirmButtonText: 'ارسال به مدیریت',
                cancelButtonText: 'انصراف',
                inputValidator: function(v) { if (!v) return 'لطفاً دلیل را بنویسید'; }
            }).then(function(result) {
                if (result.isConfirmed) {
                    fetch('<?= url('/user/custom-tasks/dispute') ?>', {
                        method: 'POST',
                        headers: { 'X-Requested-With': 'XMLHttpRequest', 'Content-Type': 'application/json', 'X-CSRF-TOKEN': '<?= csrf_token() ?>' },
                        body: JSON.stringify({ csrf_token: '<?= csrf_token() ?>', submission_id: subId, reason: result.value })
                    })
                    .then(function(r) { return r.json(); })
                    .then(function(data) {
                        var notyf = new Notyf({duration: 3000, position: {x:'left',y:'top'}});
                        if (data.success) notyf.success(data.message);
                        else notyf.error(data.message);
                    });
                }
            });
        });
    });
});
</script>

<?php
$content = ob_get_clean();
include __DIR__ . '/../../layouts/' . $layout . '.php';
?>