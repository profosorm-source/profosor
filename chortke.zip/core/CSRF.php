<?php
namespace Core;

/**
 * CSRF Protection
 * محافظت در برابر حملات CSRF
 */
class CSRF
{
    /**
     * تولید یا دریافت توکن CSRF
     */
    public static function generateToken(): string
    {
        $session = app()->session ?? null;
        if (!$session) {
            throw new \Exception('Session not available for CSRF');
        }

        if (!$session->has('_csrf_token')) {
            $token = bin2hex(random_bytes(32));
            $session->set('_csrf_token', $token);
        }

        return $session->get('_csrf_token');
    }

    /**
     * دریافت توکن
     */
    public static function getToken(): ?string
    {
        $session = app()->session ?? null;
        return $session ? $session->get('_csrf_token') : null;
    }

    /**
     * تایید توکن
     */
    public static function verify(?string $token): bool
    {
        $sessionToken = self::getToken();
        if (!$sessionToken || !$token) {
            return false;
        }

        return hash_equals($sessionToken, $token);
    }

    /**
     * بررسی درخواست برای CSRF
     */
    public static function check(): bool
    {
        $request = app()->request ?? null;
        if (!$request) return false;

        // فقط برای متدهای حساس
        if (!in_array($request->method(), ['POST', 'PUT', 'DELETE', 'PATCH'], true)) {
            return true;
        }

        $tokenName = config('csrf.token_name') ?? '_token';
        $token = $request->input($tokenName) ?? $request->header('X-CSRF-TOKEN');

        return self::verify($token);
    }

    /**
     * Middleware برای بررسی خودکار CSRF
     */
    public static function validate(): void
    {
        if (!self::check()) {

            // لاگ کردن
            if (function_exists('logger')) {
                $request = app()->request ?? null;
                logger('security', 'CSRF token validation failed', [
                    'ip' => function_exists('get_client_ip') ? get_client_ip() : 'unknown',
                    'uri' => $request ? $request->uri() : 'unknown',
                    'method' => $request ? $request->method() : 'unknown'
                ]);
            }

            // بررسی AJAX
            if (function_exists('is_ajax') && is_ajax()) {
                if (function_exists('error_response')) {
                    error_response('Invalid CSRF token', [], 403);
                } else {
                    http_response_code(403);
                    echo json_encode(['error' => 'Invalid CSRF token']);
                }
            } else {
                if (function_exists('abort')) {
                    abort(403, 'CSRF token validation failed');
                } else {
                    http_response_code(403);
                    echo 'CSRF token validation failed';
                }
            }

            exit;
        }
    }

    /**
     * بازسازی توکن
     */
    public static function regenerate(): string
    {
        $session = app()->session ?? null;
        if ($session) {
            $session->remove('_csrf_token');
        }
        return self::generateToken();
    }
}
