<?php

namespace Core;

class Application
{
    private static ?Application $instance = null;
    
    public Database $db;
    public Router $router;
    public Request $request;
    public Response $response;
    public Session $session;
    public ExceptionHandler $exceptionHandler;  // ✅ اضافه شد
    public array $config;

    private function __construct()
    {
        // بارگذاری Config
        $this->config = require __DIR__ . '/../config/config.php';
        
		 // ✅ Session (استفاده از getInstance)
        $this->session = Session::getInstance();
		
        // ✅ ثبت Exception Handler (باید اول باشه)
        $this->exceptionHandler = new ExceptionHandler();
        $this->exceptionHandler->register();
        
        // ایجاد اشیاء اصلی
        $this->request = new Request();
        $this->response = new Response();
        $this->router = new Router($this->request, $this->response);
        
        
        // اتصال به دیتابیس
        try {
            $this->db = Database::getInstance();
        } catch (\Exception $e) {
            if (env('APP_DEBUG')) {
                die("خطای اتصال به دیتابیس: " . $e->getMessage());
            } else {
                die("خطای سیستمی. لطفاً با پشتیبانی تماس بگیرید.");
            }
        }
                    
        // بررسی Maintenance Mode
        if (env('MAINTENANCE_MODE') === 'true' || env('MAINTENANCE_MODE') === true) {
            if (!$this->session->get('is_admin')) {
                http_response_code(503);
                require __DIR__ . '/../views/maintenance.php';
                exit;
            }
        }
    }
/**
 * دریافت کاربر فعلی
 */
public function user(): ?array
{
    $session = Session::getInstance();
    $userId = $session->get('user_id');
    
    if (!$userId) {
        return null;
    }
    
    $db = Database::getInstance();
    return $db->query(
        "SELECT id, first_name, last_name, email, mobile, role, status FROM users WHERE id = ?",
        [$userId]
    )->fetch();
}
    public static function getInstance(): self
    {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __clone() {}
    
    public function __wakeup()
    {
        throw new \Exception("Cannot unserialize singleton");
    }

    public function run(): void
    {
        $this->router->dispatch();
    }
}