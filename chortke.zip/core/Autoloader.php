<?php
namespace Core;

/**
 * PSR-4 Autoloader
 * 
 * بارگذاری خودکار کلاس‌ها بر اساس Namespace
 */
class Autoloader
{
    private static $namespaces = [];

    /**
     * ثبت Autoloader
     */
    public static function register()
    {
        spl_autoload_register([self::class, 'load']);
        
        // ثبت Namespaceها
        self::addNamespace('Core', __DIR__);
        self::addNamespace('App', dirname(__DIR__) . '/app');
    }

    /**
     * افزودن Namespace جدید
     */
    public static function addNamespace($prefix, $baseDir)
    {
        $prefix = trim($prefix, '\\') . '\\';
        $baseDir = rtrim($baseDir, DIRECTORY_SEPARATOR) . '/';
        
        if (!isset(self::$namespaces[$prefix])) {
            self::$namespaces[$prefix] = [];
        }
        
        array_push(self::$namespaces[$prefix], $baseDir);
    }

    /**
     * بارگذاری کلاس
     */
    private static function load($class)
    {
        $prefix = $class;
        
        while (false !== $pos = strrpos($prefix, '\\')) {
            $prefix = substr($class, 0, $pos + 1);
            $relativeClass = substr($class, $pos + 1);
            
            $mappedFile = self::loadMappedFile($prefix, $relativeClass);
            
            if ($mappedFile) {
                return $mappedFile;
            }
            
            $prefix = rtrim($prefix, '\\');
        }
        
        return false;
    }

    /**
     * بارگذاری فایل نگاشت شده
     */
    private static function loadMappedFile($prefix, $relativeClass)
    {
        if (!isset(self::$namespaces[$prefix])) {
            return false;
        }
        
        foreach (self::$namespaces[$prefix] as $baseDir) {
            $file = $baseDir . str_replace('\\', '/', $relativeClass) . '.php';
            
            if (self::requireFile($file)) {
                return $file;
            }
        }
        
        return false;
    }

    /**
     * بارگذاری فایل
     */
    private static function requireFile($file)
    {
        if (file_exists($file)) {
            require $file;
            return true;
        }
        
        return false;
    }
}