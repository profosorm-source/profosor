<?php

namespace Core;

class Router
{
	protected array $groupAttributes = [];
    private Request $request;
    private Response $response;
    private array $routes = [
        'GET' => [],
        'POST' => [],
        'PUT' => [],
        'DELETE' => [],
        'PATCH' => []
    ];

    public function __construct(Request $request, Response $response)
    {
		
        $this->request = $request;
        $this->response = $response;
    }

    /**
     * ثبت Route با متد GET
     */
    public function get(string $uri, $action): Route
    {
        return $this->addRoute('GET', $uri, $action);
    }

    /**
     * ثبت Route با متد POST
     */
    public function post(string $uri, $action): Route
    {
        return $this->addRoute('POST', $uri, $action);
    }

    /**
     * ثبت Route با متد PUT
     */
    public function put(string $uri, $action): Route
    {
        return $this->addRoute('PUT', $uri, $action);
    }

    /**
     * ثبت Route با متد DELETE
     */
    public function delete(string $uri, $action): Route
    {
        return $this->addRoute('DELETE', $uri, $action);
    }

    /**
     * ثبت Route با متد PATCH
     */
    public function patch(string $uri, $action): Route
    {
        return $this->addRoute('PATCH', $uri, $action);
    }

    /**
     * افزودن Route به لیست
     */
    private function addRoute(string $method, string $uri, $action): Route
    {
        $route = new Route($uri, $action);
        $this->routes[$method][] = [
            'uri' => $uri,
            'action' => $action,
            'middleware' => [],
            'route' => $route
        ];

        return $route;
    }

    /**
     * اجرای Router و یافتن Route مناسب
     */
   public function dispatch(): void
{
    $method = $this->request->method();
    $rawUri = $_SERVER['REQUEST_URI'] ?? '/';

    // حذف query string
    $uri = strtok($rawUri, '?');

    // پیدا کردن Base Path
    $scriptName = str_replace('\\', '/', $_SERVER['SCRIPT_NAME']);
    $basePath   = str_replace('/public', '', dirname($scriptName));

    // حذف basePath از URI
    if ($basePath !== '/' && $basePath !== '' && str_starts_with($uri, $basePath)) {
        $uri = substr($uri, strlen($basePath));
    }

    // نرمال‌سازی URI
    $uri = '/' . trim($uri, '/');
    if ($uri === '//') {
        $uri = '/';
    }

    // جستجوی Route
    foreach ($this->routes[$method] ?? [] as $routeData) {

        $matched = $this->matchRoute($routeData['uri'], $uri);

        if ($matched === false) {
            continue;
        }

        $params = $matched;

        // ✅ تزریق پارامترها به Request
        $this->request->setParams($params);
		$GLOBALS['_route_params'] = $params;

        // Middleware
        $middlewares = $routeData['route']->getMiddleware();
        foreach ($middlewares as $middleware) {
            $middlewareInstance = new $middleware();
            $middlewareInstance->handle($this->request, $this->response);
        }

        // اجرای Action
        $this->executeAction($routeData['action'], $params);
        return;
    }

    // 404
    $this->handleNotFound($uri, $method);
}



    /**
     * تطبیق URI با Pattern
     */
    private function matchRoute(string $routeUri, string $currentUri): array|false
{
    $routeUri   = trim($routeUri, '/');
    $currentUri = trim($currentUri, '/');

    $paramNames = [];

    $pattern = preg_replace_callback('/\{([a-zA-Z0-9_]+)\}/', function ($m) use (&$paramNames) {
        $paramNames[] = $m[1];
        return '([^\/]+)';
    }, $routeUri);

    $pattern = '#^' . $pattern . '$#u';

    if (!preg_match($pattern, $currentUri, $matches)) {
        return false;
    }

    $params = [];
    for ($i = 0; $i < \count($paramNames); $i++) {
        $params[$paramNames[$i]] = \urldecode($matches[$i + 1] ?? '');
    }

    return $params; // ✅ مثل: ['id' => '12']
}

    /**
     * اجرای Action
     */
    protected function executeAction(array $action, array $params = []): void
{
    [$controllerClass, $method] = $action;

    $controller = new $controllerClass($this->request, $this->response);

    // ✅ PHP8 fix: جلوگیری از Named Arguments
    // $params ممکنه ['id' => '12'] باشه؛ باید به [ '12' ] تبدیل بشه
    $args = \array_values($params);

    // ✅ جلوگیری از Too many arguments برای متدهایی که پارامتر ندارن
    try {
        $ref = new \ReflectionMethod($controller, $method);
        $expectedCount = $ref->getNumberOfParameters();

        if ($expectedCount <= 0) {
            $args = [];
        } else {
            $args = \array_slice($args, 0, $expectedCount);
        }

        $result = $ref->invokeArgs($controller, $args);

    } catch (\ReflectionException $e) {
        throw new \RuntimeException("Controller method not found: {$controllerClass}::{$method}");
    }

    if ($result instanceof \Core\Response) {
        $result->send();
        return;
    }

    if (\is_string($result)) {
        echo $result;
        return;
    }
}
/**
     * صفحه 404
     */
    private function notFound(): void
    {
        http_response_code(404);
        
        if (file_exists(__DIR__ . '/../views/errors/404.php')) {
            require __DIR__ . '/../views/errors/404.php';
        } else {
            echo '404 - Page Not Found';
        }
        
        exit;
    }

    /**
     * مدیریت 404
     */
    private function handleNotFound(string $uri, string $method): void
    {
        http_response_code(404);

        if (config('app.debug')) {
            // حالت Debug
            echo "<!DOCTYPE html>";
            echo "<html lang='fa' dir='rtl'>";
            echo "<head>";
            echo "<meta charset='UTF-8'>";
            echo "<title>404 - صفحه یافت نشد</title>";
            echo "<style>";
            echo "body { font-family: Tahoma, Arial; padding: 40px; background: #f5f5f5; }";
            echo ".container { background: white; padding: 30px; border-radius: 8px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }";
            echo "h1 { color: #e74c3c; }";
            echo "code { background: #ecf0f1; padding: 2px 6px; border-radius: 3px; }";
            echo "ul { background: #ecf0f1; padding: 20px; border-radius: 4px; }";
            echo "</style>";
            echo "</head>";
            echo "<body>";
            echo "<div class='container'>";
            echo "<h1>404</h1>";
            echo "<h2>صفحه یافت نشد</h2>";
            echo "<p>مسیر درخواستی شما در سیستم یافت نشد.</p>";
            echo "<hr>";
            echo "<h3>Request Info:</h3>";
            echo "<p><strong>Method:</strong> <code>{$method}</code></p>";
            echo "<p><strong>URI:</strong> <code>{$uri}</code></p>";
            echo "<h3>Available Routes:</h3>";
            echo "<ul>";
            foreach ($this->routes[$method] ?? [] as $route) {
                echo "<li><code>{$route['uri']}</code></li>";
            }
            echo "</ul>";
            echo "</div>";
            echo "</body>";
            echo "</html>";
        } else {
            // حالت Production
            if (file_exists(__DIR__ . '/../views/errors/404.php')) {
                require __DIR__ . '/../views/errors/404.php';
            } else {
                echo "<!DOCTYPE html>";
                echo "<html lang='fa' dir='rtl'>";
                echo "<head><meta charset='UTF-8'><title>404</title></head>";
                echo "<body style='font-family:Tahoma;text-align:center;padding:100px;'>";
                echo "<h1>404</h1>";
                echo "<p>صفحه مورد نظر یافت نشد.</p>";
                echo "</body>";
                echo "</html>";
            }
        }

        exit;
    }
 
    /**
     * گروه‌بندی مسیرها
     */
    public function group(array $attributes, callable $callback): void
    {
        $previousAttributes = $this->groupAttributes;
        
        // ادغام Middleware
        if (isset($attributes['middleware'])) {
            $middleware = is_array($attributes['middleware']) 
                ? $attributes['middleware'] 
                : [$attributes['middleware']];
            
            $this->groupAttributes['middleware'] = array_merge(
                $this->groupAttributes['middleware'] ?? [],
                $middleware
            );
        }
        
        // ادغام Prefix
        if (isset($attributes['prefix'])) {
            $this->groupAttributes['prefix'] = 
                ($this->groupAttributes['prefix'] ?? '') . $attributes['prefix'];
        }
        
        // اجرای callback
        $callback($this);
        
        // بازگرداندن به حالت قبل
        $this->groupAttributes = $previousAttributes;
    }
	
	
    /**
     * تبدیل مسیر به Regex
     */
    private function convertToRegex(string $uri): string
    {
        // تبدیل {id} به (\d+) و {slug} به ([a-z0-9-]+)
        
		$pattern = \preg_replace('/\{(\w+)\}/', '([^/]+)', $uri);
        return '#^' . $pattern . '$#';
    }
    
    /**
     * فراخوانی Action
     */
    private function callAction($action, array $params = []): void
    {
        if (is_callable($action)) {
            // Closure
            call_user_func_array($action, $params);
        } elseif (is_array($action)) {
            // [Controller::class, 'method']
            [$controller, $method] = $action;
            
            if (!class_exists($controller)) {
                throw new \Exception("Controller {$controller} not found");
            }
            
            $controllerInstance = new $controller();
            
            if (!method_exists($controllerInstance, $method)) {
                throw new \Exception("Method {$method} not found in {$controller}");
            }
            
            call_user_func_array([$controllerInstance, $method], $params);
        } else {
            throw new \Exception("Invalid route action");
        }
    }
    /**
     * اجرای Middleware ها
     */
    private function runMiddleware(array $middlewares): void
    {
        foreach ($middlewares as $middleware) {
            $middlewareInstance = new $middleware();
            
            $response = $middlewareInstance->handle($this->request, function($request) {
                return $request;
            });
            
            // اگر Middleware Response برگرداند و متفاوت از Request باشد
            if ($response !== $this->request && $response instanceof Response) {
                $response->send();
                exit;
            }
        }
    }
    /**
     * دریافت تمام Route‌ها (برای Debug)
     */
    public function getRoutes(): array
    {
        return $this->routes;
    }
}