<?php

namespace Core;

abstract class Model
{
    protected static string $table = '';
    protected \Core\Database $db;

    public function __construct()
    {
        $this->db = \Core\Database::getInstance();
    }

    /**
     * دریافت نام جدول
     */
    public static function getTable(): string
    {
        return static::$table;
    }

    /**
     * دریافت Database Instance (برای backward compatibility)
     */
    protected static function db(): Database
    {
        return app()->db;
    }

    /**
     * ایجاد رکورد جدید
     */
    public function create(array $data)
    {
        return $this->db->table(static::$table)->insert($data);
    }

    /**
     * پیدا کردن با ID
     */
    public function find(int $id): ?object
    {
        $result = $this->db->table(static::$table)
            ->where('id', '=', $id)
            ->first();

        return $result ?: null;
    }

    /**
     * دریافت همه رکوردها
     */
    public function all(int $limit = 100, int $offset = 0): array
    {
        return $this->db->table(static::$table)
            ->limit($limit)
            ->offset($offset)
            ->get();
    }

    /**
     * آپدیت رکورد
     */
    public function update(int $id, array $data): bool
    {
        $data['updated_at'] = date('Y-m-d H:i:s');

        return $this->db->table(static::$table)
            ->where('id', '=', $id)
            ->update($data);
    }

    /**
     * حذف رکورد (Soft Delete)
     */
    public function delete(int $id): bool
    {
        return $this->db->table(static::$table)
            ->where('id', '=', $id)
            ->update([
                'deleted_at' => date('Y-m-d H:i:s')
            ]);
    }

    /**
     * حذف واقعی
     */
    public function forceDelete(int $id): bool
    {
        return $this->db->table(static::$table)
            ->where('id', '=', $id)
            ->delete();
    }

    /**
     * شمارش رکوردها
     */
    public function count(): int
    {
        $result = $this->db->table(static::$table)->count();
        return (int) $result;
    }

    /**
     * بررسی وجود رکورد
     */
    public function exists(int $id): bool
    {
        return $this->find($id) !== null;
    }
}
