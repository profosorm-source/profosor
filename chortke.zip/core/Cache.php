<?php
namespace Core;

/**
 * Cache System (File-based)
 * 
 * سیستم کش ساده بر پایه فایل
 */
class Cache
{
    private static $instance = null;
    private $cacheDir;

    private function __construct()
    {
        $this->cacheDir = __DIR__ . '/../storage/cache/app/';
        
        if (!is_dir($this->cacheDir)) {
            mkdir($this->cacheDir, 0755, true);
        }
    }

    /**
     * دریافت Instance (Singleton)
     */
    public static function getInstance()
    {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        
        return self::$instance;
    }

    /**
     * ذخیره در کش
     */
    public function put($key, $value, $minutes = 60)
    {
        $file = $this->getCacheFile($key);
        
        $data = [
            'expire_at' => time() + ($minutes * 60),
            'value' => $value
        ];
        
        file_put_contents($file, serialize($data));
    }

    /**
     * دریافت از کش
     */
    public function get($key, $default = null)
    {
        $file = $this->getCacheFile($key);
        
        if (!file_exists($file)) {
            return $default;
        }
        
        $data = unserialize(file_get_contents($file));
        
        if ($data['expire_at'] < time()) {
            $this->forget($key);
            return $default;
        }
        
        return $data['value'];
    }

    /**
     * بررسی وجود
     */
    public function has($key)
    {
        $file = $this->getCacheFile($key);
        
        if (!file_exists($file)) {
            return false;
        }
        
        $data = unserialize(file_get_contents($file));
        
        if ($data['expire_at'] < time()) {
            $this->forget($key);
            return false;
        }
        
        return true;
    }

    /**
     * حذف از کش
     */
    public function forget($key)
    {
        $file = $this->getCacheFile($key);
        
        if (file_exists($file)) {
            unlink($file);
        }
    }

    /**
     * پاک کردن همه
     */
    public function flush()
    {
        $files = glob($this->cacheDir . '*.cache');
        
        foreach ($files as $file) {
            unlink($file);
        }
    }

    /**
     * Remember (دریافت یا ذخیره)
     */
    public function remember($key, $minutes, callable $callback)
    {
        if ($this->has($key)) {
            return $this->get($key);
        }
        
        $value = $callback();
        $this->put($key, $value, $minutes);
        
        return $value;
    }

    /**
     * Forever (بدون انقضا)
     */
    public function forever($key, $value)
    {
        $this->put($key, $value, 525600); // 1 سال
    }

    /**
     * Increment
     */
    public function increment($key, $value = 1)
    {
        $current = $this->get($key, 0);
        $new = $current + $value;
        $this->forever($key, $new);
        
        return $new;
    }

    /**
     * Decrement
     */
    public function decrement($key, $value = 1)
    {
        return $this->increment($key, -$value);
    }

    /**
     * دریافت مسیر فایل کش
     */
    private function getCacheFile($key)
    {
        $hash = md5($key);
        return $this->cacheDir . $hash . '.cache';
    }

    /**
     * تمیز کردن کش‌های منقضی شده
     */
    public function cleanup()
    {
        $files = glob($this->cacheDir . '*.cache');
        $cleaned = 0;
        
        foreach ($files as $file) {
            $data = unserialize(file_get_contents($file));
            
            if ($data['expire_at'] < time()) {
                unlink($file);
                $cleaned++;
            }
        }
        
        logger('info', "Cache cleanup: {$cleaned} files removed");
        
        return $cleaned;
    }

    /**
     * جلوگیری از Clone
     */
    private function __clone() {}

    /**
     * جلوگیری از Unserialize
     */
    public function __wakeup()
    {
        throw new \Exception("Cannot unserialize singleton");
    }
}