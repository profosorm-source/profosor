<?php
namespace Core;

/**
 * Rate Limiter
 * 
 * محدود کردن تعداد درخواست‌ها
 */
class RateLimiter
{
    private $db;
    private $cacheDir;

    public function __construct()
    {
        $this->db = Database::getInstance();
        $this->cacheDir = __DIR__ . '/../storage/cache/rate_limit/';
        
        if (!is_dir($this->cacheDir)) {
            mkdir($this->cacheDir, 0755, true);
        }
    }

    /**
     * بررسی Rate Limit
     */
    public function attempt($key, $maxAttempts = null, $decayMinutes = null)
    {
        $maxAttempts = $maxAttempts ?? config('rate_limit.max_attempts');
        $decayMinutes = $decayMinutes ?? config('rate_limit.decay_minutes');
        
        $attempts = $this->getAttempts($key);
        
        if ($attempts >= $maxAttempts) {
            return false;
        }
        
        $this->incrementAttempts($key, $decayMinutes);
        
        return true;
    }

    /**
     * دریافت تعداد تلاش‌ها
     */
    public function getAttempts($key)
    {
        $file = $this->getCacheFile($key);
        
        if (!file_exists($file)) {
            return 0;
        }
        
        $data = json_decode(file_get_contents($file), true);
        
        if (!$data || $data['expire_at'] < time()) {
            $this->clear($key);
            return 0;
        }
        
        return $data['attempts'];
    }

    /**
     * افزایش تلاش‌ها
     */
    public function incrementAttempts($key, $decayMinutes)
    {
        $file = $this->getCacheFile($key);
        $attempts = $this->getAttempts($key) + 1;
        
        $data = [
            'attempts' => $attempts,
            'expire_at' => time() + ($decayMinutes * 60)
        ];
        
        file_put_contents($file, json_encode($data));
    }

    /**
     * پاک کردن
     */
    public function clear($key)
    {
        $file = $this->getCacheFile($key);
        
        if (file_exists($file)) {
            unlink($file);
        }
    }

    /**
     * دریافت زمان باقیمانده
     */
    public function availableIn($key)
    {
        $file = $this->getCacheFile($key);
        
        if (!file_exists($file)) {
            return 0;
        }
        
        $data = json_decode(file_get_contents($file), true);
        
        if (!$data || $data['expire_at'] < time()) {
            return 0;
        }
        
        return $data['expire_at'] - time();
    }

    /**
     * دریافت مسیر فایل Cache
     */
    private function getCacheFile($key)
    {
        $hash = md5($key);
        return $this->cacheDir . $hash . '.json';
    }

    /**
     * بررسی برای Login
     */
    public function checkLoginAttempt($identifier)
    {
        $key = 'login_' . $identifier;
        
        if (!$this->attempt($key, 5, 15)) {
            $seconds = $this->availableIn($key);
            $minutes = ceil($seconds / 60);
            
            logger('security', 'Too many login attempts', [
                'identifier' => $identifier,
                'ip' => get_client_ip()
            ]);
            
            return [
                'allowed' => false,
                'message' => "تعداد تلاش‌های شما بیش از حد مجاز است. لطفاً {$minutes} دقیقه دیگر امتحان کنید.",
                'retry_after' => $seconds
            ];
        }
        
        return ['allowed' => true];
    }

    /**
     * پاک کردن بعد از Login موفق
     */
    public function clearLoginAttempts($identifier)
    {
        $key = 'login_' . $identifier;
        $this->clear($key);
    }

    /**
     * Rate Limit برای API
     */
    public function checkApiLimit($userId, $maxRequests = 60, $perMinutes = 1)
    {
        $key = 'api_' . $userId;
        
        if (!$this->attempt($key, $maxRequests, $perMinutes)) {
            return [
                'allowed' => false,
                'message' => 'Too many requests',
                'retry_after' => $this->availableIn($key)
            ];
        }
        
        return ['allowed' => true];
    }

    /**
     * تمیز کردن فایل‌های منقضی شده
     */
    public function cleanup()
    {
        $files = glob($this->cacheDir . '*.json');
        $now = time();
        $cleaned = 0;
        
        foreach ($files as $file) {
            $data = json_decode(file_get_contents($file), true);
            
            if ($data && $data['expire_at'] < $now) {
                unlink($file);
                $cleaned++;
            }
        }
        
        logger('info', "Rate limit cleanup: {$cleaned} files removed");
        
        return $cleaned;
    }
}