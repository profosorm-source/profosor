<?php
namespace Core;

class Session
{
    private static ?Session $instance = null;
    private bool $started = false;
    private string $fingerprint;

    private function __construct() {}

    public static function getInstance(): self
    {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }

public function saveActiveSession(int $userId): void
{
    $_SESSION['session_id'] = session_id();
    $_SESSION['user_id']    = $userId;
}
    /**
     * شروع امن Session (تنها نقطه session_start)
     */
    public function start(): void
    {
        if ($this->started || session_status() === PHP_SESSION_ACTIVE) {
            return;
        }

        $config = config('session');

        session_name($config['name']);

        session_set_cookie_params([
            'lifetime' => $config['lifetime'],
            'path'     => '/',
            'domain'   => parse_url(env('APP_URL'), PHP_URL_HOST),
            'secure'   => $config['secure'],
            'httponly' => $config['httponly'],
            'samesite' => $config['samesite'],
        ]);

        session_start();
        $this->started = true;

        if (!isset($_SESSION['_initiated'])) {
            session_regenerate_id(true);
            $_SESSION['_initiated'] = true;
        }

        $this->validateFingerprint();
    }

    /* -------------------------
     | Basic Session Methods
     * -------------------------*/

    public function set(string $key, $value): void
    {
        $_SESSION[$key] = $value;
    }

    public function get(string $key, $default = null)
    {
        return $_SESSION[$key] ?? $default;
    }

    public function has(string $key): bool
    {
        return isset($_SESSION[$key]);
    }

    public function remove(string $key): void
    {
        unset($_SESSION[$key]);
    }
public function delete(string $key): void
{
    unset($_SESSION[$key]);
}
    /* -------------------------
     | Flash Messages
     * -------------------------*/

    public function setFlash(string $key, $value): void
    {
        $_SESSION['__flash'][$key] = $value;
    }

    public function getFlash(string $key)
    {
        if (!isset($_SESSION['__flash'][$key])) {
            return null;
        }

        $value = $_SESSION['__flash'][$key];
        unset($_SESSION['__flash'][$key]);

        return $value;
    }

    public function hasFlash(string $key): bool
    {
        return isset($_SESSION['__flash'][$key]);
    }

    public function flashInput(array $data): void
    {
        foreach ($data as $key => $value) {
            $this->setFlash('old_' . $key, $value);
        }
    }


private function invalidateSession(): void
{
    // کاربر عملاً logout می‌شود
    $_SESSION = [];

    if (\session_status() === PHP_SESSION_ACTIVE) {
        \session_regenerate_id(true);
    }
}
    /* -------------------------
     | Security
     * -------------------------*/

    private function validateFingerprint(): void
{
    $current = $this->generateFingerprint();

    if (!isset($_SESSION['_fingerprint'])) {
        $_SESSION['_fingerprint'] = $current;
        return;
    }

    if (!\hash_equals((string)$_SESSION['_fingerprint'], (string)$current)) {
        // لاگ امنیتی
        if (\function_exists('logger')) {
            logger('Session fingerprint mismatch', 'warning', [
                'old' => $_SESSION['_fingerprint'] ?? null,
                'new' => $current,
                'ip'  => $_SERVER['REMOTE_ADDR'] ?? null,
                'ua'  => $_SERVER['HTTP_USER_AGENT'] ?? null,
            ]);
        }

        // ✅ به جای throw کردن: سشن را باطل کن و ادامه بده
        $this->invalidateSession();
        $_SESSION['_fingerprint'] = $this->generateFingerprint();
        return;
    }
}

    private function generateFingerprint(): string
    {
        return hash('sha256', json_encode([
            'ip'    => get_client_ip(),
            'agent' => get_user_agent(),
        ]));
    }

    /* -------------------------
     | Lifecycle
     * -------------------------*/

    public function regenerate(): void
    {
        session_regenerate_id(true);
    }

    public function destroy(): void
    {
        $_SESSION = [];

        if (ini_get('session.use_cookies')) {
            $params = session_get_cookie_params();
            setcookie(
                session_name(),
                '',
                time() - 42000,
                $params['path'],
                $params['domain'],
                $params['secure'],
                $params['httponly']
            );
        }

        session_destroy();
    }

    public function getId(): string
    {
        return session_id();
    }

    private function __clone() {}

    public function __wakeup()
    {
        throw new \Exception('Cannot unserialize singleton');
    }
}
