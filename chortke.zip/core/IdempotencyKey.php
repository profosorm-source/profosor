<?php
namespace Core;

/**
 * Idempotency Key System
 * 
 * جلوگیری از اجرای مجدد درخواست‌های مالی
 */
class IdempotencyKey
{
    private $db;
    private $table = 'idempotency_keys';

    public function __construct()
    {
        $this->db = Database::getInstance();
    }

    /**
     * تولید کلید جدید
     */
    public static function generate()
    {
        return bin2hex(random_bytes(16));
    }

    /**
     * بررسی و ذخیره کلید
     */
    public function check($key, $userId, $action)
    {
        // بررسی وجود کلید
        $existing = $this->db->table($this->table)
            ->where('key', $key)
            ->where('user_id', $userId)
            ->first();
        
        if ($existing) {
            // اگر قبلاً اجرا شده
            if ($existing['status'] === 'completed') {
                return [
                    'is_duplicate' => true,
                    'result' => json_decode($existing['result'], true)
                ];
            }
            
            // اگر در حال اجرا است
            if ($existing['status'] === 'processing') {
                // بررسی Timeout (5 دقیقه)
                $createdAt = strtotime($existing['created_at']);
                if (time() - $createdAt < 300) {
                    return [
                        'is_duplicate' => true,
                        'result' => ['message' => 'درخواست در حال پردازش است']
                    ];
                }
            }
        }
        
        // ثبت کلید جدید
        $this->db->table($this->table)->insert([
            'key' => $key,
            'user_id' => $userId,
            'action' => $action,
            'status' => 'processing',
            'created_at' => now()
        ]);
        
        return ['is_duplicate' => false];
    }

    /**
     * ذخیره نتیجه
     */
    public function complete($key, $result)
    {
        $this->db->table($this->table)
            ->where('key', $key)
            ->update([
                'status' => 'completed',
                'result' => json_encode($result, JSON_UNESCAPED_UNICODE),
                'completed_at' => now()
            ]);
    }

    /**
     * علامت‌گذاری به عنوان شکست خورده
     */
    public function fail($key, $error)
    {
        $this->db->table($this->table)
            ->where('key', $key)
            ->update([
                'status' => 'failed',
                'result' => json_encode(['error' => $error], JSON_UNESCAPED_UNICODE),
                'completed_at' => now()
            ]);
    }

    /**
     * پاک کردن کلیدهای قدیمی (بیش از 7 روز)
     */
    public function cleanup()
    {
        $sevenDaysAgo = date('Y-m-d H:i:s', strtotime('-7 days'));
        
        $deleted = $this->db->table($this->table)
            ->where('created_at', '<', $sevenDaysAgo)
            ->delete();
        
        logger('info', "Idempotency keys cleanup: {$deleted} keys removed");
        
        return $deleted;
    }

    /**
     * استفاده در تراکنش‌ها
     */
    public static function wrap($key, $userId, $action, callable $callback)
    {
        $service = new self();
        
        // بررسی کلید
        $check = $service->check($key, $userId, $action);
        
        if ($check['is_duplicate']) {
            return $check['result'];
        }
        
        try {
            // اجرای عملیات
            $result = $callback();
            
            // ذخیره نتیجه
            $service->complete($key, $result);
            
            return $result;
        } catch (\Exception $e) {
            // ذخیره خطا
            $service->fail($key, $e->getMessage());
            
            throw $e;
        }
    }
}