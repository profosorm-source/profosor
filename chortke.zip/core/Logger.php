<?php

namespace Core;

class Logger
{
    private static ?Logger $instance = null;
    private string $logPath;
    
    private function __construct()
    {
        $this->logPath = dirname(__DIR__) . '/storage/logs/';
        
        if (!is_dir($this->logPath)) {
            mkdir($this->logPath, 0755, true);
        }
    }
    
    public static function getInstance(): Logger
    {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    public function log(string $level, string $message, array $context = []): void
    {
        $date = date('Y-m-d');
        $logFile = $this->logPath . $date . '.log';
        
        $time = date('Y-m-d H:i:s');
        $contextStr = !empty($context) ? json_encode($context, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT) : '';
        
        $logLine = "[{$time}] [{$level}] {$message}";
        if ($contextStr) {
            $logLine .= " | Context: {$contextStr}";
        }
        $logLine .= PHP_EOL;
        
        file_put_contents($logFile, $logLine, FILE_APPEND);
    }
    
    public function debug(string $message, array $context = []): void
    {
        $this->log('DEBUG', $message, $context);
    }
    
    public function info(string $message, array $context = []): void
    {
        $this->log('INFO', $message, $context);
    }
    
    public function warning(string $message, array $context = []): void
    {
        $this->log('WARNING', $message, $context);
    }
    
    public function error(string $message, array $context = []): void
    {
        $this->log('ERROR', $message, $context);
    }
    
    public function critical(string $message, array $context = []): void
    {
        $this->log('CRITICAL', $message, $context);
    }
}