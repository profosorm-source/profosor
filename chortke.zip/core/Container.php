<?php
namespace Core;

/**
 * Dependency Injection Container
 * 
 * مدیریت وابستگی‌ها (ساده و کاربردی)
 */
class Container
{
    private static $instance = null;
    private $bindings = [];
    private $singletons = [];

    /**
     * دریافت Instance (Singleton)
     */
    public static function getInstance()
    {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        
        return self::$instance;
    }

    /**
     * ثبت Binding
     */
    public function bind($abstract, $concrete = null)
    {
        if ($concrete === null) {
            $concrete = $abstract;
        }
        
        $this->bindings[$abstract] = $concrete;
    }

    /**
     * ثبت Singleton
     */
    public function singleton($abstract, $concrete = null)
    {
        $this->bind($abstract, $concrete);
        $this->singletons[$abstract] = null;
    }

    /**
     * دریافت Instance
     */
    public function make($abstract)
    {
        // بررسی Singleton
        if (isset($this->singletons[$abstract])) {
            if ($this->singletons[$abstract] === null) {
                $this->singletons[$abstract] = $this->resolve($abstract);
            }
            return $this->singletons[$abstract];
        }
        
        return $this->resolve($abstract);
    }

    /**
     * Resolve کردن
     */
    private function resolve($abstract)
    {
        if (!isset($this->bindings[$abstract])) {
            // اگر Binding نداشت، سعی کن مستقیم بسازی
            if (class_exists($abstract)) {
                return $this->build($abstract);
            }
            
            throw new \Exception("No binding found for: {$abstract}");
        }
        
        $concrete = $this->bindings[$abstract];
        
        // اگر Closure بود
        if ($concrete instanceof \Closure) {
            return $concrete($this);
        }
        
        // اگر کلاس بود
        if (is_string($concrete)) {
            return $this->build($concrete);
        }
        
        return $concrete;
    }

    /**
     * ساخت Instance
     */
    private function build($class)
    {
        $reflection = new \ReflectionClass($class);
        
        if (!$reflection->isInstantiable()) {
            throw new \Exception("Class {$class} is not instantiable");
        }
        
        $constructor = $reflection->getConstructor();
        
        if ($constructor === null) {
            return new $class;
        }
        
        $parameters = $constructor->getParameters();
        $dependencies = [];
        
        foreach ($parameters as $parameter) {
            $type = $parameter->getType();
            
            if ($type === null) {
                if ($parameter->isDefaultValueAvailable()) {
                    $dependencies[] = $parameter->getDefaultValue();
                } else {
                    throw new \Exception("Cannot resolve parameter: {$parameter->getName()}");
                }
            } else {
                $typeName = $type->getName();
                $dependencies[] = $this->make($typeName);
            }
        }
        
        return $reflection->newInstanceArgs($dependencies);
    }

    /**
     * بررسی وجود Binding
     */
    public function has($abstract)
    {
        return isset($this->bindings[$abstract]);
    }

    /**
     * حذف Binding
     */
    public function forget($abstract)
    {
        unset($this->bindings[$abstract]);
        unset($this->singletons[$abstract]);
    }

    /**
     * جلوگیری از Clone
     */
    private function __clone() {}

    /**
     * جلوگیری از Unserialize
     */
    public function __wakeup()
    {
        throw new \Exception("Cannot unserialize singleton");
    }
}