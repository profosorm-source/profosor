<?php
declare(strict_types=1);

require_once __DIR__ . '/../../core/bootstrap.php';

use App\Services\EmailService;

$service = new EmailService();
$result = $service->processQueue(10);

echo "Email Queue Processed: " . json_encode($result, JSON_UNESCAPED_UNICODE) . PHP_EOL;