# Cron Jobs Documentation

## نصب Cron Jobs

برای فعال‌سازی تمام Cron Jobs، دستورات زیر را به crontab اضافه کنید:

```bash
crontab -e

# بررسی خودکار واریزهای کریپتو (هر 5 دقیقه)
*/5 * * * * /usr/bin/php /path/to/project/storage/cron/crypto_verification.php >> /path/to/project/storage/logs/cron_crypto.log 2>&1

# بررسی واریزهای منقضی‌شده (هر ساعت)
0 * * * * /usr/bin/php /path/to/project/storage/cron/check_expired_deposits.php >> /path/to/project/storage/logs/cron_expired.log 2>&1

# پاکسازی Session های قدیمی (روزانه ساعت 3 صبح)
0 3 * * * /usr/bin/php /path/to/project/storage/cron/cleanup_old_sessions.php >> /path/to/project/storage/logs/cron_cleanup.log 2>&1

# گزارش روزانه کیف پول (روزانه ساعت 23:00)
0 23 * * * /usr/bin/php /path/to/project/storage/cron/daily_wallet_report.php >> /path/to/project/storage/logs/cron_report.log 2>&1

# بررسی تراکنش‌های گیرکرده (هر 30 دقیقه)
*/30 * * * * /usr/bin/php /path/to/project/storage/cron/check_stuck_transactions.php >> /path/to/project/storage/logs/cron_stuck.log 2>&1

# پشتیبان‌گیری از دیتابیس (روزانه ساعت 2 صبح)
0 2 * * * /usr/bin/php /path/to/project/storage/cron/backup_database.php >> /path/to/project/storage/logs/cron_backup.log 2>&1
