<?php
// cron/create_rechecks.php
// اجرا: روزانه یکبار
// crontab: 0 3 * * * php /path/to/cron/create_rechecks.php

require_once __DIR__ . '/../public/index.php';

use App\Services\TaskRecheckService;

echo "[" . date('Y-m-d H:i:s') . "] Creating task rechecks...\n";

$service = new TaskRecheckService();
$result = $service->createRechecks(50);

echo "Created: {$result['created']} rechecks\n";