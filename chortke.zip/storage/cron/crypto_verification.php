<?php

/**
 * Cron Job: بررسی خودکار واریزهای کریپتو
 * 
 * اجرا: هر 5 دقیقه یکبار
 * دستور Cron: */5 * * * * php /path/to/project/storage/cron/crypto_verification.php
 */

require_once __DIR__ . '/../../vendor/autoload.php';
require_once __DIR__ . '/../../bootstrap/app.php';

use App\Models\CryptoDeposit;
use App\Services\CryptoVerificationService;
use App\Services\WalletService;

// شروع
echo "[" . date('Y-m-d H:i:s') . "] Starting crypto verification cron job...\n";

try {
    $depositModel = new CryptoDeposit();
    $verificationService = new CryptoVerificationService();
    $walletService = new WalletService();

    // دریافت واریزهای pending (حداکثر 3 تلاش)
    $deposits = $depositModel->getPendingForVerification(3, 10);

    if (empty($deposits)) {
        echo "No pending deposits found.\n";
        exit(0);
    }

    echo "Found " . count($deposits) . " pending deposit(s).\n";

    $successCount = 0;
    $failCount = 0;
    $manualReviewCount = 0;

    foreach ($deposits as $deposit) {
        echo "\nProcessing deposit ID: {$deposit->id} (User: {$deposit->user_id}, Amount: {$deposit->amount} USDT)\n";

        try {
            // افزایش تعداد تلاش
            $depositModel->incrementAttempts($deposit->id);

            // بررسی بر اساس شبکه
            if ($deposit->network === 'trc20') {
                $result = $verificationService->verifyTRC20(
                    $deposit->tx_hash,
                    $deposit->wallet_address,
                    (float)$deposit->amount
                );
            } else {
                $result = $verificationService->verifyBNB20(
                    $deposit->tx_hash,
                    $deposit->wallet_address,
                    (float)$deposit->amount
                );
            }

            if ($result['verified']) {
                // تأیید خودکار
                echo "✓ Verification successful!\n";

                // افزایش موجودی کاربر
                $transaction = $walletService->deposit(
                    $deposit->user_id,
                    (float)$deposit->amount,
                    'usdt',
                    [
                        'gateway' => 'usdt_' . $deposit->network,
                        'gateway_transaction_id' => $deposit->tx_hash,
                        'description' => 'واریز USDT - تأیید خودکار',
                    ]
                );

                if ($transaction) {
                    // بروزرسانی وضعیت
                    $depositModel->updateStatus(
                        $deposit->id,
                        'auto_verified',
                        $result['data'],
                        null,
                        null,
                        $transaction->transaction_id
                    );

                    // ثبت لاگ
                    log_activity(
                        $deposit->user_id,
                        'crypto_deposit_auto_verified',
                        "تأیید خودکار واریز {$deposit->amount} USDT ({$deposit->network})",
                        ['deposit_id' => $deposit->id, 'tx_hash' => $deposit->tx_hash]
                    );

                    $successCount++;
                    echo "✓ Deposit credited to user wallet.\n";
                } else {
                    throw new \RuntimeException('Failed to credit wallet');
                }

            } else {
                // عدم تأیید
                echo "✗ Verification failed: {$result['message']}\n";

                // بررسی تعداد تلاش
                $currentAttempts = $deposit->verification_attempts + 1;

                if ($currentAttempts >= 3) {
                    // ارجاع به بررسی دستی
                    $depositModel->updateStatus(
                        $deposit->id,
                        'manual_review',
                        $result['data']
                    );

                    echo "→ Moved to manual review (max attempts reached).\n";
                    $manualReviewCount++;

                    // اطلاع‌رسانی به مدیر (اختیاری)
                    // sendAdminNotification(...)
                } else {
                    echo "→ Will retry later (attempt {$currentAttempts}/3).\n";
                    $failCount++;
                }
            }

        } catch (\Exception $e) {
            echo "✗ Error: " . $e->getMessage() . "\n";
            logger()->error('Crypto verification cron failed', [
                'deposit_id' => $deposit->id,
                'error' => $e->getMessage()
            ]);

            $failCount++;
        }

        // تأخیر کوتاه برای جلوگیری از Rate Limit
        sleep(2);
    }

    echo "\n=== Summary ===\n";
    echo "Success: {$successCount}\n";
    echo "Failed: {$failCount}\n";
    echo "Manual Review: {$manualReviewCount}\n";
    echo "Total Processed: " . count($deposits) . "\n";

} catch (\Exception $e) {
    echo "✗ Critical Error: " . $e->getMessage() . "\n";
    logger()->error('Crypto verification cron critical error', [
        'error' => $e->getMessage(),
        'trace' => $e->getTraceAsString()
    ]);
    exit(1);
}

echo "\n[" . date('Y-m-d H:i:s') . "] Cron job completed.\n";
exit(0);