<?php

/**
 * Cron Job: پاکسازی Session های قدیمی
 * 
 * اجرا: روزانه در ساعت 3 صبح
 * دستور Cron: 0 3 * * * php /path/to/project/storage/cron/cleanup_old_sessions.php
 */

require_once __DIR__ . '/../../vendor/autoload.php';
require_once __DIR__ . '/../../bootstrap/app.php';

echo "[" . date('Y-m-d H:i:s') . "] Cleaning up old sessions...\n";

try {
    $db = \Core\Database::getInstance();
    
    // حذف Session های بیش از 7 روز
    $sql = "DELETE FROM user_sessions WHERE last_activity < DATE_SUB(NOW(), INTERVAL 7 DAY)";
    $stmt = $db->query($sql);
    $deletedCount = $stmt->rowCount();

    echo "✓ Deleted {$deletedCount} old session(s).\n";

    // پاکسازی فایل‌های Session از دیسک (اختیاری)
    $sessionPath = __DIR__ . '/../../storage/sessions/';
    if (is_dir($sessionPath)) {
        $files = glob($sessionPath . 'sess_*');
        $fileCount = 0;
        
        foreach ($files as $file) {
            // حذف فایل‌های بیش از 7 روز
            if (is_file($file) && (time() - filemtime($file)) > (7 * 24 * 60 * 60)) {
                unlink($file);
                $fileCount++;
            }
        }
        
        echo "✓ Deleted {$fileCount} session file(s).\n";
    }

} catch (\Exception $e) {
    echo "✗ Error: " . $e->getMessage() . "\n";
    logger()->error('Cleanup sessions cron failed', [
        'error' => $e->getMessage()
    ]);
    exit(1);
}

echo "[" . date('Y-m-d H:i:s') . "] Cleanup completed.\n";
exit(0);