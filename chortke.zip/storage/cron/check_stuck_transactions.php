<?php

/**
 * Cron Job: بررسی تراکنش‌های گیرکرده
 * 
 * اجرا: هر 30 دقیقه یکبار
 * دستور Cron: */30 * * * * php /path/to/project/storage/cron/check_stuck_transactions.php
 */

require_once __DIR__ . '/../../vendor/autoload.php';
require_once __DIR__ . '/../../bootstrap/app.php';

echo "[" . date('Y-m-d H:i:s') . "] Checking for stuck transactions...\n";

try {
    $db = \Core\Database::getInstance();
    
    // تراکنش‌های processing که بیش از 1 ساعت گذشته
    $sql = "
        SELECT * FROM transactions
        WHERE status = 'processing'
        AND created_at < DATE_SUB(NOW(), INTERVAL 1 HOUR)
    ";
    
    $stmt = $db->query($sql);
    $stuckTransactions = $stmt->fetchAll(\PDO::FETCH_OBJ);

    if (empty($stuckTransactions)) {
        echo "No stuck transactions found.\n";
        exit(0);
    }

    echo "Found " . count($stuckTransactions) . " stuck transaction(s).\n";

    $transactionModel = new \App\Models\Transaction();
    $count = 0;

    foreach ($stuckTransactions as $tx) {
        // تغییر وضعیت به failed
        $updated = $transactionModel->updateStatus(
            $tx->id,
            'failed',
            ['reason' => 'Transaction timeout - auto-failed by system']
        );

        if ($updated) {
            $count++;
            echo "✓ Transaction {$tx->transaction_id} marked as failed.\n";

            // اگر withdraw بود، موجودی را آزاد کن
            if ($tx->type === 'withdraw') {
                $walletService = new \App\Services\WalletService();
                $walletService->cancelWithdrawal(
                    $tx->user_id,
                    (float)$tx->amount,
                    $tx->currency,
                    $tx->transaction_id
                );
                echo "  → Wallet balance unlocked.\n";
            }

            // اطلاع‌رسانی به کاربر (اختیاری)
            // sendUserNotification($tx->user_id, ...);
        }
    }

    echo "\nTotal failed: {$count}\n";

    // اطلاع به مدیر
    if ($count > 0) {
        logger()->warning('Stuck transactions detected and auto-failed', [
            'count' => $count,
            'transaction_ids' => array_column($stuckTransactions, 'transaction_id')
        ]);
    }

} catch (\Exception $e) {
    echo "✗ Error: " . $e->getMessage() . "\n";
    logger()->error('Check stuck transactions cron failed', [
        'error' => $e->getMessage()
    ]);
    exit(1);
}

echo "[" . date('Y-m-d H:i:s') . "] Cron job completed.\n";
exit(0);