<?php
// cron/expire_tasks.php
// اجرا: هر 5 دقیقه
// crontab: */5 * * * * php /path/to/cron/expire_tasks.php

require_once __DIR__ . '/../public/index.php';

use App\Models\TaskExecution;

echo "[" . date('Y-m-d H:i:s') . "] Expiring overdue tasks...\n";

$expired = TaskExecution::expireOverdue();

echo "Expired: {$expired} tasks\n";