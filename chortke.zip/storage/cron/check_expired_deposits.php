<?php

/**
 * Cron Job: بررسی واریزهای منقضی‌شده
 * 
 * اجرا: هر ساعت یکبار
 * دستور Cron: 0 * * * * php /path/to/project/storage/cron/check_expired_deposits.php
 */

require_once __DIR__ . '/../../vendor/autoload.php';
require_once __DIR__ . '/../../bootstrap/app.php';

use App\Models\CryptoDeposit;

echo "[" . date('Y-m-d H:i:s') . "] Checking for expired deposits...\n";

try {
    $db = \Core\Database::getInstance();
    
    // واریزهای pending که بیش از 30 دقیقه گذشته و 3 بار تلاش شده
    $sql = "
        SELECT * FROM crypto_deposits
        WHERE verification_status = 'pending'
        AND verification_attempts >= 3
        AND created_at < DATE_SUB(NOW(), INTERVAL 30 MINUTE)
    ";
    
    $stmt = $db->query($sql);
    $deposits = $stmt->fetchAll(\PDO::FETCH_OBJ);

    if (empty($deposits)) {
        echo "No expired deposits found.\n";
        exit(0);
    }

    echo "Found " . count($deposits) . " expired deposit(s).\n";

    $depositModel = new CryptoDeposit();
    $count = 0;

    foreach ($deposits as $deposit) {
        // انتقال به بررسی دستی
        $updated = $depositModel->updateStatus(
            $deposit->id,
            'manual_review',
            null,
            'زمان بررسی خودکار منقضی شد - نیاز به بررسی دستی'
        );

        if ($updated) {
            $count++;
            echo "✓ Deposit ID {$deposit->id} moved to manual review.\n";
        }
    }

    echo "\nTotal moved to manual review: {$count}\n";

} catch (\Exception $e) {
    echo "✗ Error: " . $e->getMessage() . "\n";
    logger()->error('Check expired deposits cron failed', [
        'error' => $e->getMessage()
    ]);
    exit(1);
}

echo "[" . date('Y-m-d H:i:s') . "] Cron job completed.\n";
exit(0);