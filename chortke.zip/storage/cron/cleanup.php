<?php
/**
 * Cleanup Cron Job
 * 
 * اجرا: php storage/cron/cleanup.php
 * 
 * وظایف:
 * - پاکسازی Session های منقضی شده
 * - پاکسازی Rate Limit های قدیمی
 * - پاکسازی Cache های منقضی شده
 * - پاکسازی Password Reset های منقضی شده
 */

require_once __DIR__ . '/../../core/Autoloader.php';
\Core\Autoloader::register();

require_once __DIR__ . '/../../helpers/functions.php';

use Core\Session;
use Core\RateLimiter;
use Core\Cache;
use App\Models\PasswordReset;
use App\Models\ActivityLog;

echo "=================================\n";
echo "   Cleanup Cron Job Started\n";
echo "=================================\n\n";

try {
    // 1. پاکسازی Sessions
    echo "🔄 Cleaning up expired sessions...\n";
    $sessionsCleaned = Session::cleanupExpiredSessions();
    echo "✅ Cleaned {$sessionsCleaned} sessions\n\n";
    
    // 2. پاکسازی Rate Limits
    echo "🔄 Cleaning up rate limits...\n";
    $rateLimiter = new RateLimiter();
    $rateLimitsCleaned = $rateLimiter->cleanup();
    echo "✅ Cleaned {$rateLimitsCleaned} rate limit files\n\n";
    
    // 3. پاکسازی Cache
    echo "🔄 Cleaning up cache...\n";
    $cache = Cache::getInstance();
    $cacheCleaned = $cache->cleanup();
    echo "✅ Cleaned {$cacheCleaned} cache files\n\n";
    
    // 4. پاکسازی Password Resets
    echo "🔄 Cleaning up expired password resets...\n";
    $passwordReset = new PasswordReset();
    $resetsCleaned = $passwordReset->cleanupExpired();
    echo "✅ Cleaned {$resetsCleaned} password reset tokens\n\n";
    
    // 5. پاکسازی Activity Logs (قدیمی‌تر از 90 روز)
    echo "🔄 Cleaning up old activity logs...\n";
    $activityLog = new ActivityLog();
    $logsCleaned = $activityLog->cleanup(90);
    echo "✅ Cleaned {$logsCleaned} activity logs\n\n";
    
    echo "=================================\n";
    echo "   Cleanup Completed Successfully\n";
    echo "=================================\n\n";
    
} catch (\Exception $e) {
    echo "\n❌ Error: " . $e->getMessage() . "\n\n";
    logger('error', 'Cleanup cron job failed', [
        'error' => $e->getMessage()
    ]);
    exit(1);
}