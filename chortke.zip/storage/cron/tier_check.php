<?php
/**
 * Tier Level Check Cron Job
 * 
 * اجرا: php storage/cron/tier_check.php
 * 
 * وظایف:
 * - بررسی فعالیت کاربران
 * - Reset کردن Tier Level کاربران غیرفعال
 * - ارسال نوتیفیکیشن به کاربران
 */

require_once __DIR__ . '/../../core/Autoloader.php';
\Core\Autoloader::register();

require_once __DIR__ . '/../../helpers/functions.php';

use App\Models\User;
use Core\Database;

echo "=================================\n";
echo "   Tier Level Check Started\n";
echo "=================================\n\n";

try {
    $userModel = new User();
    $db = Database::getInstance();
    
    echo "🔄 Checking user tier levels...\n\n";
    
    // دریافت کاربرانی که Tier بالاتر از Silver دارند
    $users = $db->query(
        "SELECT id, username, tier_level, last_active_date 
         FROM users 
         WHERE tier_level IN ('gold', 'vip') 
         AND deleted_at IS NULL"
    )->fetchAll();
    
    if (empty($users)) {
        echo "ℹ️  No users with elevated tier levels found.\n\n";
        exit(0);
    }
    
    echo "Found " . count($users) . " users to check\n\n";
    
    $resetCount = 0;
    $now = time();
    $monthStart = strtotime(date('Y-m-01')); // اول ماه جاری
    
    foreach ($users as $user) {
        $userId = $user['id'];
        $username = $user['username'];
        $tierLevel = $user['tier_level'];
        $lastActive = $user['last_active_date'] ? strtotime($user['last_active_date']) : 0;
        
        // محاسبه تعداد روزهای غیرفعال در ماه جاری
        $inactiveDays = 0;
        
        // اگر آخرین فعالیت قبل از این ماه بود، کل ماه غیرفعال بوده
        if ($lastActive < $monthStart) {
            $inactiveDays = date('j'); // روز فعلی از ماه
        } else {
            // محاسبه روزهایی که فعال نبوده
            $daysInMonth = date('j');
            $activeDays = 0;
            
            // بررسی Activity Log
            $activityCount = $db->selectOne(
                "SELECT COUNT(DISTINCT DATE(created_at)) as days
                 FROM activity_logs 
                 WHERE user_id = ? 
                 AND created_at >= ?",
                [$userId, date('Y-m-01')]
            );
            
            $activeDays = $activityCount['days'] ?? 0;
            $inactiveDays = $daysInMonth - $activeDays;
        }
        
        echo "User: {$username} (Tier: {$tierLevel})\n";
        echo "  - Inactive days this month: {$inactiveDays}\n";
        
        // اگر بیش از 3 روز غیرفعال بوده
        if ($inactiveDays > 3) {
            echo "  ⚠️  Reset tier to Silver\n";
            
            // Reset کردن Tier
            $db->query(
                "UPDATE users 
                 SET tier_level = 'silver', 
                     tier_points = 0, 
                     tier_expires_at = NULL 
                 WHERE id = ?",
                [$userId]
            );
            
            // ثبت لاگ
            $db->query(
                "INSERT INTO activity_logs (user_id, action, description, ip_address, created_at) 
                 VALUES (?, ?, ?, ?, ?)",
                [
                    $userId,
                    'tier_reset',
                    "سطح کاربری به دلیل عدم فعالیت ({$inactiveDays} روز) به نقره‌ای تغییر کرد",
                    '127.0.0.1',
                    date('Y-m-d H:i:s')
                ]
            );
            
            $resetCount++;
            
            // TODO: ارسال نوتیفیکیشن به کاربر
            echo "  ✅ Notification sent\n";
        } else {
            echo "  ✓ Active enough, no action needed\n";
        }
        
        echo "\n";
    }
    
    echo "=================================\n";
    echo "✅ Tier Check Completed\n";
    echo "   Users checked: " . count($users) . "\n";
    echo "   Tiers reset: {$resetCount}\n";
    echo "=================================\n\n";
    
} catch (\Exception $e) {
    echo "\n❌ Error: " . $e->getMessage() . "\n\n";
    logger('error', 'Tier check cron job failed', [
        'error' => $e->getMessage()
    ]);
    exit(1);
}