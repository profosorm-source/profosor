<?php

/**
 * Cron Job: پشتیبان‌گیری از دیتابیس
 * 
 * اجرا: روزانه در ساعت 2 صبح
 * دستور Cron: 0 2 * * * php /path/to/project/storage/cron/backup_database.php
 */

require_once __DIR__ . '/../../vendor/autoload.php';
require_once __DIR__ . '/../../bootstrap/app.php';

echo "[" . date('Y-m-d H:i:s') . "] Starting database backup...\n";

try {
    $dbHost = env('DB_HOST');
    $dbName = env('DB_NAME');
    $dbUser = env('DB_USER');
    $dbPass = env('DB_PASS');

    // مسیر ذخیره
    $backupPath = __DIR__ . '/../backups/';
    if (!is_dir($backupPath)) {
        mkdir($backupPath, 0755, true);
    }

    $filename = 'backup_' . date('Y-m-d_H-i-s') . '.sql';
    $filepath = $backupPath . $filename;

    // استفاده از mysqldump
    $command = sprintf(
        'mysqldump --host=%s --user=%s --password=%s %s > %s 2>&1',
        escapeshellarg($dbHost),
        escapeshellarg($dbUser),
        escapeshellarg($dbPass),
        escapeshellarg($dbName),
        escapeshellarg($filepath)
    );

    exec($command, $output, $returnCode);

    if ($returnCode !== 0) {
        throw new \RuntimeException('Backup failed: ' . implode("\n", $output));
    }

    // فشرده‌سازی
    $gzFilepath = $filepath . '.gz';
    $gzCommand = sprintf('gzip %s', escapeshellarg($filepath));
    exec($gzCommand, $gzOutput, $gzReturn);

    if ($gzReturn === 0 && file_exists($gzFilepath)) {
        $finalFile = $gzFilepath;
        $fileSize = filesize($finalFile);
        echo "✓ Backup created: {$filename}.gz (" . round($fileSize / 1024 / 1024, 2) . " MB)\n";
    } else {
        $finalFile = $filepath;
        $fileSize = filesize($finalFile);
        echo "✓ Backup created: {$filename} (" . round($fileSize / 1024 / 1024, 2) . " MB)\n";
    }

    // حذف بکاپ‌های قدیمی (نگهداری 30 روز اخیر)
    $files = glob($backupPath . 'backup_*.sql*');
    $deletedCount = 0;
    
    foreach ($files as $file) {
        if (is_file($file) && (time() - filemtime($file)) > (30 * 24 * 60 * 60)) {
            unlink($file);
            $deletedCount++;
        }
    }

    if ($deletedCount > 0) {
        echo "✓ Deleted {$deletedCount} old backup(s).\n";
    }

    // ثبت لاگ
    logger()->info('Database backup completed', [
        'filename' => basename($finalFile),
        'size' => $fileSize
    ]);

} catch (\Exception $e) {
    echo "✗ Error: " . $e->getMessage() . "\n";
    logger()->error('Database backup failed', [
        'error' => $e->getMessage()
    ]);
    exit(1);
}

echo "[" . date('Y-m-d H:i:s') . "] Backup completed.\n";
exit(0);