<?php

/**
 * Cron Job: گزارش روزانه کیف پول
 * 
 * اجرا: روزانه در ساعت 23:00
 * دستور Cron: 0 23 * * * php /path/to/project/storage/cron/daily_wallet_report.php
 */

require_once __DIR__ . '/../../vendor/autoload.php';
require_once __DIR__ . '/../../bootstrap/app.php';

echo "[" . date('Y-m-d H:i:s') . "] Generating daily wallet report...\n";

try {
    $db = \Core\Database::getInstance();
    
    // گزارش تراکنش‌های امروز
    $today = date('Y-m-d');
    
    // تراکنش‌های IRT
    $sql = "
        SELECT 
            COUNT(*) as total_count,
            SUM(CASE WHEN type = 'deposit' AND status = 'completed' THEN amount ELSE 0 END) as total_deposits,
            SUM(CASE WHEN type = 'withdraw' AND status = 'completed' THEN amount ELSE 0 END) as total_withdrawals,
            COUNT(CASE WHEN type = 'deposit' THEN 1 END) as deposit_count,
            COUNT(CASE WHEN type = 'withdraw' THEN 1 END) as withdrawal_count
        FROM transactions
        WHERE currency = 'irt'
        AND DATE(created_at) = :date
    ";
    
    $stmt = $db->prepare($sql);
    $stmt->execute(['date' => $today]);
    $irtReport = $stmt->fetch(\PDO::FETCH_OBJ);

    // تراکنش‌های USDT
    $sql = "
        SELECT 
            COUNT(*) as total_count,
            SUM(CASE WHEN type = 'deposit' AND status = 'completed' THEN amount ELSE 0 END) as total_deposits,
            SUM(CASE WHEN type = 'withdraw' AND status = 'completed' THEN amount ELSE 0 END) as total_withdrawals,
            COUNT(CASE WHEN type = 'deposit' THEN 1 END) as deposit_count,
            COUNT(CASE WHEN type = 'withdraw' THEN 1 END) as withdrawal_count
        FROM transactions
        WHERE currency = 'usdt'
        AND DATE(created_at) = :date
    ";
    
    $stmt = $db->prepare($sql);
    $stmt->execute(['date' => $today]);
    $usdtReport = $stmt->fetch(\PDO::FETCH_OBJ);

    // ذخیره گزارش
    $report = [
        'date' => $today,
        'irt' => [
            'total_transactions' => $irtReport->total_count,
            'total_deposits' => $irtReport->total_deposits,
            'total_withdrawals' => $irtReport->total_withdrawals,
            'deposit_count' => $irtReport->deposit_count,
            'withdrawal_count' => $irtReport->withdrawal_count,
        ],
        'usdt' => [
            'total_transactions' => $usdtReport->total_count,
            'total_deposits' => $usdtReport->total_deposits,
            'total_withdrawals' => $usdtReport->total_withdrawals,
            'deposit_count' => $usdtReport->deposit_count,
            'withdrawal_count' => $usdtReport->withdrawal_count,
        ],
    ];

    // ذخیره در فایل
    $reportPath = __DIR__ . '/../reports/';
    if (!is_dir($reportPath)) {
        mkdir($reportPath, 0755, true);
    }

    $filename = $reportPath . 'wallet_report_' . $today . '.json';
    file_put_contents($filename, json_encode($report, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));

    echo "✓ Report saved: {$filename}\n";
    echo "\n=== IRT Summary ===\n";
    echo "Total Transactions: {$irtReport->total_count}\n";
    echo "Total Deposits: " . number_format($irtReport->total_deposits) . " تومان\n";
    echo "Total Withdrawals: " . number_format($irtReport->total_withdrawals) . " تومان\n";

    echo "\n=== USDT Summary ===\n";
    echo "Total Transactions: {$usdtReport->total_count}\n";
    echo "Total Deposits: {$usdtReport->total_deposits} USDT\n";
    echo "Total Withdrawals: {$usdtReport->total_withdrawals} USDT\n";

    // ارسال ایمیل به مدیران (اختیاری)
    // sendAdminEmail($report);

} catch (\Exception $e) {
    echo "✗ Error: " . $e->getMessage() . "\n";
    logger()->error('Daily wallet report cron failed', [
        'error' => $e->getMessage()
    ]);
    exit(1);
}

echo "\n[" . date('Y-m-d H:i:s') . "] Report generation completed.\n";
exit(0);