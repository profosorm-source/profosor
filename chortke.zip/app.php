<?php

// مسیر اصلی پروژه
define('BASE_PATH', dirname(__DIR__));

// autoload
require_once BASE_PATH . '/vendor/autoload.php';

// ✅ constants قبل از هر چیزی
require_once BASE_PATH . '/config/constants.php';

// helpers
require_once BASE_PATH . '/helpers/functions.php';
require_once BASE_PATH . '/helpers/label_helpers.php';

// ساخت اپ
$app = Core\Application::getInstance();

return $app;
