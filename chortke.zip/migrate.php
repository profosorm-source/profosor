<?php
/**
 * Migration Runner
 * 
 * اجرای Migration ها
 * 
 * استفاده: php migrate.php
 */

require_once __DIR__ . '/core/Autoloader.php';
\Core\Autoloader::register();

require_once __DIR__ . '/helpers/functions.php';

use Core\Database;

echo "=================================\n";
echo "   چرتکه - Migration Runner\n";
echo "=================================\n\n";

try {
    $db = Database::getInstance();
    
    // ایجاد جدول migrations (اگر وجود ندارد)
    $db->query("
        CREATE TABLE IF NOT EXISTS migrations (
            id INT AUTO_INCREMENT PRIMARY KEY,
            migration VARCHAR(255) NOT NULL,
            batch INT NOT NULL,
            executed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    ");
    
    // دریافت Migration های اجرا شده
    $executed = $db->select("SELECT migration FROM migrations");
    $executedList = array_column($executed, 'migration');
    
    // دریافت فایل‌های Migration
    $migrationFiles = glob(__DIR__ . '/database/migrations/*.php');
    sort($migrationFiles);
    
    if (empty($migrationFiles)) {
        echo "⚠️  هیچ Migration یافت نشد!\n\n";
        exit;
    }
    
    // دریافت آخرین Batch
    $lastBatch = $db->selectOne("SELECT MAX(batch) as batch FROM migrations");
    $currentBatch = ($lastBatch['batch'] ?? 0) + 1;
    
    $migrated = 0;
    
    foreach ($migrationFiles as $file) {
        $filename = basename($file);
        
        // بررسی اجرا شده یا نه
        if (in_array($filename, $executedList)) {
            echo "⏭️  건너뛰기: {$filename}\n";
            continue;
        }
        
        echo "🔄 در حال اجرا: {$filename} ... ";
        
        try {
            // اجرای Migration
            $migration = require $file;
            $migration->up();
            
            // ثبت در جدول migrations
            $db->query(
                "INSERT INTO migrations (migration, batch) VALUES (?, ?)",
                [$filename, $currentBatch]
            );
            
            echo "✅ موفق\n";
            $migrated++;
            
        } catch (\Exception $e) {
            echo "❌ خطا: " . $e->getMessage() . "\n";
            break;
        }
    }
    
    echo "\n=================================\n";
    echo "✅ تعداد Migration اجرا شده: {$migrated}\n";
    echo "=================================\n\n";
    
} catch (\Exception $e) {
    echo "\n❌ خطای سیستمی: " . $e->getMessage() . "\n\n";
    exit(1);
}