<?php


// Middleware
use App\Middleware\AuthMiddleware;
use App\Middleware\GuestMiddleware;
use App\Middleware\AdminMiddleware;
use App\Middleware\CSRFMiddleware;

// User Controllers
use App\Controllers\User\SocialAccountController;
use App\Controllers\User\AdTaskController;
use App\Controllers\User\TaskController;
use App\Controllers\FileController;
use App\Controllers\PageController;
use App\Controllers\User\SessionController as UserSessionController;
use App\Controllers\User\ProfileController;
use App\Controllers\User\WalletController;
use App\Controllers\User\KYCController as UserKYCController;
use App\Controllers\User\TwoFactorController;
use App\Controllers\User\ManualDepositController;
use App\Controllers\User\CryptoDepositController;
use App\Controllers\User\WithdrawalController;
use App\Controllers\User\BankCardController as UserBankCardController;
use App\Controllers\User\DashboardController as UserDashboardController;
use App\Controllers\User\AuthController as UserAuthController;
use App\Controllers\User\SEOTaskController;


// Admin Controllers
use App\Controllers\Admin\SystemSettingController;
use App\Controllers\Admin\KYCController as AdminKYCController;
use App\Controllers\Admin\AuthController as AdminAuthController;
use App\Controllers\Admin\LogController as AdminLogController;
use App\Controllers\Admin\UserController as AdminUserController;
use App\Controllers\Admin\BankCardController as AdminBankCardController;
use App\Controllers\Admin\DashboardController as AdminDashboardController;
use App\Controllers\Admin\NotificationController as AdminNotificationController;
use App\Controllers\Admin\TransactionController as AdminTransactionController;
use App\Controllers\Admin\ManualDepositController as AdminManualDepositController;
use App\Controllers\Admin\CryptoDepositController as AdminCryptoDepositController;
use App\Controllers\Admin\WithdrawalController as AdminWithdrawalController;
use App\Controllers\Admin\SocialAccountController as AdminSocialAccountController;
use App\Controllers\Admin\AdTaskController as AdminAdTaskController;
use App\Controllers\Admin\TaskExecutionController as AdminTaskExecutionController;
use App\Controllers\Admin\TaskDisputeController as AdminTaskDisputeController;
use App\Controllers\Admin\TaskRecheckController as AdminTaskRecheckController;
use App\Controllers\PaymentController;
use App\Controllers\Admin\SEOKeywordController;
use App\Controllers\Admin\AdminExportController;
use App\Controllers\SearchController;
use App\Controllers\User\AdvertiserController;
use App\Controllers\User\ApiTokenController;
use App\Controllers\Admin\CronController;
use App\Controllers\Admin\EmailQueueController;
use App\Controllers\Admin\ApiTokenAdminController;
use App\Controllers\Admin\CacheAdminController;
use App\Controllers\Api\TokenController;
use App\Controllers\Api\WalletController as ApiWalletController;
use App\Controllers\Api\UserController;
use App\Middleware\ApiAuthMiddleware;
use App\Controllers\Admin\AuditTrailController;
use App\Controllers\User\WithdrawalController as UserWithdrawalController;

use App\Controllers\DebugController;
use App\Controllers\TestCaptchaController;
use App\Controllers\CaptchaController;

$app = app();

$router = $app->router;

// =====================================
// Public Routes
// =====================================

$router->get('/', [PageController::class, 'home']);
$router->get('/about', [PageController::class, 'about']);
$router->get('/contact', [PageController::class, 'contact']);
$router->get('/terms', [PageController::class, 'terms']);
$router->get('/privacy', [PageController::class, 'privacy']);
$router->get('/help', [PageController::class, 'help']);

// ═══ صفحه هوم ═══
$app->router->get('/', [\App\Controllers\HomeController::class, 'index']);
/**
 * مسیرهای احراز هویت (فقط برای مهمان‌ها)
 */
$app->router->group(['middleware' => GuestMiddleware::class], function($router) {
    // ثبت‌نام
    $router->get('/register', [UserAuthController::class, 'showRegister']);
    $router->post('/register', [UserAuthController::class, 'register']);
    
    // ورود
    $router->get('/login', [UserAuthController::class, 'showLogin']);
    $router->post('/login', [UserAuthController::class, 'login']);
    
    // فراموشی رمز عبور
    $router->get('/forgot-password', [UserAuthController::class, 'showForgotPassword']);
    $router->post('/forgot-password', [UserAuthController::class, 'forgotPassword']);
    
    // بازیابی رمز عبور
    $router->get('/reset-password', [UserAuthController::class, 'showResetPassword']);
    $router->post('/reset-password', [UserAuthController::class, 'resetPassword']);
});
    // داشبورد کاربر
$app->router->group([
    'prefix' => '/user',
    'middleware' => AuthMiddleware::class
], function ($router) {
    $router->get('/dashboard', [UserDashboardController::class, 'index']);
});

/**
 * مسیرهای کاربری (نیاز به احراز هویت)
 */
$app->router->group(['middleware' => AuthMiddleware::class], function($router) {
    // خروج
    $router->get('/logout', [UserAuthController::class, 'logout']);
    $router->post('/logout', [UserAuthController::class, 'logout']);
    

    
    
    // پروفایل
    $router->get('/user/profile', [ProfileController::class, 'index']);
    $router->post('/user/profile/update', [ProfileController::class, 'update']);
    
    // تغییر رمز عبور
    $router->post('/user/profile/change-password', [ProfileController::class, 'changePassword']);
});

// آواتار (AJAX)
$app->router->post('/user/profile/upload-avatar', [ProfileController::class, 'uploadAvatar'], [AuthMiddleware::class]);
$app->router->post('/user/profile/delete-avatar', [ProfileController::class, 'deleteAvatar'], [AuthMiddleware::class]);

// عملیات بن و تعلیق
$app->router->post('/admin/users/ban/{id}', [AdminUserController::class, 'ban'], [AuthMiddleware::class, AdminMiddleware::class]);
$app->router->post('/admin/users/suspend/{id}', [AdminUserController::class, 'suspend'], [AuthMiddleware::class, AdminMiddleware::class]);


// KYC Routes
$app->router->get('/user/kyc', [UserKYCController::class, 'index'], [AuthMiddleware::class]);
$app->router->get('/user/kyc/upload', [UserKYCController::class, 'upload'], [AuthMiddleware::class]);
$app->router->post('/user/kyc/submit', [UserKYCController::class, 'submit'], [AuthMiddleware::class]);
$app->router->get('/user/kyc/status', [UserKYCController::class, 'status'], [AuthMiddleware::class]);

// کارت‌های بانکی
$app->router->get('/user/bank-cards', [BankCardController::class, 'index'], [AuthMiddleware::class]);
$app->router->get('/user/bank-cards/create', [BankCardController::class, 'create'], [AuthMiddleware::class]);
$app->router->post('/user/bank-cards/store', [BankCardController::class, 'store'], [AuthMiddleware::class]);
$app->router->post('/user/bank-cards/set-default', [BankCardController::class, 'setDefault'], [AuthMiddleware::class]);
$app->router->post('/user/bank-cards/delete', [BankCardController::class, 'delete'], [AuthMiddleware::class]);

// Bank Card Routes (User) - Action-based
$app->router->post('/user/bank-cards/delete/{id}', [UserBankCardController::class, 'delete'], [AuthMiddleware::class]);
$app->router->post('/user/bank-cards/set-default/{id}', [UserBankCardController::class, 'setDefault'], [AuthMiddleware::class]);


// Active Sessions (User)
$app->router->get('/user/sessions', [UserSessionController::class, 'index'], [AuthMiddleware::class]);
$app->router->post('/user/sessions/terminate/{id}', [UserSessionController::class, 'terminate'], [AuthMiddleware::class]);

// User Notifications
$app->router->get('/notifications', [App\Controllers\User\NotificationController::class, 'index'], [AuthMiddleware::class]);
$app->router->get('/notifications/get', [App\Controllers\User\NotificationController::class, 'get'], [AuthMiddleware::class]);
$app->router->post('/notifications/mark-read', [App\Controllers\User\NotificationController::class, 'markAsRead'], [AuthMiddleware::class]);
$app->router->post('/notifications/mark-all-read', [App\Controllers\User\NotificationController::class, 'markAllAsRead'], [AuthMiddleware::class]);
$app->router->post('/notifications/archive', [App\Controllers\User\NotificationController::class, 'archive'], [AuthMiddleware::class]);
$app->router->get('/notifications/unread-count', [App\Controllers\User\NotificationController::class, 'unreadCount'], [AuthMiddleware::class]);

$app->router->get('/notifications/preferences', [App\Controllers\User\NotificationController::class, 'preferences'], [AuthMiddleware::class]);
$app->router->post('/notifications/preferences/update', [App\Controllers\User\NotificationController::class, 'updatePreferences'], [AuthMiddleware::class]);


//-------------------------------------------------------------------------------
//Admin
//-------------------------------------------------------------------------------
// ورود و خروج ادمین
$app->router->get('/admin/login', [AdminAuthController::class, 'showLogin']);
$app->router->post('/admin/login', [AdminAuthController::class, 'login']);
$app->router->post('/admin/logout', [AdminAuthController::class, 'logout']);

// داشبورد ادمین
$app->router->get('/admin/dashboard', [AdminDashboardController::class, 'index'], [AuthMiddleware::class, AdminMiddleware::class]);

// مدیریت کاربران
$app->router->get('/admin/users', [AdminUserController::class, 'index'], [AuthMiddleware::class, AdminMiddleware::class]);
$app->router->get('/admin/users/create', [AdminUserController::class, 'create'], [AuthMiddleware::class, AdminMiddleware::class]);
$app->router->post('/admin/users/store', [AdminUserController::class, 'store'], [AuthMiddleware::class, AdminMiddleware::class]);
$app->router->get('/admin/users/{id}/edit', [AdminUserController::class, 'edit'], [AuthMiddleware::class, AdminMiddleware::class]);
$app->router->post('/admin/users/{id}/update', [AdminUserController::class, 'update'], [AuthMiddleware::class, AdminMiddleware::class]);
$app->router->post('/admin/users/{id}/ban', [AdminUserController::class, 'ban'], [AuthMiddleware::class, AdminMiddleware::class]);
$app->router->post('/admin/users/{id}/unban', [AdminUserController::class, 'unban'], [AuthMiddleware::class, AdminMiddleware::class]);
$app->router->post('/admin/users/{id}/suspend', [AdminUserController::class, 'suspend'], [AuthMiddleware::class, AdminMiddleware::class]);
$app->router->post('/admin/users/{id}/unsuspend', [AdminUserController::class, 'unsuspend'], [AuthMiddleware::class, AdminMiddleware::class]);

// KYC Management
$app->router->get('/admin/kyc', [AdminKYCController::class, 'index'], [AuthMiddleware::class, AdminMiddleware::class]);
$app->router->get('/admin/kyc/review/{id}', [AdminKYCController::class, 'review'], [AuthMiddleware::class, AdminMiddleware::class]);
$app->router->post('/admin/kyc/verify/{id}', [AdminKYCController::class, 'verify'], [AuthMiddleware::class, AdminMiddleware::class]);
$app->router->post('/admin/kyc/reject/{id}', [AdminKYCController::class, 'reject'], [AuthMiddleware::class, AdminMiddleware::class]);
$app->router->post('/admin/kyc/mark-reviewing/{id}', [AdminKYCController::class, 'markAsReviewing'], [AuthMiddleware::class, AdminMiddleware::class]);
$app->router->post('/admin/kyc/delete-image/{id}', [AdminKYCController::class, 'deleteImage'], [AuthMiddleware::class, AdminMiddleware::class]);

// لاگ‌ها
$app->router->get('/admin/logs', [AdminLogController::class, 'index'], [AuthMiddleware::class, AdminMiddleware::class]);
$app->router->post('/admin/logs/cleanup', [AdminLogController::class, 'cleanup'], [AuthMiddleware::class, AdminMiddleware::class]);

// File Routes (نمایش فایل‌ها با کنترل دسترسی)
$app->router->get('/file/view/{folder}/{filename}', [FileController::class, 'view']);


// Admin Notifications
$app->router->get('/admin/notifications', [App\Controllers\Admin\NotificationController::class, 'index'], [AuthMiddleware::class, AdminMiddleware::class]);

// ✅ Ajax routes (این‌ها را اضافه کن)
$app->router->get('/admin/notifications/fetch', [AdminNotificationController::class, 'fetch'], [AuthMiddleware::class, AdminMiddleware::class]);
$app->router->post('/admin/notifications/mark-read/{id}', [AdminNotificationController::class, 'markAsRead'], [AuthMiddleware::class, AdminMiddleware::class]);
$app->router->post('/admin/notifications/mark-all-read', [AdminNotificationController::class, 'markAllAsRead'], [AuthMiddleware::class, AdminMiddleware::class]);

// Feature Flags & Settings - Admin
$app->router->get('/admin/features', [Admin\FeatureFlagController::class, 'index'], [AuthMiddleware::class, AdminMiddleware::class]);
$app->router->post('/admin/features/toggle', [Admin\FeatureFlagController::class, 'toggle'], [AuthMiddleware::class, AdminMiddleware::class]);

// تنظیمات ادمین
$app->router->get('/admin/settings', [SystemSettingController::class, 'index'], [AuthMiddleware::class, AdminMiddleware::class]);
$app->router->post('/admin/settings/{id}/update', [SystemSettingController::class, 'update'], [AuthMiddleware::class, AdminMiddleware::class]);







// Fraud Dashboard - Admin
$app->router->get('/admin/fraud/dashboard', [Admin\FraudDashboardController::class, 'index'], [AuthMiddleware::class, AdminMiddleware::class]);

// CAPTCHA Test
$app->router->get('/test-captcha', [TestCaptchaController::class, 'index']);
$app->router->post('/test-captcha/verify', [TestCaptchaController::class, 'verify']);

// CAPTCHA Settings - Admin
$app->router->get('/admin/captcha/settings', function() {return view('admin/captcha/settings');}, [AuthMiddleware::class, AdminMiddleware::class]);


// Static Pages
$app->router->get('/pages/{slug}', [PageController::class, 'show']);

// Contact
$app->router->get('/contact', function() {
    return view('pages/contact');
});
$app->router->post('/contact/send', [ContactController::class, 'send']);

// Sitemap
$app->router->get('/sitemap.xml', [SitemapController::class, 'index']);

// Admin - Pages Management
$app->router->get('/admin/pages', [Admin\PageController::class, 'index'], [AuthMiddleware::class, AdminMiddleware::class]);
$app->router->get('/admin/pages/create', [Admin\PageController::class, 'create'], [AuthMiddleware::class, AdminMiddleware::class]);
$app->router->post('/admin/pages/store', [Admin\PageController::class, 'store'], [AuthMiddleware::class, AdminMiddleware::class]);
$app->router->get('/admin/pages/edit/{id}', [Admin\PageController::class, 'edit'], [AuthMiddleware::class, AdminMiddleware::class]);
$app->router->post('/admin/pages/update/{id}', [Admin\PageController::class, 'update'], [AuthMiddleware::class, AdminMiddleware::class]);
$app->router->post('/admin/pages/delete', [Admin\PageController::class, 'delete'], [AuthMiddleware::class, AdminMiddleware::class]);


// Tickets - User
$app->router->get('/user/tickets', [User\TicketController::class, 'index'], [AuthMiddleware::class]);
$app->router->get('/user/tickets/create', [User\TicketController::class, 'create'], [AuthMiddleware::class]);
$app->router->post('/user/tickets/store', [User\TicketController::class, 'store'], [AuthMiddleware::class]);
$app->router->get('/user/tickets/show/{id}', [User\TicketController::class, 'show'], [AuthMiddleware::class]);
$app->router->post('/user/tickets/reply', [User\TicketController::class, 'reply'], [AuthMiddleware::class]);
$app->router->post('/user/tickets/close', [User\TicketController::class, 'close'], [AuthMiddleware::class]);

// Tickets - Admin
$app->router->get('/admin/tickets', [Admin\TicketController::class, 'index'], [AuthMiddleware::class, AdminMiddleware::class]);
$app->router->get('/admin/tickets/show/{id}', [Admin\TicketController::class, 'show'], [AuthMiddleware::class, AdminMiddleware::class]);
$app->router->post('/admin/tickets/reply', [Admin\TicketController::class, 'reply'], [AuthMiddleware::class, AdminMiddleware::class]);
$app->router->post('/admin/tickets/change-status', [Admin\TicketController::class, 'changeStatus'], [AuthMiddleware::class, AdminMiddleware::class]);
$app->router->post('/admin/tickets/assign', [Admin\TicketController::class, 'assign'], [AuthMiddleware::class, AdminMiddleware::class]);


// ═══════════════════════════════════════
// حساب‌های اجتماعی (User)
// ═══════════════════════════════════════
$app->router->get('/user/social-accounts', [SocialAccountController::class, 'index'], [AuthMiddleware::class]);
$app->router->get('/user/social-accounts/create', [SocialAccountController::class, 'showCreate'], [AuthMiddleware::class]);
$app->router->post('/user/social-accounts/store', [SocialAccountController::class, 'store'], [AuthMiddleware::class]);
$app->router->get('/user/social-accounts/{id}/edit', [SocialAccountController::class, 'showEdit'], [AuthMiddleware::class]);
$app->router->post('/user/social-accounts/{id}/update', [SocialAccountController::class, 'update'], [AuthMiddleware::class]);
$app->router->post('/user/social-accounts/{id}/delete', [SocialAccountController::class, 'delete'], [AuthMiddleware::class]);

// ═══════════════════════════════════════
// تسک‌ها — تبلیغ‌دهنده (User)
// ═══════════════════════════════════════
$app->router->get('/user/ad-tasks', [AdTaskController::class, 'myTasks'], [AuthMiddleware::class]);
$app->router->get('/user/ad-tasks/create', [AdTaskController::class, 'showCreate'], [AuthMiddleware::class]);
$app->router->post('/user/ad-tasks/store', [AdTaskController::class, 'store'], [AuthMiddleware::class]);
$app->router->get('/user/ad-tasks/{id}', [AdTaskController::class, 'show'], [AuthMiddleware::class]);
$app->router->post('/user/ad-tasks/{id}/pause', [AdTaskController::class, 'pause'], [AuthMiddleware::class]);
$app->router->post('/user/ad-tasks/{id}/resume', [AdTaskController::class, 'resume'], [AuthMiddleware::class]);
$app->router->post('/user/ad-tasks/{id}/cancel', [AdTaskController::class, 'cancel'], [AuthMiddleware::class]);

// بررسی مدارک (تبلیغ‌دهنده)
$app->router->get('/user/ad-tasks/review/{id}', [AdTaskController::class, 'showReview'], [AuthMiddleware::class]);
$app->router->post('/user/ad-tasks/review/{id}/approve', [AdTaskController::class, 'approveExecution'], [AuthMiddleware::class]);
$app->router->post('/user/ad-tasks/review/{id}/reject', [AdTaskController::class, 'rejectExecution'], [AuthMiddleware::class]);

// ═══════════════════════════════════════
// تسک‌ها — انجام‌دهنده (User)
// ═══════════════════════════════════════
$app->router->get('/user/tasks', [TaskController::class, 'index'], [AuthMiddleware::class]);
$app->router->post('/user/tasks/start', [TaskController::class, 'start'], [AuthMiddleware::class]);
$app->router->get('/user/tasks/{id}/execute', [TaskController::class, 'showExecute'], [AuthMiddleware::class]);
$app->router->post('/user/tasks/{id}/submit', [TaskController::class, 'submit'], [AuthMiddleware::class]);
$app->router->get('/user/tasks/history', [TaskController::class, 'history'], [AuthMiddleware::class]);
$app->router->post('/user/tasks/{id}/dispute', [TaskController::class, 'dispute'], [AuthMiddleware::class]);

// ═══════════════════════════════════════
// Admin — حساب‌های اجتماعی
// ═══════════════════════════════════════
$app->router->get('/admin/social-accounts', [AdminSocialAccountController::class, 'index'], [AuthMiddleware::class, AdminMiddleware::class]);
$app->router->get('/admin/social-accounts/{id}', [AdminSocialAccountController::class, 'show'], [AuthMiddleware::class, AdminMiddleware::class]);
$app->router->post('/admin/social-accounts/{id}/verify', [AdminSocialAccountController::class, 'verify'], [AuthMiddleware::class, AdminMiddleware::class]);
$app->router->post('/admin/social-accounts/{id}/reject', [AdminSocialAccountController::class, 'reject'], [AuthMiddleware::class, AdminMiddleware::class]);

// ═══════════════════════════════════════
// Admin — مدیریت تسک‌ها
// ═══════════════════════════════════════
$app->router->get('/admin/ad-tasks', [AdminAdTaskController::class, 'index'], [AuthMiddleware::class, AdminMiddleware::class]);
$app->router->get('/admin/ad-tasks/{id}', [AdminAdTaskController::class, 'show'], [AuthMiddleware::class, AdminMiddleware::class]);
$app->router->post('/admin/ad-tasks/{id}/approve', [AdminAdTaskController::class, 'approve'], [AuthMiddleware::class, AdminMiddleware::class]);
$app->router->post('/admin/ad-tasks/{id}/reject', [AdminAdTaskController::class, 'reject'], [AuthMiddleware::class, AdminMiddleware::class]);

// ═══════════════════════════════════════
// Admin — اجرای تسک‌ها
// ═══════════════════════════════════════
$app->router->get('/admin/task-executions', [AdminTaskExecutionController::class, 'index'], [AuthMiddleware::class, AdminMiddleware::class]);
$app->router->get('/admin/task-executions/{id}', [AdminTaskExecutionController::class, 'show'], [AuthMiddleware::class, AdminMiddleware::class]);
$app->router->post('/admin/task-executions/{id}/approve', [AdminTaskExecutionController::class, 'approve'], [AuthMiddleware::class, AdminMiddleware::class]);
$app->router->post('/admin/task-executions/{id}/reject', [AdminTaskExecutionController::class, 'reject'], [AuthMiddleware::class, AdminMiddleware::class]);

// ═══════════════════════════════════════
// Admin — اختلافات
// ═══════════════════════════════════════
$app->router->get('/admin/task-disputes', [AdminTaskDisputeController::class, 'index'], [AuthMiddleware::class, AdminMiddleware::class]);
$app->router->get('/admin/task-disputes/{id}', [AdminTaskDisputeController::class, 'show'], [AuthMiddleware::class, AdminMiddleware::class]);
$app->router->post('/admin/task-disputes/{id}/resolve-executor', [AdminTaskDisputeController::class, 'resolveForExecutor'], [AuthMiddleware::class, AdminMiddleware::class]);
$app->router->post('/admin/task-disputes/{id}/resolve-advertiser', [AdminTaskDisputeController::class, 'resolveForAdvertiser'], [AuthMiddleware::class, AdminMiddleware::class]);

// ═══════════════════════════════════════
// Admin — بررسی مجدد
// ═══════════════════════════════════════
$app->router->get('/admin/task-rechecks', [AdminTaskRecheckController::class, 'index'], [AuthMiddleware::class, AdminMiddleware::class]);
$app->router->post('/admin/task-rechecks/{id}/pass', [AdminTaskRecheckController::class, 'pass'], [AuthMiddleware::class, AdminMiddleware::class]);
$app->router->post('/admin/task-rechecks/{id}/fail', [AdminTaskRecheckController::class, 'fail'], [AuthMiddleware::class, AdminMiddleware::class]);


// واریز دستی (IRT)
$app->router->get('/user/wallet/deposit/manual', [ManualDepositController::class, 'create'], [AuthMiddleware::class]);
$app->router->post('/user/wallet/deposit/manual', [ManualDepositController::class, 'store'], [AuthMiddleware::class]);
$app->router->get('/user/manual-deposits', [ManualDepositController::class, 'index'], [AuthMiddleware::class]);

// واریز کریپتو (USDT)
$app->router->get('/user/wallet/deposit/crypto', [CryptoDepositController::class, 'create'], [AuthMiddleware::class]);
$app->router->post('/user/wallet/deposit/crypto', [CryptoDepositController::class, 'store'], [AuthMiddleware::class]);
$app->router->get('/user/crypto-deposits', [CryptoDepositController::class, 'index'], [AuthMiddleware::class]);

// برداشت
$app->router->get('/user/wallet/withdraw', [WithdrawalController::class, 'create'], [AuthMiddleware::class]);
$app->router->post('/user/wallet/withdraw', [WithdrawalController::class, 'store'], [AuthMiddleware::class]);
$app->router->get('/user/withdrawals', [WithdrawalController::class, 'index'], [AuthMiddleware::class]);

// پرداخت آنلاین
$app->router->post('/payment/request', [PaymentController::class, 'request'], [AuthMiddleware::class]);
$app->router->get('/payment/callback', [PaymentController::class, 'callback']);


// مدیریت کارت‌های بانکی
$app->router->get('/admin/bank-cards', [AdminBankCardController::class, 'index'], [AuthMiddleware::class, AdminMiddleware::class]);
$app->router->get('/admin/bank-cards/review', [AdminBankCardController::class, 'review'], [AuthMiddleware::class, AdminMiddleware::class]);
$app->router->post('/admin/bank-cards/verify', [AdminBankCardController::class, 'verify'], [AuthMiddleware::class, AdminMiddleware::class]);
$app->router->post('/admin/bank-cards/reject', [AdminBankCardController::class, 'reject'], [AuthMiddleware::class, AdminMiddleware::class]);

// مدیریت واریزهای دستی
$app->router->get('/admin/manual-deposits', [AdminManualDepositController::class, 'index'], [AuthMiddleware::class, AdminMiddleware::class]);
$app->router->get('/admin/manual-deposits/review', [AdminManualDepositController::class, 'review'], [AuthMiddleware::class, AdminMiddleware::class]);
$app->router->post('/admin/manual-deposits/verify', [AdminManualDepositController::class, 'verify'], [AuthMiddleware::class, AdminMiddleware::class]);
$app->router->post('/admin/manual-deposits/reject', [AdminManualDepositController::class, 'reject'], [AuthMiddleware::class, AdminMiddleware::class]);

// مدیریت واریزهای کریپتو
$app->router->get('/admin/crypto-deposits', [AdminCryptoDepositController::class, 'index'], [AuthMiddleware::class, AdminMiddleware::class]);
$app->router->get('/admin/crypto-deposits/review', [AdminCryptoDepositController::class, 'review'], [AuthMiddleware::class, AdminMiddleware::class]);
$app->router->post('/admin/crypto-deposits/verify', [AdminCryptoDepositController::class, 'verify'], [AuthMiddleware::class, AdminMiddleware::class]);
$app->router->post('/admin/crypto-deposits/reject', [AdminCryptoDepositController::class, 'reject'], [AuthMiddleware::class, AdminMiddleware::class]);

// مدیریت برداشت‌ها
$app->router->get('/admin/withdrawals', [AdminWithdrawalController::class, 'index'], [AuthMiddleware::class, AdminMiddleware::class]);
$app->router->get('/admin/withdrawals/review', [AdminWithdrawalController::class, 'review'], [AuthMiddleware::class, AdminMiddleware::class]);
$app->router->post('/admin/withdrawals/process', [AdminWithdrawalController::class, 'process'], [AuthMiddleware::class, AdminMiddleware::class]);
$app->router->post('/admin/withdrawals/reject', [AdminWithdrawalController::class, 'reject'], [AuthMiddleware::class, AdminMiddleware::class]);

// مدیریت تراکنش‌ها
$app->router->get('/admin/transactions', [AdminTransactionController::class, 'index'], [AuthMiddleware::class, AdminMiddleware::class]);
$app->router->get('/admin/transactions/show', [AdminTransactionController::class, 'show'], [AuthMiddleware::class, AdminMiddleware::class]);

// لاگ‌های فعالیت
$app->router->get('/admin/activity-logs', [LogController::class, 'activityLogs'], [AuthMiddleware::class, AdminMiddleware::class]);


// ═══ SEO Tasks (User) ═══
$app->router->get('/user/seo-tasks', [SEOTaskController::class, 'index'], [AuthMiddleware::class]);
$app->router->post('/user/seo-tasks/start', [SEOTaskController::class, 'start'], [AuthMiddleware::class]);
$app->router->get('/user/seo-tasks/{id}/execute', [SEOTaskController::class, 'showExecute'], [AuthMiddleware::class]);
$app->router->post('/user/seo-tasks/{id}/complete', [SEOTaskController::class, 'complete'], [AuthMiddleware::class]);
$app->router->get('/user/seo-tasks/history', [SEOTaskController::class, 'history'], [AuthMiddleware::class]);

// ═══ SEO Keywords (Admin) ═══
$app->router->get('/admin/seo-keywords', [SEOKeywordController::class, 'index'], [AuthMiddleware::class, AdminMiddleware::class]);
$app->router->get('/admin/seo-keywords/create', [SEOKeywordController::class, 'showCreate'], [AuthMiddleware::class, AdminMiddleware::class]);
$app->router->post('/admin/seo-keywords/store', [SEOKeywordController::class, 'store'], [AuthMiddleware::class, AdminMiddleware::class]);
$app->router->get('/admin/seo-keywords/{id}/edit', [SEOKeywordController::class, 'showEdit'], [AuthMiddleware::class, AdminMiddleware::class]);
$app->router->post('/admin/seo-keywords/{id}/update', [SEOKeywordController::class, 'update'], [AuthMiddleware::class, AdminMiddleware::class]);
$app->router->post('/admin/seo-keywords/{id}/toggle', [SEOKeywordController::class, 'toggleActive'], [AuthMiddleware::class, AdminMiddleware::class]);
$app->router->post('/admin/seo-keywords/{id}/delete', [SEOKeywordController::class, 'delete'], [AuthMiddleware::class, AdminMiddleware::class]);

// === مدیریت نقش‌ها ===
$app->router->get('/admin/roles', [App\Controllers\Admin\RoleController::class, 'index'], [AuthMiddleware::class, AdminMiddleware::class,]);
$app->router->get('/admin/roles/create', [App\Controllers\Admin\RoleController::class, 'create'], [AuthMiddleware::class, AdminMiddleware::class,]);
$app->router->post('/admin/roles/store', [App\Controllers\Admin\RoleController::class, 'store'], [AuthMiddleware::class, AdminMiddleware::class,]);
$app->router->get('/admin/roles/{id}/edit', [App\Controllers\Admin\RoleController::class, 'edit'], [AuthMiddleware::class, AdminMiddleware::class,]);
$app->router->post('/admin/roles/{id}/update', [App\Controllers\Admin\RoleController::class, 'update'], [AuthMiddleware::class, AdminMiddleware::class,]);
$app->router->post('/admin/roles/{id}/delete', [App\Controllers\Admin\RoleController::class, 'delete'], [AuthMiddleware::class, AdminMiddleware::class,]);
$app->router->post('/admin/roles/{id}/toggle', [App\Controllers\Admin\RoleController::class, 'toggle'], [AuthMiddleware::class, AdminMiddleware::class,]);


// === زیرمجموعه‌گیری کاربر ===
$app->router->get('/user/referral', [App\Controllers\User\ReferralController::class, 'index'], [
    App\Middleware\AuthMiddleware::class,]);

$app->router->get('/user/referral/commissions', [App\Controllers\User\ReferralController::class, 'commissions'], [
    App\Middleware\AuthMiddleware::class,]);

$app->router->get('/user/referral/referred-users', [App\Controllers\User\ReferralController::class, 'referredUsers'], [
    App\Middleware\AuthMiddleware::class,]);

// === مدیریت Referral (ادمین) ===
$app->router->get('/admin/referral', [App\Controllers\Admin\ReferralController::class, 'index'], [
    App\Middleware\AuthMiddleware::class,
    App\Middleware\AdminMiddleware::class,]);

$app->router->get('/admin/referral/settings', [App\Controllers\Admin\ReferralController::class, 'settings'], [
    App\Middleware\AuthMiddleware::class,
    App\Middleware\AdminMiddleware::class,]);

$app->router->post('/admin/referral/settings/save', [App\Controllers\Admin\ReferralController::class, 'saveSettings'], [
    App\Middleware\AuthMiddleware::class,
    App\Middleware\AdminMiddleware::class,]);

$app->router->get('/admin/referral/user/{id}', [App\Controllers\Admin\ReferralController::class, 'userDetail'], [
    App\Middleware\AuthMiddleware::class,
    App\Middleware\AdminMiddleware::class,]);

$app->router->post('/admin/referral/{id}/cancel', [App\Controllers\Admin\ReferralController::class, 'cancel'], [
    App\Middleware\AuthMiddleware::class,
    App\Middleware\AdminMiddleware::class,]);

$app->router->post('/admin/referral/batch-pay', [App\Controllers\Admin\ReferralController::class, 'batchPay'], [
    App\Middleware\AuthMiddleware::class,
    App\Middleware\AdminMiddleware::class,]);

// === سطح‌بندی کاربر ===
$app->router->get('/user/level', [App\Controllers\User\LevelController::class, 'index'], [
    App\Middleware\AuthMiddleware::class,]);

$app->router->post('/user/level/purchase', [App\Controllers\User\LevelController::class, 'purchase'], [
    App\Middleware\AuthMiddleware::class,]);

// === مدیریت سطوح (ادمین) ===
$app->router->get('/admin/levels', [App\Controllers\Admin\LevelController::class, 'index'], [
    App\Middleware\AuthMiddleware::class,
    App\Middleware\AdminMiddleware::class,]);

$app->router->get('/admin/levels/{id}/edit', [App\Controllers\Admin\LevelController::class, 'edit'], [
    App\Middleware\AuthMiddleware::class,
    App\Middleware\AdminMiddleware::class,]);

$app->router->post('/admin/levels/{id}/update', [App\Controllers\Admin\LevelController::class, 'update'], [
    App\Middleware\AuthMiddleware::class,
    App\Middleware\AdminMiddleware::class,]);

$app->router->post('/admin/levels/change-user-level', [App\Controllers\Admin\LevelController::class, 'changeUserLevel'], [App\Middleware\AuthMiddleware::class,App\Middleware\AdminMiddleware::class,]);

$app->router->get('/admin/levels/history', [App\Controllers\Admin\LevelController::class, 'history'], [
    App\Middleware\AuthMiddleware::class,
    App\Middleware\AdminMiddleware::class,]);
// === وظایف سفارشی (کاربر) ===
$app->router->get('/user/custom-tasks', [App\Controllers\User\CustomTaskController::class, 'index'], [App\Middleware\AuthMiddleware::class]);
$app->router->get('/user/custom-tasks/available', [App\Controllers\User\CustomTaskController::class, 'available'], [App\Middleware\AuthMiddleware::class]);
$app->router->get('/user/custom-tasks/create', [App\Controllers\User\CustomTaskController::class, 'create'], [App\Middleware\AuthMiddleware::class]);
$app->router->post('/user/custom-tasks/store', [App\Controllers\User\CustomTaskController::class, 'store'], [App\Middleware\AuthMiddleware::class]);
$app->router->get('/user/custom-tasks/{id}', [App\Controllers\User\CustomTaskController::class, 'show'], [App\Middleware\AuthMiddleware::class]);
$app->router->get('/user/custom-tasks/my-submissions', [App\Controllers\User\CustomTaskController::class, 'mySubmissions'], [App\Middleware\AuthMiddleware::class]);
$app->router->post('/user/custom-tasks/start', [App\Controllers\User\CustomTaskController::class, 'start'], [App\Middleware\AuthMiddleware::class]);
$app->router->post('/user/custom-tasks/{id}/submit-proof', [App\Controllers\User\CustomTaskController::class, 'submitProof'], [App\Middleware\AuthMiddleware::class]);
$app->router->post('/user/custom-tasks/review', [App\Controllers\User\CustomTaskController::class, 'review'], [App\Middleware\AuthMiddleware::class]);
$app->router->post('/user/custom-tasks/dispute', [App\Controllers\User\CustomTaskController::class, 'dispute'], [App\Middleware\AuthMiddleware::class]);

// === وظایف سفارشی (ادمین) ===
$app->router->get('/admin/custom-tasks', [App\Controllers\Admin\CustomTaskController::class, 'index'], [App\Middleware\AuthMiddleware::class, App\Middleware\AdminMiddleware::class]);
$app->router->post('/admin/custom-tasks/approve', [App\Controllers\Admin\CustomTaskController::class, 'approve'], [App\Middleware\AuthMiddleware::class, App\Middleware\AdminMiddleware::class]);
$app->router->get('/admin/custom-tasks/disputes', [App\Controllers\Admin\CustomTaskController::class, 'disputes'], [App\Middleware\AuthMiddleware::class, App\Middleware\AdminMiddleware::class]);
$app->router->post('/admin/custom-tasks/disputes/resolve', [App\Controllers\Admin\CustomTaskController::class, 'resolveDispute'], [App\Middleware\AuthMiddleware::class, App\Middleware\AdminMiddleware::class]);

// === تبلیغات استوری (کاربر) ===
$app->router->get('/user/stories/influencers', [App\Controllers\User\StoryController::class, 'influencers'], [App\Middleware\AuthMiddleware::class]);
$app->router->get('/user/stories/register', [App\Controllers\User\StoryController::class, 'register'], [App\Middleware\AuthMiddleware::class]);
$app->router->post('/user/stories/register', [App\Controllers\User\StoryController::class, 'storeProfile'], [App\Middleware\AuthMiddleware::class]);
$app->router->get('/user/stories/create-order', [App\Controllers\User\StoryController::class, 'createOrder'], [App\Middleware\AuthMiddleware::class]);
$app->router->post('/user/stories/store-order', [App\Controllers\User\StoryController::class, 'storeOrder'], [App\Middleware\AuthMiddleware::class]);
$app->router->get('/user/stories/my-orders', [App\Controllers\User\StoryController::class, 'myOrders'], [App\Middleware\AuthMiddleware::class]);
$app->router->get('/user/stories/my-page-orders', [App\Controllers\User\StoryController::class, 'myPageOrders'], [App\Middleware\AuthMiddleware::class]);
$app->router->post('/user/stories/respond-order', [App\Controllers\User\StoryController::class, 'respondOrder'], [App\Middleware\AuthMiddleware::class]);
$app->router->post('/user/stories/{id}/submit-proof', [App\Controllers\User\StoryController::class, 'submitProof'], [App\Middleware\AuthMiddleware::class]);

// === تبلیغات استوری (ادمین) ===
$app->router->get('/admin/stories', [App\Controllers\Admin\StoryController::class, 'index'], [App\Middleware\AuthMiddleware::class, App\Middleware\AdminMiddleware::class]);
$app->router->get('/admin/stories/influencers', [App\Controllers\Admin\StoryController::class, 'influencers'], [App\Middleware\AuthMiddleware::class, App\Middleware\AdminMiddleware::class]);
$app->router->post('/admin/stories/approve-influencer', [App\Controllers\Admin\StoryController::class, 'approveInfluencer'], [App\Middleware\AuthMiddleware::class, App\Middleware\AdminMiddleware::class]);
$app->router->post('/admin/stories/verify-proof', [App\Controllers\Admin\StoryController::class, 'verifyProof'], [App\Middleware\AuthMiddleware::class, App\Middleware\AdminMiddleware::class]);

// ========================================
// محتوا و استعداد - پنل کاربر
// ========================================
$app->router->get('/user/content', [\App\Controllers\User\ContentController::class, 'index'], [\App\Middleware\AuthMiddleware::class]);
$app->router->get('/user/content/create', [\App\Controllers\User\ContentController::class, 'create'], [\App\Middleware\AuthMiddleware::class]);
$app->router->post('/user/content/store', [\App\Controllers\User\ContentController::class, 'store'], [\App\Middleware\AuthMiddleware::class]);
$app->router->get('/user/content/{id}', [\App\Controllers\User\ContentController::class, 'show'], [\App\Middleware\AuthMiddleware::class]);
$app->router->get('/user/content/revenues', [\App\Controllers\User\ContentController::class, 'revenues'], [\App\Middleware\AuthMiddleware::class]);

// ========================================
// محتوا و استعداد - پنل ادمین
// ========================================
$app->router->get('/admin/content', [\App\Controllers\Admin\ContentController::class, 'index'], [\App\Middleware\AuthMiddleware::class, \App\Middleware\AdminMiddleware::class]);
$app->router->get('/admin/content/{id}', [\App\Controllers\Admin\ContentController::class, 'show'], [\App\Middleware\AuthMiddleware::class, \App\Middleware\AdminMiddleware::class]);
$app->router->post('/admin/content/{id}/approve', [\App\Controllers\Admin\ContentController::class, 'approve'], [\App\Middleware\AuthMiddleware::class, \App\Middleware\AdminMiddleware::class]);
$app->router->post('/admin/content/{id}/reject', [\App\Controllers\Admin\ContentController::class, 'reject'], [\App\Middleware\AuthMiddleware::class, \App\Middleware\AdminMiddleware::class]);
$app->router->post('/admin/content/{id}/publish', [\App\Controllers\Admin\ContentController::class, 'publish'], [\App\Middleware\AuthMiddleware::class, \App\Middleware\AdminMiddleware::class]);
$app->router->post('/admin/content/{id}/suspend', [\App\Controllers\Admin\ContentController::class, 'suspend'], [\App\Middleware\AuthMiddleware::class, \App\Middleware\AdminMiddleware::class]);

// درآمد محتوا - ادمین
$app->router->get('/admin/content/{id}/revenue/create', [\App\Controllers\Admin\ContentController::class, 'revenueCreate'], [\App\Middleware\AuthMiddleware::class, \App\Middleware\AdminMiddleware::class]);
$app->router->post('/admin/content/{id}/revenue/store', [\App\Controllers\Admin\ContentController::class, 'revenueStore'], [\App\Middleware\AuthMiddleware::class, \App\Middleware\AdminMiddleware::class]);
$app->router->post('/admin/content/revenue/{revenue_id}/approve', [\App\Controllers\Admin\ContentController::class, 'revenueApprove'], [\App\Middleware\AuthMiddleware::class, \App\Middleware\AdminMiddleware::class]);
$app->router->post('/admin/content/revenue/{revenue_id}/pay', [\App\Controllers\Admin\ContentController::class, 'revenuePay'], [\App\Middleware\AuthMiddleware::class, \App\Middleware\AdminMiddleware::class]);
$app->router->get('/admin/content/revenues', [\App\Controllers\Admin\ContentController::class, 'revenues'], [\App\Middleware\AuthMiddleware::class, \App\Middleware\AdminMiddleware::class]);

// ========================================
// سرمایه‌گذاری - پنل کاربر
// ========================================
$app->router->get('/user/investment', [\App\Controllers\User\InvestmentController::class, 'index'], [\App\Middleware\AuthMiddleware::class]);
$app->router->get('/user/investment/create', [\App\Controllers\User\InvestmentController::class, 'create'], [\App\Middleware\AuthMiddleware::class]);
$app->router->post('/user/investment/store', [\App\Controllers\User\InvestmentController::class, 'store'], [\App\Middleware\AuthMiddleware::class]);
$app->router->post('/user/investment/withdraw', [\App\Controllers\User\InvestmentController::class, 'withdraw'], [\App\Middleware\AuthMiddleware::class]);
$app->router->get('/user/investment/profit-history', [\App\Controllers\User\InvestmentController::class, 'profitHistory'], [\App\Middleware\AuthMiddleware::class]);

// ========================================
// سرمایه‌گذاری - پنل ادمین
// ========================================
$app->router->get('/admin/investment', [\App\Controllers\Admin\InvestmentController::class, 'index'], [\App\Middleware\AuthMiddleware::class, \App\Middleware\AdminMiddleware::class]);
$app->router->get('/admin/investment/{id}', [\App\Controllers\Admin\InvestmentController::class, 'show'], [\App\Middleware\AuthMiddleware::class, \App\Middleware\AdminMiddleware::class]);
$app->router->post('/admin/investment/{id}/suspend', [\App\Controllers\Admin\InvestmentController::class, 'suspend'], [\App\Middleware\AuthMiddleware::class, \App\Middleware\AdminMiddleware::class]);

// تریدها
$app->router->get('/admin/investment/trades', [\App\Controllers\Admin\InvestmentController::class, 'trades'], [\App\Middleware\AuthMiddleware::class, \App\Middleware\AdminMiddleware::class]);
$app->router->get('/admin/investment/trades/create', [\App\Controllers\Admin\InvestmentController::class, 'tradeCreate'], [\App\Middleware\AuthMiddleware::class, \App\Middleware\AdminMiddleware::class]);
$app->router->post('/admin/investment/trades/store', [\App\Controllers\Admin\InvestmentController::class, 'tradeStore'], [\App\Middleware\AuthMiddleware::class, \App\Middleware\AdminMiddleware::class]);
$app->router->post('/admin/investment/trades/{id}/close', [\App\Controllers\Admin\InvestmentController::class, 'tradeClose'], [\App\Middleware\AuthMiddleware::class, \App\Middleware\AdminMiddleware::class]);

// اعمال سود/ضرر
$app->router->get('/admin/investment/apply-profit', [\App\Controllers\Admin\InvestmentController::class, 'applyProfitForm'], [\App\Middleware\AuthMiddleware::class, \App\Middleware\AdminMiddleware::class]);
$app->router->post('/admin/investment/apply-profit', [\App\Controllers\Admin\InvestmentController::class, 'applyProfit'], [\App\Middleware\AuthMiddleware::class, \App\Middleware\AdminMiddleware::class]);

// برداشت‌ها
$app->router->get('/admin/investment/withdrawals', [\App\Controllers\Admin\InvestmentController::class, 'withdrawals'], [\App\Middleware\AuthMiddleware::class, \App\Middleware\AdminMiddleware::class]);
$app->router->post('/admin/investment/withdrawals/{id}/approve', [\App\Controllers\Admin\InvestmentController::class, 'withdrawalApprove'], [\App\Middleware\AuthMiddleware::class, \App\Middleware\AdminMiddleware::class]);
$app->router->post('/admin/investment/withdrawals/{id}/reject', [\App\Controllers\Admin\InvestmentController::class, 'withdrawalReject'], [\App\Middleware\AuthMiddleware::class, \App\Middleware\AdminMiddleware::class]);


// ========================================
// قرعه‌کشی - پنل کاربر
// ========================================
$app->router->get('/user/lottery', [\App\Controllers\User\LotteryController::class, 'index'], [\App\Middleware\AuthMiddleware::class]);
$app->router->post('/user/lottery/join', [\App\Controllers\User\LotteryController::class, 'join'], [\App\Middleware\AuthMiddleware::class]);
$app->router->post('/user/lottery/vote', [\App\Controllers\User\LotteryController::class, 'vote'], [\App\Middleware\AuthMiddleware::class]);

// ========================================
// قرعه‌کشی - پنل ادمین
// ========================================
$app->router->get('/admin/lottery', [\App\Controllers\Admin\LotteryController::class, 'index'], [\App\Middleware\AuthMiddleware::class, \App\Middleware\AdminMiddleware::class]);
$app->router->get('/admin/lottery/create', [\App\Controllers\Admin\LotteryController::class, 'create'], [\App\Middleware\AuthMiddleware::class, \App\Middleware\AdminMiddleware::class]);
$app->router->post('/admin/lottery/store', [\App\Controllers\Admin\LotteryController::class, 'store'], [\App\Middleware\AuthMiddleware::class, \App\Middleware\AdminMiddleware::class]);
$app->router->get('/admin/lottery/{id}', [\App\Controllers\Admin\LotteryController::class, 'show'], [\App\Middleware\AuthMiddleware::class, \App\Middleware\AdminMiddleware::class]);
$app->router->post('/admin/lottery/{id}/generate-numbers', [\App\Controllers\Admin\LotteryController::class, 'generateNumbers'], [\App\Middleware\AuthMiddleware::class, \App\Middleware\AdminMiddleware::class]);
$app->router->post('/admin/lottery/daily/{daily_id}/finalize', [\App\Controllers\Admin\LotteryController::class, 'finalizeDaily'], [\App\Middleware\AuthMiddleware::class, \App\Middleware\AdminMiddleware::class]);
$app->router->post('/admin/lottery/{id}/select-winner', [\App\Controllers\Admin\LotteryController::class, 'selectWinner'], [\App\Middleware\AuthMiddleware::class, \App\Middleware\AdminMiddleware::class]);
$app->router->post('/admin/lottery/{id}/cancel', [\App\Controllers\Admin\LotteryController::class, 'cancel'], [\App\Middleware\AuthMiddleware::class, \App\Middleware\AdminMiddleware::class]);

// ===== PHASE 15: Banner & Ads Management =====

// --- بنر عمومی (بدون auth) ---
$app->router->get('/banner/click/{id}', [\App\Controllers\BannerController::class, 'click']);

// --- پنل ادمین: مدیریت بنرها ---
$app->router->get('/admin/banners', [\App\Controllers\Admin\BannerController::class, 'index'], [\App\Middleware\AuthMiddleware::class, \App\Middleware\AdminMiddleware::class]);
$app->router->get('/admin/banners/create', [\App\Controllers\Admin\BannerController::class, 'showCreate'], [\App\Middleware\AuthMiddleware::class, \App\Middleware\AdminMiddleware::class]);
$app->router->post('/admin/banners/store', [\App\Controllers\Admin\BannerController::class, 'store'], [\App\Middleware\AuthMiddleware::class, \App\Middleware\AdminMiddleware::class]);
$app->router->get('/admin/banners/{id}/edit', [\App\Controllers\Admin\BannerController::class, 'showEdit'], [\App\Middleware\AuthMiddleware::class, \App\Middleware\AdminMiddleware::class]);
$app->router->post('/admin/banners/{id}/update', [\App\Controllers\Admin\BannerController::class, 'update'], [\App\Middleware\AuthMiddleware::class, \App\Middleware\AdminMiddleware::class]);
$app->router->post('/admin/banners/{id}/delete', [\App\Controllers\Admin\BannerController::class, 'delete'], [\App\Middleware\AuthMiddleware::class, \App\Middleware\AdminMiddleware::class]);
$app->router->post('/admin/banners/{id}/toggle', [\App\Controllers\Admin\BannerController::class, 'toggle'], [\App\Middleware\AuthMiddleware::class, \App\Middleware\AdminMiddleware::class]);
$app->router->get('/admin/banners/{id}/stats', [\App\Controllers\Admin\BannerController::class, 'stats'], [\App\Middleware\AuthMiddleware::class, \App\Middleware\AdminMiddleware::class]);

// --- پنل ادمین: مدیریت جایگاه‌ها ---
$app->router->get('/admin/banners/placements', [\App\Controllers\Admin\BannerController::class, 'placements'], [\App\Middleware\AuthMiddleware::class, \App\Middleware\AdminMiddleware::class]);
$app->router->post('/admin/banners/placements/{id}/update', [\App\Controllers\Admin\BannerController::class, 'updatePlacement'], [\App\Middleware\AuthMiddleware::class, \App\Middleware\AdminMiddleware::class]);
$app->router->post('/admin/banners/placements/{id}/toggle', [\App\Controllers\Admin\BannerController::class, 'togglePlacement'], [\App\Middleware\AuthMiddleware::class, \App\Middleware\AdminMiddleware::class]);

// ===== PHASE 18: Bug Report System =====

// --- کاربر ---
$app->router->post('/user/bug-reports/store', [\App\Controllers\User\BugReportController::class, 'store'], [\App\Middleware\AuthMiddleware::class]);
$app->router->get('/user/bug-reports', [\App\Controllers\User\BugReportController::class, 'index'], [\App\Middleware\AuthMiddleware::class]);
$app->router->get('/user/bug-reports/{id}', [\App\Controllers\User\BugReportController::class, 'show'], [\App\Middleware\AuthMiddleware::class]);
$app->router->post('/user/bug-reports/{id}/comment', [\App\Controllers\User\BugReportController::class, 'addComment'], [\App\Middleware\AuthMiddleware::class]);

// --- ادمین ---
$app->router->get('/admin/bug-reports', [\App\Controllers\Admin\BugReportController::class, 'index'], [\App\Middleware\AuthMiddleware::class, \App\Middleware\AdminMiddleware::class]);
$app->router->get('/admin/bug-reports/{id}', [\App\Controllers\Admin\BugReportController::class, 'show'], [\App\Middleware\AuthMiddleware::class, \App\Middleware\AdminMiddleware::class]);
$app->router->post('/admin/bug-reports/{id}/status', [\App\Controllers\Admin\BugReportController::class, 'updateStatus'], [\App\Middleware\AuthMiddleware::class, \App\Middleware\AdminMiddleware::class]);
$app->router->post('/admin/bug-reports/{id}/priority', [\App\Controllers\Admin\BugReportController::class, 'updatePriority'], [\App\Middleware\AuthMiddleware::class, \App\Middleware\AdminMiddleware::class]);
$app->router->post('/admin/bug-reports/{id}/comment', [\App\Controllers\Admin\BugReportController::class, 'addComment'], [\App\Middleware\AuthMiddleware::class, \App\Middleware\AdminMiddleware::class]);
$app->router->post('/admin/bug-reports/{id}/suspicious', [\App\Controllers\Admin\BugReportController::class, 'toggleSuspicious'], [\App\Middleware\AuthMiddleware::class, \App\Middleware\AdminMiddleware::class]);
$app->router->post('/admin/bug-reports/{id}/delete', [\App\Controllers\Admin\BugReportController::class, 'delete'], [\App\Middleware\AuthMiddleware::class, \App\Middleware\AdminMiddleware::class]);

// ===== PHASE 19: KPI & Analytics =====
$app->router->get('/admin/kpi', [\App\Controllers\Admin\KpiController::class, 'index'], [\App\Middleware\AuthMiddleware::class, \App\Middleware\AdminMiddleware::class]);
$app->router->get('/admin/kpi/financial', [\App\Controllers\Admin\KpiController::class, 'financial'], [\App\Middleware\AuthMiddleware::class, \App\Middleware\AdminMiddleware::class]);
$app->router->get('/admin/kpi/users', [\App\Controllers\Admin\KpiController::class, 'users'], [\App\Middleware\AuthMiddleware::class, \App\Middleware\AdminMiddleware::class]);
$app->router->get('/admin/kpi/chart-data', [\App\Controllers\Admin\KpiController::class, 'chartData'], [\App\Middleware\AuthMiddleware::class, \App\Middleware\AdminMiddleware::class]);
$app->router->get('/admin/kpi/export/users', [\App\Controllers\Admin\KpiController::class, 'exportUsers'], [\App\Middleware\AuthMiddleware::class, \App\Middleware\AdminMiddleware::class]);
$app->router->get('/admin/kpi/export/transactions', [\App\Controllers\Admin\KpiController::class, 'exportTransactions'], [\App\Middleware\AuthMiddleware::class, \App\Middleware\AdminMiddleware::class]);
$app->router->get('/admin/kpi/export/summary', [\App\Controllers\Admin\KpiController::class, 'exportSummary'], [\App\Middleware\AuthMiddleware::class, \App\Middleware\AdminMiddleware::class]);

$app->router->post('/captcha/behavioral/ping', [CaptchaController::class, 'behavioralPing']);
$app->router->get('/captcha/behavioral/ping', [CaptchaController::class, 'behavioralPing']);

// ==========================================
//  REST API v1
// ==========================================
// مستندات: /api/v1/docs
// احراز هویت: Authorization: Bearer <token>



// --- Auth (بدون نیاز به token) ---
$app->router->post('/api/v1/auth/token',  [TokenController::class, 'issue']);

// --- Auth (با token) ---
$app->router->post('/api/v1/auth/revoke',           [TokenController::class, 'revoke'],      [ApiAuthMiddleware::class]);
$app->router->get('/api/v1/auth/tokens',             [TokenController::class, 'list'],        [ApiAuthMiddleware::class]);
$app->router->post('/api/v1/auth/tokens/{id}/revoke',[TokenController::class, 'revokeById'], [ApiAuthMiddleware::class]);

// --- User ---
$app->router->get('/api/v1/user/profile',                [UserController::class, 'profile'],       [ApiAuthMiddleware::class]);
$app->router->get('/api/v1/user/notifications',          [UserController::class, 'notifications'], [ApiAuthMiddleware::class]);
$app->router->post('/api/v1/user/notifications/read',    [UserController::class, 'markRead'],      [ApiAuthMiddleware::class]);

// --- Wallet ---
$app->router->get('/api/v1/wallet',             [WalletController::class, 'balance'],      [ApiAuthMiddleware::class]);
$app->router->get('/api/v1/wallet/transactions',[WalletController::class, 'transactions'], [ApiAuthMiddleware::class]);


// ==========================================
//  مدیریت سیستم (Admin)
// ==========================================

// --- Cron ---
$app->router->get('/admin/cron',     [CronController::class, 'index'], [AuthMiddleware::class, AdminMiddleware::class]);
$app->router->post('/admin/cron/run',[CronController::class, 'run'],   [AuthMiddleware::class, AdminMiddleware::class]);

// --- Email Queue ---
$app->router->get('/admin/email-queue',              [EmailQueueController::class, 'index'],       [AuthMiddleware::class, AdminMiddleware::class]);
$app->router->post('/admin/email-queue/process',     [EmailQueueController::class, 'process'],     [AuthMiddleware::class, AdminMiddleware::class]);
$app->router->post('/admin/email-queue/retry-failed',[EmailQueueController::class, 'retryFailed'],[AuthMiddleware::class, AdminMiddleware::class]);
$app->router->post('/admin/email-queue/{id}/retry',  [EmailQueueController::class, 'retry'],      [AuthMiddleware::class, AdminMiddleware::class]);

// --- API Tokens (Admin) ---
$app->router->get('/admin/api-tokens',                   [ApiTokenAdminController::class, 'index'],         [AuthMiddleware::class, AdminMiddleware::class]);
$app->router->post('/admin/api-tokens/{id}/revoke',      [ApiTokenAdminController::class, 'revoke'],        [AuthMiddleware::class, AdminMiddleware::class]);
$app->router->post('/admin/api-tokens/revoke-expired',   [ApiTokenAdminController::class, 'revokeExpired'],[AuthMiddleware::class, AdminMiddleware::class]);

// --- Cache ---
$app->router->get('/admin/cache',           [CacheAdminController::class, 'index'],  [AuthMiddleware::class, AdminMiddleware::class]);
$app->router->post('/admin/cache/clear',    [CacheAdminController::class, 'clear'],  [AuthMiddleware::class, AdminMiddleware::class]);
$app->router->post('/admin/cache/forget',   [CacheAdminController::class, 'forget'], [AuthMiddleware::class, AdminMiddleware::class]);

// ==========================================
//  API Tokens (User)
// ==========================================

$app->router->get('/user/api-tokens',               [ApiTokenController::class, 'index'],  [AuthMiddleware::class]);
$app->router->post('/user/api-tokens/create',       [ApiTokenController::class, 'create'], [AuthMiddleware::class]);
$app->router->post('/user/api-tokens/{id}/revoke',  [ApiTokenController::class, 'revoke'], [AuthMiddleware::class]);


// ==========================================
//  Advertiser Panel (User)
// ==========================================

$app->router->get('/advertiser',                          [AdvertiserController::class, 'index'],     [AuthMiddleware::class]);
$app->router->get('/advertiser/campaigns',                [AdvertiserController::class, 'campaigns'], [AuthMiddleware::class]);
$app->router->get('/advertiser/analytics',                [AdvertiserController::class, 'analytics'], [AuthMiddleware::class]);
$app->router->get('/advertiser/reviews',                  [AdvertiserController::class, 'reviews'],   [AuthMiddleware::class]);
$app->router->post('/advertiser/reviews/{id}/approve',    [AdvertiserController::class, 'approve'],   [AuthMiddleware::class]);
$app->router->post('/advertiser/reviews/{id}/reject',     [AdvertiserController::class, 'reject'],    [AuthMiddleware::class]);
$app->router->get('/advertiser/chart-data',               [AdvertiserController::class, 'chartData'], [AuthMiddleware::class]);

// ==========================================
//  Global Search
// ==========================================


$app->router->get('/search',                  [SearchController::class, 'fullResults'], [AuthMiddleware::class]);
$app->router->get('/search/ajax',             [SearchController::class, 'userSearch'],  [AuthMiddleware::class]);
$app->router->get('/admin/search',            [SearchController::class, 'adminSearch'], [AuthMiddleware::class, AdminMiddleware::class]);

// ==========================================
//  Audit Trail (Admin)
// ==========================================


$app->router->get('/admin/audit-trail', [AuditTrailController::class, 'index'], [AuthMiddleware::class, AdminMiddleware::class]);

// ==========================================
//  Export (Admin) - مسیرهای اضافی
// ==========================================


$app->router->get('/admin/export',              [AdminExportController::class, 'index'],        [AuthMiddleware::class, AdminMiddleware::class]);
$app->router->get('/admin/export/users',        [AdminExportController::class, 'users'],        [AuthMiddleware::class, AdminMiddleware::class]);
$app->router->get('/admin/export/transactions', [AdminExportController::class, 'transactions'], [AuthMiddleware::class, AdminMiddleware::class]);
$app->router->get('/admin/export/withdrawals',  [AdminExportController::class, 'withdrawals'],  [AuthMiddleware::class, AdminMiddleware::class]);
$app->router->get('/admin/export/audit-trail',  [AdminExportController::class, 'auditTrail'],   [AuthMiddleware::class, AdminMiddleware::class]);

// Audit Trail - export
$app->router->get('/admin/audit-trail/export', [AuditTrailController::class, 'export'], [AuthMiddleware::class, AdminMiddleware::class]);

// Withdrawal limits info (AJAX)

$app->router->get('/user/withdrawal/limits', [WithdrawalController::class, 'limitsInfo'], [AuthMiddleware::class]);
