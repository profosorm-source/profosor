<?php
ini_set('display_errors', '1');
ini_set('display_startup_errors', '1');
error_reporting(E_ALL);

/**
 * چرتکه (Chortke) - Entry Point
 * 
 * تمامی درخواست‌ها از اینجا شروع می‌شوند
 */

// --------------------
// Base Path
// --------------------
define('BASE_PATH', dirname(__DIR__));

// --------------------
// Output Buffering
// --------------------
ob_start();
ob_implicit_flush(false); // ✅ غیرفعال کردن Auto Flush

// --------------------
// Timezone
// --------------------
date_default_timezone_set('Asia/Tehran');

// --------------------
// Load Environment
// --------------------
$envPath = BASE_PATH . '/.env';

if (file_exists($envPath)) {
    $env = parse_ini_file($envPath, false, INI_SCANNER_RAW);

    if ($env === false) {
        die('.env file is invalid');
    }

    $appDebug = filter_var($env['APP_DEBUG'] ?? false, FILTER_VALIDATE_BOOLEAN);

    if ($appDebug) {
        error_reporting(E_ALL);
        ini_set('display_errors', '1');
    } else {
        error_reporting(0);
        ini_set('display_errors', '0');
    }
}

// --------------------
// Security Headers
// --------------------

header('X-Frame-Options: SAMEORIGIN');
header('X-Content-Type-Options: nosniff');
header('X-XSS-Protection: 1; mode=block');
header('Referrer-Policy: strict-origin-when-cross-origin');
header('Permissions-Policy: geolocation=(), microphone=(), camera=()');
header(
    "Content-Security-Policy: " .
    "default-src 'self'; " .
    "base-uri 'self'; " .
    "form-action 'self'; " .
    "frame-ancestors 'self'; " .

    // Scripts (CDN + reCAPTCHA)
    "script-src 'self' 'unsafe-inline' 'unsafe-eval' " .
        "https://cdn.jsdelivr.net https://code.jquery.com " .
        "https://www.google.com https://www.gstatic.com; " .

    // Styles
    "style-src 'self' 'unsafe-inline' https://fonts.googleapis.com https://cdn.jsdelivr.net; " .

    // Fonts
    "font-src 'self' https://fonts.gstatic.com; " .

    // Images (اجازه برای google/gstatic هم بهتر است باشد)
    "img-src 'self' data: https: https://www.google.com https://www.gstatic.com; " .

    // XHR/Fetch (برای برخی سناریوهای reCAPTCHA ممکن است لازم شود)
    "connect-src 'self' https://www.google.com https://www.gstatic.com; " .

    // ✅ لازم برای iframe های reCAPTCHA
    "frame-src 'self' https://www.google.com https://www.gstatic.com; "
);

// --------------------
// Autoloader
// --------------------
require_once BASE_PATH . '/core/Autoloader.php';
\Core\Autoloader::register();

// در ابتدای فایل بعد از autoload
$uploadPath = __DIR__ . '/../storage/uploads/kyc/';
if (!is_dir($uploadPath)) {
    mkdir($uploadPath, 0755, true);
}

// --------------------
// Helpers
// --------------------
require_once BASE_PATH . '/helpers/functions.php';
// --------------------

// ------------------

// ✅ اینجا
\Core\Session::getInstance()->start();

// =======================
// Maintenance Mode (Global)
// =======================
try {
    // اولویت با DB (اگر از پنل مدیریت کنترلش می‌کنی)
    // اگر کلید در DB نداری، از env استفاده می‌کند
    $maintenanceEnabledRaw = setting('maintenance_enabled', env('MAINTENANCE_MODE', '0'));
    $maintenanceEnabledRaw = \strtolower(\trim((string)$maintenanceEnabledRaw));
    $maintenanceEnabled = \in_array($maintenanceEnabledRaw, ['1', 'true', 'on', 'yes'], true);

    if ($maintenanceEnabled) {
        $uriPath = \parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH) ?: '/';

        // دسترسی مدیر
        $isAdmin = \function_exists('is_admin') && is_admin();

        // اجازه به پنل ادمین (برای اینکه مدیر بتواند وارد شود)
        $isAdminPath = \str_starts_with($uriPath, '/admin');

        if (!($isAdmin || $isAdminPath)) {
            $message = setting(
                'maintenance_message',
                env('MAINTENANCE_MESSAGE', 'سایت در حال تعمیر است. لطفاً بعداً مراجعه کنید.')
            );

            \http_response_code(503);
            \header('Content-Type: text/html; charset=utf-8');
            \header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
            \header('Pragma: no-cache');
            \header('Retry-After: 600');

            echo view('errors.503', [
                'message' => (string)$message
            ]);
            exit;
        }
    }
} catch (\Throwable $e) {
    // Fail-safe: اگر settings/env مشکل داشت سایت نخوابد
}
// --------------------
// Exception Handler
// --------------------
\Core\ExceptionHandler::register();

// --------------------
// Initialize Application
// --------------------
$app = \Core\Application::getInstance();

// --------------------
// Load Routes
// --------------------
require_once BASE_PATH . '/routes/routes.php';

// --------------------
// Run Application
// --------------------
$app->run();

// --------------------
// Flush Output Buffer
// --------------------
ob_end_flush();
