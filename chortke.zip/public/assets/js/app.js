// ==================== DROPDOWN SYSTEM ====================
(function() {
    'use strict';
    
    function closeAllDropdowns() {
        document.querySelectorAll('[data-dd-menu].is-open').forEach(menu => {
            menu.classList.remove('is-open');
            menu.style.transform = 'translateX(0px)';
        });
    }
    
    function openDropdown(toggleEl, key) {
        const menu = document.querySelector(`[data-dd-menu="${key}"]`);
        if (!menu) return;
        
        const rect = toggleEl.getBoundingClientRect();
        const top = rect.bottom + 10;
        const right = window.innerWidth - rect.right;
        
        menu.style.top = top + 'px';
        menu.style.right = right + 'px';
        menu.style.left = 'auto';
        menu.style.transform = 'translateX(0px)';
        menu.classList.add('is-open');
        
        const pad = 12;
        let menuRect = menu.getBoundingClientRect();
        
        if (menuRect.left < pad) {
            menu.style.transform = `translateX(${pad - menuRect.left}px)`;
            menuRect = menu.getBoundingClientRect();
        }
        
        if (menuRect.right > (window.innerWidth - pad)) {
            menu.style.transform = `translateX(${(window.innerWidth - pad) - menuRect.right}px)`;
        }
    }
    
    document.addEventListener('click', function(e) {
        const toggle = e.target.closest('[data-dd-toggle]');
        const insideMenu = e.target.closest('[data-dd-menu]');
        
        if (insideMenu && !toggle) return;
        
        if (toggle) {
            const key = toggle.getAttribute('data-dd-toggle');
            const menu = document.querySelector(`[data-dd-menu="${key}"]`);
            const wasOpen = menu && menu.classList.contains('is-open');
            
            closeAllDropdowns();
            if (!wasOpen) openDropdown(toggle, key);
            return;
        }
        
        closeAllDropdowns();
    });
    
    window.addEventListener('resize', closeAllDropdowns);
    document.addEventListener('keydown', e => {
        if (e.key === 'Escape') closeAllDropdowns();
    });
})();


// ==================== SIDEBAR MENU SYSTEM ====================
document.addEventListener('DOMContentLoaded', function() {
    'use strict';
    
    const sidebar = document.getElementById('mainSidebar');
    const overlay = document.getElementById('sidebarOverlay');
    const toggleBtn = document.getElementById('sidebarToggle');
    const closeBtn = document.getElementById('sidebarCloseBtn');
    const menuLinks = document.querySelectorAll('[data-toggle="submenu"]');
    
    function isMobile() {
        return window.matchMedia('(max-width: 768px)').matches;
    }
    
    function openSidebar() {
        if (!sidebar) return;
        sidebar.classList.add('is-open');
        if (overlay) overlay.classList.add('is-open');
        document.body.style.overflow = 'hidden';
    }
    
    function closeSidebar() {
        if (!sidebar) return;
        sidebar.classList.remove('is-open');
        if (overlay) overlay.classList.remove('is-open');
        document.body.style.overflow = '';
    }
    
    function toggleSidebar() {
        if (!sidebar) return;
        sidebar.classList.contains('is-open') ? closeSidebar() : openSidebar();
    }
    
    // ===== Toggle Button =====
    if (toggleBtn) {
        toggleBtn.addEventListener('click', function() {
            if (isMobile()) toggleSidebar();
        });
    }
    
    // ===== Close Button =====
    if (closeBtn) {
        closeBtn.addEventListener('click', closeSidebar);
    }
    
    // ===== Overlay Click =====
    if (overlay) {
        overlay.addEventListener('click', closeSidebar);
    }
    
    // ===== ESC Key =====
    document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape' && isMobile()) {
            closeSidebar();
        }
    });
    
    // ===== Resize =====
    window.addEventListener('resize', function() {
        if (!isMobile()) {
            closeSidebar();
        }
    });
    
    // ==================== SUBMENU TOGGLE ====================
    menuLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            
            if (this.getAttribute('href') === '#') {
                e.preventDefault();
            }
            
            const parentItem = this.closest('.menu-item');
            if (!parentItem) return;
            
            const isOpen = parentItem.classList.contains('is-open');
            
            document.querySelectorAll('.menu-item.is-open').forEach(item => {
                if (item !== parentItem) {
                    item.classList.remove('is-open');
                }
            });
            
            parentItem.classList.toggle('is-open', !isOpen);
            
            saveMenuState();
        });
    });
    
    // ==================== SAVE MENU STATE ====================
    function saveMenuState() {
        const openMenus = [];
        
        document.querySelectorAll('.menu-item.is-open').forEach(item => {
            const menuId = item.querySelector('[data-menu-id]')?.getAttribute('data-menu-id');
            if (menuId) openMenus.push(menuId);
        });
        
        localStorage.setItem('sidebar_open_menus', JSON.stringify(openMenus));
    }
    
    function loadMenuState() {
        const savedState = localStorage.getItem('sidebar_open_menus');
        
        if (!savedState) return;
        
        try {
            const openMenus = JSON.parse(savedState);
            
            openMenus.forEach(menuId => {
                const menuItem = document
                    .querySelector(`[data-menu-id="${menuId}"]`)
                    ?.closest('.menu-item');
                
                if (menuItem) {
                    menuItem.classList.add('is-open');
                }
            });
        } catch(e) {
            console.error('Error loading menu state:', e);
        }
    }
    
    loadMenuState();
    
    // ==================== SCROLL SHADOW ====================
    if (sidebar) {
        sidebar.addEventListener('scroll', function() {
            this.classList.toggle('scrolled', this.scrollTop > 10);
        });
    }
});


// ==================== FORM VALIDATION CLEAR ====================
document.addEventListener('input', function(e) {
    if (e.target.classList.contains('is-invalid')) {
        e.target.classList.remove('is-invalid');
        const feedback = e.target.nextElementSibling;
        if (feedback && feedback.classList.contains('invalid-feedback')) {
            feedback.textContent = '';
        }
    }
});


// ==================== AJAX FORM HANDLER ====================
function handleAjaxForm(formElement, successCallback) {
    formElement.addEventListener('submit', async function(e) {
        e.preventDefault();
        
        const formData = new FormData(this);
        const submitBtn = this.querySelector('button[type="submit"]');
        const originalText = submitBtn ? submitBtn.innerHTML : '';
        
        if (submitBtn) {
            submitBtn.disabled = true;
            submitBtn.innerHTML = '<span class="spinner-border spinner-border-sm"></span> در حال ارسال...';
        }
        
        try {
            const response = await fetch(this.action, {
                method: this.method,
                body: formData
            });
            
            const result = await response.json();
            
            if (result.success) {
                if (window.notyf) notyf.success(result.message);
                if (successCallback) successCallback(result);
            } else {
                if (window.notyf) notyf.error(result.message || 'خطایی رخ داده است');
                
                if (result.errors) {
                    Object.keys(result.errors).forEach(field => {
                        const input = formElement.querySelector(`[name="${field}"]`);
                        if (input) {
                            input.classList.add('is-invalid');
                            const feedback = input.nextElementSibling;
                            if (feedback && feedback.classList.contains('invalid-feedback')) {
                                feedback.textContent = result.errors[field][0];
                            }
                        }
                    });
                }
            }
        } catch (error) {
            console.error(error);
            if (window.notyf) notyf.error('خطا در ارتباط با سرور');
        } finally {
            if (submitBtn) {
                submitBtn.disabled = false;
                submitBtn.innerHTML = originalText;
            }
        }
    });
}

document.addEventListener('DOMContentLoaded', function () {
  const toggles = document.querySelectorAll('[data-submenu-toggle]');

  function closeAllExcept(exceptionLi) {
    document.querySelectorAll('.sidebar-menu li.has-submenu.open').forEach(li => {
      if (li !== exceptionLi) li.classList.remove('open');
    });
  }

  toggles.forEach(a => {
    a.addEventListener('click', function (e) {
      e.preventDefault();

      const li = this.closest('li.has-submenu');
      if (!li) return;

      const isOpen = li.classList.contains('open');
      closeAllExcept(li);

      if (isOpen) li.classList.remove('open');
      else li.classList.add('open');
    });
  });
});
// ==================== UTILITIES ====================
function formatNumber(num) {
    return new Intl.NumberFormat('fa-IR').format(num);
}

function copyToClipboard(text) {
    navigator.clipboard.writeText(text).then(() => {
        if (window.notyf) notyf.success('کپی شد');
    });
}
